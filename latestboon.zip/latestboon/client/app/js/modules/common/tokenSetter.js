define([
    'angular'
], function(angular) {
    'use strict'

    return angular.module('app.common.token', [])
        .service('TokenService', function($window, $state) {
            var tokenSetter = {
                token: '',
                setToken: function(token) {
                    //Set the new token to session storage
                    tokenSetter.token = token
                    var tokenTemp = $window.sessionStorage.getItem('userInfo'),
                        tokenObj
                    if (tokenTemp != null) {
                        tokenObj = JSON.parse(tokenTemp)
                        if (tokenObj != null) {
                            if (tokenObj.hasOwnProperty('accessToken')) {
                                tokenObj.accessToken = token
                            }
                            $window.sessionStorage['userInfo'] = JSON.stringify(tokenObj)
                        }

                    }

                },
                getToken: function() {
                    //Get the token from session storage
                    var tokenTemp = $window.sessionStorage.getItem('userInfo'),
                        tokenObj
                    if (tokenTemp != null) {
                        tokenObj = JSON.parse(tokenTemp)
                        if (tokenObj != null) {
                            if (tokenObj.hasOwnProperty('accessToken')) {
                                tokenSetter.token = tokenObj.accessToken
                            }
                        }

                    }
                    return tokenSetter.token
                },
                logoutUser: function() {
                    //log out user if token is expired
                    $window.sessionStorage['userInfo'] = null
                    $state.go('login')
                },
                setResponseHeader: function(responseHeader) {
                    //check the response header for token expiry and refreshed token
                    if (responseHeader['refreshed-token']) {
                        tokenSetter.setToken(responseHeader['refreshed-token'])
                    } else if (responseHeader['token-expired']) {
                        tokenSetter.logoutUser()
                    }
                }
            }
            return tokenSetter
        })
})
