define(['./module'], function(module) {
    'use strict'
    module.directive('imageonload', function() {
        return {
            restrict: 'A',
            link: function(scope, element, attrs) {
                element.bind('load', function() {

                  scope.$apply(function() {
                      if( scope.checkModel.primary ) {
                          scope.drawShapeOnPrimary()
                      } else {
                          scope.drawShapeOnSecondary()
                      }

                  })
                })
                element.bind('error', function(){
                    alert('image could not be loaded')
                })
            }
        }
    })
})
