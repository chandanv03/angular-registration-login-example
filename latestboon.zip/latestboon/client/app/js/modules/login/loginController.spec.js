/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */

define([
  'angular-mocks',
  'Source/modules/login/loginController',
  'Source/modules/login/authService'
], function () {
    describe('editdoorController', function(){

      var scope, createController, q;

      beforeEach(angular.mock.module('app.login'));

      
      var mockAuthService;

      beforeEach(module(function($provide) {
        mockAuthService = {
          login: function() {}
        };
        $provide.value('Auth', mockAuthService);
      }));      

      beforeEach(angular.mock.inject(function ($rootScope, $controller, $q) {
               scope = $rootScope.$new();
               createController = function() {
                  return $controller('LoginController', {
                    '$scope': scope,
                    'Auth' : mockAuthService
                  });
               };
               deferred = $q.defer();
               q= $q
               spyOn(mockAuthService, 'login').and.returnValue(deferred.promise);
      }));

    describe('LoginController', function() {

     it('should test if controller is initiated with scope', function(){
          createController();
          expect(scope.title).toEqual('Login Page');
     })

     it('should test if authenticate is called', function(){
          scope.login = {}
          scope.login.$valid = true
          createController();
          expect(scope.authenticate).toBeDefined();
     })    


      it('should test if promise is rejected with message property defined', function() {
          scope.login = {}
          scope.login.$valid = true
          createController();
          scope.authenticate()
          var result = {};
          result.message = {}
          result.message = 'test'
          expect(scope.invalid).not.toBeDefined()
          deferred.reject(result)
          expect(scope.invalid).not.toBeDefined()
          scope.$digest();
          expect(scope.invalid).toBeDefined()
          expect(scope.invalid).toBe(true)
          expect(scope.message).toEqual('test')
      });     


      it('should test if promise is rejected without message', function() {
          scope.login = {}
          scope.login.$valid = true
          createController();
          scope.authenticate()
          var result = {};
          expect(scope.invalid).not.toBeDefined()
          deferred.reject(result)
          expect(scope.invalid).not.toBeDefined()
          scope.$digest();
          expect(scope.invalid).toBeDefined()
          expect(scope.invalid).toBe(true)
          expect(scope.message).toEqual('Invalid User Credentials.')
      });          


    });

      

    })
})