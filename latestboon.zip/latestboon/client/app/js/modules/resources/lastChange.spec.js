/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
 define([
  'angular-mocks',
  'Source/modules/resources/lastChange',
  'Source/modules/common/tokenSetter',
  'Source/config'
  ], function(){

   describe('lastChange', function () {
  	var mockMotorDrive, $httpBackend, url, token;

	  	beforeEach(angular.mock.module('app.resources.lastChange'));

	  	beforeEach(module('ui.router'));

	  	beforeEach(angular.mock.module('app.common.token'));

	  	beforeEach(angular.mock.module('app.constants', function ($provide) {
	    $provide.constant('CONFIG',{
	      url: 'http://localhost:3000/'
	    });


		}))

	  	var state;
	  	beforeEach(angular.mock.inject(function (LastChange, _$httpBackend_, CONFIG, $state, TokenService) {
	  		url = CONFIG.url;
	  		$httpBackend = _$httpBackend_;
	        mockLastChange = LastChange;
	        state = $state;
          token = TokenService.getToken();
		}))

	  	it('should test if resource is defined', function(){
	  		expect(mockLastChange).toBeDefined();
	  	})

	  	it('should test if resource is defined', function(){
	  		expect(mockLastChange.getLastChange).toBeDefined();
	  	})

      it('should test the URL', function(){
        $httpBackend.expect('GET', url + 'doors/lastchange').respond(200, {result:'success'});
        mockLastChange.getLastChange(token).get();
        $httpBackend.flush();
      })
   })

 })
