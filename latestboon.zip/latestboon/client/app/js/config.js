/**
 * Defines constants for application
 */
define(['angular'], function (angular) {
  return angular.module('app.constants', [])
    .constant('CONFIG', {
      //url: 'http://nlboed01.sgti.nl:3000/'
      url: 'https://localhost/api/',
      LONG_VISUAL_DELAY: 2000,
      SHORT_VISUAL_DELAY:1000,
      STEREOVISION_RECAPTURE_DELAY: 15000,
      STEREOVISION_CAPTURE_DELAY: 0,
      CHECK_LAST_CHANGE: 3000,
      CHART_DELAY: 0,
      DOOR_STATUS_NORMAL: 0,
      DOOR_STATUS_SNOOZE: 1,
      DOOR_STATUS_NOTIFICATION: 2,
      DOOR_STATUS_WARNING: 3,
      DOOR_STATUS_ALERT: 4,
      TIME_MILLIS: 60 * 1000,
      SNOOZE_TIME: 10
    })
})
