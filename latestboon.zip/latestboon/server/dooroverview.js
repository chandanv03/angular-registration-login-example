class Door {
  constructor () {
    this.id_ = null
    this.id = null
    this.name = null
    this.nodeid = null
    this.deviceID = null
    this.ip_number = null
    this.mac_address = null
    this.time_first_seen = null
    this.time_last_seen = null
    this.location = null
    this.product_type = null
    this.last_state = null
    this.ce_number = null
    this.hostname = null
    this.latitude = null
    this.longitude = null
    this.timeZone = null
    this.flag = null
    this.assigned = null
    this.doorstatus = null
    this.cause = null
    this.entranceName =null
  }

  populate (row) {
    this.id_ = row.id_
    this.id = row.id
    this.name = row.real_name
    this.nodeid = row.nodeid
    this.deviceID = row.deviceID
    this.ip_number = row.ip_number
    this.mac_address = row.mac_address
    this.time_first_seen = row.time_first_seen
    this.time_last_seen = row.time_last_seen
    this.location = row.location
    this.product_type = row.product_type
    this.last_state = row.last_state
    this.ce_number = row.ce_number
    this.hostname = row.hostname
    this.latitude = row.latitude
    this.longitude = row.longitude
    this.timeZone = row.timeZone
    this.flag = row.flag
    this.assigned = row.assigned
    this.doorstatus = row.doorStatus
    this.cause =row.cause
    this.entranceName=row.entranceName
  }

}

class Subentrance {
  constructor () {
    this.subentranceId = null
    this.subentranceName = null
    this.doors = []
  }
  populate (row) {
    this.subentranceId = row.subentranceId
    this.subentranceName = row.subentranceName
  }
}

class Entrance {
  constructor () {
    this.entranceId = null
    this.entranceName = null
    this.children = []
  }
  populate (row) {
    this.entranceId = row.entranceId
    this.entranceName = row.entranceName
  }
}

class Building {
  constructor () {
    this.buildingId = null
    this.buildingName = null
    this.children = []
  }
  populate (row) {
    this.buildingId = row.buildingId
    this.buildingName = row.buildingName
  }
}
class Campus {
  constructor () {
    this.campusId = null
    this.campusName = null
    this.children = []
  }
  populate (row) {
    this.campusId = row.campusId
    this.campusName = row.campusName
  }
}

module.exports =
  class Dooroverview {
    constructor () {
      this.campuses = []
      this.rejections = null
      this.transactions = null
    }

    populate (rows) {
      var i = 0
      var lastCampusId = null
      var lastBuildingId = null
      var lastEntranceId = null
      var lastSubEntranceId = null
      var campusId
      var buildingId
      var entranceId
      var subentranceId
      var doorId
      var building
      var entrance
      var subentrance
      var door
      var campus

      while (rows[i]){
        door = new Door()


        door.populate(rows[i])

        subentranceId = rows[i].subentranceId
        entranceId = rows[i].entranceId
        buildingId = rows[i].buildingId
        campusId = rows[i].campusId

        if ((subentranceId !== lastSubEntranceId)||(entranceId !== lastEntranceId) || (buildingId !== lastBuildingId) || (campusId !== lastCampusId)) {
          if (lastSubEntranceId !== null) {
            entrance['children'].push(subentrance)
          }
          lastSubEntranceId = subentranceId
          subentrance = new Subentrance()
          subentrance.populate(rows[i])
        }
        if (door.id){
        subentrance['doors'].push(door)
        }
        if ((entranceId !== lastEntranceId) || (buildingId !== lastBuildingId) || (campusId !== lastCampusId)) {
          if (lastEntranceId !== null) {
           building['children'].push(entrance)
          }
          lastEntranceId = entranceId
          entrance = new Entrance()
          entrance.populate(rows[i])

        }

        if ((buildingId !== lastBuildingId) ||(campusId !== lastCampusId)) {
          if (lastBuildingId !== null) {
            campus['children'].push(building)
          }
          lastBuildingId = buildingId
          building = new Building()
          building.populate(rows[i])
        }

        if (campusId !== lastCampusId) {
          if (lastCampusId !== null) {
            this.campuses.push(campus)
            }
          lastCampusId = campusId
          campus = new Campus()
          campus.populate(rows[i])
        }
        i++
      }
      //last row actions

      entrance['children'].push(subentrance)
      building['children'].push(entrance)
      campus['children'].push(building)
      this.campuses.push(campus) //push last campus

    }
    fillRejections(rejections) {
      this.rejections = rejections
    }

    fillTransactions(transactions) {
      this.transactions = transactions
    }
}
