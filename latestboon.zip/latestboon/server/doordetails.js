module.exports = 
  class Doordetails {
    constructor(){
      this.doorMain = null
      this.transactionTimes = null
      this.rejectionCount = null
      this.timeOfFlight = null
      this.plc = null
      this.motorDrive = null
      this.doorStatus = null
    }
  }

