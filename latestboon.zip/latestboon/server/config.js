// constants for db
var dns = require('dns')
var developmentDb = 'hugedb'//'userdb'//'testdb'
var connManagmentDb = 'connectorDatabase'
var dbUser = 'root'
var dbPasswd = ''
var ip = ''
var tokenSecret = 'boon edam token secret'
var saltLength = 10
var databaseIP = 'localhost'
var invalidAttempts = 3
var iPBlockingTime = 5
var tokenExpiryTime = '10m'
var timeMillis = 60 * 1000
var serverURL = 'http://localhost:9002/notification'
var doorStatus_Warning = 3
function findIp() { dns.lookup('onpremise', (err, addresses, family) => {
    if (err)
    {
      console.log ('cannot return Ip-address for onpremise host' )
    } else {
      console.log('addresses:', addresses)
  //    ip=addresses
      return addresses
    }
  })
}

// constants for server
var portNumber = 3010
var receivingPort = 4000

// whitelisting
var whitelist = [
  'https://localhost',
  'https://localhost:4000',
  'http://onpremise:4000',
  'http://NLBOED01.sgti.nl:4000',
  'http://10.76.70.5'
]
exports.tokenSecret = tokenSecret
exports.portNumber = portNumber
exports.connManagmentDb = connManagmentDb
exports.dbUser = dbUser
exports.dbPasswd = dbPasswd
exports.developmentDb = developmentDb
exports.whitelist = whitelist
exports.saltLength = saltLength
exports.databaseIP = databaseIP
exports.invalidAttempts = invalidAttempts
exports.iPBlockingTime = iPBlockingTime
exports.tokenExpiryTime = tokenExpiryTime
exports.serverURL = serverURL
exports.timeMillis = timeMillis
exports.doorStatus_Warning = doorStatus_Warning
