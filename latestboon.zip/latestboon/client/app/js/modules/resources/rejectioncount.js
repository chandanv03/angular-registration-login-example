define([
    'angular',
    'ngResource'
], function(angular) {
    'use strict'

    return angular.module('app.resources.rejectioncount', ['ngResource'])
        .service('RejectionCount', function($resource, CONFIG, TokenService) {
            return {
                getRejectionCount: function(token) {

                    return $resource(CONFIG.url + 'doors/rejectioncount?id=:id&type=:type', {
                        id: '@id',
                        type: '@type'
                    }, {
                        query: {
                            method: 'GET',
                            isArray: true,
                            headers: {
                                'x-access-token': token
                            },
                            transformResponse: function(data, headers) {
                                //Check the response header for token expiry and new token.
                                var headers = headers()
                                TokenService.setResponseHeader(headers)
                                return angular.fromJson(data)
                            }

                        }
                    })

                }
            }
        })
})
