/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */

 'use strict';

  define([
  'angular-mocks',
  'Source/modules/login/encodeService'
  ], function(){

  	describe('EncodeService', function () {
  		var q, mockEncodeService, state, deferred;

  		beforeEach(angular.mock.module('app.login'));

		beforeEach(angular.mock.inject(function(EncodeService){
	      mockEncodeService = EncodeService

		}))

		it('should exist', function(){
       		expect(mockEncodeService).toBeDefined()
		})

	    it('should test if encode works fine', function(){
	       var normalString = "1234567"
	       var encodedString = mockEncodeService.encode(normalString);
	       expect(normalString).not.toEqual(encodedString)
	    })

	    it('should test if decode works fine', function(){
	       var inputString = "1234567"
	       var encodedString = mockEncodeService.encode(inputString);
	       var decodedString = mockEncodeService.decode(encodedString)
	       expect(decodedString).toEqual(inputString)
         inputString = "ASDUISFIOUHAIEH4345"
         encodedString = mockEncodeService.encode(inputString);
         decodedString = mockEncodeService.decode(encodedString)
         expect(decodedString).toEqual(inputString)
	    })

  	})
  })
