define([
    'angular'
], function(angular) {
    'use strict'
    //Header directive is used to display header in multiple pages
    return angular.module('app.common.header', [])
        .directive('headerDirective', function() {
            return {
                restrict: 'E',
                templateUrl: 'js/modules/common/header.html',
                scope: {},
                controller: function($scope, $window, $location, $state) {
                    /*Fetch username from session*/
                    if ($window.sessionStorage.getItem('userInfo') == null || $window.sessionStorage.getItem('userInfo') === 'null') {
                        $state.go('login')
                    }
                    var isAdmin = JSON.parse($window.sessionStorage.getItem('userInfo')).admin
                    var loginUserName = JSON.parse($window.sessionStorage.getItem('userInfo')).userName
                    $scope.loginuser = loginUserName
                    if (isAdmin === true) {
                        $scope.admin = false
                    } else {
                        $scope.admin = true
                    }
                    var location = $location.path()
                    if (location == '/admin') {
                        $scope.set_active = 'admin'
                    } else if (location.indexOf('editdoor') > -1) {
                        $scope.set_active = '1'
                    } else if (location == '/dashboard') {
                        $scope.set_active = '1'
                    } else if (location == '/adduser') {
                        $scope.set_active = 'admin'
                    } else if (location.indexOf('edituser') > -1) {
                        $scope.set_active = 'admin'
                    } else if (location == '/changePassword') {
                        $scope.set_active = 'changepwd'
                    }




                    var that = this
                    this.logout = function() {
                        $window.sessionStorage['userInfo'] = null
                        $window.sessionStorage['usernamelist'] = null
                        $window.sessionStorage.setItem("activeTab", null)
                        $state.go('login')
                    }
                },
                controllerAs: 'ctrl'
            }
        })
})
