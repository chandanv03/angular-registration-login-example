/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
 define([
  'angular-mocks',
  'Source/modules/resources/rejectioncount',
  'Source/modules/common/tokenSetter',
  'Source/config'
  ], function(){

   describe('RejectionCount', function () {
  	var mockRejectionCount, $httpBackend, url, token;

	  	beforeEach(angular.mock.module('app.resources.rejectioncount'));

	  	beforeEach(module('ui.router'));

	  	beforeEach(angular.mock.module('app.common.token'));

	  	beforeEach(angular.mock.module('app.constants', function ($provide) {
	    $provide.constant('CONFIG',{
	      url: 'http://nlboed01.sgti.nl:3000/'
	    });


		}))

	  	var state;
	  	beforeEach(angular.mock.inject(function (RejectionCount, _$httpBackend_, CONFIG, $state, TokenService) {
	  		url = CONFIG.url;
	  		$httpBackend = _$httpBackend_;
	        mockRejectionCount = RejectionCount;
	        state = $state;
          token = TokenService.getToken();
		}))

	  	it('should test if resource is defined', function(){
	  		expect(mockRejectionCount).toBeDefined();
	  	})

	  	it('should test if resource is defined', function(){
	  		expect(mockRejectionCount.getRejectionCount).toBeDefined();
	  	})

      it('should test the URL', function(){
        $httpBackend.expect('GET', url + 'doors/rejectioncount?id=10&type=1').respond(200, [1,2]);
        mockRejectionCount.getRejectionCount(token).query({id: 10, type:1});
        $httpBackend.flush();
      })

   })

 })
