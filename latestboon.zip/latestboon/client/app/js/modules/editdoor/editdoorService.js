define(['./module'], function(module) {
    'use strict'

    module.service('EditDoorService', function($rootScope, $state, $location, $window, EditDoor, TimeOfFlight, MotorDrive, PlcData, DoorData, ChangeLog, $q, TokenService) {
        var service = {
            fetchChangeLog: function(doorId) {
                var payload = {
                    id: doorId
                }
                var deferred = $q.defer()
                var getChangeLog = ChangeLog.getChangeLog(TokenService.getToken()).get({

                }, payload, function() {
                    deferred.resolve(getChangeLog)
                })
                return deferred.promise
            },
            fetchDoorDetail: function(doorId) {
                var payload = {
                    id: doorId
                }
                var deferred = $q.defer()
                var getDoors = EditDoor.getDoor(TokenService.getToken()).get({
                    path: 'v1'
                }, payload, function() {
                    deferred.resolve(getDoors)
                })

                return deferred.promise
            },
            //To Update Time of Flight data
            putTimeofFlight: function(tofArray, doorId) {
                var payload = {
                    deviceId: doorId
                }
                var deferred = $q.defer()
                var tof_response = TimeOfFlight.updateTOF(TokenService.getToken()).update(
                    payload, tofArray,
                    function(result) {
                        deferred.resolve(result)
                    })

                return deferred.promise
            },
            //To Update Motor Drive data
            putMotorDrive: function(mtrArray, doorId) {
                var payload = {
                    deviceId: doorId
                }
                var deferred = $q.defer()
                var mtr_response = MotorDrive.updateMotor(TokenService.getToken()).update(
                    payload, mtrArray,
                    function(result) {
                        deferred.resolve(result)
                    })

                return deferred.promise
            },

            //To Update PLCData1 data
            putPlcData1: function(plcData1Array, doorId) {
                var payload = {
                    deviceId: doorId
                }
                var deferred = $q.defer()
                var plcyData1_response = PlcData.updatePlc(TokenService.getToken()).update(
                    payload, plcData1Array,
                    function(result) {
                        deferred.resolve(result)
                    })

                return deferred.promise
            },

            //To Update Door Data
            putDoorData: function(doorData, deviceId) {
                var payload = {
                    deviceId: deviceId
                }
                var deferred = $q.defer()
                var door_response = DoorData.updateDoor(TokenService.getToken()).update(
                    payload, doorData,
                    function(result) {
                        deferred.resolve(result)
                    })

                return deferred.promise
            },
            //Send Recapture image JSON command
            updateStereovisionImage: function(deviceId, jsonCommand) {

                var payload = {
                    deviceId: deviceId
                }
                var deferred = $q.defer()
                var door_response = TimeOfFlight.updateStereovisionImage(TokenService.getToken()).update(
                  payload, jsonCommand,
                   function(result) {
                    deferred.resolve(result)
                })
                return deferred.promise
            }

        }

        return service
    })
})
