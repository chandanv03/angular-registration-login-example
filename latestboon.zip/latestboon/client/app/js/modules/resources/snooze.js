define([
    'angular',
    'ngResource'
], function(angular) {
    'use strict'

    return angular.module('app.resources.snooze', ['ngResource'])
        .service('Snooze', function($resource, CONFIG, TokenService) {
            return {
                putSnooze: function(token) {

                    return $resource(CONFIG.url + 'doors/product', {
                        deviceId: '@deviceId'
                    }, {
                        update: {
                            method: 'PUT',
                            headers: {
                                'x-access-token': token,
                                'Content-Type': 'application/json'
                            },
                            transformResponse: function(data, headers) {
                                //Check the response header for token expiry and new token.
                                var headers = headers()
                                TokenService.setResponseHeader(headers)
                                return angular.fromJson(data)
                            }

                        }
                    })

                }
            }
        })
})
