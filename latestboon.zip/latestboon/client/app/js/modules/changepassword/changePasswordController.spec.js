/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */

define([
  'angular-mocks',
  'Source/modules/changepassword/changePasswordController',
  'Source/modules/changepassword/changePasswordService',
  'Source/modules/common/locationsService',
  'Source/modules/common/tokenSetter'
], function () {
    describe('adminController', function(){

      var scope, mockchangePasswordService, mockDashboardTreeView, createController, window;

      beforeEach(angular.mock.module('app.changePassword'));

      beforeEach(angular.mock.module('app.dashboard'));

      beforeEach(angular.mock.module('app.common.token'));

      beforeEach(angular.mock.module('app.common.locations'));
      

      beforeEach(module(function($provide) {
        mockchangePasswordService = {
          updatePassword: function() {}
        };
        $provide.value('changePasswordService', mockchangePasswordService);
      }));

      beforeEach(angular.mock.inject(function ($rootScope, $controller, $q, $window, $state) {
               var mockData = {accessToken: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiY…yMDl9.gqSOzp5_fVUGzrn5AREhK11opo-CJsM_m-vMy_K7Xtc", userName: "boonadmin", admin: true}
               spyOn(JSON, 'parse').and.returnValue(mockData)
               scope = $rootScope.$new();
               createController = function() {
                  return $controller('changePasswordController', {
                    '$scope': scope,
                    'changePasswordService' : mockchangePasswordService
                  });
               };
               deferred = $q.defer();
               spyOn(mockchangePasswordService, 'updatePassword').and.returnValue(deferred.promise);
               
      }));



    describe('EditDoorController', function() {

      it('should test if controller is initiated with scope', function() {
          createController()
          expect(scope.changepassword).toBeDefined()
          expect(scope.user).toBeDefined()
      });

      it('should test if changepassword works as expected when current password and old password are same', function() {
          var ctrl = createController();
          scope.user.password = "testPassword"
          scope.user.cpassword = "testPassword"

          scope.changepassword()
          expect(mockchangePasswordService.updatePassword).toHaveBeenCalled()
          var result = true
          deferred.resolve(result)
          scope.$digest()
          expect(scope.successMessage).toEqual('Password has been changed')
      });

      it('should test if changepassword works as expected when current password and old password are not same', function() {
          var ctrl = createController();
          scope.user.password = "testPasswordxxx"
          scope.user.cpassword = "testPassword"

          scope.changepassword()
          expect(mockchangePasswordService.updatePassword).not.toHaveBeenCalled()
          var result = true
          expect(scope.errorMessage).toEqual('ERROR : Password can not be changed. New password and confirm password doesnt not match.')
      });      

      it('should test if changepassword works as expected when promise is rejected', function() {
          var ctrl = createController();
          scope.user.password = "testPassword"
          scope.user.cpassword = "testPassword"

          scope.changepassword()
          expect(mockchangePasswordService.updatePassword).toHaveBeenCalled()
          var result = true
          deferred.reject(result)
          scope.$digest()
          expect(scope.errorMessage).toEqual('ERROR : Password can not be changed. Please enter the correct old password.')
      });

    })
})
})    