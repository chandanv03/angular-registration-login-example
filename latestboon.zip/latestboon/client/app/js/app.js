/**
 * loads sub modules and wraps them up into the main module.
 * This should be used for top-level module definitions only.
 */
define([
    'angular',
    'ui.router',
    'ui.bootstrap.tpl',
    './config',
    './modules/common/tokenSetter',
    './modules/common/headerDirective',
    './modules/login/index',
    './modules/dashboard/index',
    './modules/changepassword/index',
    './modules/editdoor/index',
    './modules/admin/index',
    './modules/common/locationsService',
    './modules/common/userLevelService'
], function(angular) {
    return angular.module('app', [
            'app.constants',
            'app.common.token',
            'app.dashboard',
            'app.login',
            'app.admin',
            'app.editdoor',
            'ui.router',
            'ui.bootstrap.tpls',
            'app.common.header',
            'app.changePassword',
            'app.common.locations',
            'app.common.userlevel'
        ]).config(function($urlRouterProvider, $locationProvider, $stateProvider, $windowProvider) {


            /* Added state provider for routing */

            $urlRouterProvider.otherwise('/login');
            $stateProvider
                .state('private', {
                    abstract: true,
                    template: '<ui-view/>'

                })
                .state('dashboard', {
                    parent: 'private',
                    url: '/dashboard',
                    templateUrl: 'js/modules/dashboard/dashboard.html',
                    controller: 'DashboardController',
                    controllerAs: 'ctrl',
                    requireLogin: true
                })
                .state('admin', {
                    parent: 'private',
                    url: '/admin',
                    templateUrl: 'js/modules/admin/admin.html',
                    controller: 'adminController',
                    requireLogin: true
                })
                .state('adduser', {
                    parent: 'private',
                    url: '/adduser',
                    templateUrl: 'js/modules/admin/adduser.html',
                    controller: 'userController',
                    requireLogin: true
                })
                .state('edituser', {
                    parent: 'private',
                    url: '/edituser/id/:id',
                    templateUrl: 'js/modules/admin/edituser.html',
                    params: {
                        id: null
                    },
                    controller: 'userController',
                    requireLogin: true
                })
                .state('editdoor', {
                    parent: 'private',
                    url: '/editdoor/id/:id',
                    templateUrl: 'js/modules/editdoor/editdoor.html',
                    params: {
                        id: null
                    },
                    controller: 'EditDoorController',
                    controllerAs: 'ctrl',
                    requireLogin: true
                })
                .state('changePassword', {
                    parent: 'private',
                    url: '/changePassword',
                    templateUrl: 'js/modules/changepassword/changePassword.html',
                    controller: 'changePasswordController',
                    requireLogin: true
                })
                .state('login', {
                    url: '/login',
                    templateUrl: 'js/modules/login/login.html',
                    controller: 'LoginController',
                    requireLogin: false
                })


            // if you don't wish to set base URL then use this
            // $locationProvider.html5Mode(true)
        })
        .run(function($location, $rootScope, $state, $window) {
            $rootScope.$on('$stateChangeStart', function(event, toState) {
                var requireLogin = toState.requireLogin
                var userInfo = $window.sessionStorage.getItem('userInfo')
                if (requireLogin == true && (userInfo == null || userInfo === 'null')) {
                    event.preventDefault()
                    $state.go('login')
                }
            })

        })
})
