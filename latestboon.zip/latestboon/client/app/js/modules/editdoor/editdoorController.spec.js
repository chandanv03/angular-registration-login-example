/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
define([
    'angular-mocks',
    'Source/modules/editdoor/editdoorController',
    'Source/modules/editdoor/editdoorService',
    'Source/modules/dashboard/dashboardTreeviewService',
    'Source/modules/common/locationsService',
    'Source/modules/common/tokenSetter',
    'Source/modules/common/userLevelService'
], function() {
    describe('EditdoorController', function() {

        var scope, mockEditDoorService, mockDashboardTreeView, createController, q, $window, state, mockUserLevelService, $timeout;

        beforeEach(angular.mock.module('app.editdoor'));

        beforeEach(angular.mock.module('app.dashboard'));

        beforeEach(angular.mock.module('app.common.token'));

        beforeEach(angular.mock.module('app.common.locations'));

        beforeEach(angular.mock.module('app.common.userlevel'));

        var mockEditDoorService;


        beforeEach(module(function($provide) {
            mockEditDoorService = {
                fetchDoorDetail: function() {},
                fetchChangeLog: function() {},
                putTimeofFlight: function() {},
                putMotorDrive: function() {},
                putPlcy1: function() {},
                putPlcy2: function() {},
                putDoorData: function() {},
                putPlcData1: function() {},
                putPlcData2: function() {},
                putPlcData3: function() {},
                updateStereovisionImage: function() {}
            };
            $provide.value('EditDoorService', mockEditDoorService);

            mockLocationService = {
                getLocations: function() {}
            }
            $provide.value('LocationsService', mockLocationService);
        }));

        beforeEach(angular.mock.inject(function($rootScope, $controller, $q, _$state_, _$window_, _userLevelService_, _$timeout_) {
            state = _$state_
            $window = _$window_
            scope = $rootScope.$new();
            createController = function() {
                return $controller('EditDoorController', {
                    '$scope': scope,
                    'EditDoorService': mockEditDoorService,
                    mockUserLevelService: _userLevelService_
                });
            };
            q = $q;
            deferred = $q.defer();
            $timeout = _$timeout_
            spyOn(mockEditDoorService, 'fetchDoorDetail').and.returnValue(deferred.promise);
            spyOn(mockLocationService, 'getLocations').and.returnValue(deferred.promise);
        }));

        it('should test if controller is initiated with scope', function() {
            spyOn(JSON, 'parse').and.returnValue({
                "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                "userName": "BoonAdmin",
                "admin": true,
                "level1": false,
                "level2": false,
                "level3": false,
                "level4": false,
                "level5": false,
                "level6": false,
                "level7": false,
                "level8": false,
                "level9": true,
                "level10": false
            });
            expect(scope.ediDoorData).not.toBeDefined()
            expect(scope.editFields).not.toBeDefined()
            expect(scope.columnBreak).not.toBeDefined()
            expect(scope.onlyNumbers).not.toBeDefined()
            expect(scope.init).not.toBeDefined()
            createController()
            expect(scope.init).toBeDefined()
            expect(scope.editFields).toBeDefined()
            expect(scope.editFields.editCampus).toBe(false)
            expect(scope.editFields.editEntrance).toBe(false)
            expect(scope.editFields.editBuilding).toBe(false)
            expect(scope.editFields.editSubEntrance).toBe(false)
            expect(scope.onlyNumbers).toBeDefined()
            expect(scope.columnBreak).toEqual(4)
        });

        it('should test if controller is initiated with scope', function() {
            spyOn(JSON, 'parse').and.returnValue({
                "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                "userName": "BoonAdmin",
                "admin": true,
                "level1": false,
                "level2": false,
                "level3": false,
                "level4": false,
                "level5": false,
                "level6": false,
                "level7": false,
                "level8": false,
                "level9": true,
                "level10": false
            });
            createController()
            scope.resetmsg();
        });

        it('should test $event.preventDefault to have been called', function() {
            spyOn(JSON, 'parse').and.returnValue({
                "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                "userName": "BoonAdmin",
                "admin": true,
                "level1": false,
                "level2": false,
                "level3": false,
                "level4": false,
                "level5": false,
                "level6": false,
                "level7": false,
                "level8": false,
                "level9": true,
                "level10": false
            });
            createController();
            var $event = jasmine.createSpyObj('$event', ['preventDefault']);
            scope.onlyNumbers($event);
            expect($event.preventDefault).toHaveBeenCalled()
        })

        it('should check if editCampus if working fine', function() {
            spyOn(JSON, 'parse').and.returnValue({
                "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                "userName": "BoonAdmin",
                "admin": true,
                "level1": false,
                "level2": false,
                "level3": false,
                "level4": false,
                "level5": false,
                "level6": false,
                "level7": false,
                "level8": false,
                "level9": true,
                "level10": false
            });
            createController();
            scope.editFields.editCampus = false;
            scope.editCampus(true)
            expect(scope.editFields.editCampus).toBe(true)
        })

        it('should check if scope.init if working fine', function() {
            spyOn(JSON, 'parse').and.returnValue({
                "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                "userName": "BoonAdmin",
                "admin": true,
                "level1": false,
                "level2": false,
                "level3": false,
                "level4": false,
                "level5": false,
                "level6": false,
                "level7": false,
                "level8": false,
                "level9": true,
                "level10": false
            });
            createController();
            scope.init()
            expect(scope.activeMenu).toEqual('primary')
            expect(scope.active).toEqual('true')
        })

        it('should check if editBuilding if working fine', function() {
            spyOn(JSON, 'parse').and.returnValue({
                "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                "userName": "BoonAdmin",
                "admin": true,
                "level1": false,
                "level2": false,
                "level3": false,
                "level4": false,
                "level5": false,
                "level6": false,
                "level7": false,
                "level8": false,
                "level9": true,
                "level10": false
            });
            createController();
            scope.editFields.editBuilding = false;
            scope.editBuilding(true)
            expect(scope.editFields.editBuilding).toBe(true)
        })

        it('should check if editEntrance if working fine', function() {
            spyOn(JSON, 'parse').and.returnValue({
                "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                "userName": "BoonAdmin",
                "admin": true,
                "level1": false,
                "level2": false,
                "level3": false,
                "level4": false,
                "level5": false,
                "level6": false,
                "level7": false,
                "level8": false,
                "level9": true,
                "level10": false
            });
            createController();
            scope.editFields.editEntrance = false;
            scope.editEntrance(true)
            expect(scope.editFields.editEntrance).toBe(true)
        })

        it('should check if editSubEntrance if working fine', function() {
            spyOn(JSON, 'parse').and.returnValue({
                "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                "userName": "BoonAdmin",
                "admin": true,
                "level1": false,
                "level2": false,
                "level3": false,
                "level4": false,
                "level5": false,
                "level6": false,
                "level7": false,
                "level8": false,
                "level9": true,
                "level10": false
            });
            createController();
            scope.editFields.editSubEntrance = false;
            scope.editSubEntrance(true)
            expect(scope.editFields.editSubEntrance).toBe(true)
        })

        it('should test if promise is resolved if plc_values is not undefined ', function() {
          spyOn(JSON, 'parse').and.returnValue({
              "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
              "userName": "BoonAdmin",
              "admin": true,
              "level1": false,
              "level2": false,
              "level3": false,
              "level4": false,
              "level5": false,
              "level6": true,
              "level7": false,
              "level8": false,
              "level9": true,
              "level10": false
          });
          var dummyElement = document.createElement('canvas');
          var id = document.createAttribute("id");
          id.value = 'stereovisionCanvas';
          dummyElement.setAttributeNode(id);
          var width = document.createAttribute("width");
          width.value = '176px';
          dummyElement.setAttributeNode(width);
          var height = document.createAttribute("height");
          height.value = '132px';
          dummyElement.setAttributeNode(height);
          spyOn(document, 'getElementById').and.returnValue(dummyElement);
          createController();
          var result = {
              "companies":[{"companyId":1,"companyName":"Boon Edam","children":[{"countryId":1,"countryName":"Netherlands","children":[{"campusId":1,"campusName":"notassigned~","children":[{"buildingId":1,"buildingName":"notassigned~","children":[{"entranceId":1,"entranceName":"notassigned~","children":[{"subentranceId":1,"subentranceName":"notassigned~"}]}]}]},{"campusId":2,"campusName":"CampusA","children":[{"buildingId":2,"buildingName":"BuildingAA","children":[{"entranceId":2,"entranceName":"EntranceAAA","children":[{"subentranceId":2,"subentranceName":"SubEntranceAAAA"}]},{"entranceId":3,"entranceName":"EntranceAAB","children":[{"subentranceId":3,"subentranceName":"SubEntranceAABA"}]},{"entranceId":18,"entranceName":"MyEntrance","children":[{"subentranceId":3379,"subentranceName":"LeftEntrace"}]}]},{"buildingId":3,"buildingName":"BuildingAB","children":[{"entranceId":4,"entranceName":"EntranceABA","children":[{"subentranceId":4,"subentranceName":"SubEntranceABAA"}]},{"entranceId":5,"entranceName":"EntranceABB","children":[{"subentranceId":5,"subentranceName":"SubEntranceABBA"}]}]}]},{"campusId":3,"campusName":"CampusB","children":[{"buildingId":4,"buildingName":"BuildingBA","children":[{"entranceId":6,"entranceName":"EntranceBAA","children":[{"subentranceId":6,"subentranceName":"SubEntranceBAAA"},{"subentranceId":7,"subentranceName":"SubEntranceBAAB"}]},{"entranceId":7,"entranceName":"EntranceBAB","children":[{"subentranceId":8,"subentranceName":"SubEntranceBABA"},{"subentranceId":9,"subentranceName":"SubEntranceBABB"}]}]},{"buildingId":5,"buildingName":"BuildingBB","children":[]}]},{"campusId":4,"campusName":"CampusC","children":[{"buildingId":6,"buildingName":"BuildingCA","children":[{"entranceId":8,"entranceName":"EntranceCAA","children":[{"subentranceId":10,"subentranceName":"SubEntranceCAAA"},{"subentranceId":3378,"subentranceName":"MyPrivateEntrance"}]}]}]},{"campusId":5,"campusName":"CampusD","children":[{"buildingId":7,"buildingName":"BuildingDA","children":[{"entranceId":9,"entranceName":"EntranceDAA","children":[{"subentranceId":11,"subentranceName":"SubEntranceDAAA"}]}]},{"buildingId":15,"buildingName":"MyHome","children":[{"entranceId":20,"entranceName":"Front","children":[{"subentranceId":3381,"subentranceName":"Pietke"}]}]}]},{"campusId":6,"campusName":"CampusE","children":[{"buildingId":8,"buildingName":"BuildingEA","children":[{"entranceId":10,"entranceName":"EntranceEAA","children":[{"subentranceId":12,"subentranceName":"SubEntranceEAAA"}]}]}]},{"campusId":17,"campusName":"Capmus19","children":[{"buildingId":12,"buildingName":"B19","children":[{"entranceId":15,"entranceName":"E19","children":[{"subentranceId":3375,"subentranceName":"sE19"}]}]}]},{"campusId":18,"campusName":"Cloud","children":[{"buildingId":13,"buildingName":"CloudBuilding","children":[{"entranceId":16,"entranceName":"CloudEntrance","children":[{"subentranceId":3376,"subentranceName":"CloudSubEntrance"}]}]}]},{"campusId":19,"campusName":"TestFerdi","children":[{"buildingId":14,"buildingName":"Testbuilding","children":[{"entranceId":17,"entranceName":"TestEntrance","children":[{"subentranceId":3377,"subentranceName":"TestSubEntrance"}]},{"entranceId":19,"entranceName":"CircleLockShowRoom","children":[{"subentranceId":3380,"subentranceName":"Circlelock"}]}]}]},{"campusId":20,"campusName":"Edam","children":[{"buildingId":16,"buildingName":"Ambachtstraat","children":[{"entranceId":21,"entranceName":"Showroom","children":[{"subentranceId":3382,"subentranceName":"Showroom"}]}]},{"buildingId":17,"buildingName":"Aambeeldstraat","children":[{"entranceId":22,"entranceName":"Development","children":[{"subentranceId":3383,"subentranceName":"Upstairs"},{"subentranceId":3384,"subentranceName":"Downstairs"},{"subentranceId":3385,"subentranceName":"Simulators"},{"subentranceId":3387,"subentranceName":"MyEntrance"}]}]},{"buildingId":18,"buildingName":"Hamerstraat","children":[{"entranceId":23,"entranceName":"Main","children":[{"subentranceId":3386,"subentranceName":"Floor"}]}]}]},{"campusId":21,"campusName":"Volendam","children":[{"buildingId":19,"buildingName":"Van der Valk","children":[{"entranceId":24,"entranceName":"Hotel Entry","children":[{"subentranceId":3388,"subentranceName":"LeftEntrace"}]}]}]},{"campusId":22,"campusName":"Lillington","children":[{"buildingId":20,"buildingName":"Main","children":[{"entranceId":25,"entranceName":"Entrance1","children":[{"subentranceId":3389,"subentranceName":"Sub1"},{"subentranceId":3390,"subentranceName":"Sub2"}]}]}]},{"campusId":23,"campusName":"Test","children":[{"buildingId":21,"buildingName":"Building","children":[{"entranceId":26,"entranceName":"Entrance","children":[{"subentranceId":3391,"subentranceName":"SubEntrance"}]}]}]}]},{"countryId":2,"countryName":"United States of America","children":[{"campusId":null,"campusName":null,"children":[{"buildingId":null,"buildingName":null,"children":[{"entranceId":null,"entranceName":null,"children":[{"subentranceId":null,"subentranceName":null}]}]}]}]}]}],
              "success":true,
              "results" :[{"success" : true}],
              "doorMain": [{
                  "id": 8,
                  "nodeid": "JAbmykU/TpSIAn6XF6PyP+Ub0JA=",
                  "DeviceID": "4",
                  "ip_number": "192.168.1.52",
                  "mac_address": "00:1f:7b:b2:14:d6",
                  "hostname": "",
                  "time_first_seen": 1454410566,
                  "time_last_seen": 1467491252,
                  "lastupdateby": "boonadmin",
                  "snoozeExitTime": 1467491852,
                  "real_name": "Bylorus RnD Wandbboard",
                  "location": "Aambeeldstraat",
                  "product_type": "Bylorus",
                  "last_state": "OK",
                  "users": "boon, walt",
                  "ce_number": "",
                  "latitude": "",
                  "longitude": "",
                  "timezone": null,
                  "campusId": "boonCampus",
                  "buildingId": "boonBuilding",
                  "entranceId": "boonEntrance",
                  "subEntranceId": "boonsub",
                  "campusName": "boonCampus",
                  "buildingName": null,
                  "entranceName": "boonEntrance",
                  "subEntranceName": "subEntranceT",
                  "companyId": 1,
                  "info1": "",
                  "info2": "",
                  "assigned": 1,
                  "flag": 0
              }],
              "transactionTimes": [],
              "rejectionCount": [],
              "timeOfFlight": [{
                  "id": 173,
                  "DeviceId": "4",
                  "EpochTime": 1467364984,
                  "Primary_Log_Capture": 0,
                  "Primary_Log_CaptureZero": 0,
                  "Primary_Log_CaptureOne": 0,
                  "Primary_Log_CaptureMore": 0,
                  "Primary_Log_CaptureSus": 0,
                  "Primary_Log_Still": 0,
                  "Primary_Log_StillZero": 0,
                  "Primary_Log_StillOne": 0,
                  "Primary_Log_StillMore": 0,
                  "Primary_Log_StillSus": 0,
                  "Primary_Log_OutputCounts": 0,
                  "Primary_OutputStatus_Authorization": 0,
                  "Primary_OutputStatus_Zero": 0,
                  "Primary_OutputStatus_One": 0,
                  "Primary_OutputStatus_More": 0,
                  "Primary_OutputStatus_Sus": 0,
                  "Primary_OutputStatus_Air": 0,
                  "Primary_Sensitivity_Volume": 5,
                  "Primary_Sensitivity_Moment": 4,
                  "Primary_Sensitivity_LowObject": 9,
                  "Primary_Sensitivity_SensorBlinding": 8,
                  "Primary_Sensitivity_OnePerson": 7,
                  "Primary_Sensitivity_MorePerson": 6,
                  "Primary_DoorSetting_SensorDirection": 0,
                  "Primary_DoorSetting_HeightUnderCanopy": 0,
                  "Primary_DoorSetting_Diameter": 0,
                  "Primary_DoorSetting_DoorOpen": 0,
                  "Primary_DoorSetting_DoorClose": 0,
                  "Primary_DoorSetting_VerificationDevice": 0,
                  "Primary_DoorSetting_WheelChair": 0,
                  "Primary_DoorSetting_ShaftPosition_X": 0,
                  "Primary_DoorSetting_ShaftPosition_Y": 0,
                  "Primary_DoorSetting_ShaftPosition1_X": 0,
                  "Primary_DoorSetting_ShaftPosition1_Y": 0,
                  "Primary_DoorSetting_ShaftPosition2_X": 0,
                  "Primary_DoorSetting_ShaftPosition2_Y": 0,
                  "Primary_DoorSetting_DoorPosition": 0,
                  "Primary_DoorSetting_OffsetAngle": 0,
                  "Primary_DoorSetting_TipOfEndPosition_X": 0,
                  "Primary_DoorSetting_TipOfEndPosition_Y": 0,
                  "Secondary_Log_Capture": 0,
                  "Secondary_Log_CaptureZero": 0,
                  "Secondary_Log_CaptureOne": 0,
                  "Secondary_Log_CaptureMore": 0,
                  "Secondary_Log_CaptureSus": 0,
                  "Secondary_Log_Still": 0,
                  "Secondary_Log_StillZero": 0,
                  "Secondary_Log_StillOne": 0,
                  "Secondary_Log_StillMore": 0,
                  "Secondary_Log_StillSus": 0,
                  "Secondary_Log_OutputCounts": 0,
                  "Secondary_OutputStatus_Authorization": 0,
                  "Secondary_OutputStatus_Zero": 0,
                  "Secondary_OutputStatus_One": 0,
                  "Secondary_OutputStatus_More": 0,
                  "Secondary_OutputStatus_Sus": 0,
                  "Secondary_OutputStatus_Air": 0,
                  "Secondary_Sensitivity_Volume": 0,
                  "Secondary_Sensitivity_Moment": 0,
                  "Secondary_Sensitivity_LowObject": 0,
                  "Secondary_Sensitivity_SensorBlinding": 0,
                  "Secondary_Sensitivity_OnePerson": 0,
                  "Secondary_Sensitivity_MorePerson": 0,
                  "Secondary_DoorSetting_SensorDirection": 0,
                  "Secondary_DoorSetting_HeightUnderCanopy": 0,
                  "Secondary_DoorSetting_Diameter": 0,
                  "Secondary_DoorSetting_DoorOpen": 0,
                  "Secondary_DoorSetting_DoorClose": 0,
                  "Secondary_DoorSetting_VerificationDevice": 0,
                  "Secondary_DoorSetting_WheelChair": 0,
                  "Secondary_DoorSetting_ShaftPosition_X": 0,
                  "Secondary_DoorSetting_ShaftPosition_Y": 0,
                  "Secondary_DoorSetting_ShaftPosition1_X": 0,
                  "Secondary_DoorSetting_ShaftPosition1_Y": 0,
                  "Secondary_DoorSetting_ShaftPosition2_X": 0,
                  "Secondary_DoorSetting_ShaftPosition2_Y": 0,
                  "Secondary_DoorSetting_DoorPosition": 0,
                  "Secondary_DoorSetting_OffsetAngle": 0,
                  "Secondary_DoorSetting_TipOfEndPosition_X": 0,
                  "Secondary_DoorSetting_TipOfEndPosition_Y": 0
              }],
              "plc": [{
                  "id": 3568,
                  "DeviceId": "4",
                  "EpochTime": 1466584246,
                  "Alarm": 0,
                  "BiometricRejectionCount": null,
                  "BothDoorsOpenCount": null,
                  "Cleaning": null,
                  "CleaningTime": 0,
                  "DelayTimeNoOutputSV": 0,
                  "DoorForcedCount": null,
                  "EndSwitchClosedInnerDoorDefective": 0,
                  "EndSwitchClosedOuterDoorDefective": 0,
                  "Event1st": 0,
                  "Event2nd": 0,
                  "Event3rd": 0,
                  "Event4th": 0,
                  "Event5th": 0,
                  "FireAlarmCount": null,
                  "FireAlarmModeSet": 0,
                  "IllegalTime": 0,
                  "IllegalUse": 0,
                  "IRSensorHungCount": null,
                  "IRSSensorDelay": 0,
                  "Locking": 0,
                  "LuminanceErrorDelay": 0,
                  "OnePersonInCount": null,
                  "OpeningCounterInnerDoor": 0,
                  "OpeningCounterOuterDoor": null,
                  "OpenTimeIn": 0,
                  "OpenTimeOut": 0,
                  "OverallTimeClosingInnerDoor": 0,
                  "OverallTimeClosingOuterDoor": 0,
                  "OverallTimeOpeningInnerDoor": 0,
                  "OverallTimeOpeningOuterDoor": 0,
                  "PowerLossCount": null,
                  "PresenceDelay": 0,
                  "PulsesInCounter": 0,
                  "PulsesInSpecialCounter": 0,
                  "PulsesOutCounter": 0,
                  "PulsesOutSpecialCounter": 0,
                  "Reset": 0,
                  "ReturnSignalInTime": 0,
                  "ReturnSignalOutTime": 0,
                  "ReverseButtonActivation": 0,
                  "SafetyRailInnerDoorClosing": 0,
                  "SafetyRailOuterDoorClosing": null,
                  "TimeExceededinCabinCount": null,
                  "TimeExceededMax": 0,
                  "TimeOutTime": 0,
                  "TOF0PersonIn": 0,
                  "TOF0PersonOut": 0,
                  "TOF1PersonIn": null,
                  "TOF1PersonOut": 0,
                  "TOF2PersonsIn": null,
                  "TOF2PersonsOut": 0,
                  "TOFRejection": 0,
                  "TOFRejectionsIn": null,
                  "TOFRejectionsOut": null,
                  "TOFSuspiciousIn": 0,
                  "TOFSuspiciousOut": 0,
                  "EndSwitchOutsideClosed": 0,
                  "EndSwitchOutsideSlow": 0,
                  "EndSwitchOutsideOpen": 0,
                  "EndSwitchInsideClosed": 0,
                  "EndSwitchInsideSlow": 0,
                  "EndSwitchInsideOpen": 0,
                  "BiometricAccessGranted": 0,
                  "FireAlarm": 0,
                  "MotorThermalOverload": 0,
                  "PowerFailure": 0,
                  "EmergencyButton": 0,
                  "SafetyRail": 0,
                  "PulseIn": 0,
                  "PulseOut": 0,
                  "PulseInSpecial": 0,
                  "PulseOutSpecial": 0,
                  "BothDoorsOpen": 0,
                  "LockSwitch": 0,
                  "IrisScanEntryRejected": null,
                  "InfraRedSensors": 0,
                  "SVSInOn": 0,
                  "SVSOutOn": 0,
                  "CleaningMode": 0,
                  "ResetSwitch": 0,
                  "EmptyDoorIn": 0,
                  "OnePersonIn": 0,
                  "TwoPersonIn": 0,
                  "SuspiciousIn": 0,
                  "AIRSensorsIn": 0,
                  "SVSEnabledIn": 0,
                  "EmptyDoorOut": 0,
                  "OnePersonOut": 0,
                  "TwoPersonOut": 0,
                  "SuspiciousOut": 0,
                  "AIRSensorsOut": 0,
                  "SVSEnabledOut": 0,
                  "ReturnSignalIn": 0,
                  "ReturnSignalOut": 0,
                  "MotorOuter": null,
                  "MotorInner": null,
                  "LockOuter": null,
                  "LockInner": null,
                  "MagLockOuter": null,
                  "MagLockInner": null,
                  "VFDForward": 0,
                  "VFDReverse": 0,
                  "VFDSpeedRef2and4": 0,
                  "VFDSpeedRef3and4": 0,
                  "VFDSecondAccDec": null,
                  "TOFReset": 0,
                  "TOFShutdown": 0,
                  "GeneralAlarm": 0,
                  "SignalLEDGreenIn": 0,
                  "SignalLEDRedIn": 0,
                  "SignalLEDGreenOut": 0,
                  "SignalLEDRedOut": 0,
                  "AuthorizationIn": 0,
                  "AIRActiveIn": 0,
                  "AuthorizationOut": 0,
                  "AIRActiveOut": 0,
                  "TwoPersonRejection": 0,
                  "BiometricRejection": 0,
                  "TimeExceededInCabin": 0,
                  "SafetyRailActivation": 0,
                  "EmergencyButtonActivation": 0,
                  "PowerLoss": 0,
                  "IRSensorHung": 0,
                  "PersonInCabin": null,
                  "BiometricStart": 0,
                  "OuterDoorClosed": 0,
                  "InnerDoorClosed": 0,
                  "EmergencyButtonLED": 0,
                  "Voice1": 0,
                  "Voice2": 0,
                  "SignalGreenInterior": 0,
                  "SignalRedInterior": 0,
                  "EnableBiometricEntry": null,
                  "EnableBiometricExit": null
              }],
              "motorDrive": [{
                  "id": 11,
                  "DeviceId": "4",
                  "EpochTime": 1466584661,
                  "OutputFrequency": 1,
                  "BaseFrequency": 0,
                  "OutputCurrent": 1,
                  "NormalSpeed": 1,
                  "OutputVoltage": null,
                  "BaseVoltage": null,
                  "SlowSpeedOuter": null,
                  "SlowSpeedInner": null,
                  "AccelerationTime1st": null,
                  "AccelerationTime2nd": null,
                  "DecelerationTime1st": null,
                  "DecelerationTime2nd": null,
                  "BrakingTime": null,
                  "Braking": null
              }],
              "doorStatus": null
          }
          spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise);
          deferred.resolve(result);
          expect(scope.plc_data1).toBe(undefined)
          expect(scope.output1 ).toBe(undefined)
          expect(scope.output2_1).toBe(undefined)
          expect(scope.output2_2).toBe(undefined)
          expect(scope.output2_3).toBe(undefined)
          expect(scope.output2_4).toBe(undefined)
          scope.$digest();
          expect(scope.plc_data1).not.toBe(undefined)
          expect(scope.output1 ).not.toBe(undefined)
          expect(scope.output2_1).not.toBe(undefined)
          expect(scope.output2_2).not.toBe(undefined)
          expect(scope.output2_3).not.toBe(undefined)
          expect(scope.output2_4).not.toBe(undefined)
          expect(scope.activeMenu).toEqual('primary')
        });

        it('should test if promise is resolved if plc_values is undefined ', function() {
            spyOn(JSON, 'parse').and.returnValue({
                "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                "userName": "BoonAdmin",
                "admin": true,
                "level1": false,
                "level2": false,
                "level3": false,
                "level4": false,
                "level5": false,
                "level6": false,
                "level7": false,
                "level8": false,
                "level9": true,
                "level10": false
            });
            var dummyElement = document.createElement('canvas');
            var id = document.createAttribute("id");
            id.value = 'stereovisionCanvas';
            dummyElement.setAttributeNode(id);
            var width = document.createAttribute("width");
            width.value = '176px';
            dummyElement.setAttributeNode(width);
            var height = document.createAttribute("height");
            height.value = '132px';
            dummyElement.setAttributeNode(height);
            spyOn(document, 'getElementById').and.returnValue(dummyElement);
            createController();
            var result = {
                "doorMain": [{
                    "id": 8,
                    "nodeid": "JAbmykU/TpSIAn6XF6PyP+Ub0JA=",
                    "DeviceID": "4",
                    "ip_number": "192.168.1.52",
                    "mac_address": "00:1f:7b:b2:14:d6",
                    "hostname": "",
                    "time_first_seen": 1454410566,
                    "time_last_seen": 1467491252,
                    "lastupdateby": "boonadmin",
                    "snoozeExitTime": 1467491852,
                    "real_name": "Bylorus RnD Wandbboard",
                    "location": "Aambeeldstraat",
                    "product_type": "Bylorus",
                    "last_state": "OK",
                    "users": "boon, walt",
                    "ce_number": "",
                    "latitude": "",
                    "longitude": "",
                    "timezone": null,
                    "campusId": "boonCampus",
                    "buildingId": "boonBuilding",
                    "entranceId": "boonEntrance",
                    "subEntranceId": "boonsub",
                    "campusName": "boonCampus",
                    "buildingName": null,
                    "entranceName": "boonEntrance",
                    "subEntranceName": "subEntranceT",
                    "companyId": 1,
                    "info1": "",
                    "info2": "",
                    "assigned": 1,
                    "flag": 0
                }],
                "transactionTimes": [],
                "rejectionCount": [],
                "timeOfFlight": [{
                    "id": 173,
                    "DeviceId": "4",
                    "EpochTime": 1467364984,
                    "Primary_Log_Capture": 0,
                    "Primary_Log_CaptureZero": 0,
                    "Primary_Log_CaptureOne": 0,
                    "Primary_Log_CaptureMore": 0,
                    "Primary_Log_CaptureSus": 0,
                    "Primary_Log_Still": 0,
                    "Primary_Log_StillZero": 0,
                    "Primary_Log_StillOne": 0,
                    "Primary_Log_StillMore": 0,
                    "Primary_Log_StillSus": 0,
                    "Primary_Log_OutputCounts": 0,
                    "Primary_OutputStatus_Authorization": 0,
                    "Primary_OutputStatus_Zero": 0,
                    "Primary_OutputStatus_One": 0,
                    "Primary_OutputStatus_More": 0,
                    "Primary_OutputStatus_Sus": 0,
                    "Primary_OutputStatus_Air": 0,
                    "Primary_Sensitivity_Volume": 5,
                    "Primary_Sensitivity_Moment": 4,
                    "Primary_Sensitivity_LowObject": 9,
                    "Primary_Sensitivity_SensorBlinding": 8,
                    "Primary_Sensitivity_OnePerson": 7,
                    "Primary_Sensitivity_MorePerson": 6,
                    "Primary_DoorSetting_SensorDirection": 0,
                    "Primary_DoorSetting_HeightUnderCanopy": 0,
                    "Primary_DoorSetting_Diameter": 0,
                    "Primary_DoorSetting_DoorOpen": 0,
                    "Primary_DoorSetting_DoorClose": 0,
                    "Primary_DoorSetting_VerificationDevice": 0,
                    "Primary_DoorSetting_WheelChair": 0,
                    "Primary_DoorSetting_ShaftPosition_X": 0,
                    "Primary_DoorSetting_ShaftPosition_Y": 0,
                    "Primary_DoorSetting_ShaftPosition1_X": 0,
                    "Primary_DoorSetting_ShaftPosition1_Y": 0,
                    "Primary_DoorSetting_ShaftPosition2_X": 0,
                    "Primary_DoorSetting_ShaftPosition2_Y": 0,
                    "Primary_DoorSetting_DoorPosition": 0,
                    "Primary_DoorSetting_OffsetAngle": 0,
                    "Primary_DoorSetting_TipOfEndPosition_X": 0,
                    "Primary_DoorSetting_TipOfEndPosition_Y": 0,
                    "Secondary_Log_Capture": 0,
                    "Secondary_Log_CaptureZero": 0,
                    "Secondary_Log_CaptureOne": 0,
                    "Secondary_Log_CaptureMore": 0,
                    "Secondary_Log_CaptureSus": 0,
                    "Secondary_Log_Still": 0,
                    "Secondary_Log_StillZero": 0,
                    "Secondary_Log_StillOne": 0,
                    "Secondary_Log_StillMore": 0,
                    "Secondary_Log_StillSus": 0,
                    "Secondary_Log_OutputCounts": 0,
                    "Secondary_OutputStatus_Authorization": 0,
                    "Secondary_OutputStatus_Zero": 0,
                    "Secondary_OutputStatus_One": 0,
                    "Secondary_OutputStatus_More": 0,
                    "Secondary_OutputStatus_Sus": 0,
                    "Secondary_OutputStatus_Air": 0,
                    "Secondary_Sensitivity_Volume": 0,
                    "Secondary_Sensitivity_Moment": 0,
                    "Secondary_Sensitivity_LowObject": 0,
                    "Secondary_Sensitivity_SensorBlinding": 0,
                    "Secondary_Sensitivity_OnePerson": 0,
                    "Secondary_Sensitivity_MorePerson": 0,
                    "Secondary_DoorSetting_SensorDirection": 0,
                    "Secondary_DoorSetting_HeightUnderCanopy": 0,
                    "Secondary_DoorSetting_Diameter": 0,
                    "Secondary_DoorSetting_DoorOpen": 0,
                    "Secondary_DoorSetting_DoorClose": 0,
                    "Secondary_DoorSetting_VerificationDevice": 0,
                    "Secondary_DoorSetting_WheelChair": 0,
                    "Secondary_DoorSetting_ShaftPosition_X": 0,
                    "Secondary_DoorSetting_ShaftPosition_Y": 0,
                    "Secondary_DoorSetting_ShaftPosition1_X": 0,
                    "Secondary_DoorSetting_ShaftPosition1_Y": 0,
                    "Secondary_DoorSetting_ShaftPosition2_X": 0,
                    "Secondary_DoorSetting_ShaftPosition2_Y": 0,
                    "Secondary_DoorSetting_DoorPosition": 0,
                    "Secondary_DoorSetting_OffsetAngle": 0,
                    "Secondary_DoorSetting_TipOfEndPosition_X": 0,
                    "Secondary_DoorSetting_TipOfEndPosition_Y": 0
                }],
                "plc": [],
                "motorDrive": [{
                    "id": 11,
                    "DeviceId": "4",
                    "EpochTime": 1466584661,
                    "OutputFrequency": 1,
                    "BaseFrequency": 0,
                    "OutputCurrent": 1,
                    "NormalSpeed": 1,
                    "OutputVoltage": null,
                    "BaseVoltage": null,
                    "SlowSpeedOuter": null,
                    "SlowSpeedInner": null,
                    "AccelerationTime1st": null,
                    "AccelerationTime2nd": null,
                    "DecelerationTime1st": null,
                    "DecelerationTime2nd": null,
                    "BrakingTime": null,
                    "Braking": null
                }],
                "doorStatus": null
            }
            spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise);
            deferred.resolve(result);
            expect(scope.plcx_msg).toBe(undefined)
            scope.$digest();
            expect(scope.plcx_msg).toEqual('No data found for this Door');
            expect(scope.activeMenu).toEqual('primary')
        });

        it('should test if promise for EditDoorService.fetchDoorDetail is resolved', function() {
          spyOn(JSON, 'parse').and.returnValue({
              "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
              "userName": "BoonAdmin",
              "admin": true,
              "level1": false,
              "level2": false,
              "level3": false,
              "level4": false,
              "level5": false,
              "level6": false,
              "level7": false,
              "level8": false,
              "level9": true,
              "level10": false
          });
          var dummyElement = document.createElement('canvas');
          var id = document.createAttribute("id");
          id.value = 'stereovisionCanvas';
          dummyElement.setAttributeNode(id);
          var width = document.createAttribute("width");
          width.value = '176px';
          dummyElement.setAttributeNode(width);
          var height = document.createAttribute("height");
          height.value = '132px';
          dummyElement.setAttributeNode(height);
          spyOn(document, 'getElementById').and.returnValue(dummyElement);
          createController();
          expect(scope.stereovisionImgPath).toBe(undefined)
          var result = {"doorMain":[{"id":285,"nodeid":"MDA6MUY6N0I6QjI6MTQ6RDU=","DeviceID":"bc5137d1-98a6-4ce0-bca3-3a3ac9c219bb","ip_number":"127.0.0.1","mac_address":"00:1F:7B:B2:14:D5","hostname":"wandboard-dual","protocol":"AMQP","protocol_version":"3","time_first_seen":1473686858,"time_last_seen":1485843046,"lastupdateby":null,"snoozeExitTime":1484221143,"real_name":"Bylorus","location":"2","product_type":"Bylorus","last_state":null,"users":null,"ce_number":"toDefine","latitude":null,"longitude":null,"timezone":null,"campusId":20,"buildingId":17,"entranceId":22,"subentranceId":3383,"campusName":"Edam","buildingName":"Aambeeldstraat","entranceName":"Development","subEntranceName":"Upstairs","companyId":1,"info1":null,"info2":null,"assigned":1,"flag":null}],"transactionTimes":[],"rejectionCount":[],"timeOfFlight":[{"id":956,"DeviceId":"bc5137d1-98a6-4ce0-bca3-3a3ac9c219bb","EpochTime":1484212684,"Primary_Log_Capture":0,"Primary_Log_CaptureZero":0,"Primary_Log_CaptureOne":0,"Primary_Log_CaptureMore":0,"Primary_Log_CaptureSus":0,"Primary_Log_Still":0,"Primary_Log_StillZero":0,"Primary_Log_StillOne":0,"Primary_Log_StillMore":0,"Primary_Log_StillSus":0,"Primary_Log_OutputCounts":0,"Primary_OutputStatus_Authorization":0,"Primary_OutputStatus_Zero":0,"Primary_OutputStatus_One":0,"Primary_OutputStatus_More":0,"Primary_OutputStatus_Sus":0,"Primary_OutputStatus_Air":0,"Primary_Sensitivity_Volume":0,"Primary_Sensitivity_Moment":0,"Primary_Sensitivity_LowObject":0,"Primary_Sensitivity_SensorBlinding":0,"Primary_Sensitivity_OnePerson":0,"Primary_Sensitivity_MorePerson":0,"Primary_DoorSetting_SensorDirection":0,"Primary_DoorSetting_HeightUnderCanopy":0,"Primary_DoorSetting_Diameter":0,"Primary_DoorSetting_DoorOpen":0,"Primary_DoorSetting_DoorClose":0,"Primary_DoorSetting_VerificationDevice":0,"Primary_DoorSetting_WheelChair":0,"Primary_DoorSetting_ShaftPosition_X":0,"Primary_DoorSetting_ShaftPosition_Y":0,"Primary_DoorSetting_ShaftPosition1_X":55,"Primary_DoorSetting_ShaftPosition1_Y":55,"Primary_DoorSetting_ShaftPosition2_X":30,"Primary_DoorSetting_ShaftPosition2_Y":65,"Primary_DoorSetting_DoorPosition":0,"Primary_DoorSetting_OffsetAngle":0,"Primary_DoorSetting_TipOfEndPosition_X":0,"Primary_DoorSetting_TipOfEndPosition_Y":0,"Secondary_Log_Capture":0,"Secondary_Log_CaptureZero":0,"Secondary_Log_CaptureOne":0,"Secondary_Log_CaptureMore":0,"Secondary_Log_CaptureSus":0,"Secondary_Log_Still":0,"Secondary_Log_StillZero":0,"Secondary_Log_StillOne":0,"Secondary_Log_StillMore":0,"Secondary_Log_StillSus":0,"Secondary_Log_OutputCounts":0,"Secondary_OutputStatus_Authorization":0,"Secondary_OutputStatus_Zero":0,"Secondary_OutputStatus_One":0,"Secondary_OutputStatus_More":0,"Secondary_OutputStatus_Sus":0,"Secondary_OutputStatus_Air":0,"Secondary_Sensitivity_Volume":0,"Secondary_Sensitivity_Moment":0,"Secondary_Sensitivity_LowObject":0,"Secondary_Sensitivity_SensorBlinding":0,"Secondary_Sensitivity_OnePerson":0,"Secondary_Sensitivity_MorePerson":0,"Secondary_DoorSetting_SensorDirection":0,"Secondary_DoorSetting_HeightUnderCanopy":0,"Secondary_DoorSetting_Diameter":0,"Secondary_DoorSetting_DoorOpen":0,"Secondary_DoorSetting_DoorClose":0,"Secondary_DoorSetting_VerificationDevice":0,"Secondary_DoorSetting_WheelChair":0,"Secondary_DoorSetting_ShaftPosition_X":0,"Secondary_DoorSetting_ShaftPosition_Y":0,"Secondary_DoorSetting_ShaftPosition1_X":55,"Secondary_DoorSetting_ShaftPosition1_Y":55,"Secondary_DoorSetting_ShaftPosition2_X":30,"Secondary_DoorSetting_ShaftPosition2_Y":65,"Secondary_DoorSetting_DoorPosition":0,"Secondary_DoorSetting_OffsetAngle":0,"Secondary_DoorSetting_TipOfEndPosition_X":0,"Secondary_DoorSetting_TipOfEndPosition_Y":0}],"plc":[{"id":3831,"DeviceId":"bc5137d1-98a6-4ce0-bca3-3a3ac9c219bb","EpochTime":1485842500,"Alarm":0,"BiometricRejectionCount":0,"BothDoorsOpenCount":0,"Cleaning":0,"CleaningTime":1200,"DelayTimeNoOutputSV":0,"DoorForcedCount":0,"EndSwitchClosedInnerDoorDefective":0,"EndSwitchClosedOuterDoorDefective":0,"Event1st":0,"Event2nd":0,"Event3rd":0,"Event4th":0,"Event5th":0,"FireAlarmCount":0,"FireAlarmModeSet":2,"IllegalTime":26,"IllegalUse":16,"IRSensorHungCount":0,"IRSSensorDelay":25,"Locking":0,"LuminanceErrorDelay":0,"OnePersonInCount":0,"OpeningCounterInnerDoor":0,"OpeningCounterOuterDoor":0,"OpenTimeIn":51,"OpenTimeOut":52,"OverallTimeClosingInnerDoor":0,"OverallTimeClosingOuterDoor":0,"OverallTimeOpeningInnerDoor":0,"OverallTimeOpeningOuterDoor":0,"PowerLossCount":3,"PresenceDelay":21,"PulsesInCounter":0,"PulsesInSpecialCounter":0,"PulsesOutCounter":1,"PulsesOutSpecialCounter":0,"Reset":0,"ReturnSignalInTime":29,"ReturnSignalOutTime":23,"ReverseButtonActivation":0,"SafetyRailInnerDoorClosing":0,"SafetyRailOuterDoorClosing":0,"TimeExceededinCabinCount":21,"TimeExceededMax":160,"TimeOutTime":250,"TOF0PersonIn":0,"TOF0PersonOut":0,"TOF1PersonIn":0,"TOF1PersonOut":0,"TOF2PersonsIn":0,"TOF2PersonsOut":0,"TOFRejection":1,"TOFRejectionsIn":0,"TOFRejectionsOut":0,"TOFSuspiciousIn":5,"TOFSuspiciousOut":0,"EndSwitchOutsideClosed":0,"EndSwitchOutsideSlow":0,"EndSwitchOutsideOpen":0,"EndSwitchInsideClosed":0,"EndSwitchInsideSlow":0,"EndSwitchInsideOpen":0,"BiometricAccessGranted":0,"FireAlarm":1,"MotorThermalOverload":1,"PowerFailure":1,"EmergencyButton":0,"SafetyRail":1,"PulseIn":0,"PulseOut":0,"PulseInSpecial":0,"PulseOutSpecial":0,"BothDoorsOpen":0,"LockSwitch":1,"IrisScanEntryRejected":0,"InfraRedSensors":0,"SVSInOn":0,"SVSOutOn":0,"CleaningMode":0,"ResetSwitch":0,"EmptyDoorIn":0,"OnePersonIn":0,"TwoPersonIn":0,"SuspiciousIn":0,"AIRSensorsIn":0,"SVSEnabledIn":0,"EmptyDoorOut":0,"OnePersonOut":0,"TwoPersonOut":0,"SuspiciousOut":0,"AIRSensorsOut":0,"SVSEnabledOut":0,"ReturnSignalIn":1,"ReturnSignalOut":0,"MotorOuter":0,"MotorInner":0,"LockOuter":0,"LockInner":0,"MagLockOuter":0,"MagLockInner":0,"VFDForward":0,"VFDReverse":0,"VFDSpeedRef2and4":0,"VFDSpeedRef3and4":0,"VFDSecondAccDec":0,"TOFReset":0,"TOFShutdown":0,"GeneralAlarm":0,"SignalLEDGreenIn":0,"SignalLEDRedIn":0,"SignalLEDGreenOut":0,"SignalLEDRedOut":0,"AuthorizationIn":0,"AIRActiveIn":0,"AuthorizationOut":0,"AIRActiveOut":0,"TwoPersonRejection":0,"BiometricRejection":0,"TimeExceededInCabin":0,"SafetyRailActivation":1,"EmergencyButtonActivation":0,"PowerLoss":0,"IRSensorHung":0,"PersonInCabin":0,"BiometricStart":0,"OuterDoorClosed":0,"InnerDoorClosed":0,"EmergencyButtonLED":1,"Voice1":0,"Voice2":0,"SignalGreenInterior":0,"SignalRedInterior":0,"EnableBiometricEntry":0,"EnableBiometricExit":0,"AntiLockInButton":1,"AntiLockInButtonActivation":0,"AntiLockInButtonLED":0,"AntiLockInButtonActivationIn":0,"AntiLockInButtonActivationOut":0,"TimeExceededinCabinIn":0,"TimeExceededinCabinOut":0,"BiometricRejectionIn":0,"BiometricRejectionOut":0,"BiometricRejectionEntry":0,"BiometricStartEntry":0,"DoorForcedCountInside":0,"DoorForcedCountOutside":0,"EnableSVIn":1,"EnableSVOut":1,"IRSensorHungInside":0,"IRSensorHungOutside":0,"MaxAuthorisations":0}],"motorDrive":[{"id":260,"DeviceId":"bc5137d1-98a6-4ce0-bca3-3a3ac9c219bb","EpochTime":1485843046,"OutputFrequency":0,"BaseFrequency":3100,"OutputCurrent":0,"NormalSpeed":3600,"OutputVoltage":0,"BaseVoltage":760,"SlowSpeedOuter":600,"SlowSpeedInner":700,"AccelerationTime1st":9,"AccelerationTime2nd":8,"DecelerationTime1st":5,"DecelerationTime2nd":6,"BrakingTime":7,"Braking":110}],"doorStatus":null}
          spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise);
          deferred.resolve(result); // Resolve the promise.
          expect(scope.mtr_drive).toBe(undefined)
          scope.$digest();
          var editdoor = angular.copy(result.doorMain)
          scope.doordetail = editdoor[0];
          scope.getPrimaryData()
          $timeout.flush();
          expect(scope.stereovisionImgPath).toEqual('http://127.0.0.1/image_primary.png');
          expect(scope.activeMenu).toEqual('primary')
          expect(scope.checkModel.primary).toEqual(true)
          expect(scope.checkModel.secondary).toEqual(false)
          expect(scope.flag).toEqual(0)
          expect(scope.sliders.capture_counts).toEqual(result.timeOfFlight[0].Primary_Log_OutputCounts)
          expect(scope.sliders.height_canopy).toEqual(result.timeOfFlight[0].Primary_DoorSetting_HeightUnderCanopy)
          expect(scope.sliders.door_diameter).toEqual(result.timeOfFlight[0].Primary_DoorSetting_Diameter)
          expect(scope.sliders.capture_image).toEqual(result.timeOfFlight[0].Primary_Log_Capture)
          expect(scope.sliders.sensor_direction).toEqual(result.timeOfFlight[0].Primary_DoorSetting_SensorDirection)
          expect(scope.sliders.primary_door_setting_open).toEqual(result.timeOfFlight[0].Primary_DoorSetting_DoorOpen)
          expect(scope.sliders.primary_door_setting_close).toEqual(result.timeOfFlight[0].Primary_DoorSetting_DoorClose)
          expect(scope.sliders.wheel_chair).toEqual(result.timeOfFlight[0].Primary_DoorSetting_WheelChair)
          expect(scope.sliders.verification_device).toEqual(result.timeOfFlight[0].Primary_DoorSetting_VerificationDevice)
          expect(scope.sliders.lowObjValue).toEqual(result.timeOfFlight[0].Primary_Sensitivity_LowObject)
          expect(scope.sliders.blindingValue).toEqual(result.timeOfFlight[0].Primary_Sensitivity_SensorBlinding)
          expect(scope.sliders.onePersonValue).toEqual(result.timeOfFlight[0].Primary_Sensitivity_OnePerson)
          expect(scope.sliders.morePersonValue).toEqual(result.timeOfFlight[0].Primary_Sensitivity_MorePerson)
          expect(scope.sliders.volumeValue).toEqual(result.timeOfFlight[0].Primary_Sensitivity_Volume)
          expect(scope.sliders.momentValue).toEqual(result.timeOfFlight[0].Primary_Sensitivity_Moment)
          expect(scope.sliders.x_shaft_1x).toEqual(result.timeOfFlight[0].Primary_DoorSetting_ShaftPosition1_X)
          expect(scope.sliders.x_shaft_2x).toEqual(result.timeOfFlight[0].Primary_DoorSetting_ShaftPosition2_X)
          expect(scope.sliders.x_shaft_11x).toEqual(result.timeOfFlight[0].Primary_DoorSetting_ShaftPosition1_Y)
          expect(scope.sliders.x_shaft_22x).toEqual(result.timeOfFlight[0].Primary_DoorSetting_ShaftPosition2_Y)
          expect(scope.sliders.min).toEqual(1)
          expect(scope.sliders.max).toEqual(9)
          expect(scope.sliders.capture_counts).toEqual(result.timeOfFlight[0].Primary_Log_OutputCounts)
          expect(scope.sliders.capture_counts).toEqual(result.timeOfFlight[0].Primary_Log_OutputCounts)
          expect(scope.input1).toBeDefined()
          expect(scope.plc_data1[0].value).toEqual('5.1')
          expect(scope.plc_data1[1].value).toEqual('2.1')
          expect(scope.plc_data1[2].value).toEqual('25.0')
          expect(scope.plc_data1[3].value).toEqual(1)
          expect(scope.plc_data1[4].value).toEqual('5.2')
          expect(scope.plc_data1[5].value).toEqual('2.5')
          expect(scope.plc_data1[6].value).toEqual('2.6')
          expect(scope.plc_data1[7].value).toEqual(1)
          expect(scope.plc_data1[8].value).toEqual('2.9')
          expect(scope.plc_data1[9].value).toEqual('1.6')
          expect(scope.plc_data1[10].value).toEqual('120.0')
          expect(scope.plc_data1[11].value).toEqual('2.3')
          expect(scope.plc_data1[12].value).toEqual('16.0')
          expect(scope.plc_data1[13].value).toEqual(2)
          console.log(scope.mtr_drive)
          expect(scope.mtr_drive.output_frequency).toEqual(0)
          expect(scope.mtr_drive.base_frequency).toEqual('31.00')
          expect(scope.mtr_drive.normal_speed).toEqual('36.00')
          expect(scope.mtr_drive.base_voltage).toEqual('76.0')
          expect(scope.mtr_drive.slow_speed_outer).toEqual('6.00')
          expect(scope.mtr_drive.slow_speed_inner).toEqual('7.00')
          expect(scope.mtr_drive.aec_time_one).toEqual('0.9')
          expect(scope.mtr_drive.aec_time_two).toEqual('0.8')
          expect(scope.mtr_drive.dec_time_one).toEqual('0.5')
          expect(scope.mtr_drive.dec_time_two).toEqual('0.6')
          expect(scope.mtr_drive.break_time).toEqual('0.7')
          expect(scope.mtr_drive.break_percent).toEqual('11.0')

        });

        it('should test if promise is resolved if timeOfFlight is undefined ', function() {
          spyOn(JSON, 'parse').and.returnValue({
              "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
              "userName": "BoonAdmin",
              "admin": true,
              "level1": false,
              "level2": false,
              "level3": false,
              "level4": false,
              "level5": false,
              "level6": false,
              "level7": false,
              "level8": false,
              "level9": true,
              "level10": false
          });
          createController();
          var result = {
              "doorMain": [{
                  "id": 8,
                  "nodeid": "JAbmykU/TpSIAn6XF6PyP+Ub0JA=",
                  "DeviceID": "4",
                  "ip_number": "192.168.1.52",
                  "mac_address": "00:1f:7b:b2:14:d6",
                  "hostname": "",
                  "time_first_seen": 1454410566,
                  "time_last_seen": 1467491252,
                  "lastupdateby": "boonadmin",
                  "snoozeExitTime": 1467491852,
                  "real_name": "Bylorus RnD Wandbboard",
                  "location": "Aambeeldstraat",
                  "product_type": "Bylorus",
                  "last_state": "OK",
                  "users": "boon, walt",
                  "ce_number": "",
                  "latitude": "",
                  "longitude": "",
                  "timezone": null,
                  "campusId": "boonCampus",
                  "buildingId": "boonBuilding",
                  "entranceId": "boonEntrance",
                  "subEntranceId": "boonsub",
                  "campusName": "boonCampus",
                  "buildingName": null,
                  "entranceName": "boonEntrance",
                  "subEntranceName": "subEntranceT",
                  "companyId": 1,
                  "info1": "",
                  "info2": "",
                  "assigned": 1,
                  "flag": 0
              }],
              "transactionTimes": [],
              "rejectionCount": [],
              "timeOfFlight": [],
              "plc": [],
              "motorDrive": [],
              "doorStatus": null
          }
          spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise);
          deferred.resolve(result);
          scope.$digest();
          expect(scope.tof_msg).toEqual("No data found for this door.r")
          expect(scope.flag).toEqual(1)
        });

        it('should test if validateTimeFlight works as expected if scope.checkModel.secondary is false UPDATED', function() {
            var deffered_StereovisionImage = q.defer();
            spyOn(JSON, 'parse').and.returnValue({
                "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                "userName": "BoonAdmin",
                "admin": true,
                "level1": false,
                "level2": false,
                "level3": false,
                "level4": false,
                "level5": false,
                "level6": false,
                "level7": true,
                "level8": false,
                "level9": true,
                "level10": false
            });
            var dummyElement = document.createElement('canvas');
            var id = document.createAttribute("id");
            id.value = 'stereovisionCanvas';
            dummyElement.setAttributeNode(id);
            var width = document.createAttribute("width");
            width.value = '176px';
            dummyElement.setAttributeNode(width);
            var height = document.createAttribute("height");
            height.value = '132px';
            dummyElement.setAttributeNode(height);
            spyOn(document, 'getElementById').and.returnValue(dummyElement);
            createController();
            var result = {
                "success": true,
                "message": "Update successful.",
                "doorMain": [{
                    "id": 8,
                    "nodeid": "JAbmykU/TpSIAn6XF6PyP+Ub0JA=",
                    "DeviceID": "4",
                    "ip_number": "192.168.1.52",
                    "mac_address": "00:1f:7b:b2:14:d6",
                    "hostname": "",
                    "time_first_seen": 1454410566,
                    "time_last_seen": 1467491252,
                    "lastupdateby": "boonadmin",
                    "snoozeExitTime": 1467491852,
                    "real_name": "Bylorus RnD Wandbboard",
                    "location": "Aambeeldstraat",
                    "product_type": "Bylorus",
                    "last_state": "OK",
                    "users": "boon, walt",
                    "ce_number": "",
                    "latitude": "",
                    "longitude": "",
                    "timezone": null,
                    "campusId": "boonCampus",
                    "buildingId": "boonBuilding",
                    "entranceId": "boonEntrance",
                    "subEntranceId": "boonsub",
                    "campusName": "boonCampus",
                    "buildingName": null,
                    "entranceName": "boonEntrance",
                    "subEntranceName": "subEntranceT",
                    "companyId": 1,
                    "info1": "",
                    "info2": "",
                    "assigned": 1,
                    "flag": 0
                }],
                "transactionTimes": [],
                "rejectionCount": [],
                "timeOfFlight": [{
                    "id": 173,
                    "DeviceId": "4",
                    "EpochTime": 1467364984,
                    "Primary_Log_Capture": 0,
                    "Primary_Log_CaptureZero": 0,
                    "Primary_Log_CaptureOne": 0,
                    "Primary_Log_CaptureMore": 0,
                    "Primary_Log_CaptureSus": 0,
                    "Primary_Log_Still": 0,
                    "Primary_Log_StillZero": 0,
                    "Primary_Log_StillOne": 0,
                    "Primary_Log_StillMore": 0,
                    "Primary_Log_StillSus": 0,
                    "Primary_Log_OutputCounts": 0,
                    "Primary_OutputStatus_Authorization": 0,
                    "Primary_OutputStatus_Zero": 0,
                    "Primary_OutputStatus_One": 0,
                    "Primary_OutputStatus_More": 0,
                    "Primary_OutputStatus_Sus": 0,
                    "Primary_OutputStatus_Air": 0,
                    "Primary_Sensitivity_Volume": 5,
                    "Primary_Sensitivity_Moment": 4,
                    "Primary_Sensitivity_LowObject": 9,
                    "Primary_Sensitivity_SensorBlinding": 8,
                    "Primary_Sensitivity_OnePerson": 7,
                    "Primary_Sensitivity_MorePerson": 6,
                    "Primary_DoorSetting_SensorDirection": 0,
                    "Primary_DoorSetting_HeightUnderCanopy": 0,
                    "Primary_DoorSetting_Diameter": 0,
                    "Primary_DoorSetting_DoorOpen": 0,
                    "Primary_DoorSetting_DoorClose": 0,
                    "Primary_DoorSetting_VerificationDevice": 0,
                    "Primary_DoorSetting_WheelChair": 0,
                    "Primary_DoorSetting_ShaftPosition_X": 0,
                    "Primary_DoorSetting_ShaftPosition_Y": 0,
                    "Primary_DoorSetting_ShaftPosition1_X": 0,
                    "Primary_DoorSetting_ShaftPosition1_Y": 0,
                    "Primary_DoorSetting_ShaftPosition2_X": 0,
                    "Primary_DoorSetting_ShaftPosition2_Y": 0,
                    "Primary_DoorSetting_DoorPosition": 0,
                    "Primary_DoorSetting_OffsetAngle": 0,
                    "Primary_DoorSetting_TipOfEndPosition_X": 0,
                    "Primary_DoorSetting_TipOfEndPosition_Y": 0,
                    "Secondary_Log_Capture": 0,
                    "Secondary_Log_CaptureZero": 0,
                    "Secondary_Log_CaptureOne": 0,
                    "Secondary_Log_CaptureMore": 0,
                    "Secondary_Log_CaptureSus": 0,
                    "Secondary_Log_Still": 0,
                    "Secondary_Log_StillZero": 0,
                    "Secondary_Log_StillOne": 0,
                    "Secondary_Log_StillMore": 0,
                    "Secondary_Log_StillSus": 0,
                    "Secondary_Log_OutputCounts": 0,
                    "Secondary_OutputStatus_Authorization": 0,
                    "Secondary_OutputStatus_Zero": 0,
                    "Secondary_OutputStatus_One": 0,
                    "Secondary_OutputStatus_More": 0,
                    "Secondary_OutputStatus_Sus": 0,
                    "Secondary_OutputStatus_Air": 0,
                    "Secondary_Sensitivity_Volume": 0,
                    "Secondary_Sensitivity_Moment": 0,
                    "Secondary_Sensitivity_LowObject": 0,
                    "Secondary_Sensitivity_SensorBlinding": 0,
                    "Secondary_Sensitivity_OnePerson": 0,
                    "Secondary_Sensitivity_MorePerson": 0,
                    "Secondary_DoorSetting_SensorDirection": 0,
                    "Secondary_DoorSetting_HeightUnderCanopy": 0,
                    "Secondary_DoorSetting_Diameter": 0,
                    "Secondary_DoorSetting_DoorOpen": 0,
                    "Secondary_DoorSetting_DoorClose": 0,
                    "Secondary_DoorSetting_VerificationDevice": 0,
                    "Secondary_DoorSetting_WheelChair": 0,
                    "Secondary_DoorSetting_ShaftPosition_X": 0,
                    "Secondary_DoorSetting_ShaftPosition_Y": 0,
                    "Secondary_DoorSetting_ShaftPosition1_X": 0,
                    "Secondary_DoorSetting_ShaftPosition1_Y": 0,
                    "Secondary_DoorSetting_ShaftPosition2_X": 0,
                    "Secondary_DoorSetting_ShaftPosition2_Y": 0,
                    "Secondary_DoorSetting_DoorPosition": 0,
                    "Secondary_DoorSetting_OffsetAngle": 0,
                    "Secondary_DoorSetting_TipOfEndPosition_X": 0,
                    "Secondary_DoorSetting_TipOfEndPosition_Y": 0
                }],
                "plc": [{
                    "id": 3568,
                    "DeviceId": "4",
                    "EpochTime": 1466584246,
                    "Alarm": 0,
                    "BiometricRejectionCount": null,
                    "BothDoorsOpenCount": null,
                    "Cleaning": null,
                    "CleaningTime": 0,
                    "DelayTimeNoOutputSV": 0,
                    "DoorForcedCount": null,
                    "EndSwitchClosedInnerDoorDefective": 0,
                    "EndSwitchClosedOuterDoorDefective": 0,
                    "Event1st": 0,
                    "Event2nd": 0,
                    "Event3rd": 0,
                    "Event4th": 0,
                    "Event5th": 0,
                    "FireAlarmCount": null,
                    "FireAlarmModeSet": 0,
                    "IllegalTime": 0,
                    "IllegalUse": 0,
                    "IRSensorHungCount": null,
                    "IRSSensorDelay": 0,
                    "Locking": 0,
                    "LuminanceErrorDelay": 0,
                    "OnePersonInCount": null,
                    "OpeningCounterInnerDoor": 0,
                    "OpeningCounterOuterDoor": null,
                    "OpenTimeIn": 0,
                    "OpenTimeOut": 0,
                    "OverallTimeClosingInnerDoor": 0,
                    "OverallTimeClosingOuterDoor": 0,
                    "OverallTimeOpeningInnerDoor": 0,
                    "OverallTimeOpeningOuterDoor": 0,
                    "PowerLossCount": null,
                    "PresenceDelay": 0,
                    "PulsesInCounter": 0,
                    "PulsesInSpecialCounter": 0,
                    "PulsesOutCounter": 0,
                    "PulsesOutSpecialCounter": 0,
                    "Reset": 0,
                    "ReturnSignalInTime": 0,
                    "ReturnSignalOutTime": 0,
                    "ReverseButtonActivation": 0,
                    "SafetyRailInnerDoorClosing": 0,
                    "SafetyRailOuterDoorClosing": null,
                    "TimeExceededinCabinCount": null,
                    "TimeExceededMax": 0,
                    "TimeOutTime": 0,
                    "TOF0PersonIn": 0,
                    "TOF0PersonOut": 0,
                    "TOF1PersonIn": null,
                    "TOF1PersonOut": 0,
                    "TOF2PersonsIn": null,
                    "TOF2PersonsOut": 0,
                    "TOFRejection": 0,
                    "TOFRejectionsIn": null,
                    "TOFRejectionsOut": null,
                    "TOFSuspiciousIn": 0,
                    "TOFSuspiciousOut": 0,
                    "EndSwitchOutsideClosed": 0,
                    "EndSwitchOutsideSlow": 0,
                    "EndSwitchOutsideOpen": 0,
                    "EndSwitchInsideClosed": 0,
                    "EndSwitchInsideSlow": 0,
                    "EndSwitchInsideOpen": 0,
                    "BiometricAccessGranted": 0,
                    "FireAlarm": 0,
                    "MotorThermalOverload": 0,
                    "PowerFailure": 0,
                    "EmergencyButton": 0,
                    "SafetyRail": 0,
                    "PulseIn": 0,
                    "PulseOut": 0,
                    "PulseInSpecial": 0,
                    "PulseOutSpecial": 0,
                    "BothDoorsOpen": 0,
                    "LockSwitch": 0,
                    "IrisScanEntryRejected": null,
                    "InfraRedSensors": 0,
                    "SVSInOn": 0,
                    "SVSOutOn": 0,
                    "CleaningMode": 0,
                    "ResetSwitch": 0,
                    "EmptyDoorIn": 0,
                    "OnePersonIn": 0,
                    "TwoPersonIn": 0,
                    "SuspiciousIn": 0,
                    "AIRSensorsIn": 0,
                    "SVSEnabledIn": 0,
                    "EmptyDoorOut": 0,
                    "OnePersonOut": 0,
                    "TwoPersonOut": 0,
                    "SuspiciousOut": 0,
                    "AIRSensorsOut": 0,
                    "SVSEnabledOut": 0,
                    "ReturnSignalIn": 0,
                    "ReturnSignalOut": 0,
                    "MotorOuter": null,
                    "MotorInner": null,
                    "LockOuter": null,
                    "LockInner": null,
                    "MagLockOuter": null,
                    "MagLockInner": null,
                    "VFDForward": 0,
                    "VFDReverse": 0,
                    "VFDSpeedRef2and4": 0,
                    "VFDSpeedRef3and4": 0,
                    "VFDSecondAccDec": null,
                    "TOFReset": 0,
                    "TOFShutdown": 0,
                    "GeneralAlarm": 0,
                    "SignalLEDGreenIn": 0,
                    "SignalLEDRedIn": 0,
                    "SignalLEDGreenOut": 0,
                    "SignalLEDRedOut": 0,
                    "AuthorizationIn": 0,
                    "AIRActiveIn": 0,
                    "AuthorizationOut": 0,
                    "AIRActiveOut": 0,
                    "TwoPersonRejection": 0,
                    "BiometricRejection": 0,
                    "TimeExceededInCabin": 0,
                    "SafetyRailActivation": 0,
                    "EmergencyButtonActivation": 0,
                    "PowerLoss": 0,
                    "IRSensorHung": 0,
                    "PersonInCabin": null,
                    "BiometricStart": 0,
                    "OuterDoorClosed": 0,
                    "InnerDoorClosed": 0,
                    "EmergencyButtonLED": 0,
                    "Voice1": 0,
                    "Voice2": 0,
                    "SignalGreenInterior": 0,
                    "SignalRedInterior": 0,
                    "EnableBiometricEntry": null,
                    "EnableBiometricExit": null
                }],
                "motorDrive": [{
                    "id": 11,
                    "DeviceId": "4",
                    "EpochTime": 1466584661,
                    "OutputFrequency": 1,
                    "BaseFrequency": 0,
                    "OutputCurrent": 1,
                    "NormalSpeed": 1,
                    "OutputVoltage": null,
                    "BaseVoltage": null,
                    "SlowSpeedOuter": null,
                    "SlowSpeedInner": null,
                    "AccelerationTime1st": null,
                    "AccelerationTime2nd": null,
                    "DecelerationTime1st": null,
                    "DecelerationTime2nd": null,
                    "BrakingTime": null,
                    "Braking": null
                }],
                "doorStatus": null
            }
            var timeofflight = {
                "Primary_Log_Capture": 0,
                "Primary_Log_OutputCounts": "1",
                "Primary_DoorSetting_HeightUnderCanopy": 2000,
                "Primary_DoorSetting_Diameter": 1800,
                "Primary_DoorSetting_SensorDirection": 0,
                "Primary_DoorSetting_DoorOpen": 0,
                "Primary_DoorSetting_DoorClose": 0,
                "Primary_DoorSetting_WheelChair": 0,
                "Primary_DoorSetting_VerificationDevice": 0,
                "Primary_Sensitivity_LowObject": 5,
                "Primary_Sensitivity_SensorBlinding": 5,
                "Primary_Sensitivity_OnePerson": 5,
                "Primary_Sensitivity_MorePerson": 4,
                "Primary_Sensitivity_Volume": 6,
                "Primary_Sensitivity_Moment": 5,
                "Primary_DoorSetting_ShaftPosition1_X": 0,
                "Primary_DoorSetting_ShaftPosition2_X": 0,
                "Primary_DoorSetting_ShaftPosition1_Y": 0,
                "Primary_DoorSetting_ShaftPosition2_Y": 0
            }
            scope.sliders = {
                capture_counts: timeofflight.Primary_Log_OutputCounts,
                height_canopy: timeofflight.Primary_DoorSetting_HeightUnderCanopy,
                door_diameter: timeofflight.Primary_DoorSetting_Diameter,
                capture_image: timeofflight.Primary_Log_Capture,
                sensor_direction: timeofflight.Primary_DoorSetting_SensorDirection,
                primary_door_setting_open: timeofflight.Primary_DoorSetting_DoorOpen,
                primary_door_setting_close: timeofflight.Primary_DoorSetting_DoorClose,
                wheel_chair: timeofflight.Primary_DoorSetting_WheelChair,
                verification_device: timeofflight.Primary_DoorSetting_VerificationDevice,
                lowObjValue: timeofflight.Primary_Sensitivity_LowObject,
                blindingValue: timeofflight.Primary_Sensitivity_SensorBlinding,
                onePersonValue: timeofflight.Primary_Sensitivity_OnePerson,
                morePersonValue: timeofflight.Primary_Sensitivity_MorePerson,
                volumeValue: timeofflight.Primary_Sensitivity_Volume,
                momentValue: timeofflight.Primary_Sensitivity_Moment,
                x_shaft_1x: timeofflight.Primary_DoorSetting_ShaftPosition1_X,
                x_shaft_2x: timeofflight.Primary_DoorSetting_ShaftPosition2_X,
                x_shaft_11x: timeofflight.Primary_DoorSetting_ShaftPosition1_Y,
                x_shaft_22x: timeofflight.Primary_DoorSetting_ShaftPosition2_Y,
                min: 1,
                max: 9
            }
            spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise)
            spyOn(mockEditDoorService, 'putTimeofFlight').and.returnValue(deferred.promise);
            spyOn(mockEditDoorService, 'updateStereovisionImage').and.returnValue(deffered_StereovisionImage.promise);
            scope.validateTimeFlight()
            deferred.resolve(result); // Resolve the promise.
            scope.$digest();
            scope.validateTimeFlight()
            expect(scope.tof_message).toEqual(result.message)
            expect(scope.status).toEqual('success')
            scope.checkModel.primary = true;
            scope.recaptureImage()
            $timeout.flush();
            deffered_StereovisionImage.resolve(result);
            scope.$digest();
        });

        it('should test if validateTimeFlight works as expected if incorrect data is returned', function() {
            var deffered_StereovisionImage = q.defer();
            spyOn(JSON, 'parse').and.returnValue({
                "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                "userName": "BoonAdmin",
                "admin": true,
                "level1": false,
                "level2": false,
                "level3": false,
                "level4": false,
                "level5": false,
                "level6": false,
                "level7": true,
                "level8": false,
                "level9": true,
                "level10": false
            });
            var dummyElement = document.createElement('canvas');
            var id = document.createAttribute("id");
            id.value = 'stereovisionCanvas';
            dummyElement.setAttributeNode(id);
            var width = document.createAttribute("width");
            width.value = '176px';
            dummyElement.setAttributeNode(width);
            var height = document.createAttribute("height");
            height.value = '132px';
            dummyElement.setAttributeNode(height);
            spyOn(document, 'getElementById').and.returnValue(dummyElement);
            createController();
            var result = {
                "message": "Update successful.",
                "doorMain": [{
                    "id": 8,
                    "nodeid": "JAbmykU/TpSIAn6XF6PyP+Ub0JA=",
                    "DeviceID": "4",
                    "ip_number": "192.168.1.52",
                    "mac_address": "00:1f:7b:b2:14:d6",
                    "hostname": "",
                    "time_first_seen": 1454410566,
                    "time_last_seen": 1467491252,
                    "lastupdateby": "boonadmin",
                    "snoozeExitTime": 1467491852,
                    "real_name": "Bylorus RnD Wandbboard",
                    "location": "Aambeeldstraat",
                    "product_type": "Bylorus",
                    "last_state": "OK",
                    "users": "boon, walt",
                    "ce_number": "",
                    "latitude": "",
                    "longitude": "",
                    "timezone": null,
                    "campusId": "boonCampus",
                    "buildingId": "boonBuilding",
                    "entranceId": "boonEntrance",
                    "subEntranceId": "boonsub",
                    "campusName": "boonCampus",
                    "buildingName": null,
                    "entranceName": "boonEntrance",
                    "subEntranceName": "subEntranceT",
                    "companyId": 1,
                    "info1": "",
                    "info2": "",
                    "assigned": 1,
                    "flag": 0
                }],
                "transactionTimes": [],
                "rejectionCount": [],
                "timeOfFlight": [{
                    "id": 173,
                    "DeviceId": "4",
                    "EpochTime": 1467364984,
                    "Primary_Log_Capture": 0,
                    "Primary_Log_CaptureZero": 0,
                    "Primary_Log_CaptureOne": 0,
                    "Primary_Log_CaptureMore": 0,
                    "Primary_Log_CaptureSus": 0,
                    "Primary_Log_Still": 0,
                    "Primary_Log_StillZero": 0,
                    "Primary_Log_StillOne": 0,
                    "Primary_Log_StillMore": 0,
                    "Primary_Log_StillSus": 0,
                    "Primary_Log_OutputCounts": 0,
                    "Primary_OutputStatus_Authorization": 0,
                    "Primary_OutputStatus_Zero": 0,
                    "Primary_OutputStatus_One": 0,
                    "Primary_OutputStatus_More": 0,
                    "Primary_OutputStatus_Sus": 0,
                    "Primary_OutputStatus_Air": 0,
                    "Primary_Sensitivity_Volume": 5,
                    "Primary_Sensitivity_Moment": 4,
                    "Primary_Sensitivity_LowObject": 9,
                    "Primary_Sensitivity_SensorBlinding": 8,
                    "Primary_Sensitivity_OnePerson": 7,
                    "Primary_Sensitivity_MorePerson": 6,
                    "Primary_DoorSetting_SensorDirection": 0,
                    "Primary_DoorSetting_HeightUnderCanopy": 0,
                    "Primary_DoorSetting_Diameter": 0,
                    "Primary_DoorSetting_DoorOpen": 0,
                    "Primary_DoorSetting_DoorClose": 0,
                    "Primary_DoorSetting_VerificationDevice": 0,
                    "Primary_DoorSetting_WheelChair": 0,
                    "Primary_DoorSetting_ShaftPosition_X": 0,
                    "Primary_DoorSetting_ShaftPosition_Y": 0,
                    "Primary_DoorSetting_ShaftPosition1_X": 0,
                    "Primary_DoorSetting_ShaftPosition1_Y": 0,
                    "Primary_DoorSetting_ShaftPosition2_X": 0,
                    "Primary_DoorSetting_ShaftPosition2_Y": 0,
                    "Primary_DoorSetting_DoorPosition": 0,
                    "Primary_DoorSetting_OffsetAngle": 0,
                    "Primary_DoorSetting_TipOfEndPosition_X": 0,
                    "Primary_DoorSetting_TipOfEndPosition_Y": 0,
                    "Secondary_Log_Capture": 0,
                    "Secondary_Log_CaptureZero": 0,
                    "Secondary_Log_CaptureOne": 0,
                    "Secondary_Log_CaptureMore": 0,
                    "Secondary_Log_CaptureSus": 0,
                    "Secondary_Log_Still": 0,
                    "Secondary_Log_StillZero": 0,
                    "Secondary_Log_StillOne": 0,
                    "Secondary_Log_StillMore": 0,
                    "Secondary_Log_StillSus": 0,
                    "Secondary_Log_OutputCounts": 0,
                    "Secondary_OutputStatus_Authorization": 0,
                    "Secondary_OutputStatus_Zero": 0,
                    "Secondary_OutputStatus_One": 0,
                    "Secondary_OutputStatus_More": 0,
                    "Secondary_OutputStatus_Sus": 0,
                    "Secondary_OutputStatus_Air": 0,
                    "Secondary_Sensitivity_Volume": 0,
                    "Secondary_Sensitivity_Moment": 0,
                    "Secondary_Sensitivity_LowObject": 0,
                    "Secondary_Sensitivity_SensorBlinding": 0,
                    "Secondary_Sensitivity_OnePerson": 0,
                    "Secondary_Sensitivity_MorePerson": 0,
                    "Secondary_DoorSetting_SensorDirection": 0,
                    "Secondary_DoorSetting_HeightUnderCanopy": 0,
                    "Secondary_DoorSetting_Diameter": 0,
                    "Secondary_DoorSetting_DoorOpen": 0,
                    "Secondary_DoorSetting_DoorClose": 0,
                    "Secondary_DoorSetting_VerificationDevice": 0,
                    "Secondary_DoorSetting_WheelChair": 0,
                    "Secondary_DoorSetting_ShaftPosition_X": 0,
                    "Secondary_DoorSetting_ShaftPosition_Y": 0,
                    "Secondary_DoorSetting_ShaftPosition1_X": 0,
                    "Secondary_DoorSetting_ShaftPosition1_Y": 0,
                    "Secondary_DoorSetting_ShaftPosition2_X": 0,
                    "Secondary_DoorSetting_ShaftPosition2_Y": 0,
                    "Secondary_DoorSetting_DoorPosition": 0,
                    "Secondary_DoorSetting_OffsetAngle": 0,
                    "Secondary_DoorSetting_TipOfEndPosition_X": 0,
                    "Secondary_DoorSetting_TipOfEndPosition_Y": 0
                }],
                "plc": [{
                    "id": 3568,
                    "DeviceId": "4",
                    "EpochTime": 1466584246,
                    "Alarm": 0,
                    "BiometricRejectionCount": null,
                    "BothDoorsOpenCount": null,
                    "Cleaning": null,
                    "CleaningTime": 0,
                    "DelayTimeNoOutputSV": 0,
                    "DoorForcedCount": null,
                    "EndSwitchClosedInnerDoorDefective": 0,
                    "EndSwitchClosedOuterDoorDefective": 0,
                    "Event1st": 0,
                    "Event2nd": 0,
                    "Event3rd": 0,
                    "Event4th": 0,
                    "Event5th": 0,
                    "FireAlarmCount": null,
                    "FireAlarmModeSet": 0,
                    "IllegalTime": 0,
                    "IllegalUse": 0,
                    "IRSensorHungCount": null,
                    "IRSSensorDelay": 0,
                    "Locking": 0,
                    "LuminanceErrorDelay": 0,
                    "OnePersonInCount": null,
                    "OpeningCounterInnerDoor": 0,
                    "OpeningCounterOuterDoor": null,
                    "OpenTimeIn": 0,
                    "OpenTimeOut": 0,
                    "OverallTimeClosingInnerDoor": 0,
                    "OverallTimeClosingOuterDoor": 0,
                    "OverallTimeOpeningInnerDoor": 0,
                    "OverallTimeOpeningOuterDoor": 0,
                    "PowerLossCount": null,
                    "PresenceDelay": 0,
                    "PulsesInCounter": 0,
                    "PulsesInSpecialCounter": 0,
                    "PulsesOutCounter": 0,
                    "PulsesOutSpecialCounter": 0,
                    "Reset": 0,
                    "ReturnSignalInTime": 0,
                    "ReturnSignalOutTime": 0,
                    "ReverseButtonActivation": 0,
                    "SafetyRailInnerDoorClosing": 0,
                    "SafetyRailOuterDoorClosing": null,
                    "TimeExceededinCabinCount": null,
                    "TimeExceededMax": 0,
                    "TimeOutTime": 0,
                    "TOF0PersonIn": 0,
                    "TOF0PersonOut": 0,
                    "TOF1PersonIn": null,
                    "TOF1PersonOut": 0,
                    "TOF2PersonsIn": null,
                    "TOF2PersonsOut": 0,
                    "TOFRejection": 0,
                    "TOFRejectionsIn": null,
                    "TOFRejectionsOut": null,
                    "TOFSuspiciousIn": 0,
                    "TOFSuspiciousOut": 0,
                    "EndSwitchOutsideClosed": 0,
                    "EndSwitchOutsideSlow": 0,
                    "EndSwitchOutsideOpen": 0,
                    "EndSwitchInsideClosed": 0,
                    "EndSwitchInsideSlow": 0,
                    "EndSwitchInsideOpen": 0,
                    "BiometricAccessGranted": 0,
                    "FireAlarm": 0,
                    "MotorThermalOverload": 0,
                    "PowerFailure": 0,
                    "EmergencyButton": 0,
                    "SafetyRail": 0,
                    "PulseIn": 0,
                    "PulseOut": 0,
                    "PulseInSpecial": 0,
                    "PulseOutSpecial": 0,
                    "BothDoorsOpen": 0,
                    "LockSwitch": 0,
                    "IrisScanEntryRejected": null,
                    "InfraRedSensors": 0,
                    "SVSInOn": 0,
                    "SVSOutOn": 0,
                    "CleaningMode": 0,
                    "ResetSwitch": 0,
                    "EmptyDoorIn": 0,
                    "OnePersonIn": 0,
                    "TwoPersonIn": 0,
                    "SuspiciousIn": 0,
                    "AIRSensorsIn": 0,
                    "SVSEnabledIn": 0,
                    "EmptyDoorOut": 0,
                    "OnePersonOut": 0,
                    "TwoPersonOut": 0,
                    "SuspiciousOut": 0,
                    "AIRSensorsOut": 0,
                    "SVSEnabledOut": 0,
                    "ReturnSignalIn": 0,
                    "ReturnSignalOut": 0,
                    "MotorOuter": null,
                    "MotorInner": null,
                    "LockOuter": null,
                    "LockInner": null,
                    "MagLockOuter": null,
                    "MagLockInner": null,
                    "VFDForward": 0,
                    "VFDReverse": 0,
                    "VFDSpeedRef2and4": 0,
                    "VFDSpeedRef3and4": 0,
                    "VFDSecondAccDec": null,
                    "TOFReset": 0,
                    "TOFShutdown": 0,
                    "GeneralAlarm": 0,
                    "SignalLEDGreenIn": 0,
                    "SignalLEDRedIn": 0,
                    "SignalLEDGreenOut": 0,
                    "SignalLEDRedOut": 0,
                    "AuthorizationIn": 0,
                    "AIRActiveIn": 0,
                    "AuthorizationOut": 0,
                    "AIRActiveOut": 0,
                    "TwoPersonRejection": 0,
                    "BiometricRejection": 0,
                    "TimeExceededInCabin": 0,
                    "SafetyRailActivation": 0,
                    "EmergencyButtonActivation": 0,
                    "PowerLoss": 0,
                    "IRSensorHung": 0,
                    "PersonInCabin": null,
                    "BiometricStart": 0,
                    "OuterDoorClosed": 0,
                    "InnerDoorClosed": 0,
                    "EmergencyButtonLED": 0,
                    "Voice1": 0,
                    "Voice2": 0,
                    "SignalGreenInterior": 0,
                    "SignalRedInterior": 0,
                    "EnableBiometricEntry": null,
                    "EnableBiometricExit": null
                }],
                "motorDrive": [{
                    "id": 11,
                    "DeviceId": "4",
                    "EpochTime": 1466584661,
                    "OutputFrequency": 1,
                    "BaseFrequency": 0,
                    "OutputCurrent": 1,
                    "NormalSpeed": 1,
                    "OutputVoltage": null,
                    "BaseVoltage": null,
                    "SlowSpeedOuter": null,
                    "SlowSpeedInner": null,
                    "AccelerationTime1st": null,
                    "AccelerationTime2nd": null,
                    "DecelerationTime1st": null,
                    "DecelerationTime2nd": null,
                    "BrakingTime": null,
                    "Braking": null
                }],
                "doorStatus": null
            }
            var timeofflight = {
                "Primary_Log_Capture": 0,
                "Primary_Log_OutputCounts": "1",
                "Primary_DoorSetting_HeightUnderCanopy": 2000,
                "Primary_DoorSetting_Diameter": 1800,
                "Primary_DoorSetting_SensorDirection": 0,
                "Primary_DoorSetting_DoorOpen": 0,
                "Primary_DoorSetting_DoorClose": 0,
                "Primary_DoorSetting_WheelChair": 0,
                "Primary_DoorSetting_VerificationDevice": 0,
                "Primary_Sensitivity_LowObject": 5,
                "Primary_Sensitivity_SensorBlinding": 5,
                "Primary_Sensitivity_OnePerson": 5,
                "Primary_Sensitivity_MorePerson": 4,
                "Primary_Sensitivity_Volume": 6,
                "Primary_Sensitivity_Moment": 5,
                "Primary_DoorSetting_ShaftPosition1_X": 0,
                "Primary_DoorSetting_ShaftPosition2_X": 0,
                "Primary_DoorSetting_ShaftPosition1_Y": 0,
                "Primary_DoorSetting_ShaftPosition2_Y": 0
            }
            scope.sliders = {
                capture_counts: timeofflight.Primary_Log_OutputCounts,
                height_canopy: timeofflight.Primary_DoorSetting_HeightUnderCanopy,
                door_diameter: timeofflight.Primary_DoorSetting_Diameter,
                capture_image: timeofflight.Primary_Log_Capture,
                sensor_direction: timeofflight.Primary_DoorSetting_SensorDirection,
                primary_door_setting_open: timeofflight.Primary_DoorSetting_DoorOpen,
                primary_door_setting_close: timeofflight.Primary_DoorSetting_DoorClose,
                wheel_chair: timeofflight.Primary_DoorSetting_WheelChair,
                verification_device: timeofflight.Primary_DoorSetting_VerificationDevice,
                lowObjValue: timeofflight.Primary_Sensitivity_LowObject,
                blindingValue: timeofflight.Primary_Sensitivity_SensorBlinding,
                onePersonValue: timeofflight.Primary_Sensitivity_OnePerson,
                morePersonValue: timeofflight.Primary_Sensitivity_MorePerson,
                volumeValue: timeofflight.Primary_Sensitivity_Volume,
                momentValue: timeofflight.Primary_Sensitivity_Moment,
                x_shaft_1x: timeofflight.Primary_DoorSetting_ShaftPosition1_X,
                x_shaft_2x: timeofflight.Primary_DoorSetting_ShaftPosition2_X,
                x_shaft_11x: timeofflight.Primary_DoorSetting_ShaftPosition1_Y,
                x_shaft_22x: timeofflight.Primary_DoorSetting_ShaftPosition2_Y,
                min: 1,
                max: 9
            }
            spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise)
            spyOn(mockEditDoorService, 'putTimeofFlight').and.returnValue(deferred.promise);
            spyOn(mockEditDoorService, 'updateStereovisionImage').and.returnValue(deffered_StereovisionImage.promise);
            scope.validateTimeFlight()
            deferred.resolve(result); // Resolve the promise.
            scope.$digest();
            scope.validateTimeFlight()
            expect(scope.tof_message).toEqual(result.message)
            expect(scope.status).toEqual('failed')
            scope.checkModel.primary = true;
            // scope.recaptureImage()
            // $timeout.flush();
            deffered_StereovisionImage.resolve(result);
            scope.$digest();
        });

        it('should test if validateTimeFlight works as expected if scope.checkModel.secondary is false', function() {
            spyOn(JSON, 'parse').and.returnValue({
                "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                "userName": "BoonAdmin",
                "admin": true,
                "level1": false,
                "level2": false,
                "level3": false,
                "level4": false,
                "level5": false,
                "level6": false,
                "level7": false,
                "level8": false,
                "level9": true,
                "level10": false
            });
            var dummyElement = document.createElement('canvas');
            var id = document.createAttribute("id");
            id.value = 'stereovisionCanvas';
            dummyElement.setAttributeNode(id);
            var width = document.createAttribute("width");
            width.value = '176px';
            dummyElement.setAttributeNode(width);
            var height = document.createAttribute("height");
            height.value = '132px';
            dummyElement.setAttributeNode(height);
            spyOn(document, 'getElementById').and.returnValue(dummyElement);
            createController();
            var result = {
                "success": true,
                "message": "Update successful.",
                "doorMain": [{
                    "id": 8,
                    "nodeid": "JAbmykU/TpSIAn6XF6PyP+Ub0JA=",
                    "DeviceID": "4",
                    "ip_number": "192.168.1.52",
                    "mac_address": "00:1f:7b:b2:14:d6",
                    "hostname": "",
                    "time_first_seen": 1454410566,
                    "time_last_seen": 1467491252,
                    "lastupdateby": "boonadmin",
                    "snoozeExitTime": 1467491852,
                    "real_name": "Bylorus RnD Wandbboard",
                    "location": "Aambeeldstraat",
                    "product_type": "Bylorus",
                    "last_state": "OK",
                    "users": "boon, walt",
                    "ce_number": "",
                    "latitude": "",
                    "longitude": "",
                    "timezone": null,
                    "campusId": "boonCampus",
                    "buildingId": "boonBuilding",
                    "entranceId": "boonEntrance",
                    "subEntranceId": "boonsub",
                    "campusName": "boonCampus",
                    "buildingName": null,
                    "entranceName": "boonEntrance",
                    "subEntranceName": "subEntranceT",
                    "companyId": 1,
                    "info1": "",
                    "info2": "",
                    "assigned": 1,
                    "flag": 0
                }],
                "transactionTimes": [],
                "rejectionCount": [],
                "timeOfFlight": [{
                    "id": 173,
                    "DeviceId": "4",
                    "EpochTime": 1467364984,
                    "Primary_Log_Capture": 0,
                    "Primary_Log_CaptureZero": 0,
                    "Primary_Log_CaptureOne": 0,
                    "Primary_Log_CaptureMore": 0,
                    "Primary_Log_CaptureSus": 0,
                    "Primary_Log_Still": 0,
                    "Primary_Log_StillZero": 0,
                    "Primary_Log_StillOne": 0,
                    "Primary_Log_StillMore": 0,
                    "Primary_Log_StillSus": 0,
                    "Primary_Log_OutputCounts": 0,
                    "Primary_OutputStatus_Authorization": 0,
                    "Primary_OutputStatus_Zero": 0,
                    "Primary_OutputStatus_One": 0,
                    "Primary_OutputStatus_More": 0,
                    "Primary_OutputStatus_Sus": 0,
                    "Primary_OutputStatus_Air": 0,
                    "Primary_Sensitivity_Volume": 5,
                    "Primary_Sensitivity_Moment": 4,
                    "Primary_Sensitivity_LowObject": 9,
                    "Primary_Sensitivity_SensorBlinding": 8,
                    "Primary_Sensitivity_OnePerson": 7,
                    "Primary_Sensitivity_MorePerson": 6,
                    "Primary_DoorSetting_SensorDirection": 0,
                    "Primary_DoorSetting_HeightUnderCanopy": 0,
                    "Primary_DoorSetting_Diameter": 0,
                    "Primary_DoorSetting_DoorOpen": 0,
                    "Primary_DoorSetting_DoorClose": 0,
                    "Primary_DoorSetting_VerificationDevice": 0,
                    "Primary_DoorSetting_WheelChair": 0,
                    "Primary_DoorSetting_ShaftPosition_X": 0,
                    "Primary_DoorSetting_ShaftPosition_Y": 0,
                    "Primary_DoorSetting_ShaftPosition1_X": 0,
                    "Primary_DoorSetting_ShaftPosition1_Y": 0,
                    "Primary_DoorSetting_ShaftPosition2_X": 0,
                    "Primary_DoorSetting_ShaftPosition2_Y": 0,
                    "Primary_DoorSetting_DoorPosition": 0,
                    "Primary_DoorSetting_OffsetAngle": 0,
                    "Primary_DoorSetting_TipOfEndPosition_X": 0,
                    "Primary_DoorSetting_TipOfEndPosition_Y": 0,
                    "Secondary_Log_Capture": 0,
                    "Secondary_Log_CaptureZero": 0,
                    "Secondary_Log_CaptureOne": 0,
                    "Secondary_Log_CaptureMore": 0,
                    "Secondary_Log_CaptureSus": 0,
                    "Secondary_Log_Still": 0,
                    "Secondary_Log_StillZero": 0,
                    "Secondary_Log_StillOne": 0,
                    "Secondary_Log_StillMore": 0,
                    "Secondary_Log_StillSus": 0,
                    "Secondary_Log_OutputCounts": 0,
                    "Secondary_OutputStatus_Authorization": 0,
                    "Secondary_OutputStatus_Zero": 0,
                    "Secondary_OutputStatus_One": 0,
                    "Secondary_OutputStatus_More": 0,
                    "Secondary_OutputStatus_Sus": 0,
                    "Secondary_OutputStatus_Air": 0,
                    "Secondary_Sensitivity_Volume": 0,
                    "Secondary_Sensitivity_Moment": 0,
                    "Secondary_Sensitivity_LowObject": 0,
                    "Secondary_Sensitivity_SensorBlinding": 0,
                    "Secondary_Sensitivity_OnePerson": 0,
                    "Secondary_Sensitivity_MorePerson": 0,
                    "Secondary_DoorSetting_SensorDirection": 0,
                    "Secondary_DoorSetting_HeightUnderCanopy": 0,
                    "Secondary_DoorSetting_Diameter": 0,
                    "Secondary_DoorSetting_DoorOpen": 0,
                    "Secondary_DoorSetting_DoorClose": 0,
                    "Secondary_DoorSetting_VerificationDevice": 0,
                    "Secondary_DoorSetting_WheelChair": 0,
                    "Secondary_DoorSetting_ShaftPosition_X": 0,
                    "Secondary_DoorSetting_ShaftPosition_Y": 0,
                    "Secondary_DoorSetting_ShaftPosition1_X": 0,
                    "Secondary_DoorSetting_ShaftPosition1_Y": 0,
                    "Secondary_DoorSetting_ShaftPosition2_X": 0,
                    "Secondary_DoorSetting_ShaftPosition2_Y": 0,
                    "Secondary_DoorSetting_DoorPosition": 0,
                    "Secondary_DoorSetting_OffsetAngle": 0,
                    "Secondary_DoorSetting_TipOfEndPosition_X": 0,
                    "Secondary_DoorSetting_TipOfEndPosition_Y": 0
                }],
                "plc": [{
                    "id": 3568,
                    "DeviceId": "4",
                    "EpochTime": 1466584246,
                    "Alarm": 0,
                    "BiometricRejectionCount": null,
                    "BothDoorsOpenCount": null,
                    "Cleaning": null,
                    "CleaningTime": 0,
                    "DelayTimeNoOutputSV": 0,
                    "DoorForcedCount": null,
                    "EndSwitchClosedInnerDoorDefective": 0,
                    "EndSwitchClosedOuterDoorDefective": 0,
                    "Event1st": 0,
                    "Event2nd": 0,
                    "Event3rd": 0,
                    "Event4th": 0,
                    "Event5th": 0,
                    "FireAlarmCount": null,
                    "FireAlarmModeSet": 0,
                    "IllegalTime": 0,
                    "IllegalUse": 0,
                    "IRSensorHungCount": null,
                    "IRSSensorDelay": 0,
                    "Locking": 0,
                    "LuminanceErrorDelay": 0,
                    "OnePersonInCount": null,
                    "OpeningCounterInnerDoor": 0,
                    "OpeningCounterOuterDoor": null,
                    "OpenTimeIn": 0,
                    "OpenTimeOut": 0,
                    "OverallTimeClosingInnerDoor": 0,
                    "OverallTimeClosingOuterDoor": 0,
                    "OverallTimeOpeningInnerDoor": 0,
                    "OverallTimeOpeningOuterDoor": 0,
                    "PowerLossCount": null,
                    "PresenceDelay": 0,
                    "PulsesInCounter": 0,
                    "PulsesInSpecialCounter": 0,
                    "PulsesOutCounter": 0,
                    "PulsesOutSpecialCounter": 0,
                    "Reset": 0,
                    "ReturnSignalInTime": 0,
                    "ReturnSignalOutTime": 0,
                    "ReverseButtonActivation": 0,
                    "SafetyRailInnerDoorClosing": 0,
                    "SafetyRailOuterDoorClosing": null,
                    "TimeExceededinCabinCount": null,
                    "TimeExceededMax": 0,
                    "TimeOutTime": 0,
                    "TOF0PersonIn": 0,
                    "TOF0PersonOut": 0,
                    "TOF1PersonIn": null,
                    "TOF1PersonOut": 0,
                    "TOF2PersonsIn": null,
                    "TOF2PersonsOut": 0,
                    "TOFRejection": 0,
                    "TOFRejectionsIn": null,
                    "TOFRejectionsOut": null,
                    "TOFSuspiciousIn": 0,
                    "TOFSuspiciousOut": 0,
                    "EndSwitchOutsideClosed": 0,
                    "EndSwitchOutsideSlow": 0,
                    "EndSwitchOutsideOpen": 0,
                    "EndSwitchInsideClosed": 0,
                    "EndSwitchInsideSlow": 0,
                    "EndSwitchInsideOpen": 0,
                    "BiometricAccessGranted": 0,
                    "FireAlarm": 0,
                    "MotorThermalOverload": 0,
                    "PowerFailure": 0,
                    "EmergencyButton": 0,
                    "SafetyRail": 0,
                    "PulseIn": 0,
                    "PulseOut": 0,
                    "PulseInSpecial": 0,
                    "PulseOutSpecial": 0,
                    "BothDoorsOpen": 0,
                    "LockSwitch": 0,
                    "IrisScanEntryRejected": null,
                    "InfraRedSensors": 0,
                    "SVSInOn": 0,
                    "SVSOutOn": 0,
                    "CleaningMode": 0,
                    "ResetSwitch": 0,
                    "EmptyDoorIn": 0,
                    "OnePersonIn": 0,
                    "TwoPersonIn": 0,
                    "SuspiciousIn": 0,
                    "AIRSensorsIn": 0,
                    "SVSEnabledIn": 0,
                    "EmptyDoorOut": 0,
                    "OnePersonOut": 0,
                    "TwoPersonOut": 0,
                    "SuspiciousOut": 0,
                    "AIRSensorsOut": 0,
                    "SVSEnabledOut": 0,
                    "ReturnSignalIn": 0,
                    "ReturnSignalOut": 0,
                    "MotorOuter": null,
                    "MotorInner": null,
                    "LockOuter": null,
                    "LockInner": null,
                    "MagLockOuter": null,
                    "MagLockInner": null,
                    "VFDForward": 0,
                    "VFDReverse": 0,
                    "VFDSpeedRef2and4": 0,
                    "VFDSpeedRef3and4": 0,
                    "VFDSecondAccDec": null,
                    "TOFReset": 0,
                    "TOFShutdown": 0,
                    "GeneralAlarm": 0,
                    "SignalLEDGreenIn": 0,
                    "SignalLEDRedIn": 0,
                    "SignalLEDGreenOut": 0,
                    "SignalLEDRedOut": 0,
                    "AuthorizationIn": 0,
                    "AIRActiveIn": 0,
                    "AuthorizationOut": 0,
                    "AIRActiveOut": 0,
                    "TwoPersonRejection": 0,
                    "BiometricRejection": 0,
                    "TimeExceededInCabin": 0,
                    "SafetyRailActivation": 0,
                    "EmergencyButtonActivation": 0,
                    "PowerLoss": 0,
                    "IRSensorHung": 0,
                    "PersonInCabin": null,
                    "BiometricStart": 0,
                    "OuterDoorClosed": 0,
                    "InnerDoorClosed": 0,
                    "EmergencyButtonLED": 0,
                    "Voice1": 0,
                    "Voice2": 0,
                    "SignalGreenInterior": 0,
                    "SignalRedInterior": 0,
                    "EnableBiometricEntry": null,
                    "EnableBiometricExit": null
                }],
                "motorDrive": [{
                    "id": 11,
                    "DeviceId": "4",
                    "EpochTime": 1466584661,
                    "OutputFrequency": 1,
                    "BaseFrequency": 0,
                    "OutputCurrent": 1,
                    "NormalSpeed": 1,
                    "OutputVoltage": null,
                    "BaseVoltage": null,
                    "SlowSpeedOuter": null,
                    "SlowSpeedInner": null,
                    "AccelerationTime1st": null,
                    "AccelerationTime2nd": null,
                    "DecelerationTime1st": null,
                    "DecelerationTime2nd": null,
                    "BrakingTime": null,
                    "Braking": null
                }],
                "doorStatus": null
            }

            // spyOn(JSON, 'parse').and.returnValue(mockData)
            var timeofflight = {
                "Primary_Log_Capture": 0,
                "Primary_Log_OutputCounts": "1",
                "Primary_DoorSetting_HeightUnderCanopy": 2000,
                "Primary_DoorSetting_Diameter": 1800,
                "Primary_DoorSetting_SensorDirection": 0,
                "Primary_DoorSetting_DoorOpen": 0,
                "Primary_DoorSetting_DoorClose": 0,
                "Primary_DoorSetting_WheelChair": 0,
                "Primary_DoorSetting_VerificationDevice": 0,
                "Primary_Sensitivity_LowObject": 5,
                "Primary_Sensitivity_SensorBlinding": 5,
                "Primary_Sensitivity_OnePerson": 5,
                "Primary_Sensitivity_MorePerson": 4,
                "Primary_Sensitivity_Volume": 6,
                "Primary_Sensitivity_Moment": 5,
                "Primary_DoorSetting_ShaftPosition1_X": 0,
                "Primary_DoorSetting_ShaftPosition2_X": 0,
                "Primary_DoorSetting_ShaftPosition1_Y": 0,
                "Primary_DoorSetting_ShaftPosition2_Y": 0
            }
            scope.sliders = {
                capture_counts: timeofflight.Primary_Log_OutputCounts,
                height_canopy: timeofflight.Primary_DoorSetting_HeightUnderCanopy,
                door_diameter: timeofflight.Primary_DoorSetting_Diameter,
                capture_image: timeofflight.Primary_Log_Capture,
                sensor_direction: timeofflight.Primary_DoorSetting_SensorDirection,
                primary_door_setting_open: timeofflight.Primary_DoorSetting_DoorOpen,
                primary_door_setting_close: timeofflight.Primary_DoorSetting_DoorClose,
                wheel_chair: timeofflight.Primary_DoorSetting_WheelChair,
                verification_device: timeofflight.Primary_DoorSetting_VerificationDevice,
                lowObjValue: timeofflight.Primary_Sensitivity_LowObject,
                blindingValue: timeofflight.Primary_Sensitivity_SensorBlinding,
                onePersonValue: timeofflight.Primary_Sensitivity_OnePerson,
                morePersonValue: timeofflight.Primary_Sensitivity_MorePerson,
                volumeValue: timeofflight.Primary_Sensitivity_Volume,
                momentValue: timeofflight.Primary_Sensitivity_Moment,
                x_shaft_1x: timeofflight.Primary_DoorSetting_ShaftPosition1_X,
                x_shaft_2x: timeofflight.Primary_DoorSetting_ShaftPosition2_X,
                x_shaft_11x: timeofflight.Primary_DoorSetting_ShaftPosition1_Y,
                x_shaft_22x: timeofflight.Primary_DoorSetting_ShaftPosition2_Y,
                min: 1,
                max: 9
            }
            spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise)
            spyOn(mockEditDoorService, 'putTimeofFlight').and.returnValue(deferred.promise);
            scope.validateTimeFlight()
            deferred.resolve(result); // Resolve the promise.
            scope.$digest();

        });

        it('should test if validateTimeFlight works as expected if scope.checkModel.secondary is false and invalid values are entered', function() {
            var mockData = {
                "id": 4,
                "username": "boonadmin",
                "registrationdatetime": "2016-06-17T11:59:01.000Z",
                "level1": 1,
                "level2": 1,
                "level3": 1,
                "enabled": 1,
                "country": null,
                "campus": "boonCampus",
                "building": null,
                "entrance": null,
                "company_ID": null
            };
            spyOn(JSON, 'parse').and.returnValue({
                "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                "userName": "BoonAdmin",
                "admin": true,
                "level1": false,
                "level2": false,
                "level3": false,
                "level4": false,
                "level5": false,
                "level6": false,
                "level7": true,
                "level8": false,
                "level9": true,
                "level10": false
            });
            var dummyElement = document.createElement('canvas');
            var id = document.createAttribute("id");
            id.value = 'stereovisionCanvas';
            dummyElement.setAttributeNode(id);
            var width = document.createAttribute("width");
            width.value = '176px';
            dummyElement.setAttributeNode(width);
            var height = document.createAttribute("height");
            height.value = '132px';
            dummyElement.setAttributeNode(height);
            spyOn(document, 'getElementById').and.returnValue(dummyElement);
            // spyOn(scope, 'drawShapeOnPrimary').and.callThrough();
            createController();
            var result = {
                "success": true,
                "message": "Update successful.",
                "doorMain": [{
                    "id": 8,
                    "nodeid": "JAbmykU/TpSIAn6XF6PyP+Ub0JA=",
                    "DeviceID": "4",
                    "ip_number": "192.168.1.52",
                    "mac_address": "00:1f:7b:b2:14:d6",
                    "hostname": "",
                    "time_first_seen": 1454410566,
                    "time_last_seen": 1467491252,
                    "lastupdateby": "boonadmin",
                    "snoozeExitTime": 1467491852,
                    "real_name": "Bylorus RnD Wandbboard",
                    "location": "Aambeeldstraat",
                    "product_type": "Bylorus",
                    "last_state": "OK",
                    "users": "boon, walt",
                    "ce_number": "",
                    "latitude": "",
                    "longitude": "",
                    "timezone": null,
                    "campusId": "boonCampus",
                    "buildingId": "boonBuilding",
                    "entranceId": "boonEntrance",
                    "subEntranceId": "boonsub",
                    "campusName": "boonCampus",
                    "buildingName": null,
                    "entranceName": "boonEntrance",
                    "subEntranceName": "subEntranceT",
                    "companyId": 1,
                    "info1": "",
                    "info2": "",
                    "assigned": 1,
                    "flag": 0
                }],
                "transactionTimes": [],
                "rejectionCount": [],
                "timeOfFlight": [{
                    "id": 173,
                    "DeviceId": "4",
                    "EpochTime": 1467364984,
                    "Primary_Log_Capture": 0,
                    "Primary_Log_CaptureZero": 0,
                    "Primary_Log_CaptureOne": 0,
                    "Primary_Log_CaptureMore": 0,
                    "Primary_Log_CaptureSus": 0,
                    "Primary_Log_Still": 0,
                    "Primary_Log_StillZero": 0,
                    "Primary_Log_StillOne": 0,
                    "Primary_Log_StillMore": 0,
                    "Primary_Log_StillSus": 0,
                    "Primary_Log_OutputCounts": 0,
                    "Primary_OutputStatus_Authorization": 0,
                    "Primary_OutputStatus_Zero": 0,
                    "Primary_OutputStatus_One": 0,
                    "Primary_OutputStatus_More": 0,
                    "Primary_OutputStatus_Sus": 0,
                    "Primary_OutputStatus_Air": 0,
                    "Primary_Sensitivity_Volume": 5,
                    "Primary_Sensitivity_Moment": 4,
                    "Primary_Sensitivity_LowObject": 9,
                    "Primary_Sensitivity_SensorBlinding": 8,
                    "Primary_Sensitivity_OnePerson": 7,
                    "Primary_Sensitivity_MorePerson": 6,
                    "Primary_DoorSetting_SensorDirection": 0,
                    "Primary_DoorSetting_HeightUnderCanopy": 0,
                    "Primary_DoorSetting_Diameter": 0,
                    "Primary_DoorSetting_DoorOpen": 0,
                    "Primary_DoorSetting_DoorClose": 0,
                    "Primary_DoorSetting_VerificationDevice": 0,
                    "Primary_DoorSetting_WheelChair": 0,
                    "Primary_DoorSetting_ShaftPosition_X": 0,
                    "Primary_DoorSetting_ShaftPosition_Y": 0,
                    "Primary_DoorSetting_ShaftPosition1_X": 0,
                    "Primary_DoorSetting_ShaftPosition1_Y": 0,
                    "Primary_DoorSetting_ShaftPosition2_X": 0,
                    "Primary_DoorSetting_ShaftPosition2_Y": 0,
                    "Primary_DoorSetting_DoorPosition": 0,
                    "Primary_DoorSetting_OffsetAngle": 0,
                    "Primary_DoorSetting_TipOfEndPosition_X": 0,
                    "Primary_DoorSetting_TipOfEndPosition_Y": 0,
                    "Secondary_Log_Capture": 0,
                    "Secondary_Log_CaptureZero": 0,
                    "Secondary_Log_CaptureOne": 0,
                    "Secondary_Log_CaptureMore": 0,
                    "Secondary_Log_CaptureSus": 0,
                    "Secondary_Log_Still": 0,
                    "Secondary_Log_StillZero": 0,
                    "Secondary_Log_StillOne": 0,
                    "Secondary_Log_StillMore": 0,
                    "Secondary_Log_StillSus": 0,
                    "Secondary_Log_OutputCounts": 0,
                    "Secondary_OutputStatus_Authorization": 0,
                    "Secondary_OutputStatus_Zero": 0,
                    "Secondary_OutputStatus_One": 0,
                    "Secondary_OutputStatus_More": 0,
                    "Secondary_OutputStatus_Sus": 0,
                    "Secondary_OutputStatus_Air": 0,
                    "Secondary_Sensitivity_Volume": 0,
                    "Secondary_Sensitivity_Moment": 0,
                    "Secondary_Sensitivity_LowObject": 0,
                    "Secondary_Sensitivity_SensorBlinding": 0,
                    "Secondary_Sensitivity_OnePerson": 0,
                    "Secondary_Sensitivity_MorePerson": 0,
                    "Secondary_DoorSetting_SensorDirection": 0,
                    "Secondary_DoorSetting_HeightUnderCanopy": 0,
                    "Secondary_DoorSetting_Diameter": 0,
                    "Secondary_DoorSetting_DoorOpen": 0,
                    "Secondary_DoorSetting_DoorClose": 0,
                    "Secondary_DoorSetting_VerificationDevice": 0,
                    "Secondary_DoorSetting_WheelChair": 0,
                    "Secondary_DoorSetting_ShaftPosition_X": 0,
                    "Secondary_DoorSetting_ShaftPosition_Y": 0,
                    "Secondary_DoorSetting_ShaftPosition1_X": 0,
                    "Secondary_DoorSetting_ShaftPosition1_Y": 0,
                    "Secondary_DoorSetting_ShaftPosition2_X": 0,
                    "Secondary_DoorSetting_ShaftPosition2_Y": 0,
                    "Secondary_DoorSetting_DoorPosition": 0,
                    "Secondary_DoorSetting_OffsetAngle": 0,
                    "Secondary_DoorSetting_TipOfEndPosition_X": 0,
                    "Secondary_DoorSetting_TipOfEndPosition_Y": 0
                }],
                "plc": [{
                    "id": 3568,
                    "DeviceId": "4",
                    "EpochTime": 1466584246,
                    "Alarm": 0,
                    "BiometricRejectionCount": null,
                    "BothDoorsOpenCount": null,
                    "Cleaning": null,
                    "CleaningTime": 0,
                    "DelayTimeNoOutputSV": 0,
                    "DoorForcedCount": null,
                    "EndSwitchClosedInnerDoorDefective": 0,
                    "EndSwitchClosedOuterDoorDefective": 0,
                    "Event1st": 0,
                    "Event2nd": 0,
                    "Event3rd": 0,
                    "Event4th": 0,
                    "Event5th": 0,
                    "FireAlarmCount": null,
                    "FireAlarmModeSet": 0,
                    "IllegalTime": 0,
                    "IllegalUse": 0,
                    "IRSensorHungCount": null,
                    "IRSSensorDelay": 0,
                    "Locking": 0,
                    "LuminanceErrorDelay": 0,
                    "OnePersonInCount": null,
                    "OpeningCounterInnerDoor": 0,
                    "OpeningCounterOuterDoor": null,
                    "OpenTimeIn": 0,
                    "OpenTimeOut": 0,
                    "OverallTimeClosingInnerDoor": 0,
                    "OverallTimeClosingOuterDoor": 0,
                    "OverallTimeOpeningInnerDoor": 0,
                    "OverallTimeOpeningOuterDoor": 0,
                    "PowerLossCount": null,
                    "PresenceDelay": 0,
                    "PulsesInCounter": 0,
                    "PulsesInSpecialCounter": 0,
                    "PulsesOutCounter": 0,
                    "PulsesOutSpecialCounter": 0,
                    "Reset": 0,
                    "ReturnSignalInTime": 0,
                    "ReturnSignalOutTime": 0,
                    "ReverseButtonActivation": 0,
                    "SafetyRailInnerDoorClosing": 0,
                    "SafetyRailOuterDoorClosing": null,
                    "TimeExceededinCabinCount": null,
                    "TimeExceededMax": 0,
                    "TimeOutTime": 0,
                    "TOF0PersonIn": 0,
                    "TOF0PersonOut": 0,
                    "TOF1PersonIn": null,
                    "TOF1PersonOut": 0,
                    "TOF2PersonsIn": null,
                    "TOF2PersonsOut": 0,
                    "TOFRejection": 0,
                    "TOFRejectionsIn": null,
                    "TOFRejectionsOut": null,
                    "TOFSuspiciousIn": 0,
                    "TOFSuspiciousOut": 0,
                    "EndSwitchOutsideClosed": 0,
                    "EndSwitchOutsideSlow": 0,
                    "EndSwitchOutsideOpen": 0,
                    "EndSwitchInsideClosed": 0,
                    "EndSwitchInsideSlow": 0,
                    "EndSwitchInsideOpen": 0,
                    "BiometricAccessGranted": 0,
                    "FireAlarm": 0,
                    "MotorThermalOverload": 0,
                    "PowerFailure": 0,
                    "EmergencyButton": 0,
                    "SafetyRail": 0,
                    "PulseIn": 0,
                    "PulseOut": 0,
                    "PulseInSpecial": 0,
                    "PulseOutSpecial": 0,
                    "BothDoorsOpen": 0,
                    "LockSwitch": 0,
                    "IrisScanEntryRejected": null,
                    "InfraRedSensors": 0,
                    "SVSInOn": 0,
                    "SVSOutOn": 0,
                    "CleaningMode": 0,
                    "ResetSwitch": 0,
                    "EmptyDoorIn": 0,
                    "OnePersonIn": 0,
                    "TwoPersonIn": 0,
                    "SuspiciousIn": 0,
                    "AIRSensorsIn": 0,
                    "SVSEnabledIn": 0,
                    "EmptyDoorOut": 0,
                    "OnePersonOut": 0,
                    "TwoPersonOut": 0,
                    "SuspiciousOut": 0,
                    "AIRSensorsOut": 0,
                    "SVSEnabledOut": 0,
                    "ReturnSignalIn": 0,
                    "ReturnSignalOut": 0,
                    "MotorOuter": null,
                    "MotorInner": null,
                    "LockOuter": null,
                    "LockInner": null,
                    "MagLockOuter": null,
                    "MagLockInner": null,
                    "VFDForward": 0,
                    "VFDReverse": 0,
                    "VFDSpeedRef2and4": 0,
                    "VFDSpeedRef3and4": 0,
                    "VFDSecondAccDec": null,
                    "TOFReset": 0,
                    "TOFShutdown": 0,
                    "GeneralAlarm": 0,
                    "SignalLEDGreenIn": 0,
                    "SignalLEDRedIn": 0,
                    "SignalLEDGreenOut": 0,
                    "SignalLEDRedOut": 0,
                    "AuthorizationIn": 0,
                    "AIRActiveIn": 0,
                    "AuthorizationOut": 0,
                    "AIRActiveOut": 0,
                    "TwoPersonRejection": 0,
                    "BiometricRejection": 0,
                    "TimeExceededInCabin": 0,
                    "SafetyRailActivation": 0,
                    "EmergencyButtonActivation": 0,
                    "PowerLoss": 0,
                    "IRSensorHung": 0,
                    "PersonInCabin": null,
                    "BiometricStart": 0,
                    "OuterDoorClosed": 0,
                    "InnerDoorClosed": 0,
                    "EmergencyButtonLED": 0,
                    "Voice1": 0,
                    "Voice2": 0,
                    "SignalGreenInterior": 0,
                    "SignalRedInterior": 0,
                    "EnableBiometricEntry": null,
                    "EnableBiometricExit": null
                }],
                "motorDrive": [{
                    "id": 11,
                    "DeviceId": "4",
                    "EpochTime": 1466584661,
                    "OutputFrequency": 1,
                    "BaseFrequency": 0,
                    "OutputCurrent": 1,
                    "NormalSpeed": 1,
                    "OutputVoltage": null,
                    "BaseVoltage": null,
                    "SlowSpeedOuter": null,
                    "SlowSpeedInner": null,
                    "AccelerationTime1st": null,
                    "AccelerationTime2nd": null,
                    "DecelerationTime1st": null,
                    "DecelerationTime2nd": null,
                    "BrakingTime": null,
                    "Braking": null
                }],
                "doorStatus": null
            }
            var timeofflight = {
                "Primary_Log_Capture": 0,
                "Primary_Log_OutputCounts": "10",
                "Primary_DoorSetting_HeightUnderCanopy": 1900,
                "Primary_DoorSetting_Diameter": 1875,
                "Primary_DoorSetting_SensorDirection": 0,
                "Primary_DoorSetting_DoorOpen": 0,
                "Primary_DoorSetting_DoorClose": 0,
                "Primary_DoorSetting_WheelChair": 0,
                "Primary_DoorSetting_VerificationDevice": 0,
                "Primary_Sensitivity_LowObject": 5,
                "Primary_Sensitivity_SensorBlinding": 5,
                "Primary_Sensitivity_OnePerson": 5,
                "Primary_Sensitivity_MorePerson": 4,
                "Primary_Sensitivity_Volume": 6,
                "Primary_Sensitivity_Moment": 5,
                "Primary_DoorSetting_ShaftPosition1_X": 172,
                "Primary_DoorSetting_ShaftPosition2_X": 172,
                "Primary_DoorSetting_ShaftPosition1_Y": 132,
                "Primary_DoorSetting_ShaftPosition2_Y": 132
            }
            scope.sliders = {
                capture_counts: timeofflight.Primary_Log_OutputCounts,
                height_canopy: timeofflight.Primary_DoorSetting_HeightUnderCanopy,
                door_diameter: timeofflight.Primary_DoorSetting_Diameter,
                capture_image: timeofflight.Primary_Log_Capture,
                sensor_direction: timeofflight.Primary_DoorSetting_SensorDirection,
                primary_door_setting_open: timeofflight.Primary_DoorSetting_DoorOpen,
                primary_door_setting_close: timeofflight.Primary_DoorSetting_DoorClose,
                wheel_chair: timeofflight.Primary_DoorSetting_WheelChair,
                verification_device: timeofflight.Primary_DoorSetting_VerificationDevice,
                lowObjValue: timeofflight.Primary_Sensitivity_LowObject,
                blindingValue: timeofflight.Primary_Sensitivity_SensorBlinding,
                onePersonValue: timeofflight.Primary_Sensitivity_OnePerson,
                morePersonValue: timeofflight.Primary_Sensitivity_MorePerson,
                volumeValue: timeofflight.Primary_Sensitivity_Volume,
                momentValue: timeofflight.Primary_Sensitivity_Moment,
                x_shaft_1x: timeofflight.Primary_DoorSetting_ShaftPosition1_X,
                x_shaft_2x: timeofflight.Primary_DoorSetting_ShaftPosition2_X,
                x_shaft_11x: timeofflight.Primary_DoorSetting_ShaftPosition1_Y,
                x_shaft_22x: timeofflight.Primary_DoorSetting_ShaftPosition2_Y,
                min: 1,
                max: 9
            }
            scope.original_time_of_flight_prim = {
                capture_counts: 0,
                height_canopy: 0,
                door_diameter: 0,
                capture_image: 0,
                sensor_direction: 0,
                primary_door_setting_open: 0,
                primary_door_setting_close: 0,
                wheel_chair: 0,
                verification_device: 0,
                lowObjValue: 0,
                blindingValue: 0,
                onePersonValue: 0,
                morePersonValue: 0,
                volumeValue: 0,
                momentValue: 0,
                x_shaft_1x: 0,
                x_shaft_2x: 0,
                x_shaft_11x: 0,
                x_shaft_22x: 0,
                min: 1,
                max: 9
            }
            spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise)
            spyOn(mockEditDoorService, 'putTimeofFlight').and.returnValue(deferred.promise);
            scope.validateTimeFlight()
            deferred.resolve(result); // Resolve the promise.
            scope.$digest();
            scope.validateTimeFlight()
            expect(scope.tof_message).not.toEqual(result.message)
                // expect(scope.drawShapeOnPrimary).toHaveBeenCalled();
        });

        it('should test if validateTimeFlight works as expected if scope.checkModel.secondary is true', function() {
          var deffered_StereovisionImage = q.defer();
          spyOn(JSON, 'parse').and.returnValue({
              "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
              "userName": "BoonAdmin",
              "admin": true,
              "level1": false,
              "level2": false,
              "level3": false,
              "level4": false,
              "level5": false,
              "level6": false,
              "level7": true,
              "level8": false,
              "level9": true,
              "level10": false
          });
          var dummyElement = document.createElement('canvas');
          var id = document.createAttribute("id");
          id.value = 'stereovisionCanvas';
          dummyElement.setAttributeNode(id);
          var width = document.createAttribute("width");
          width.value = '176px';
          dummyElement.setAttributeNode(width);
          var height = document.createAttribute("height");
          height.value = '132px';
          dummyElement.setAttributeNode(height);
          spyOn(document, 'getElementById').and.returnValue(dummyElement);
          createController();
          var result = {
              "success": true,
              "message": "Update successful.",
              "doorMain": [{
                  "id": 8,
                  "nodeid": "JAbmykU/TpSIAn6XF6PyP+Ub0JA=",
                  "DeviceID": "4",
                  "ip_number": "192.168.1.52",
                  "mac_address": "00:1f:7b:b2:14:d6",
                  "hostname": "",
                  "time_first_seen": 1454410566,
                  "time_last_seen": 1467491252,
                  "lastupdateby": "boonadmin",
                  "snoozeExitTime": 1467491852,
                  "real_name": "Bylorus RnD Wandbboard",
                  "location": "Aambeeldstraat",
                  "product_type": "Bylorus",
                  "last_state": "OK",
                  "users": "boon, walt",
                  "ce_number": "",
                  "latitude": "",
                  "longitude": "",
                  "timezone": null,
                  "campusId": "boonCampus",
                  "buildingId": "boonBuilding",
                  "entranceId": "boonEntrance",
                  "subEntranceId": "boonsub",
                  "campusName": "boonCampus",
                  "buildingName": null,
                  "entranceName": "boonEntrance",
                  "subEntranceName": "subEntranceT",
                  "companyId": 1,
                  "info1": "",
                  "info2": "",
                  "assigned": 1,
                  "flag": 0
              }],
              "transactionTimes": [],
              "rejectionCount": [],
              "timeOfFlight": [{
                  "id": 173,
                  "DeviceId": "4",
                  "EpochTime": 1467364984,
                  "Primary_Log_Capture": 0,
                  "Primary_Log_CaptureZero": 0,
                  "Primary_Log_CaptureOne": 0,
                  "Primary_Log_CaptureMore": 0,
                  "Primary_Log_CaptureSus": 0,
                  "Primary_Log_Still": 0,
                  "Primary_Log_StillZero": 0,
                  "Primary_Log_StillOne": 0,
                  "Primary_Log_StillMore": 0,
                  "Primary_Log_StillSus": 0,
                  "Primary_Log_OutputCounts": 0,
                  "Primary_OutputStatus_Authorization": 0,
                  "Primary_OutputStatus_Zero": 0,
                  "Primary_OutputStatus_One": 0,
                  "Primary_OutputStatus_More": 0,
                  "Primary_OutputStatus_Sus": 0,
                  "Primary_OutputStatus_Air": 0,
                  "Primary_Sensitivity_Volume": 5,
                  "Primary_Sensitivity_Moment": 4,
                  "Primary_Sensitivity_LowObject": 9,
                  "Primary_Sensitivity_SensorBlinding": 8,
                  "Primary_Sensitivity_OnePerson": 7,
                  "Primary_Sensitivity_MorePerson": 6,
                  "Primary_DoorSetting_SensorDirection": 0,
                  "Primary_DoorSetting_HeightUnderCanopy": 0,
                  "Primary_DoorSetting_Diameter": 0,
                  "Primary_DoorSetting_DoorOpen": 0,
                  "Primary_DoorSetting_DoorClose": 0,
                  "Primary_DoorSetting_VerificationDevice": 0,
                  "Primary_DoorSetting_WheelChair": 0,
                  "Primary_DoorSetting_ShaftPosition_X": 0,
                  "Primary_DoorSetting_ShaftPosition_Y": 0,
                  "Primary_DoorSetting_ShaftPosition1_X": 0,
                  "Primary_DoorSetting_ShaftPosition1_Y": 0,
                  "Primary_DoorSetting_ShaftPosition2_X": 0,
                  "Primary_DoorSetting_ShaftPosition2_Y": 0,
                  "Primary_DoorSetting_DoorPosition": 0,
                  "Primary_DoorSetting_OffsetAngle": 0,
                  "Primary_DoorSetting_TipOfEndPosition_X": 0,
                  "Primary_DoorSetting_TipOfEndPosition_Y": 0,
                  "Secondary_Log_Capture": 0,
                  "Secondary_Log_CaptureZero": 0,
                  "Secondary_Log_CaptureOne": 0,
                  "Secondary_Log_CaptureMore": 0,
                  "Secondary_Log_CaptureSus": 0,
                  "Secondary_Log_Still": 0,
                  "Secondary_Log_StillZero": 0,
                  "Secondary_Log_StillOne": 0,
                  "Secondary_Log_StillMore": 0,
                  "Secondary_Log_StillSus": 0,
                  "Secondary_Log_OutputCounts": 0,
                  "Secondary_OutputStatus_Authorization": 0,
                  "Secondary_OutputStatus_Zero": 0,
                  "Secondary_OutputStatus_One": 0,
                  "Secondary_OutputStatus_More": 0,
                  "Secondary_OutputStatus_Sus": 0,
                  "Secondary_OutputStatus_Air": 0,
                  "Secondary_Sensitivity_Volume": 0,
                  "Secondary_Sensitivity_Moment": 0,
                  "Secondary_Sensitivity_LowObject": 0,
                  "Secondary_Sensitivity_SensorBlinding": 0,
                  "Secondary_Sensitivity_OnePerson": 0,
                  "Secondary_Sensitivity_MorePerson": 0,
                  "Secondary_DoorSetting_SensorDirection": 0,
                  "Secondary_DoorSetting_HeightUnderCanopy": 0,
                  "Secondary_DoorSetting_Diameter": 0,
                  "Secondary_DoorSetting_DoorOpen": 0,
                  "Secondary_DoorSetting_DoorClose": 0,
                  "Secondary_DoorSetting_VerificationDevice": 0,
                  "Secondary_DoorSetting_WheelChair": 0,
                  "Secondary_DoorSetting_ShaftPosition_X": 0,
                  "Secondary_DoorSetting_ShaftPosition_Y": 0,
                  "Secondary_DoorSetting_ShaftPosition1_X": 0,
                  "Secondary_DoorSetting_ShaftPosition1_Y": 0,
                  "Secondary_DoorSetting_ShaftPosition2_X": 0,
                  "Secondary_DoorSetting_ShaftPosition2_Y": 0,
                  "Secondary_DoorSetting_DoorPosition": 0,
                  "Secondary_DoorSetting_OffsetAngle": 0,
                  "Secondary_DoorSetting_TipOfEndPosition_X": 0,
                  "Secondary_DoorSetting_TipOfEndPosition_Y": 0
              }],
              "plc": [{
                  "id": 3568,
                  "DeviceId": "4",
                  "EpochTime": 1466584246,
                  "Alarm": 0,
                  "BiometricRejectionCount": null,
                  "BothDoorsOpenCount": null,
                  "Cleaning": null,
                  "CleaningTime": 0,
                  "DelayTimeNoOutputSV": 0,
                  "DoorForcedCount": null,
                  "EndSwitchClosedInnerDoorDefective": 0,
                  "EndSwitchClosedOuterDoorDefective": 0,
                  "Event1st": 0,
                  "Event2nd": 0,
                  "Event3rd": 0,
                  "Event4th": 0,
                  "Event5th": 0,
                  "FireAlarmCount": null,
                  "FireAlarmModeSet": 0,
                  "IllegalTime": 0,
                  "IllegalUse": 0,
                  "IRSensorHungCount": null,
                  "IRSSensorDelay": 0,
                  "Locking": 0,
                  "LuminanceErrorDelay": 0,
                  "OnePersonInCount": null,
                  "OpeningCounterInnerDoor": 0,
                  "OpeningCounterOuterDoor": null,
                  "OpenTimeIn": 0,
                  "OpenTimeOut": 0,
                  "OverallTimeClosingInnerDoor": 0,
                  "OverallTimeClosingOuterDoor": 0,
                  "OverallTimeOpeningInnerDoor": 0,
                  "OverallTimeOpeningOuterDoor": 0,
                  "PowerLossCount": null,
                  "PresenceDelay": 0,
                  "PulsesInCounter": 0,
                  "PulsesInSpecialCounter": 0,
                  "PulsesOutCounter": 0,
                  "PulsesOutSpecialCounter": 0,
                  "Reset": 0,
                  "ReturnSignalInTime": 0,
                  "ReturnSignalOutTime": 0,
                  "ReverseButtonActivation": 0,
                  "SafetyRailInnerDoorClosing": 0,
                  "SafetyRailOuterDoorClosing": null,
                  "TimeExceededinCabinCount": null,
                  "TimeExceededMax": 0,
                  "TimeOutTime": 0,
                  "TOF0PersonIn": 0,
                  "TOF0PersonOut": 0,
                  "TOF1PersonIn": null,
                  "TOF1PersonOut": 0,
                  "TOF2PersonsIn": null,
                  "TOF2PersonsOut": 0,
                  "TOFRejection": 0,
                  "TOFRejectionsIn": null,
                  "TOFRejectionsOut": null,
                  "TOFSuspiciousIn": 0,
                  "TOFSuspiciousOut": 0,
                  "EndSwitchOutsideClosed": 0,
                  "EndSwitchOutsideSlow": 0,
                  "EndSwitchOutsideOpen": 0,
                  "EndSwitchInsideClosed": 0,
                  "EndSwitchInsideSlow": 0,
                  "EndSwitchInsideOpen": 0,
                  "BiometricAccessGranted": 0,
                  "FireAlarm": 0,
                  "MotorThermalOverload": 0,
                  "PowerFailure": 0,
                  "EmergencyButton": 0,
                  "SafetyRail": 0,
                  "PulseIn": 0,
                  "PulseOut": 0,
                  "PulseInSpecial": 0,
                  "PulseOutSpecial": 0,
                  "BothDoorsOpen": 0,
                  "LockSwitch": 0,
                  "IrisScanEntryRejected": null,
                  "InfraRedSensors": 0,
                  "SVSInOn": 0,
                  "SVSOutOn": 0,
                  "CleaningMode": 0,
                  "ResetSwitch": 0,
                  "EmptyDoorIn": 0,
                  "OnePersonIn": 0,
                  "TwoPersonIn": 0,
                  "SuspiciousIn": 0,
                  "AIRSensorsIn": 0,
                  "SVSEnabledIn": 0,
                  "EmptyDoorOut": 0,
                  "OnePersonOut": 0,
                  "TwoPersonOut": 0,
                  "SuspiciousOut": 0,
                  "AIRSensorsOut": 0,
                  "SVSEnabledOut": 0,
                  "ReturnSignalIn": 0,
                  "ReturnSignalOut": 0,
                  "MotorOuter": null,
                  "MotorInner": null,
                  "LockOuter": null,
                  "LockInner": null,
                  "MagLockOuter": null,
                  "MagLockInner": null,
                  "VFDForward": 0,
                  "VFDReverse": 0,
                  "VFDSpeedRef2and4": 0,
                  "VFDSpeedRef3and4": 0,
                  "VFDSecondAccDec": null,
                  "TOFReset": 0,
                  "TOFShutdown": 0,
                  "GeneralAlarm": 0,
                  "SignalLEDGreenIn": 0,
                  "SignalLEDRedIn": 0,
                  "SignalLEDGreenOut": 0,
                  "SignalLEDRedOut": 0,
                  "AuthorizationIn": 0,
                  "AIRActiveIn": 0,
                  "AuthorizationOut": 0,
                  "AIRActiveOut": 0,
                  "TwoPersonRejection": 0,
                  "BiometricRejection": 0,
                  "TimeExceededInCabin": 0,
                  "SafetyRailActivation": 0,
                  "EmergencyButtonActivation": 0,
                  "PowerLoss": 0,
                  "IRSensorHung": 0,
                  "PersonInCabin": null,
                  "BiometricStart": 0,
                  "OuterDoorClosed": 0,
                  "InnerDoorClosed": 0,
                  "EmergencyButtonLED": 0,
                  "Voice1": 0,
                  "Voice2": 0,
                  "SignalGreenInterior": 0,
                  "SignalRedInterior": 0,
                  "EnableBiometricEntry": null,
                  "EnableBiometricExit": null
              }],
              "motorDrive": [{
                  "id": 11,
                  "DeviceId": "4",
                  "EpochTime": 1466584661,
                  "OutputFrequency": 1,
                  "BaseFrequency": 0,
                  "OutputCurrent": 1,
                  "NormalSpeed": 1,
                  "OutputVoltage": null,
                  "BaseVoltage": null,
                  "SlowSpeedOuter": null,
                  "SlowSpeedInner": null,
                  "AccelerationTime1st": null,
                  "AccelerationTime2nd": null,
                  "DecelerationTime1st": null,
                  "DecelerationTime2nd": null,
                  "BrakingTime": null,
                  "Braking": null
              }],
              "doorStatus": null
          }
          var mockData = {
              "id": 4,
              "username": "boonadmin",
              "registrationdatetime": "2016-06-17T11:59:01.000Z",
              "level1": 1,
              "level2": 1,
              "level3": 1,
              "enabled": 1,
              "country": null,
              "campus": "boonCampus",
              "building": null,
              "entrance": null,
              "company_ID": null
          }
          var timeofflight = {
              "Secondary_Log_Capture": 0,
              "Secondary_Log_OutputCounts": "1",
              "Secondary_DoorSetting_HeightUnderCanopy": "2000",
              "Secondary_DoorSetting_Diameter": "1800",
              "Secondary_DoorSetting_SensorDirection": 0,
              "Secondary_DoorSetting_DoorOpen": 0,
              "Secondary_DoorSetting_DoorClose": 0,
              "Secondary_DoorSetting_WheelChair": 0,
              "Secondary_DoorSetting_VerificationDevice": 0,
              "Secondary_Sensitivity_LowObject": 0,
              "Secondary_Sensitivity_SensorBlinding": 0,
              "Secondary_Sensitivity_OnePerson": 0,
              "Secondary_Sensitivity_MorePerson": 0,
              "Secondary_Sensitivity_Volume": 0,
              "Secondary_Sensitivity_Moment": 0,
              "Secondary_DoorSetting_ShaftPosition1_X": 0,
              "Secondary_DoorSetting_ShaftPosition2_X": 0,
              "Secondary_DoorSetting_ShaftPosition1_Y": 0,
              "Secondary_DoorSetting_ShaftPosition2_Y": 0
          }
          scope.sliders_sec = {
              capture_counts_sec: timeofflight.Secondary_Log_OutputCounts,
              height_canopy_sec: timeofflight.Secondary_DoorSetting_HeightUnderCanopy,
              door_diameter_sec: timeofflight.Secondary_DoorSetting_Diameter,
              capture_image_sec: timeofflight.Secondary_Log_Capture,
              sensor_direction_sec: timeofflight.Secondary_DoorSetting_SensorDirection,
              secondary_door_setting_open_sec: timeofflight.Secondary_DoorSetting_DoorOpen,
              secondary_door_setting_close_sec: timeofflight.Secondary_DoorSetting_DoorClose,
              wheel_chair_sec: timeofflight.Secondary_DoorSetting_WheelChair,
              verification_device_sec: timeofflight.Secondary_DoorSetting_VerificationDevice,
              lowObjValue_sec: timeofflight.Secondary_Sensitivity_LowObject,
              blindingValue_sec: timeofflight.Secondary_Sensitivity_SensorBlinding,
              onePersonValue_sec: timeofflight.Secondary_Sensitivity_OnePerson,
              morePersonValue_sec: timeofflight.Secondary_Sensitivity_MorePerson,
              volumeValue_sec: timeofflight.Secondary_Sensitivity_Volume,
              momentValue_sec: timeofflight.Secondary_Sensitivity_Moment,
              x_shaft_1x_sec: timeofflight.Secondary_DoorSetting_ShaftPosition1_X,
              x_shaft_2x_sec: timeofflight.Secondary_DoorSetting_ShaftPosition2_X,
              x_shaft_11x_sec: timeofflight.Secondary_DoorSetting_ShaftPosition1_Y,
              x_shaft_22x_sec: timeofflight.Secondary_DoorSetting_ShaftPosition2_Y,
              min: 1,
              max: 9
          }
          spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise)
          spyOn(mockEditDoorService, 'putTimeofFlight').and.returnValue(deferred.promise);
          spyOn(mockEditDoorService, 'updateStereovisionImage').and.returnValue(deffered_StereovisionImage.promise);
          scope.checkModel.secondary = true
          scope.validateTimeFlight()
          deferred.resolve(result);
          scope.$digest();
          expect(scope.tof_message_sec).toEqual(result.message)
          expect(scope.status).toEqual('success')
          scope.checkModel.primary = false;
          // scope.recaptureImage()
          // $timeout.flush();
          deffered_StereovisionImage.resolve(result);
          scope.$digest();

        });

        it('should test if validateTimeFlight works as expected if scope.checkModel.secondary is true and invalid values are entered', function() {
            spyOn(JSON, 'parse').and.returnValue({
                "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                "userName": "BoonAdmin",
                "admin": true,
                "level1": false,
                "level2": false,
                "level3": false,
                "level4": false,
                "level5": false,
                "level6": false,
                "level7": true,
                "level8": false,
                "level9": true,
                "level10": false
            });
            var dummyElement = document.createElement('canvas');
            var id = document.createAttribute("id");
            id.value = 'stereovisionCanvas';
            dummyElement.setAttributeNode(id);
            var width = document.createAttribute("width");
            width.value = '176px';
            dummyElement.setAttributeNode(width);
            var height = document.createAttribute("height");
            height.value = '132px';
            dummyElement.setAttributeNode(height);
            spyOn(document, 'getElementById').and.returnValue(dummyElement);
            createController();
            var result = {
                "success": true,
                "message": "Update successful.",
                "doorMain": [{
                    "id": 8,
                    "nodeid": "JAbmykU/TpSIAn6XF6PyP+Ub0JA=",
                    "DeviceID": "4",
                    "ip_number": "192.168.1.52",
                    "mac_address": "00:1f:7b:b2:14:d6",
                    "hostname": "",
                    "time_first_seen": 1454410566,
                    "time_last_seen": 1467491252,
                    "lastupdateby": "boonadmin",
                    "snoozeExitTime": 1467491852,
                    "real_name": "Bylorus RnD Wandbboard",
                    "location": "Aambeeldstraat",
                    "product_type": "Bylorus",
                    "last_state": "OK",
                    "users": "boon, walt",
                    "ce_number": "",
                    "latitude": "",
                    "longitude": "",
                    "timezone": null,
                    "campusId": "boonCampus",
                    "buildingId": "boonBuilding",
                    "entranceId": "boonEntrance",
                    "subEntranceId": "boonsub",
                    "campusName": "boonCampus",
                    "buildingName": null,
                    "entranceName": "boonEntrance",
                    "subEntranceName": "subEntranceT",
                    "companyId": 1,
                    "info1": "",
                    "info2": "",
                    "assigned": 1,
                    "flag": 0
                }],
                "transactionTimes": [],
                "rejectionCount": [],
                "timeOfFlight": [{
                    "id": 173,
                    "DeviceId": "4",
                    "EpochTime": 1467364984,
                    "Primary_Log_Capture": 0,
                    "Primary_Log_CaptureZero": 0,
                    "Primary_Log_CaptureOne": 0,
                    "Primary_Log_CaptureMore": 0,
                    "Primary_Log_CaptureSus": 0,
                    "Primary_Log_Still": 0,
                    "Primary_Log_StillZero": 0,
                    "Primary_Log_StillOne": 0,
                    "Primary_Log_StillMore": 0,
                    "Primary_Log_StillSus": 0,
                    "Primary_Log_OutputCounts": 0,
                    "Primary_OutputStatus_Authorization": 0,
                    "Primary_OutputStatus_Zero": 0,
                    "Primary_OutputStatus_One": 0,
                    "Primary_OutputStatus_More": 0,
                    "Primary_OutputStatus_Sus": 0,
                    "Primary_OutputStatus_Air": 0,
                    "Primary_Sensitivity_Volume": 5,
                    "Primary_Sensitivity_Moment": 4,
                    "Primary_Sensitivity_LowObject": 9,
                    "Primary_Sensitivity_SensorBlinding": 8,
                    "Primary_Sensitivity_OnePerson": 7,
                    "Primary_Sensitivity_MorePerson": 6,
                    "Primary_DoorSetting_SensorDirection": 0,
                    "Primary_DoorSetting_HeightUnderCanopy": 0,
                    "Primary_DoorSetting_Diameter": 0,
                    "Primary_DoorSetting_DoorOpen": 0,
                    "Primary_DoorSetting_DoorClose": 0,
                    "Primary_DoorSetting_VerificationDevice": 0,
                    "Primary_DoorSetting_WheelChair": 0,
                    "Primary_DoorSetting_ShaftPosition_X": 0,
                    "Primary_DoorSetting_ShaftPosition_Y": 0,
                    "Primary_DoorSetting_ShaftPosition1_X": 0,
                    "Primary_DoorSetting_ShaftPosition1_Y": 0,
                    "Primary_DoorSetting_ShaftPosition2_X": 0,
                    "Primary_DoorSetting_ShaftPosition2_Y": 0,
                    "Primary_DoorSetting_DoorPosition": 0,
                    "Primary_DoorSetting_OffsetAngle": 0,
                    "Primary_DoorSetting_TipOfEndPosition_X": 0,
                    "Primary_DoorSetting_TipOfEndPosition_Y": 0,
                    "Secondary_Log_Capture": 0,
                    "Secondary_Log_CaptureZero": 0,
                    "Secondary_Log_CaptureOne": 0,
                    "Secondary_Log_CaptureMore": 0,
                    "Secondary_Log_CaptureSus": 0,
                    "Secondary_Log_Still": 0,
                    "Secondary_Log_StillZero": 0,
                    "Secondary_Log_StillOne": 0,
                    "Secondary_Log_StillMore": 0,
                    "Secondary_Log_StillSus": 0,
                    "Secondary_Log_OutputCounts": 0,
                    "Secondary_OutputStatus_Authorization": 0,
                    "Secondary_OutputStatus_Zero": 0,
                    "Secondary_OutputStatus_One": 0,
                    "Secondary_OutputStatus_More": 0,
                    "Secondary_OutputStatus_Sus": 0,
                    "Secondary_OutputStatus_Air": 0,
                    "Secondary_Sensitivity_Volume": 0,
                    "Secondary_Sensitivity_Moment": 0,
                    "Secondary_Sensitivity_LowObject": 0,
                    "Secondary_Sensitivity_SensorBlinding": 0,
                    "Secondary_Sensitivity_OnePerson": 0,
                    "Secondary_Sensitivity_MorePerson": 0,
                    "Secondary_DoorSetting_SensorDirection": 0,
                    "Secondary_DoorSetting_HeightUnderCanopy": 0,
                    "Secondary_DoorSetting_Diameter": 0,
                    "Secondary_DoorSetting_DoorOpen": 0,
                    "Secondary_DoorSetting_DoorClose": 0,
                    "Secondary_DoorSetting_VerificationDevice": 0,
                    "Secondary_DoorSetting_WheelChair": 0,
                    "Secondary_DoorSetting_ShaftPosition_X": 0,
                    "Secondary_DoorSetting_ShaftPosition_Y": 0,
                    "Secondary_DoorSetting_ShaftPosition1_X": 0,
                    "Secondary_DoorSetting_ShaftPosition1_Y": 0,
                    "Secondary_DoorSetting_ShaftPosition2_X": 0,
                    "Secondary_DoorSetting_ShaftPosition2_Y": 0,
                    "Secondary_DoorSetting_DoorPosition": 0,
                    "Secondary_DoorSetting_OffsetAngle": 0,
                    "Secondary_DoorSetting_TipOfEndPosition_X": 0,
                    "Secondary_DoorSetting_TipOfEndPosition_Y": 0
                }],
                "plc": [{
                    "id": 3568,
                    "DeviceId": "4",
                    "EpochTime": 1466584246,
                    "Alarm": 0,
                    "BiometricRejectionCount": null,
                    "BothDoorsOpenCount": null,
                    "Cleaning": null,
                    "CleaningTime": 0,
                    "DelayTimeNoOutputSV": 0,
                    "DoorForcedCount": null,
                    "EndSwitchClosedInnerDoorDefective": 0,
                    "EndSwitchClosedOuterDoorDefective": 0,
                    "Event1st": 0,
                    "Event2nd": 0,
                    "Event3rd": 0,
                    "Event4th": 0,
                    "Event5th": 0,
                    "FireAlarmCount": null,
                    "FireAlarmModeSet": 0,
                    "IllegalTime": 0,
                    "IllegalUse": 0,
                    "IRSensorHungCount": null,
                    "IRSSensorDelay": 0,
                    "Locking": 0,
                    "LuminanceErrorDelay": 0,
                    "OnePersonInCount": null,
                    "OpeningCounterInnerDoor": 0,
                    "OpeningCounterOuterDoor": null,
                    "OpenTimeIn": 0,
                    "OpenTimeOut": 0,
                    "OverallTimeClosingInnerDoor": 0,
                    "OverallTimeClosingOuterDoor": 0,
                    "OverallTimeOpeningInnerDoor": 0,
                    "OverallTimeOpeningOuterDoor": 0,
                    "PowerLossCount": null,
                    "PresenceDelay": 0,
                    "PulsesInCounter": 0,
                    "PulsesInSpecialCounter": 0,
                    "PulsesOutCounter": 0,
                    "PulsesOutSpecialCounter": 0,
                    "Reset": 0,
                    "ReturnSignalInTime": 0,
                    "ReturnSignalOutTime": 0,
                    "ReverseButtonActivation": 0,
                    "SafetyRailInnerDoorClosing": 0,
                    "SafetyRailOuterDoorClosing": null,
                    "TimeExceededinCabinCount": null,
                    "TimeExceededMax": 0,
                    "TimeOutTime": 0,
                    "TOF0PersonIn": 0,
                    "TOF0PersonOut": 0,
                    "TOF1PersonIn": null,
                    "TOF1PersonOut": 0,
                    "TOF2PersonsIn": null,
                    "TOF2PersonsOut": 0,
                    "TOFRejection": 0,
                    "TOFRejectionsIn": null,
                    "TOFRejectionsOut": null,
                    "TOFSuspiciousIn": 0,
                    "TOFSuspiciousOut": 0,
                    "EndSwitchOutsideClosed": 0,
                    "EndSwitchOutsideSlow": 0,
                    "EndSwitchOutsideOpen": 0,
                    "EndSwitchInsideClosed": 0,
                    "EndSwitchInsideSlow": 0,
                    "EndSwitchInsideOpen": 0,
                    "BiometricAccessGranted": 0,
                    "FireAlarm": 0,
                    "MotorThermalOverload": 0,
                    "PowerFailure": 0,
                    "EmergencyButton": 0,
                    "SafetyRail": 0,
                    "PulseIn": 0,
                    "PulseOut": 0,
                    "PulseInSpecial": 0,
                    "PulseOutSpecial": 0,
                    "BothDoorsOpen": 0,
                    "LockSwitch": 0,
                    "IrisScanEntryRejected": null,
                    "InfraRedSensors": 0,
                    "SVSInOn": 0,
                    "SVSOutOn": 0,
                    "CleaningMode": 0,
                    "ResetSwitch": 0,
                    "EmptyDoorIn": 0,
                    "OnePersonIn": 0,
                    "TwoPersonIn": 0,
                    "SuspiciousIn": 0,
                    "AIRSensorsIn": 0,
                    "SVSEnabledIn": 0,
                    "EmptyDoorOut": 0,
                    "OnePersonOut": 0,
                    "TwoPersonOut": 0,
                    "SuspiciousOut": 0,
                    "AIRSensorsOut": 0,
                    "SVSEnabledOut": 0,
                    "ReturnSignalIn": 0,
                    "ReturnSignalOut": 0,
                    "MotorOuter": null,
                    "MotorInner": null,
                    "LockOuter": null,
                    "LockInner": null,
                    "MagLockOuter": null,
                    "MagLockInner": null,
                    "VFDForward": 0,
                    "VFDReverse": 0,
                    "VFDSpeedRef2and4": 0,
                    "VFDSpeedRef3and4": 0,
                    "VFDSecondAccDec": null,
                    "TOFReset": 0,
                    "TOFShutdown": 0,
                    "GeneralAlarm": 0,
                    "SignalLEDGreenIn": 0,
                    "SignalLEDRedIn": 0,
                    "SignalLEDGreenOut": 0,
                    "SignalLEDRedOut": 0,
                    "AuthorizationIn": 0,
                    "AIRActiveIn": 0,
                    "AuthorizationOut": 0,
                    "AIRActiveOut": 0,
                    "TwoPersonRejection": 0,
                    "BiometricRejection": 0,
                    "TimeExceededInCabin": 0,
                    "SafetyRailActivation": 0,
                    "EmergencyButtonActivation": 0,
                    "PowerLoss": 0,
                    "IRSensorHung": 0,
                    "PersonInCabin": null,
                    "BiometricStart": 0,
                    "OuterDoorClosed": 0,
                    "InnerDoorClosed": 0,
                    "EmergencyButtonLED": 0,
                    "Voice1": 0,
                    "Voice2": 0,
                    "SignalGreenInterior": 0,
                    "SignalRedInterior": 0,
                    "EnableBiometricEntry": null,
                    "EnableBiometricExit": null
                }],
                "motorDrive": [{
                    "id": 11,
                    "DeviceId": "4",
                    "EpochTime": 1466584661,
                    "OutputFrequency": 1,
                    "BaseFrequency": 0,
                    "OutputCurrent": 1,
                    "NormalSpeed": 1,
                    "OutputVoltage": null,
                    "BaseVoltage": null,
                    "SlowSpeedOuter": null,
                    "SlowSpeedInner": null,
                    "AccelerationTime1st": null,
                    "AccelerationTime2nd": null,
                    "DecelerationTime1st": null,
                    "DecelerationTime2nd": null,
                    "BrakingTime": null,
                    "Braking": null
                }],
                "doorStatus": null
            }
            var mockData = {
                "id": 4,
                "username": "boonadmin",
                "registrationdatetime": "2016-06-17T11:59:01.000Z",
                "level1": 1,
                "level2": 1,
                "level3": 1,
                "enabled": 1,
                "country": null,
                "campus": "boonCampus",
                "building": null,
                "entrance": null,
                "company_ID": null
            }

            var timeofflight = {
                "Secondary_Log_Capture": 0,
                "Secondary_Log_OutputCounts": "10",
                "Secondary_DoorSetting_HeightUnderCanopy": "1800",
                "Secondary_DoorSetting_Diameter": "1875",
                "Secondary_DoorSetting_SensorDirection": 0,
                "Secondary_DoorSetting_DoorOpen": 0,
                "Secondary_DoorSetting_DoorClose": 0,
                "Secondary_DoorSetting_WheelChair": 0,
                "Secondary_DoorSetting_VerificationDevice": 0,
                "Secondary_Sensitivity_LowObject": 0,
                "Secondary_Sensitivity_SensorBlinding": 0,
                "Secondary_Sensitivity_OnePerson": 0,
                "Secondary_Sensitivity_MorePerson": 0,
                "Secondary_Sensitivity_Volume": 0,
                "Secondary_Sensitivity_Moment": 0,
                "Secondary_DoorSetting_ShaftPosition1_X": 172,
                "Secondary_DoorSetting_ShaftPosition2_X": 172,
                "Secondary_DoorSetting_ShaftPosition1_Y": 132,
                "Secondary_DoorSetting_ShaftPosition2_Y": 132
            }
            scope.sliders_sec = {
                capture_counts_sec: timeofflight.Secondary_Log_OutputCounts,
                height_canopy_sec: timeofflight.Secondary_DoorSetting_HeightUnderCanopy,
                door_diameter_sec: timeofflight.Secondary_DoorSetting_Diameter,
                capture_image_sec: timeofflight.Secondary_Log_Capture,
                sensor_direction_sec: timeofflight.Secondary_DoorSetting_SensorDirection,
                secondary_door_setting_open_sec: timeofflight.Secondary_DoorSetting_DoorOpen,
                secondary_door_setting_close_sec: timeofflight.Secondary_DoorSetting_DoorClose,
                wheel_chair_sec: timeofflight.Secondary_DoorSetting_WheelChair,
                verification_device_sec: timeofflight.Secondary_DoorSetting_VerificationDevice,
                lowObjValue_sec: timeofflight.Secondary_Sensitivity_LowObject,
                blindingValue_sec: timeofflight.Secondary_Sensitivity_SensorBlinding,
                onePersonValue_sec: timeofflight.Secondary_Sensitivity_OnePerson,
                morePersonValue_sec: timeofflight.Secondary_Sensitivity_MorePerson,
                volumeValue_sec: timeofflight.Secondary_Sensitivity_Volume,
                momentValue_sec: timeofflight.Secondary_Sensitivity_Moment,
                x_shaft_1x_sec: timeofflight.Secondary_DoorSetting_ShaftPosition1_X,
                x_shaft_2x_sec: timeofflight.Secondary_DoorSetting_ShaftPosition2_X,
                x_shaft_11x_sec: timeofflight.Secondary_DoorSetting_ShaftPosition1_Y,
                x_shaft_22x_sec: timeofflight.Secondary_DoorSetting_ShaftPosition2_Y,
                min: 1,
                max: 9
            }
            scope.original_time_of_flight_sec = {
                capture_counts_sec: 0,
                height_canopy_sec: 0,
                door_diameter_sec: 0,
                capture_image_sec: 0,
                sensor_direction_sec: 0,
                secondary_door_setting_open_sec: 0,
                secondary_door_setting_close_sec: 0,
                wheel_chair_sec: 0,
                verification_device_sec: 0,
                lowObjValue_sec: 0,
                blindingValue_sec: 0,
                onePersonValue_sec: 0,
                morePersonValue_sec: 0,
                volumeValue_sec: 0,
                momentValue_sec: 0,
                x_shaft_1x_sec: 0,
                x_shaft_2x_sec: 0,
                x_shaft_11x_sec: 0,
                x_shaft_22x_sec: 0,
                min: 1,
                max: 9
            }
            spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise)
            spyOn(mockEditDoorService, 'putTimeofFlight').and.returnValue(deferred.promise);
            scope.checkModel.secondary = true
            scope.validateTimeFlight()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.tof_message).not.toEqual(result.message)

        });

        it('should test if validateMotorDrive works as expected', function() {
            spyOn(JSON, 'parse').and.returnValue({
                  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                  "userName": "BoonAdmin",
                  "admin": true,
                  "level1": false,
                  "level2": false,
                  "level3": false,
                  "level4": false,
                  "level5": false,
                  "level6": true,
                  "level7": false,
                  "level8": false,
                  "level9": true,
                  "level10": false
                });
            var dummyElement = document.createElement('canvas');
            var id = document.createAttribute("id");
            id.value = 'stereovisionCanvas';
            dummyElement.setAttributeNode(id);
            var width = document.createAttribute("width");
            width.value = '176px';
            dummyElement.setAttributeNode(width);
            var height = document.createAttribute("height");
            height.value = '132px';
            dummyElement.setAttributeNode(height);
            spyOn(document, 'getElementById').and.returnValue(dummyElement);
            createController();
            var result = {
                "success": true,
                "message": "Update successful.",
                "doorMain": [{
                    "id": 8,
                    "nodeid": "JAbmykU/TpSIAn6XF6PyP+Ub0JA=",
                    "DeviceID": "4",
                    "ip_number": "192.168.1.52",
                    "mac_address": "00:1f:7b:b2:14:d6",
                    "hostname": "",
                    "time_first_seen": 1454410566,
                    "time_last_seen": 1467491252,
                    "lastupdateby": "boonadmin",
                    "snoozeExitTime": 1467491852,
                    "real_name": "Bylorus RnD Wandbboard",
                    "location": "Aambeeldstraat",
                    "product_type": "Bylorus",
                    "last_state": "OK",
                    "users": "boon, walt",
                    "ce_number": "",
                    "latitude": "",
                    "longitude": "",
                    "timezone": null,
                    "campusId": "boonCampus",
                    "buildingId": "boonBuilding",
                    "entranceId": "boonEntrance",
                    "subEntranceId": "boonsub",
                    "campusName": "boonCampus",
                    "buildingName": null,
                    "entranceName": "boonEntrance",
                    "subEntranceName": "subEntranceT",
                    "companyId": 1,
                    "info1": "",
                    "info2": "",
                    "assigned": 1,
                    "flag": 0
                }],
                "transactionTimes": [],
                "rejectionCount": [],
                "timeOfFlight": [{
                    "id": 173,
                    "DeviceId": "4",
                    "EpochTime": 1467364984,
                    "Primary_Log_Capture": 0,
                    "Primary_Log_CaptureZero": 0,
                    "Primary_Log_CaptureOne": 0,
                    "Primary_Log_CaptureMore": 0,
                    "Primary_Log_CaptureSus": 0,
                    "Primary_Log_Still": 0,
                    "Primary_Log_StillZero": 0,
                    "Primary_Log_StillOne": 0,
                    "Primary_Log_StillMore": 0,
                    "Primary_Log_StillSus": 0,
                    "Primary_Log_OutputCounts": 0,
                    "Primary_OutputStatus_Authorization": 0,
                    "Primary_OutputStatus_Zero": 0,
                    "Primary_OutputStatus_One": 0,
                    "Primary_OutputStatus_More": 0,
                    "Primary_OutputStatus_Sus": 0,
                    "Primary_OutputStatus_Air": 0,
                    "Primary_Sensitivity_Volume": 5,
                    "Primary_Sensitivity_Moment": 4,
                    "Primary_Sensitivity_LowObject": 9,
                    "Primary_Sensitivity_SensorBlinding": 8,
                    "Primary_Sensitivity_OnePerson": 7,
                    "Primary_Sensitivity_MorePerson": 6,
                    "Primary_DoorSetting_SensorDirection": 0,
                    "Primary_DoorSetting_HeightUnderCanopy": 0,
                    "Primary_DoorSetting_Diameter": 0,
                    "Primary_DoorSetting_DoorOpen": 0,
                    "Primary_DoorSetting_DoorClose": 0,
                    "Primary_DoorSetting_VerificationDevice": 0,
                    "Primary_DoorSetting_WheelChair": 0,
                    "Primary_DoorSetting_ShaftPosition_X": 0,
                    "Primary_DoorSetting_ShaftPosition_Y": 0,
                    "Primary_DoorSetting_ShaftPosition1_X": 0,
                    "Primary_DoorSetting_ShaftPosition1_Y": 0,
                    "Primary_DoorSetting_ShaftPosition2_X": 0,
                    "Primary_DoorSetting_ShaftPosition2_Y": 0,
                    "Primary_DoorSetting_DoorPosition": 0,
                    "Primary_DoorSetting_OffsetAngle": 0,
                    "Primary_DoorSetting_TipOfEndPosition_X": 0,
                    "Primary_DoorSetting_TipOfEndPosition_Y": 0,
                    "Secondary_Log_Capture": 0,
                    "Secondary_Log_CaptureZero": 0,
                    "Secondary_Log_CaptureOne": 0,
                    "Secondary_Log_CaptureMore": 0,
                    "Secondary_Log_CaptureSus": 0,
                    "Secondary_Log_Still": 0,
                    "Secondary_Log_StillZero": 0,
                    "Secondary_Log_StillOne": 0,
                    "Secondary_Log_StillMore": 0,
                    "Secondary_Log_StillSus": 0,
                    "Secondary_Log_OutputCounts": 0,
                    "Secondary_OutputStatus_Authorization": 0,
                    "Secondary_OutputStatus_Zero": 0,
                    "Secondary_OutputStatus_One": 0,
                    "Secondary_OutputStatus_More": 0,
                    "Secondary_OutputStatus_Sus": 0,
                    "Secondary_OutputStatus_Air": 0,
                    "Secondary_Sensitivity_Volume": 0,
                    "Secondary_Sensitivity_Moment": 0,
                    "Secondary_Sensitivity_LowObject": 0,
                    "Secondary_Sensitivity_SensorBlinding": 0,
                    "Secondary_Sensitivity_OnePerson": 0,
                    "Secondary_Sensitivity_MorePerson": 0,
                    "Secondary_DoorSetting_SensorDirection": 0,
                    "Secondary_DoorSetting_HeightUnderCanopy": 0,
                    "Secondary_DoorSetting_Diameter": 0,
                    "Secondary_DoorSetting_DoorOpen": 0,
                    "Secondary_DoorSetting_DoorClose": 0,
                    "Secondary_DoorSetting_VerificationDevice": 0,
                    "Secondary_DoorSetting_WheelChair": 0,
                    "Secondary_DoorSetting_ShaftPosition_X": 0,
                    "Secondary_DoorSetting_ShaftPosition_Y": 0,
                    "Secondary_DoorSetting_ShaftPosition1_X": 0,
                    "Secondary_DoorSetting_ShaftPosition1_Y": 0,
                    "Secondary_DoorSetting_ShaftPosition2_X": 0,
                    "Secondary_DoorSetting_ShaftPosition2_Y": 0,
                    "Secondary_DoorSetting_DoorPosition": 0,
                    "Secondary_DoorSetting_OffsetAngle": 0,
                    "Secondary_DoorSetting_TipOfEndPosition_X": 0,
                    "Secondary_DoorSetting_TipOfEndPosition_Y": 0
                }],
                "plc": [{
                    "id": 3568,
                    "DeviceId": "4",
                    "EpochTime": 1466584246,
                    "Alarm": 0,
                    "BiometricRejectionCount": null,
                    "BothDoorsOpenCount": null,
                    "Cleaning": null,
                    "CleaningTime": 0,
                    "DelayTimeNoOutputSV": 0,
                    "DoorForcedCount": null,
                    "EndSwitchClosedInnerDoorDefective": 0,
                    "EndSwitchClosedOuterDoorDefective": 0,
                    "Event1st": 0,
                    "Event2nd": 0,
                    "Event3rd": 0,
                    "Event4th": 0,
                    "Event5th": 0,
                    "FireAlarmCount": null,
                    "FireAlarmModeSet": 0,
                    "IllegalTime": 0,
                    "IllegalUse": 0,
                    "IRSensorHungCount": null,
                    "IRSSensorDelay": 0,
                    "Locking": 0,
                    "LuminanceErrorDelay": 0,
                    "OnePersonInCount": null,
                    "OpeningCounterInnerDoor": 0,
                    "OpeningCounterOuterDoor": null,
                    "OpenTimeIn": 0,
                    "OpenTimeOut": 0,
                    "OverallTimeClosingInnerDoor": 0,
                    "OverallTimeClosingOuterDoor": 0,
                    "OverallTimeOpeningInnerDoor": 0,
                    "OverallTimeOpeningOuterDoor": 0,
                    "PowerLossCount": null,
                    "PresenceDelay": 0,
                    "PulsesInCounter": 0,
                    "PulsesInSpecialCounter": 0,
                    "PulsesOutCounter": 0,
                    "PulsesOutSpecialCounter": 0,
                    "Reset": 0,
                    "ReturnSignalInTime": 0,
                    "ReturnSignalOutTime": 0,
                    "ReverseButtonActivation": 0,
                    "SafetyRailInnerDoorClosing": 0,
                    "SafetyRailOuterDoorClosing": null,
                    "TimeExceededinCabinCount": null,
                    "TimeExceededMax": 0,
                    "TimeOutTime": 0,
                    "TOF0PersonIn": 0,
                    "TOF0PersonOut": 0,
                    "TOF1PersonIn": null,
                    "TOF1PersonOut": 0,
                    "TOF2PersonsIn": null,
                    "TOF2PersonsOut": 0,
                    "TOFRejection": 0,
                    "TOFRejectionsIn": null,
                    "TOFRejectionsOut": null,
                    "TOFSuspiciousIn": 0,
                    "TOFSuspiciousOut": 0,
                    "EndSwitchOutsideClosed": 0,
                    "EndSwitchOutsideSlow": 0,
                    "EndSwitchOutsideOpen": 0,
                    "EndSwitchInsideClosed": 0,
                    "EndSwitchInsideSlow": 0,
                    "EndSwitchInsideOpen": 0,
                    "BiometricAccessGranted": 0,
                    "FireAlarm": 0,
                    "MotorThermalOverload": 0,
                    "PowerFailure": 0,
                    "EmergencyButton": 0,
                    "SafetyRail": 0,
                    "PulseIn": 0,
                    "PulseOut": 0,
                    "PulseInSpecial": 0,
                    "PulseOutSpecial": 0,
                    "BothDoorsOpen": 0,
                    "LockSwitch": 0,
                    "IrisScanEntryRejected": null,
                    "InfraRedSensors": 0,
                    "SVSInOn": 0,
                    "SVSOutOn": 0,
                    "CleaningMode": 0,
                    "ResetSwitch": 0,
                    "EmptyDoorIn": 0,
                    "OnePersonIn": 0,
                    "TwoPersonIn": 0,
                    "SuspiciousIn": 0,
                    "AIRSensorsIn": 0,
                    "SVSEnabledIn": 0,
                    "EmptyDoorOut": 0,
                    "OnePersonOut": 0,
                    "TwoPersonOut": 0,
                    "SuspiciousOut": 0,
                    "AIRSensorsOut": 0,
                    "SVSEnabledOut": 0,
                    "ReturnSignalIn": 0,
                    "ReturnSignalOut": 0,
                    "MotorOuter": null,
                    "MotorInner": null,
                    "LockOuter": null,
                    "LockInner": null,
                    "MagLockOuter": null,
                    "MagLockInner": null,
                    "VFDForward": 0,
                    "VFDReverse": 0,
                    "VFDSpeedRef2and4": 0,
                    "VFDSpeedRef3and4": 0,
                    "VFDSecondAccDec": null,
                    "TOFReset": 0,
                    "TOFShutdown": 0,
                    "GeneralAlarm": 0,
                    "SignalLEDGreenIn": 0,
                    "SignalLEDRedIn": 0,
                    "SignalLEDGreenOut": 0,
                    "SignalLEDRedOut": 0,
                    "AuthorizationIn": 0,
                    "AIRActiveIn": 0,
                    "AuthorizationOut": 0,
                    "AIRActiveOut": 0,
                    "TwoPersonRejection": 0,
                    "BiometricRejection": 0,
                    "TimeExceededInCabin": 0,
                    "SafetyRailActivation": 0,
                    "EmergencyButtonActivation": 0,
                    "PowerLoss": 0,
                    "IRSensorHung": 0,
                    "PersonInCabin": null,
                    "BiometricStart": 0,
                    "OuterDoorClosed": 0,
                    "InnerDoorClosed": 0,
                    "EmergencyButtonLED": 0,
                    "Voice1": 0,
                    "Voice2": 0,
                    "SignalGreenInterior": 0,
                    "SignalRedInterior": 0,
                    "EnableBiometricEntry": null,
                    "EnableBiometricExit": null
                }],
                "motorDrive": [{
                    "id": 11,
                    "DeviceId": "4",
                    "EpochTime": 1466584661,
                    "OutputFrequency": 1,
                    "BaseFrequency": 0,
                    "OutputCurrent": 1,
                    "NormalSpeed": 1,
                    "OutputVoltage": null,
                    "BaseVoltage": null,
                    "SlowSpeedOuter": null,
                    "SlowSpeedInner": null,
                    "AccelerationTime1st": null,
                    "AccelerationTime2nd": null,
                    "DecelerationTime1st": null,
                    "DecelerationTime2nd": null,
                    "BrakingTime": null,
                    "Braking": null
                }],
                "doorStatus": null
            }
            var mockData = {
                    "id": 4,
                    "username": "boonadmin",
                    "registrationdatetime": "2016-06-17T11:59:01.000Z",
                    "level1": 1,
                    "level2": 1,
                    "level3": 1,
                    "enabled": 1,
                    "country": null,
                    "campus": "boonCampus",
                    "building": null,
                    "entrance": null,
                    "company_ID": null
                }
            var motorDrive = {
                "output_frequency": 1,
                "output_current": 67,
                "output_voltage": 3,
                "base_frequency": 30,
                "normal_speed": 40,
                "base_voltage": 75,
                "slow_speed_outer": 5,
                "slow_speed_inner": 5,
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "9"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise)
            spyOn(mockEditDoorService, 'putMotorDrive').and.returnValue(deferred.promise);
            scope.validateMotorDrive()
            deferred.resolve(result); // Resolve the promise.
            scope.$digest();
            expect(scope.mtrdrve_message).toEqual(result.message)
          });

          it('should test if validateMotorDrive works as expected if valid values are entered', function() {
              spyOn(JSON, 'parse').and.returnValue({
                  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                  "userName": "BoonAdmin",
                  "admin": true,
                  "level1": false,
                  "level2": false,
                  "level3": false,
                  "level4": false,
                  "level5": false,
                  "level6": true,
                  "level7": false,
                  "level8": false,
                  "level9": true,
                  "level10": false
              });
              var dummyElement = document.createElement('canvas');
              var id = document.createAttribute("id");
              id.value = 'stereovisionCanvas';
              dummyElement.setAttributeNode(id);
              var width = document.createAttribute("width");
              width.value = '176px';
              dummyElement.setAttributeNode(width);
              var height = document.createAttribute("height");
              height.value = '132px';
              dummyElement.setAttributeNode(height);
              spyOn(document, 'getElementById').and.returnValue(dummyElement);
              createController();
              var result = {
                  "success": true,
                  "message": "Update successful.",
                  "doorMain": [{
                      "id": 8,
                      "nodeid": "JAbmykU/TpSIAn6XF6PyP+Ub0JA=",
                      "DeviceID": "4",
                      "ip_number": "192.168.1.52",
                      "mac_address": "00:1f:7b:b2:14:d6",
                      "hostname": "",
                      "time_first_seen": 1454410566,
                      "time_last_seen": 1467491252,
                      "lastupdateby": "boonadmin",
                      "snoozeExitTime": 1467491852,
                      "real_name": "Bylorus RnD Wandbboard",
                      "location": "Aambeeldstraat",
                      "product_type": "Bylorus",
                      "last_state": "OK",
                      "users": "boon, walt",
                      "ce_number": "",
                      "latitude": "",
                      "longitude": "",
                      "timezone": null,
                      "campusId": "boonCampus",
                      "buildingId": "boonBuilding",
                      "entranceId": "boonEntrance",
                      "subEntranceId": "boonsub",
                      "campusName": "boonCampus",
                      "buildingName": null,
                      "entranceName": "boonEntrance",
                      "subEntranceName": "subEntranceT",
                      "companyId": 1,
                      "info1": "",
                      "info2": "",
                      "assigned": 1,
                      "flag": 0
                  }],
                  "transactionTimes": [],
                  "rejectionCount": [],
                  "timeOfFlight": [{
                      "id": 173,
                      "DeviceId": "4",
                      "EpochTime": 1467364984,
                      "Primary_Log_Capture": 0,
                      "Primary_Log_CaptureZero": 0,
                      "Primary_Log_CaptureOne": 0,
                      "Primary_Log_CaptureMore": 0,
                      "Primary_Log_CaptureSus": 0,
                      "Primary_Log_Still": 0,
                      "Primary_Log_StillZero": 0,
                      "Primary_Log_StillOne": 0,
                      "Primary_Log_StillMore": 0,
                      "Primary_Log_StillSus": 0,
                      "Primary_Log_OutputCounts": 0,
                      "Primary_OutputStatus_Authorization": 0,
                      "Primary_OutputStatus_Zero": 0,
                      "Primary_OutputStatus_One": 0,
                      "Primary_OutputStatus_More": 0,
                      "Primary_OutputStatus_Sus": 0,
                      "Primary_OutputStatus_Air": 0,
                      "Primary_Sensitivity_Volume": 5,
                      "Primary_Sensitivity_Moment": 4,
                      "Primary_Sensitivity_LowObject": 9,
                      "Primary_Sensitivity_SensorBlinding": 8,
                      "Primary_Sensitivity_OnePerson": 7,
                      "Primary_Sensitivity_MorePerson": 6,
                      "Primary_DoorSetting_SensorDirection": 0,
                      "Primary_DoorSetting_HeightUnderCanopy": 0,
                      "Primary_DoorSetting_Diameter": 0,
                      "Primary_DoorSetting_DoorOpen": 0,
                      "Primary_DoorSetting_DoorClose": 0,
                      "Primary_DoorSetting_VerificationDevice": 0,
                      "Primary_DoorSetting_WheelChair": 0,
                      "Primary_DoorSetting_ShaftPosition_X": 0,
                      "Primary_DoorSetting_ShaftPosition_Y": 0,
                      "Primary_DoorSetting_ShaftPosition1_X": 0,
                      "Primary_DoorSetting_ShaftPosition1_Y": 0,
                      "Primary_DoorSetting_ShaftPosition2_X": 0,
                      "Primary_DoorSetting_ShaftPosition2_Y": 0,
                      "Primary_DoorSetting_DoorPosition": 0,
                      "Primary_DoorSetting_OffsetAngle": 0,
                      "Primary_DoorSetting_TipOfEndPosition_X": 0,
                      "Primary_DoorSetting_TipOfEndPosition_Y": 0,
                      "Secondary_Log_Capture": 0,
                      "Secondary_Log_CaptureZero": 0,
                      "Secondary_Log_CaptureOne": 0,
                      "Secondary_Log_CaptureMore": 0,
                      "Secondary_Log_CaptureSus": 0,
                      "Secondary_Log_Still": 0,
                      "Secondary_Log_StillZero": 0,
                      "Secondary_Log_StillOne": 0,
                      "Secondary_Log_StillMore": 0,
                      "Secondary_Log_StillSus": 0,
                      "Secondary_Log_OutputCounts": 0,
                      "Secondary_OutputStatus_Authorization": 0,
                      "Secondary_OutputStatus_Zero": 0,
                      "Secondary_OutputStatus_One": 0,
                      "Secondary_OutputStatus_More": 0,
                      "Secondary_OutputStatus_Sus": 0,
                      "Secondary_OutputStatus_Air": 0,
                      "Secondary_Sensitivity_Volume": 0,
                      "Secondary_Sensitivity_Moment": 0,
                      "Secondary_Sensitivity_LowObject": 0,
                      "Secondary_Sensitivity_SensorBlinding": 0,
                      "Secondary_Sensitivity_OnePerson": 0,
                      "Secondary_Sensitivity_MorePerson": 0,
                      "Secondary_DoorSetting_SensorDirection": 0,
                      "Secondary_DoorSetting_HeightUnderCanopy": 0,
                      "Secondary_DoorSetting_Diameter": 0,
                      "Secondary_DoorSetting_DoorOpen": 0,
                      "Secondary_DoorSetting_DoorClose": 0,
                      "Secondary_DoorSetting_VerificationDevice": 0,
                      "Secondary_DoorSetting_WheelChair": 0,
                      "Secondary_DoorSetting_ShaftPosition_X": 0,
                      "Secondary_DoorSetting_ShaftPosition_Y": 0,
                      "Secondary_DoorSetting_ShaftPosition1_X": 0,
                      "Secondary_DoorSetting_ShaftPosition1_Y": 0,
                      "Secondary_DoorSetting_ShaftPosition2_X": 0,
                      "Secondary_DoorSetting_ShaftPosition2_Y": 0,
                      "Secondary_DoorSetting_DoorPosition": 0,
                      "Secondary_DoorSetting_OffsetAngle": 0,
                      "Secondary_DoorSetting_TipOfEndPosition_X": 0,
                      "Secondary_DoorSetting_TipOfEndPosition_Y": 0
                  }],
                  "plc": [{
                      "id": 3568,
                      "DeviceId": "4",
                      "EpochTime": 1466584246,
                      "Alarm": 0,
                      "BiometricRejectionCount": null,
                      "BothDoorsOpenCount": null,
                      "Cleaning": null,
                      "CleaningTime": 0,
                      "DelayTimeNoOutputSV": 0,
                      "DoorForcedCount": null,
                      "EndSwitchClosedInnerDoorDefective": 0,
                      "EndSwitchClosedOuterDoorDefective": 0,
                      "Event1st": 0,
                      "Event2nd": 0,
                      "Event3rd": 0,
                      "Event4th": 0,
                      "Event5th": 0,
                      "FireAlarmCount": null,
                      "FireAlarmModeSet": 0,
                      "IllegalTime": 0,
                      "IllegalUse": 0,
                      "IRSensorHungCount": null,
                      "IRSSensorDelay": 0,
                      "Locking": 0,
                      "LuminanceErrorDelay": 0,
                      "OnePersonInCount": null,
                      "OpeningCounterInnerDoor": 0,
                      "OpeningCounterOuterDoor": null,
                      "OpenTimeIn": 0,
                      "OpenTimeOut": 0,
                      "OverallTimeClosingInnerDoor": 0,
                      "OverallTimeClosingOuterDoor": 0,
                      "OverallTimeOpeningInnerDoor": 0,
                      "OverallTimeOpeningOuterDoor": 0,
                      "PowerLossCount": null,
                      "PresenceDelay": 0,
                      "PulsesInCounter": 0,
                      "PulsesInSpecialCounter": 0,
                      "PulsesOutCounter": 0,
                      "PulsesOutSpecialCounter": 0,
                      "Reset": 0,
                      "ReturnSignalInTime": 0,
                      "ReturnSignalOutTime": 0,
                      "ReverseButtonActivation": 0,
                      "SafetyRailInnerDoorClosing": 0,
                      "SafetyRailOuterDoorClosing": null,
                      "TimeExceededinCabinCount": null,
                      "TimeExceededMax": 0,
                      "TimeOutTime": 0,
                      "TOF0PersonIn": 0,
                      "TOF0PersonOut": 0,
                      "TOF1PersonIn": null,
                      "TOF1PersonOut": 0,
                      "TOF2PersonsIn": null,
                      "TOF2PersonsOut": 0,
                      "TOFRejection": 0,
                      "TOFRejectionsIn": null,
                      "TOFRejectionsOut": null,
                      "TOFSuspiciousIn": 0,
                      "TOFSuspiciousOut": 0,
                      "EndSwitchOutsideClosed": 0,
                      "EndSwitchOutsideSlow": 0,
                      "EndSwitchOutsideOpen": 0,
                      "EndSwitchInsideClosed": 0,
                      "EndSwitchInsideSlow": 0,
                      "EndSwitchInsideOpen": 0,
                      "BiometricAccessGranted": 0,
                      "FireAlarm": 0,
                      "MotorThermalOverload": 0,
                      "PowerFailure": 0,
                      "EmergencyButton": 0,
                      "SafetyRail": 0,
                      "PulseIn": 0,
                      "PulseOut": 0,
                      "PulseInSpecial": 0,
                      "PulseOutSpecial": 0,
                      "BothDoorsOpen": 0,
                      "LockSwitch": 0,
                      "IrisScanEntryRejected": null,
                      "InfraRedSensors": 0,
                      "SVSInOn": 0,
                      "SVSOutOn": 0,
                      "CleaningMode": 0,
                      "ResetSwitch": 0,
                      "EmptyDoorIn": 0,
                      "OnePersonIn": 0,
                      "TwoPersonIn": 0,
                      "SuspiciousIn": 0,
                      "AIRSensorsIn": 0,
                      "SVSEnabledIn": 0,
                      "EmptyDoorOut": 0,
                      "OnePersonOut": 0,
                      "TwoPersonOut": 0,
                      "SuspiciousOut": 0,
                      "AIRSensorsOut": 0,
                      "SVSEnabledOut": 0,
                      "ReturnSignalIn": 0,
                      "ReturnSignalOut": 0,
                      "MotorOuter": null,
                      "MotorInner": null,
                      "LockOuter": null,
                      "LockInner": null,
                      "MagLockOuter": null,
                      "MagLockInner": null,
                      "VFDForward": 0,
                      "VFDReverse": 0,
                      "VFDSpeedRef2and4": 0,
                      "VFDSpeedRef3and4": 0,
                      "VFDSecondAccDec": null,
                      "TOFReset": 0,
                      "TOFShutdown": 0,
                      "GeneralAlarm": 0,
                      "SignalLEDGreenIn": 0,
                      "SignalLEDRedIn": 0,
                      "SignalLEDGreenOut": 0,
                      "SignalLEDRedOut": 0,
                      "AuthorizationIn": 0,
                      "AIRActiveIn": 0,
                      "AuthorizationOut": 0,
                      "AIRActiveOut": 0,
                      "TwoPersonRejection": 0,
                      "BiometricRejection": 0,
                      "TimeExceededInCabin": 0,
                      "SafetyRailActivation": 0,
                      "EmergencyButtonActivation": 0,
                      "PowerLoss": 0,
                      "IRSensorHung": 0,
                      "PersonInCabin": null,
                      "BiometricStart": 0,
                      "OuterDoorClosed": 0,
                      "InnerDoorClosed": 0,
                      "EmergencyButtonLED": 0,
                      "Voice1": 0,
                      "Voice2": 0,
                      "SignalGreenInterior": 0,
                      "SignalRedInterior": 0,
                      "EnableBiometricEntry": null,
                      "EnableBiometricExit": null
                  }],
                  "motorDrive": [{
                      "id": 11,
                      "DeviceId": "4",
                      "EpochTime": 1466584661,
                      "OutputFrequency": 1,
                      "BaseFrequency": 0,
                      "OutputCurrent": 1,
                      "NormalSpeed": 2000,
                      "OutputVoltage": null,
                      "BaseVoltage": null,
                      "SlowSpeedOuter": null,
                      "SlowSpeedInner": null,
                      "AccelerationTime1st": 100,
                      "AccelerationTime2nd": null,
                      "DecelerationTime1st": null,
                      "DecelerationTime2nd": null,
                      "BrakingTime": null,
                      "Braking": null
                  }],
                  "doorStatus": null
              }
              var mockData = {
                      "id": 4,
                      "username": "boonadmin",
                      "registrationdatetime": "2016-06-17T11:59:01.000Z",
                      "level1": 1,
                      "level2": 1,
                      "level3": 1,
                      "enabled": 1,
                      "country": null,
                      "campus": "boonCampus",
                      "building": null,
                      "entrance": null,
                      "company_ID": null
                  }
              var motorDrive = {
                  "base_frequency": '30.01',
                  "normal_speed": '35.01',
                  "base_voltage": '75.1',
                  "slow_speed_outer": '5.2',
                  "slow_speed_inner": '5.2',
                  "aec_time_one": "0.8",
                  "aec_time_two": "0.8",
                  "dec_time_one": "0.8",
                  "dec_time_two": "0.8",
                  "break_time": "0.2",
                  "break_percent": "11"
              }
              scope.mtr_drive = {
                  "output_frequency": motorDrive.output_frequency,
                  "output_current": motorDrive.output_current,
                  "output_voltage": motorDrive.output_voltage,
                  "base_frequency": motorDrive.base_frequency,
                  "normal_speed": motorDrive.normal_speed,
                  "base_voltage": motorDrive.base_voltage,
                  "slow_speed_outer": motorDrive.slow_speed_outer,
                  "slow_speed_inner": motorDrive.slow_speed_inner,
                  "aec_time_one": motorDrive.aec_time_one,
                  "aec_time_two": motorDrive.aec_time_two,
                  "dec_time_one": motorDrive.dec_time_one,
                  "dec_time_two": motorDrive.dec_time_two,
                  "break_time": motorDrive.break_time,
                  "break_percent": motorDrive.break_percent
              }
              scope.original_motor_drive = {
                  "output_frequency": 0,
                  "output_current": 0,
                  "output_voltage": 0,
                  "base_frequency": 0,
                  "normal_speed": 0,
                  "base_voltage": 0,
                  "slow_speed_outer": 0,
                  "slow_speed_inner": 0,
                  "aec_time_one": 0,
                  "aec_time_two": 0,
                  "dec_time_one": 0,
                  "dec_time_two": 0,
                  "break_time": 0,
                  "break_percent": 0
              }

              spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise)
              spyOn(mockEditDoorService, 'putMotorDrive').and.returnValue(deferred.promise);
              scope.validateMotorDrive()
              deferred.resolve(result);
              scope.$digest();
              expect(scope.mtrdrve_message).toEqual(result.message)
              scope.resetmsg()
              scope.base_frequency_msg=''
              scope.mtrdrve_message=''

              var motorDrive = {
                  "base_frequency": '80.00',
                  "normal_speed": '50.00',
                  "base_voltage": '150.0',
                  "slow_speed_outer": '9.25',
                  "slow_speed_inner": '9.25',
                  "aec_time_one": "1.0",
                  "aec_time_two": "0.8",
                  "dec_time_one": "0.8",
                  "dec_time_two": "0.8",
                  "break_time": "0.2",
                  "break_percent": "11"
              }
              scope.mtr_drive = {
                  "output_frequency": motorDrive.output_frequency,
                  "output_current": motorDrive.output_current,
                  "output_voltage": motorDrive.output_voltage,
                  "base_frequency": motorDrive.base_frequency,
                  "normal_speed": motorDrive.normal_speed,
                  "base_voltage": motorDrive.base_voltage,
                  "slow_speed_outer": motorDrive.slow_speed_outer,
                  "slow_speed_inner": motorDrive.slow_speed_inner,
                  "aec_time_one": motorDrive.aec_time_one,
                  "aec_time_two": motorDrive.aec_time_two,
                  "dec_time_one": motorDrive.dec_time_one,
                  "dec_time_two": motorDrive.dec_time_two,
                  "break_time": motorDrive.break_time,
                  "break_percent": motorDrive.break_percent
              }
              scope.original_motor_drive = {
                  "output_frequency": 0,
                  "output_current": 0,
                  "output_voltage": 0,
                  "base_frequency": 0,
                  "normal_speed": 0,
                  "base_voltage": 0,
                  "slow_speed_outer": 0,
                  "slow_speed_inner": 0,
                  "aec_time_one": 0,
                  "aec_time_two": 0,
                  "dec_time_one": 0,
                  "dec_time_two": 0,
                  "break_time": 0,
                  "break_percent": 0
              }

              scope.validateMotorDrive()
              deferred.resolve(result);
              scope.$digest();
              expect(scope.mtrdrve_message).toEqual(result.message)
              scope.resetmsg()
              scope.base_frequency_msg=''
              scope.mtrdrve_message=''

              var motorDrive = {
                  "base_frequency": '80.00',
                  "normal_speed": '50.00',
                  "base_voltage": '150.0',
                  "slow_speed_outer": '10.00',
                  "slow_speed_inner": '10.00',
                  "aec_time_one": "1.0",
                  "aec_time_two": "0.8",
                  "dec_time_one": "0.8",
                  "dec_time_two": "0.8",
                  "break_time": "0.2",
                  "break_percent": "11"
              }
              scope.mtr_drive = {
                  "output_frequency": motorDrive.output_frequency,
                  "output_current": motorDrive.output_current,
                  "output_voltage": motorDrive.output_voltage,
                  "base_frequency": motorDrive.base_frequency,
                  "normal_speed": motorDrive.normal_speed,
                  "base_voltage": motorDrive.base_voltage,
                  "slow_speed_outer": motorDrive.slow_speed_outer,
                  "slow_speed_inner": motorDrive.slow_speed_inner,
                  "aec_time_one": motorDrive.aec_time_one,
                  "aec_time_two": motorDrive.aec_time_two,
                  "dec_time_one": motorDrive.dec_time_one,
                  "dec_time_two": motorDrive.dec_time_two,
                  "break_time": motorDrive.break_time,
                  "break_percent": motorDrive.break_percent
              }
              scope.original_motor_drive = {
                  "output_frequency": 0,
                  "output_current": 0,
                  "output_voltage": 0,
                  "base_frequency": 0,
                  "normal_speed": 0,
                  "base_voltage": 0,
                  "slow_speed_outer": 0,
                  "slow_speed_inner": 0,
                  "aec_time_one": 0,
                  "aec_time_two": 0,
                  "dec_time_one": 0,
                  "dec_time_two": 0,
                  "break_time": 0,
                  "break_percent": 0
              }

              scope.validateMotorDrive()
              deferred.resolve(result);
              scope.$digest();
              expect(scope.mtrdrve_message).toEqual(result.message)
              scope.resetmsg()
              scope.base_frequency_msg=''
              scope.mtrdrve_message=''
            });

        it('should test if validateMotorDrive works as expected if invalid values are entered', function() {
            spyOn(JSON, 'parse').and.returnValue({
                "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                "userName": "BoonAdmin",
                "admin": true,
                "level1": false,
                "level2": false,
                "level3": false,
                "level4": false,
                "level5": false,
                "level6": true,
                "level7": false,
                "level8": false,
                "level9": true,
                "level10": false
            });
            var dummyElement = document.createElement('canvas');
            var id = document.createAttribute("id");
            id.value = 'stereovisionCanvas';
            dummyElement.setAttributeNode(id);
            var width = document.createAttribute("width");
            width.value = '176px';
            dummyElement.setAttributeNode(width);
            var height = document.createAttribute("height");
            height.value = '132px';
            dummyElement.setAttributeNode(height);
            spyOn(document, 'getElementById').and.returnValue(dummyElement);
            createController();
            var result = {
                "success": true,
                "message": "Update successful.",
                "doorMain": [{
                    "id": 8,
                    "nodeid": "JAbmykU/TpSIAn6XF6PyP+Ub0JA=",
                    "DeviceID": "4",
                    "ip_number": "192.168.1.52",
                    "mac_address": "00:1f:7b:b2:14:d6",
                    "hostname": "",
                    "time_first_seen": 1454410566,
                    "time_last_seen": 1467491252,
                    "lastupdateby": "boonadmin",
                    "snoozeExitTime": 1467491852,
                    "real_name": "Bylorus RnD Wandbboard",
                    "location": "Aambeeldstraat",
                    "product_type": "Bylorus",
                    "last_state": "OK",
                    "users": "boon, walt",
                    "ce_number": "",
                    "latitude": "",
                    "longitude": "",
                    "timezone": null,
                    "campusId": "boonCampus",
                    "buildingId": "boonBuilding",
                    "entranceId": "boonEntrance",
                    "subEntranceId": "boonsub",
                    "campusName": "boonCampus",
                    "buildingName": null,
                    "entranceName": "boonEntrance",
                    "subEntranceName": "subEntranceT",
                    "companyId": 1,
                    "info1": "",
                    "info2": "",
                    "assigned": 1,
                    "flag": 0
                }],
                "transactionTimes": [],
                "rejectionCount": [],
                "timeOfFlight": [{
                    "id": 173,
                    "DeviceId": "4",
                    "EpochTime": 1467364984,
                    "Primary_Log_Capture": 0,
                    "Primary_Log_CaptureZero": 0,
                    "Primary_Log_CaptureOne": 0,
                    "Primary_Log_CaptureMore": 0,
                    "Primary_Log_CaptureSus": 0,
                    "Primary_Log_Still": 0,
                    "Primary_Log_StillZero": 0,
                    "Primary_Log_StillOne": 0,
                    "Primary_Log_StillMore": 0,
                    "Primary_Log_StillSus": 0,
                    "Primary_Log_OutputCounts": 0,
                    "Primary_OutputStatus_Authorization": 0,
                    "Primary_OutputStatus_Zero": 0,
                    "Primary_OutputStatus_One": 0,
                    "Primary_OutputStatus_More": 0,
                    "Primary_OutputStatus_Sus": 0,
                    "Primary_OutputStatus_Air": 0,
                    "Primary_Sensitivity_Volume": 5,
                    "Primary_Sensitivity_Moment": 4,
                    "Primary_Sensitivity_LowObject": 9,
                    "Primary_Sensitivity_SensorBlinding": 8,
                    "Primary_Sensitivity_OnePerson": 7,
                    "Primary_Sensitivity_MorePerson": 6,
                    "Primary_DoorSetting_SensorDirection": 0,
                    "Primary_DoorSetting_HeightUnderCanopy": 0,
                    "Primary_DoorSetting_Diameter": 0,
                    "Primary_DoorSetting_DoorOpen": 0,
                    "Primary_DoorSetting_DoorClose": 0,
                    "Primary_DoorSetting_VerificationDevice": 0,
                    "Primary_DoorSetting_WheelChair": 0,
                    "Primary_DoorSetting_ShaftPosition_X": 0,
                    "Primary_DoorSetting_ShaftPosition_Y": 0,
                    "Primary_DoorSetting_ShaftPosition1_X": 0,
                    "Primary_DoorSetting_ShaftPosition1_Y": 0,
                    "Primary_DoorSetting_ShaftPosition2_X": 0,
                    "Primary_DoorSetting_ShaftPosition2_Y": 0,
                    "Primary_DoorSetting_DoorPosition": 0,
                    "Primary_DoorSetting_OffsetAngle": 0,
                    "Primary_DoorSetting_TipOfEndPosition_X": 0,
                    "Primary_DoorSetting_TipOfEndPosition_Y": 0,
                    "Secondary_Log_Capture": 0,
                    "Secondary_Log_CaptureZero": 0,
                    "Secondary_Log_CaptureOne": 0,
                    "Secondary_Log_CaptureMore": 0,
                    "Secondary_Log_CaptureSus": 0,
                    "Secondary_Log_Still": 0,
                    "Secondary_Log_StillZero": 0,
                    "Secondary_Log_StillOne": 0,
                    "Secondary_Log_StillMore": 0,
                    "Secondary_Log_StillSus": 0,
                    "Secondary_Log_OutputCounts": 0,
                    "Secondary_OutputStatus_Authorization": 0,
                    "Secondary_OutputStatus_Zero": 0,
                    "Secondary_OutputStatus_One": 0,
                    "Secondary_OutputStatus_More": 0,
                    "Secondary_OutputStatus_Sus": 0,
                    "Secondary_OutputStatus_Air": 0,
                    "Secondary_Sensitivity_Volume": 0,
                    "Secondary_Sensitivity_Moment": 0,
                    "Secondary_Sensitivity_LowObject": 0,
                    "Secondary_Sensitivity_SensorBlinding": 0,
                    "Secondary_Sensitivity_OnePerson": 0,
                    "Secondary_Sensitivity_MorePerson": 0,
                    "Secondary_DoorSetting_SensorDirection": 0,
                    "Secondary_DoorSetting_HeightUnderCanopy": 0,
                    "Secondary_DoorSetting_Diameter": 0,
                    "Secondary_DoorSetting_DoorOpen": 0,
                    "Secondary_DoorSetting_DoorClose": 0,
                    "Secondary_DoorSetting_VerificationDevice": 0,
                    "Secondary_DoorSetting_WheelChair": 0,
                    "Secondary_DoorSetting_ShaftPosition_X": 0,
                    "Secondary_DoorSetting_ShaftPosition_Y": 0,
                    "Secondary_DoorSetting_ShaftPosition1_X": 0,
                    "Secondary_DoorSetting_ShaftPosition1_Y": 0,
                    "Secondary_DoorSetting_ShaftPosition2_X": 0,
                    "Secondary_DoorSetting_ShaftPosition2_Y": 0,
                    "Secondary_DoorSetting_DoorPosition": 0,
                    "Secondary_DoorSetting_OffsetAngle": 0,
                    "Secondary_DoorSetting_TipOfEndPosition_X": 0,
                    "Secondary_DoorSetting_TipOfEndPosition_Y": 0
                }],
                "plc": [{
                    "id": 3568,
                    "DeviceId": "4",
                    "EpochTime": 1466584246,
                    "Alarm": 0,
                    "BiometricRejectionCount": null,
                    "BothDoorsOpenCount": null,
                    "Cleaning": null,
                    "CleaningTime": 0,
                    "DelayTimeNoOutputSV": 0,
                    "DoorForcedCount": null,
                    "EndSwitchClosedInnerDoorDefective": 0,
                    "EndSwitchClosedOuterDoorDefective": 0,
                    "Event1st": 0,
                    "Event2nd": 0,
                    "Event3rd": 0,
                    "Event4th": 0,
                    "Event5th": 0,
                    "FireAlarmCount": null,
                    "FireAlarmModeSet": 0,
                    "IllegalTime": 0,
                    "IllegalUse": 0,
                    "IRSensorHungCount": null,
                    "IRSSensorDelay": 0,
                    "Locking": 0,
                    "LuminanceErrorDelay": 0,
                    "OnePersonInCount": null,
                    "OpeningCounterInnerDoor": 0,
                    "OpeningCounterOuterDoor": null,
                    "OpenTimeIn": 0,
                    "OpenTimeOut": 0,
                    "OverallTimeClosingInnerDoor": 0,
                    "OverallTimeClosingOuterDoor": 0,
                    "OverallTimeOpeningInnerDoor": 0,
                    "OverallTimeOpeningOuterDoor": 0,
                    "PowerLossCount": null,
                    "PresenceDelay": 0,
                    "PulsesInCounter": 0,
                    "PulsesInSpecialCounter": 0,
                    "PulsesOutCounter": 0,
                    "PulsesOutSpecialCounter": 0,
                    "Reset": 0,
                    "ReturnSignalInTime": 0,
                    "ReturnSignalOutTime": 0,
                    "ReverseButtonActivation": 0,
                    "SafetyRailInnerDoorClosing": 0,
                    "SafetyRailOuterDoorClosing": null,
                    "TimeExceededinCabinCount": null,
                    "TimeExceededMax": 0,
                    "TimeOutTime": 0,
                    "TOF0PersonIn": 0,
                    "TOF0PersonOut": 0,
                    "TOF1PersonIn": null,
                    "TOF1PersonOut": 0,
                    "TOF2PersonsIn": null,
                    "TOF2PersonsOut": 0,
                    "TOFRejection": 0,
                    "TOFRejectionsIn": null,
                    "TOFRejectionsOut": null,
                    "TOFSuspiciousIn": 0,
                    "TOFSuspiciousOut": 0,
                    "EndSwitchOutsideClosed": 0,
                    "EndSwitchOutsideSlow": 0,
                    "EndSwitchOutsideOpen": 0,
                    "EndSwitchInsideClosed": 0,
                    "EndSwitchInsideSlow": 0,
                    "EndSwitchInsideOpen": 0,
                    "BiometricAccessGranted": 0,
                    "FireAlarm": 0,
                    "MotorThermalOverload": 0,
                    "PowerFailure": 0,
                    "EmergencyButton": 0,
                    "SafetyRail": 0,
                    "PulseIn": 0,
                    "PulseOut": 0,
                    "PulseInSpecial": 0,
                    "PulseOutSpecial": 0,
                    "BothDoorsOpen": 0,
                    "LockSwitch": 0,
                    "IrisScanEntryRejected": null,
                    "InfraRedSensors": 0,
                    "SVSInOn": 0,
                    "SVSOutOn": 0,
                    "CleaningMode": 0,
                    "ResetSwitch": 0,
                    "EmptyDoorIn": 0,
                    "OnePersonIn": 0,
                    "TwoPersonIn": 0,
                    "SuspiciousIn": 0,
                    "AIRSensorsIn": 0,
                    "SVSEnabledIn": 0,
                    "EmptyDoorOut": 0,
                    "OnePersonOut": 0,
                    "TwoPersonOut": 0,
                    "SuspiciousOut": 0,
                    "AIRSensorsOut": 0,
                    "SVSEnabledOut": 0,
                    "ReturnSignalIn": 0,
                    "ReturnSignalOut": 0,
                    "MotorOuter": null,
                    "MotorInner": null,
                    "LockOuter": null,
                    "LockInner": null,
                    "MagLockOuter": null,
                    "MagLockInner": null,
                    "VFDForward": 0,
                    "VFDReverse": 0,
                    "VFDSpeedRef2and4": 0,
                    "VFDSpeedRef3and4": 0,
                    "VFDSecondAccDec": null,
                    "TOFReset": 0,
                    "TOFShutdown": 0,
                    "GeneralAlarm": 0,
                    "SignalLEDGreenIn": 0,
                    "SignalLEDRedIn": 0,
                    "SignalLEDGreenOut": 0,
                    "SignalLEDRedOut": 0,
                    "AuthorizationIn": 0,
                    "AIRActiveIn": 0,
                    "AuthorizationOut": 0,
                    "AIRActiveOut": 0,
                    "TwoPersonRejection": 0,
                    "BiometricRejection": 0,
                    "TimeExceededInCabin": 0,
                    "SafetyRailActivation": 0,
                    "EmergencyButtonActivation": 0,
                    "PowerLoss": 0,
                    "IRSensorHung": 0,
                    "PersonInCabin": null,
                    "BiometricStart": 0,
                    "OuterDoorClosed": 0,
                    "InnerDoorClosed": 0,
                    "EmergencyButtonLED": 0,
                    "Voice1": 0,
                    "Voice2": 0,
                    "SignalGreenInterior": 0,
                    "SignalRedInterior": 0,
                    "EnableBiometricEntry": null,
                    "EnableBiometricExit": null
                }],
                "motorDrive": [{
                    "id": 11,
                    "DeviceId": "4",
                    "EpochTime": 1466584661,
                    "OutputFrequency": 1,
                    "BaseFrequency": 0,
                    "OutputCurrent": 1,
                    "NormalSpeed": 2000,
                    "OutputVoltage": null,
                    "BaseVoltage": null,
                    "SlowSpeedOuter": null,
                    "SlowSpeedInner": null,
                    "AccelerationTime1st": 100,
                    "AccelerationTime2nd": null,
                    "DecelerationTime1st": null,
                    "DecelerationTime2nd": null,
                    "BrakingTime": null,
                    "Braking": null
                }],
                "doorStatus": null
            }
            var mockData = {
                    "id": 4,
                    "username": "boonadmin",
                    "registrationdatetime": "2016-06-17T11:59:01.000Z",
                    "level1": 1,
                    "level2": 1,
                    "level3": 1,
                    "enabled": 1,
                    "country": null,
                    "campus": "boonCampus",
                    "building": null,
                    "entrance": null,
                    "company_ID": null
                }
                //base frequency: 29.0 is invalid
            //invalid base_frequency
            var motorDrive = {
                "base_frequency": '29.0',
                "normal_speed": '35',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }

            spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise)
            spyOn(mockEditDoorService, 'putMotorDrive').and.returnValue(deferred.promise);
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.base_frequency_msg).toEqual('Please Enter Base Frequency value between 30.00-80.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.base_frequency_msg=''
            scope.mtrdrve_message=''

            //invalid base_frequency
            var motorDrive = {
                "base_frequency": '30.000',
                "normal_speed": '35',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": '45.00',
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.base_frequency_msg).toEqual('Please Enter Base Frequency value between 30.00-80.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.base_frequency_msg=''
            scope.mtrdrve_message=''

            //invalid base_frequency
            var motorDrive = {
                "base_frequency": '81',
                "normal_speed": '35',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": '45.00',
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.base_frequency_msg).toEqual('Please Enter Base Frequency value between 30.00-80.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.base_frequency_msg=''
            scope.mtrdrve_message=''

            //invalid base_frequency
            var motorDrive = {
                "base_frequency": '79.001',
                "normal_speed": '35',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": '45.00',
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.base_frequency_msg).toEqual('Please Enter Base Frequency value between 30.00-80.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.base_frequency_msg=''
            scope.mtrdrve_message=''

            //invalid base_frequency
            var motorDrive = {
                "base_frequency": '80.01',
                "normal_speed": '35',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": '45.00',
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.base_frequency_msg).toEqual('Please Enter Base Frequency value between 30.00-80.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.base_frequency_msg=''
            scope.mtrdrve_message=''

            var motorDrive = {
                "base_frequency": '29.99',
                "normal_speed": '35',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": '45.00',
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.base_frequency_msg).toEqual('Please Enter Base Frequency value between 30.00-80.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.base_frequency_msg=''
            scope.mtrdrve_message=''

            //invalid base_frequency
            var motorDrive = {
                "base_frequency": '81.001',
                "normal_speed": '35',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": '45.00',
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.base_frequency_msg).toEqual('Please Enter Base Frequency value between 30.00-80.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.base_frequency_msg=''
            scope.mtrdrve_message=''

            //invalid normal_speed
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.001',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": '45.00',
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.normal_speed_msg).toEqual('Please Enter Normal Speed value between 35.00-50.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.normal_speed_msg=''
            scope.mtrdrve_message=''

            //invalid normal_speed
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '50.001',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": '45.00',
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            // expect(scope.base_frequency_msg).toEqual('Please Enter Base Frequency value between 30.00-80.00 (two digit after decimal)');
            expect(scope.normal_speed_msg).toEqual('Please Enter Normal Speed value between 35.00-50.00 (two digit after decimal)');
            // expect(scope.base_voltage_msg).toEqual('Please Enter Base Voltage value between 75.0-150.0 (single digit after decimal)');
            // expect(scope.slow_speed_outer_msg).toEqual('Please Enter Slow Speed None-Secured (Hz) value between 5.00-10.00 (two digit after decimal)');
            // expect(scope.slow_speed_inner_msg).toEqual('Please Enter Slow Speed Secured (Hz) value between 5.00-10.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.normal_speed_msg=''
            scope.mtrdrve_message=''

            //invalid normal_speed
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '34.001',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": '45.00',
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.normal_speed_msg).toEqual('Please Enter Normal Speed value between 35.00-50.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.normal_speed_msg=''
            scope.mtrdrve_message=''

            //invalid normal_speed
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '51',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": '45.00',
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.normal_speed_msg).toEqual('Please Enter Normal Speed value between 35.00-50.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.normal_speed_msg=''
            scope.mtrdrve_message=''

            //invalid normal_speed
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '34.01',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": '45.00',
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.normal_speed_msg).toEqual('Please Enter Normal Speed value between 35.00-50.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.normal_speed_msg=''
            scope.mtrdrve_message=''

            //invalid normal_speed
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '50.01',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": '45.00',
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.normal_speed_msg).toEqual('Please Enter Normal Speed value between 35.00-50.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.normal_speed_msg=''
            scope.mtrdrve_message=''

            //invalid normal_speed
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '-35.0',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": '45.00',
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.normal_speed_msg).toEqual('Please Enter Normal Speed value between 35.00-50.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.normal_speed_msg=''
            scope.mtrdrve_message=''

            //invalid normal_speed
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '34',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": '45.00',
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.normal_speed_msg).toEqual('Please Enter Normal Speed value between 35.00-50.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.normal_speed_msg=''
            scope.mtrdrve_message=''

            //invalid acceleration time 1st
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "-1.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": '0.7',
                "aec_time_two": '0.7',
                "dec_time_one": '0.7',
                "dec_time_two": '0.7',
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.aecmsg1 ).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.aecmsg1=''
            scope.mtrdrve_message=''

            //invalid acceleration time 1st
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "1.1",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": '0.7',
                "aec_time_two": '0.7',
                "dec_time_one": '0.7',
                "dec_time_two": '0.7',
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.aecmsg1 ).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.aecmsg1=''
            scope.mtrdrve_message=''

            //invalid acceleration time 1st
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "10",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": '0.7',
                "aec_time_two": '0.7',
                "dec_time_one": '0.7',
                "dec_time_two": '0.7',
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.aecmsg1).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.aecmsg1=''
            scope.mtrdrve_message=''

            //invalid DecelerationTime1st
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "-1.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": '0.7',
                "aec_time_two": '0.7',
                "dec_time_one": '0.7',
                "dec_time_two": '0.7',
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.decmsg1 ).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.decmsg1=''
            scope.mtrdrve_message=''

            //invalid DecelerationTime1st
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "1.1",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": '0.7',
                "aec_time_two": '0.7',
                "dec_time_one": '0.7',
                "dec_time_two": '0.7',
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.decmsg1 ).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.decmsg1=''
            scope.mtrdrve_message=''

            //invalid DecelerationTime1st
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "10",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": '0.7',
                "aec_time_two": '0.7',
                "dec_time_one": '0.7',
                "dec_time_two": '0.7',
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.decmsg1).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.decmsg1=''
            scope.mtrdrve_message=''

            //invalid braking time
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "-1.0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 8,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.brktimemsg).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()

            //invalid braking time
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0.01",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 8,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.brktimemsg).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()

            //invalid braking time
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "10.01",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 8,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.brktimemsg).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()

            //invalid braking time
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "1.1",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 8,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.brktimemsg).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()

            //invalid braking time
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "10",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 8,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.brktimemsg).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()

            //invalid braking percent
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0.0",
                "break_percent": "31"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": '29'
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.brkpercentmsg).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()

            //invalid braking percent
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0.0",
                "break_percent": "29.55"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": '29'
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.brkpercentmsg).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()


            //invalid DecelerationTime2nd
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "-1.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.decmsg2 ).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.decmsg2=''
            scope.mtrdrve_message=''

            //invalid DecelerationTime2nd
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "1.1",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": '0.7',
                "aec_time_two": '0.7',
                "dec_time_one": '0.7',
                "dec_time_two": '0.7',
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.decmsg2 ).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.decmsg2=''
            scope.mtrdrve_message=''

            //invalid base voltage
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '74',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": '78',
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.base_voltage_msg ).toEqual('Please Enter Base Voltage value between 75.0-150.0 (single digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()

            //invalid base voltage
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75.12',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": '78',
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.base_voltage_msg ).toEqual('Please Enter Base Voltage value between 75.0-150.0 (single digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()

            //invalid base voltage
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '151.12',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": '78',
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.base_voltage_msg ).toEqual('Please Enter Base Voltage value between 75.0-150.0 (single digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()

            //invalid base voltage
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '151.1',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": '78',
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.base_voltage_msg ).toEqual('Please Enter Base Voltage value between 75.0-150.0 (single digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()

            //invalid base voltage
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '150.01',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": '78',
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.base_voltage_msg ).toEqual('Please Enter Base Voltage value between 75.0-150.0 (single digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()

            scope.mtrdrve_message = ''

            //invalid base voltage
            var motorDrive = {
                "base_frequency": '00.0',
                "normal_speed": '35.00',
                "base_voltage": '0',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": '79.0',
                "normal_speed": 0,
                "base_voltage": '78',
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.base_voltage_msg).toEqual('Please Enter Base Voltage value between 75.0-150.0 (single digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()

            //invalid base voltage
            var motorDrive = {
                "base_frequency": '00.0',
                "normal_speed": '35.00',
                "base_voltage": '75.01',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": '79.0',
                "normal_speed": 0,
                "base_voltage": '78',
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.base_voltage_msg).toEqual('Please Enter Base Voltage value between 75.0-150.0 (single digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.base_voltage_msg=''

            //invalid Slow Speed None-Secured and Slow Speed Secured
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '9.123',
                "slow_speed_inner": '9.123',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": '79.0',
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": '6.00',
                "slow_speed_inner": '6.00',
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.slow_speed_inner_msg).toEqual('Please Enter Slow Speed Secured (Hz) value between 5.00-10.00 (two digit after decimal)');
            expect(scope.slow_speed_outer_msg).toEqual('Please Enter Slow Speed Non-Secured (Hz) value between 5.00-10.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.slow_speed_inner_msg=''
            scope.slow_speed_outer_msg=''
            scope.mtrdrve_message=''

            //invalid Slow Speed None-Secured and Slow Speed Secured
            var motorDrive = {
                "base_frequency": '00.0',
                "normal_speed": '35.00',
                "base_voltage": '75.00',
                "slow_speed_outer": '5.123',
                "slow_speed_inner": '5.123',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": '79.0',
                "normal_speed": 0,
                "base_voltage": '78',
                "slow_speed_outer": '6.00',
                "slow_speed_inner": '6.00',
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.slow_speed_inner_msg).toEqual('Please Enter Slow Speed Secured (Hz) value between 5.00-10.00 (two digit after decimal)');
            expect(scope.slow_speed_outer_msg).toEqual('Please Enter Slow Speed Non-Secured (Hz) value between 5.00-10.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.slow_speed_inner_msg=''
            scope.slow_speed_outer_msg=''
            scope.mtrdrve_message=''

            //invalid Slow Speed None-Secured and Slow Speed Secured
            var motorDrive = {
                "base_frequency": '00.0',
                "normal_speed": '35.00',
                "base_voltage": '75.01',
                "slow_speed_outer": '4.99',
                "slow_speed_inner": '4.99',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": '79.0',
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": '6.00',
                "slow_speed_inner": '6.00',
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.base_voltage_msg).toEqual('Please Enter Base Voltage value between 75.0-150.0 (single digit after decimal)');
            expect(scope.slow_speed_inner_msg).toEqual('Please Enter Slow Speed Secured (Hz) value between 5.00-10.00 (two digit after decimal)');
            expect(scope.slow_speed_outer_msg).toEqual('Please Enter Slow Speed Non-Secured (Hz) value between 5.00-10.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.slow_speed_inner_msg=''
            scope.slow_speed_outer_msg=''
            scope.mtrdrve_message=''


            //invalid Slow Speed None-Secured and Slow Speed Secured
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '10.001',
                "slow_speed_inner": '10.001',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": '79.0',
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": '6.00',
                "slow_speed_inner": '6.00',
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.base_voltage_msg).toEqual('Please Enter Base Voltage value between 75.0-150.0 (single digit after decimal)');
            expect(scope.slow_speed_inner_msg).toEqual('Please Enter Slow Speed Secured (Hz) value between 5.00-10.00 (two digit after decimal)');
            expect(scope.slow_speed_outer_msg).toEqual('Please Enter Slow Speed Non-Secured (Hz) value between 5.00-10.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.slow_speed_inner_msg=''
            scope.slow_speed_outer_msg=''
            scope.mtrdrve_message=''

            //invalid Slow Speed None-Secured and Slow Speed Secured
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '10.01',
                "slow_speed_inner": '10.01',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": '79.0',
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": '6.00',
                "slow_speed_inner": '6.00',
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.base_voltage_msg).toEqual('Please Enter Base Voltage value between 75.0-150.0 (single digit after decimal)');
            expect(scope.slow_speed_inner_msg).toEqual('Please Enter Slow Speed Secured (Hz) value between 5.00-10.00 (two digit after decimal)');
            expect(scope.slow_speed_outer_msg).toEqual('Please Enter Slow Speed Non-Secured (Hz) value between 5.00-10.00 (two digit after decimal)');
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.resetmsg()
            scope.slow_speed_inner_msg=''
            scope.slow_speed_outer_msg=''
            scope.mtrdrve_message=''

            //invalid DecelerationTime2nd
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "-1.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.decmsg2 ).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.decmsg2=''
            scope.mtrdrve_message=''

            //invalid DecelerationTime2nd
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "1.1",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.decmsg2 ).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.decmsg2=''
            scope.mtrdrve_message=''


            //invalid DecelerationTime2nd
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "0.0",
                "dec_time_one": "0.0",
                "dec_time_two": "10",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.decmsg2).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.decmsg2=''
            scope.mtrdrve_message=''

            //invalid AccelerationTime2nd
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "-1.0",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.aecmsg2 ).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.aecmsg2=''
            scope.mtrdrve_message=''

            //invalid AccelerationTime2nd
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "1.1",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.aecmsg2 ).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.aecmsg2=''
            scope.mtrdrve_message=''

            //invalid AccelerationTime2nd
            var motorDrive = {
                "base_frequency": '30.0',
                "normal_speed": '35.00',
                "base_voltage": '75',
                "slow_speed_outer": '6',
                "slow_speed_inner": '6',
                "aec_time_one": "0.0",
                "aec_time_two": "10",
                "dec_time_one": "0.0",
                "dec_time_two": "0.0",
                "break_time": "0",
                "break_percent": "11"
            }
            scope.mtr_drive = {
                "output_frequency": motorDrive.output_frequency,
                "output_current": motorDrive.output_current,
                "output_voltage": motorDrive.output_voltage,
                "base_frequency": motorDrive.base_frequency,
                "normal_speed": motorDrive.normal_speed,
                "base_voltage": motorDrive.base_voltage,
                "slow_speed_outer": motorDrive.slow_speed_outer,
                "slow_speed_inner": motorDrive.slow_speed_inner,
                "aec_time_one": motorDrive.aec_time_one,
                "aec_time_two": motorDrive.aec_time_two,
                "dec_time_one": motorDrive.dec_time_one,
                "dec_time_two": motorDrive.dec_time_two,
                "break_time": motorDrive.break_time,
                "break_percent": motorDrive.break_percent
            }
            scope.original_motor_drive = {
                "output_frequency": 0,
                "output_current": 0,
                "output_voltage": 0,
                "base_frequency": 0,
                "normal_speed": 0,
                "base_voltage": 0,
                "slow_speed_outer": 0,
                "slow_speed_inner": 0,
                "aec_time_one": 0,
                "aec_time_two": 0,
                "dec_time_one": 0,
                "dec_time_two": 0,
                "break_time": 0,
                "break_percent": 0
            }
            scope.validateMotorDrive()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.aecmsg2).toEqual(1);
            expect(scope.mtrdrve_message).not.toEqual(result.message)
            scope.aecmsg2=''
            scope.mtrdrve_message=''
        });

        it('should test if UpdateDoorData works as expected if result.success is true', function() {
          var mockData = {"id":4,"username":"boonadmin","registrationdatetime":"2016-06-17T11:59:01.000Z","level1":1,"level2":1,"level3":1,"enabled":1,"country":null,"campus":"boonCampus","building":null,"entrance":null,"company_ID":null}
          // spyOn(JSON, 'parse').and.returnValue(mockData)
          spyOn(JSON, 'parse').and.returnValue({"accessToken":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw","userName":"BoonAdmin","admin":true,"level1":false,"level2":false,"level3":false,"level4":false,"level5":false,"level6":true,"level7":false,"level8":false,"level9":true,"level10":true});
          var dummyElement = document.createElement('canvas');
          var id = document.createAttribute("id");
          id.value = 'stereovisionCanvas';
          dummyElement.setAttributeNode(id);
          var width = document.createAttribute("width");
          width.value = '176px';
          dummyElement.setAttributeNode(width);
          var height = document.createAttribute("height");
          height.value = '132px';
          dummyElement.setAttributeNode(height);
          spyOn(document, 'getElementById').and.returnValue(dummyElement);
          createController();
          var result = {"success":true,"message":"Update successful.", "doorMain":[{"id":8,"nodeid":"JAbmykU/TpSIAn6XF6PyP+Ub0JA=","DeviceID":"4","ip_number":"192.168.1.52","mac_address":"00:1f:7b:b2:14:d6","hostname":"","time_first_seen":1454410566,"time_last_seen":1467491252,"lastupdateby":"boonadmin","snoozeExitTime":1467491852,"real_name":"Bylorus RnD Wandbboard","location":"Aambeeldstraat","product_type":"Bylorus","last_state":"OK","users":"boon, walt","ce_number":"","latitude":"","longitude":"","timezone":null,"campusId":"boonCampus","buildingId":"boonBuilding","entranceId":"boonEntrance","subEntranceId":"boonsub","campusName":"boonCampus","buildingName":null,"entranceName":"boonEntrance","subEntranceName":"subEntranceT","companyId":1,"info1":"","info2":"","assigned":1,"flag":0}],"transactionTimes":[],"rejectionCount":[],"timeOfFlight":[{"id":173,"DeviceId":"4","EpochTime":1467364984,"Primary_Log_Capture":0,"Primary_Log_CaptureZero":0,"Primary_Log_CaptureOne":0,"Primary_Log_CaptureMore":0,"Primary_Log_CaptureSus":0,"Primary_Log_Still":0,"Primary_Log_StillZero":0,"Primary_Log_StillOne":0,"Primary_Log_StillMore":0,"Primary_Log_StillSus":0,"Primary_Log_OutputCounts":0,"Primary_OutputStatus_Authorization":0,"Primary_OutputStatus_Zero":0,"Primary_OutputStatus_One":0,"Primary_OutputStatus_More":0,"Primary_OutputStatus_Sus":0,"Primary_OutputStatus_Air":0,"Primary_Sensitivity_Volume":5,"Primary_Sensitivity_Moment":4,"Primary_Sensitivity_LowObject":9,"Primary_Sensitivity_SensorBlinding":8,"Primary_Sensitivity_OnePerson":7,"Primary_Sensitivity_MorePerson":6,"Primary_DoorSetting_SensorDirection":0,"Primary_DoorSetting_HeightUnderCanopy":0,"Primary_DoorSetting_Diameter":0,"Primary_DoorSetting_DoorOpen":0,"Primary_DoorSetting_DoorClose":0,"Primary_DoorSetting_VerificationDevice":0,"Primary_DoorSetting_WheelChair":0,"Primary_DoorSetting_ShaftPosition_X":0,"Primary_DoorSetting_ShaftPosition_Y":0,"Primary_DoorSetting_ShaftPosition1_X":0,"Primary_DoorSetting_ShaftPosition1_Y":0,"Primary_DoorSetting_ShaftPosition2_X":0,"Primary_DoorSetting_ShaftPosition2_Y":0,"Primary_DoorSetting_DoorPosition":0,"Primary_DoorSetting_OffsetAngle":0,"Primary_DoorSetting_TipOfEndPosition_X":0,"Primary_DoorSetting_TipOfEndPosition_Y":0,"Secondary_Log_Capture":0,"Secondary_Log_CaptureZero":0,"Secondary_Log_CaptureOne":0,"Secondary_Log_CaptureMore":0,"Secondary_Log_CaptureSus":0,"Secondary_Log_Still":0,"Secondary_Log_StillZero":0,"Secondary_Log_StillOne":0,"Secondary_Log_StillMore":0,"Secondary_Log_StillSus":0,"Secondary_Log_OutputCounts":0,"Secondary_OutputStatus_Authorization":0,"Secondary_OutputStatus_Zero":0,"Secondary_OutputStatus_One":0,"Secondary_OutputStatus_More":0,"Secondary_OutputStatus_Sus":0,"Secondary_OutputStatus_Air":0,"Secondary_Sensitivity_Volume":0,"Secondary_Sensitivity_Moment":0,"Secondary_Sensitivity_LowObject":0,"Secondary_Sensitivity_SensorBlinding":0,"Secondary_Sensitivity_OnePerson":0,"Secondary_Sensitivity_MorePerson":0,"Secondary_DoorSetting_SensorDirection":0,"Secondary_DoorSetting_HeightUnderCanopy":0,"Secondary_DoorSetting_Diameter":0,"Secondary_DoorSetting_DoorOpen":0,"Secondary_DoorSetting_DoorClose":0,"Secondary_DoorSetting_VerificationDevice":0,"Secondary_DoorSetting_WheelChair":0,"Secondary_DoorSetting_ShaftPosition_X":0,"Secondary_DoorSetting_ShaftPosition_Y":0,"Secondary_DoorSetting_ShaftPosition1_X":0,"Secondary_DoorSetting_ShaftPosition1_Y":0,"Secondary_DoorSetting_ShaftPosition2_X":0,"Secondary_DoorSetting_ShaftPosition2_Y":0,"Secondary_DoorSetting_DoorPosition":0,"Secondary_DoorSetting_OffsetAngle":0,"Secondary_DoorSetting_TipOfEndPosition_X":0,"Secondary_DoorSetting_TipOfEndPosition_Y":0}],"plc":[{"id":3568,"DeviceId":"4","EpochTime":1466584246,"Alarm":0,"BiometricRejectionCount":null,"BothDoorsOpenCount":null,"Cleaning":null,"CleaningTime":0,"DelayTimeNoOutputSV":0,"DoorForcedCount":null,"EndSwitchClosedInnerDoorDefective":0,"EndSwitchClosedOuterDoorDefective":0,"Event1st":0,"Event2nd":0,"Event3rd":0,"Event4th":0,"Event5th":0,"FireAlarmCount":null,"FireAlarmModeSet":0,"IllegalTime":0,"IllegalUse":0,"IRSensorHungCount":null,"IRSSensorDelay":0,"Locking":0,"LuminanceErrorDelay":0,"OnePersonInCount":null,"OpeningCounterInnerDoor":0,"OpeningCounterOuterDoor":null,"OpenTimeIn":0,"OpenTimeOut":0,"OverallTimeClosingInnerDoor":0,"OverallTimeClosingOuterDoor":0,"OverallTimeOpeningInnerDoor":0,"OverallTimeOpeningOuterDoor":0,"PowerLossCount":null,"PresenceDelay":0,"PulsesInCounter":0,"PulsesInSpecialCounter":0,"PulsesOutCounter":0,"PulsesOutSpecialCounter":0,"Reset":0,"ReturnSignalInTime":0,"ReturnSignalOutTime":0,"ReverseButtonActivation":0,"SafetyRailInnerDoorClosing":0,"SafetyRailOuterDoorClosing":null,"TimeExceededinCabinCount":null,"TimeExceededMax":0,"TimeOutTime":0,"TOF0PersonIn":0,"TOF0PersonOut":0,"TOF1PersonIn":null,"TOF1PersonOut":0,"TOF2PersonsIn":null,"TOF2PersonsOut":0,"TOFRejection":0,"TOFRejectionsIn":null,"TOFRejectionsOut":null,"TOFSuspiciousIn":0,"TOFSuspiciousOut":0,"EndSwitchOutsideClosed":0,"EndSwitchOutsideSlow":0,"EndSwitchOutsideOpen":0,"EndSwitchInsideClosed":0,"EndSwitchInsideSlow":0,"EndSwitchInsideOpen":0,"BiometricAccessGranted":0,"FireAlarm":0,"MotorThermalOverload":0,"PowerFailure":0,"EmergencyButton":0,"SafetyRail":0,"PulseIn":0,"PulseOut":0,"PulseInSpecial":0,"PulseOutSpecial":0,"BothDoorsOpen":0,"LockSwitch":0,"IrisScanEntryRejected":null,"InfraRedSensors":0,"SVSInOn":0,"SVSOutOn":0,"CleaningMode":0,"ResetSwitch":0,"EmptyDoorIn":0,"OnePersonIn":0,"TwoPersonIn":0,"SuspiciousIn":0,"AIRSensorsIn":0,"SVSEnabledIn":0,"EmptyDoorOut":0,"OnePersonOut":0,"TwoPersonOut":0,"SuspiciousOut":0,"AIRSensorsOut":0,"SVSEnabledOut":0,"ReturnSignalIn":0,"ReturnSignalOut":0,"MotorOuter":null,"MotorInner":null,"LockOuter":null,"LockInner":null,"MagLockOuter":null,"MagLockInner":null,"VFDForward":0,"VFDReverse":0,"VFDSpeedRef2and4":0,"VFDSpeedRef3and4":0,"VFDSecondAccDec":null,"TOFReset":0,"TOFShutdown":0,"GeneralAlarm":0,"SignalLEDGreenIn":0,"SignalLEDRedIn":0,"SignalLEDGreenOut":0,"SignalLEDRedOut":0,"AuthorizationIn":0,"AIRActiveIn":0,"AuthorizationOut":0,"AIRActiveOut":0,"TwoPersonRejection":0,"BiometricRejection":0,"TimeExceededInCabin":0,"SafetyRailActivation":0,"EmergencyButtonActivation":0,"PowerLoss":0,"IRSensorHung":0,"PersonInCabin":null,"BiometricStart":0,"OuterDoorClosed":0,"InnerDoorClosed":0,"EmergencyButtonLED":0,"Voice1":0,"Voice2":0,"SignalGreenInterior":0,"SignalRedInterior":0,"EnableBiometricEntry":null,"EnableBiometricExit":null}],"motorDrive":[{"id":11,"DeviceId":"4","EpochTime":1466584661,"OutputFrequency":1,"BaseFrequency":0,"OutputCurrent":1,"NormalSpeed":1,"OutputVoltage":null,"BaseVoltage":null,"SlowSpeedOuter":null,"SlowSpeedInner":null,"AccelerationTime1st":null,"AccelerationTime2nd":null,"DecelerationTime1st":null,"DecelerationTime2nd":null,"BrakingTime":null,"Braking":null}],"doorStatus":null}
          var editdoor = angular.copy(result.doorMain)
          scope.doordetail = editdoor[0];
          scope.editCampus(true)
          spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise)
          spyOn(mockEditDoorService, 'putDoorData').and.returnValue(deferred.promise);
          spyOn(state, 'go').and.returnValue(true)
          scope.doordetail.real_name = 'testDoor1'
          scope.editFields.editCampus = true
          scope.doordetail.newcampusName = 'CampusA'
          scope.editFields.buildingName =true
          scope.doordetail.newbuildingName = 'BuildingA'
          scope.editFields.editEntrance = true
          scope.doordetail.newentranceName = 'EntranceA'
          scope.editFields.editSubEntrance = true
          scope.doordetail.newsubEntranceName = 'SubEntranceA'
          scope.editFields.editBuilding = true
          scope.UpdateDoorData()
          deferred.resolve(result);
          scope.$digest();
          expect(scope.door_msg).toEqual('Update successful.')
        });

        it('should test if UpdateDoorData works as expected if result.success is false', function() {
            var mockData = {"id":4,"username":"boonadmin","registrationdatetime":"2016-06-17T11:59:01.000Z","level1":1,"level2":1,"level3":1,"enabled":1,"country":null,"campus":"boonCampus","building":null,"entrance":null,"company_ID":null}
            // spyOn(JSON, 'parse').and.returnValue(mockData)
            spyOn(JSON, 'parse').and.returnValue({"accessToken":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw","userName":"BoonAdmin","admin":true,"level1":false,"level2":false,"level3":false,"level4":false,"level5":false,"level6":true,"level7":false,"level8":false,"level9":true,"level10":true});
            var dummyElement = document.createElement('canvas');
            var id = document.createAttribute("id");
            id.value = 'stereovisionCanvas';
            dummyElement.setAttributeNode(id);
            var width = document.createAttribute("width");
            width.value = '176px';
            dummyElement.setAttributeNode(width);
            var height = document.createAttribute("height");
            height.value = '132px';
            dummyElement.setAttributeNode(height);
            spyOn(document, 'getElementById').and.returnValue(dummyElement);
            createController();
            var result = {"message":"Update successful.", "doorMain":[{"id":8,"nodeid":"JAbmykU/TpSIAn6XF6PyP+Ub0JA=","DeviceID":"4","ip_number":"192.168.1.52","mac_address":"00:1f:7b:b2:14:d6","hostname":"","time_first_seen":1454410566,"time_last_seen":1467491252,"lastupdateby":"boonadmin","snoozeExitTime":1467491852,"real_name":"Bylorus RnD Wandbboard","location":"Aambeeldstraat","product_type":"Bylorus","last_state":"OK","users":"boon, walt","ce_number":"","latitude":"","longitude":"","timezone":null,"campusId":"boonCampus","buildingId":"boonBuilding","entranceId":"boonEntrance","subEntranceId":"boonsub","campusName":"boonCampus","buildingName":null,"entranceName":"boonEntrance","subEntranceName":"subEntranceT","companyId":1,"info1":"","info2":"","assigned":1,"flag":0}],"transactionTimes":[],"rejectionCount":[],"timeOfFlight":[{"id":173,"DeviceId":"4","EpochTime":1467364984,"Primary_Log_Capture":0,"Primary_Log_CaptureZero":0,"Primary_Log_CaptureOne":0,"Primary_Log_CaptureMore":0,"Primary_Log_CaptureSus":0,"Primary_Log_Still":0,"Primary_Log_StillZero":0,"Primary_Log_StillOne":0,"Primary_Log_StillMore":0,"Primary_Log_StillSus":0,"Primary_Log_OutputCounts":0,"Primary_OutputStatus_Authorization":0,"Primary_OutputStatus_Zero":0,"Primary_OutputStatus_One":0,"Primary_OutputStatus_More":0,"Primary_OutputStatus_Sus":0,"Primary_OutputStatus_Air":0,"Primary_Sensitivity_Volume":5,"Primary_Sensitivity_Moment":4,"Primary_Sensitivity_LowObject":9,"Primary_Sensitivity_SensorBlinding":8,"Primary_Sensitivity_OnePerson":7,"Primary_Sensitivity_MorePerson":6,"Primary_DoorSetting_SensorDirection":0,"Primary_DoorSetting_HeightUnderCanopy":0,"Primary_DoorSetting_Diameter":0,"Primary_DoorSetting_DoorOpen":0,"Primary_DoorSetting_DoorClose":0,"Primary_DoorSetting_VerificationDevice":0,"Primary_DoorSetting_WheelChair":0,"Primary_DoorSetting_ShaftPosition_X":0,"Primary_DoorSetting_ShaftPosition_Y":0,"Primary_DoorSetting_ShaftPosition1_X":0,"Primary_DoorSetting_ShaftPosition1_Y":0,"Primary_DoorSetting_ShaftPosition2_X":0,"Primary_DoorSetting_ShaftPosition2_Y":0,"Primary_DoorSetting_DoorPosition":0,"Primary_DoorSetting_OffsetAngle":0,"Primary_DoorSetting_TipOfEndPosition_X":0,"Primary_DoorSetting_TipOfEndPosition_Y":0,"Secondary_Log_Capture":0,"Secondary_Log_CaptureZero":0,"Secondary_Log_CaptureOne":0,"Secondary_Log_CaptureMore":0,"Secondary_Log_CaptureSus":0,"Secondary_Log_Still":0,"Secondary_Log_StillZero":0,"Secondary_Log_StillOne":0,"Secondary_Log_StillMore":0,"Secondary_Log_StillSus":0,"Secondary_Log_OutputCounts":0,"Secondary_OutputStatus_Authorization":0,"Secondary_OutputStatus_Zero":0,"Secondary_OutputStatus_One":0,"Secondary_OutputStatus_More":0,"Secondary_OutputStatus_Sus":0,"Secondary_OutputStatus_Air":0,"Secondary_Sensitivity_Volume":0,"Secondary_Sensitivity_Moment":0,"Secondary_Sensitivity_LowObject":0,"Secondary_Sensitivity_SensorBlinding":0,"Secondary_Sensitivity_OnePerson":0,"Secondary_Sensitivity_MorePerson":0,"Secondary_DoorSetting_SensorDirection":0,"Secondary_DoorSetting_HeightUnderCanopy":0,"Secondary_DoorSetting_Diameter":0,"Secondary_DoorSetting_DoorOpen":0,"Secondary_DoorSetting_DoorClose":0,"Secondary_DoorSetting_VerificationDevice":0,"Secondary_DoorSetting_WheelChair":0,"Secondary_DoorSetting_ShaftPosition_X":0,"Secondary_DoorSetting_ShaftPosition_Y":0,"Secondary_DoorSetting_ShaftPosition1_X":0,"Secondary_DoorSetting_ShaftPosition1_Y":0,"Secondary_DoorSetting_ShaftPosition2_X":0,"Secondary_DoorSetting_ShaftPosition2_Y":0,"Secondary_DoorSetting_DoorPosition":0,"Secondary_DoorSetting_OffsetAngle":0,"Secondary_DoorSetting_TipOfEndPosition_X":0,"Secondary_DoorSetting_TipOfEndPosition_Y":0}],"plc":[{"id":3568,"DeviceId":"4","EpochTime":1466584246,"Alarm":0,"BiometricRejectionCount":null,"BothDoorsOpenCount":null,"Cleaning":null,"CleaningTime":0,"DelayTimeNoOutputSV":0,"DoorForcedCount":null,"EndSwitchClosedInnerDoorDefective":0,"EndSwitchClosedOuterDoorDefective":0,"Event1st":0,"Event2nd":0,"Event3rd":0,"Event4th":0,"Event5th":0,"FireAlarmCount":null,"FireAlarmModeSet":0,"IllegalTime":0,"IllegalUse":0,"IRSensorHungCount":null,"IRSSensorDelay":0,"Locking":0,"LuminanceErrorDelay":0,"OnePersonInCount":null,"OpeningCounterInnerDoor":0,"OpeningCounterOuterDoor":null,"OpenTimeIn":0,"OpenTimeOut":0,"OverallTimeClosingInnerDoor":0,"OverallTimeClosingOuterDoor":0,"OverallTimeOpeningInnerDoor":0,"OverallTimeOpeningOuterDoor":0,"PowerLossCount":null,"PresenceDelay":0,"PulsesInCounter":0,"PulsesInSpecialCounter":0,"PulsesOutCounter":0,"PulsesOutSpecialCounter":0,"Reset":0,"ReturnSignalInTime":0,"ReturnSignalOutTime":0,"ReverseButtonActivation":0,"SafetyRailInnerDoorClosing":0,"SafetyRailOuterDoorClosing":null,"TimeExceededinCabinCount":null,"TimeExceededMax":0,"TimeOutTime":0,"TOF0PersonIn":0,"TOF0PersonOut":0,"TOF1PersonIn":null,"TOF1PersonOut":0,"TOF2PersonsIn":null,"TOF2PersonsOut":0,"TOFRejection":0,"TOFRejectionsIn":null,"TOFRejectionsOut":null,"TOFSuspiciousIn":0,"TOFSuspiciousOut":0,"EndSwitchOutsideClosed":0,"EndSwitchOutsideSlow":0,"EndSwitchOutsideOpen":0,"EndSwitchInsideClosed":0,"EndSwitchInsideSlow":0,"EndSwitchInsideOpen":0,"BiometricAccessGranted":0,"FireAlarm":0,"MotorThermalOverload":0,"PowerFailure":0,"EmergencyButton":0,"SafetyRail":0,"PulseIn":0,"PulseOut":0,"PulseInSpecial":0,"PulseOutSpecial":0,"BothDoorsOpen":0,"LockSwitch":0,"IrisScanEntryRejected":null,"InfraRedSensors":0,"SVSInOn":0,"SVSOutOn":0,"CleaningMode":0,"ResetSwitch":0,"EmptyDoorIn":0,"OnePersonIn":0,"TwoPersonIn":0,"SuspiciousIn":0,"AIRSensorsIn":0,"SVSEnabledIn":0,"EmptyDoorOut":0,"OnePersonOut":0,"TwoPersonOut":0,"SuspiciousOut":0,"AIRSensorsOut":0,"SVSEnabledOut":0,"ReturnSignalIn":0,"ReturnSignalOut":0,"MotorOuter":null,"MotorInner":null,"LockOuter":null,"LockInner":null,"MagLockOuter":null,"MagLockInner":null,"VFDForward":0,"VFDReverse":0,"VFDSpeedRef2and4":0,"VFDSpeedRef3and4":0,"VFDSecondAccDec":null,"TOFReset":0,"TOFShutdown":0,"GeneralAlarm":0,"SignalLEDGreenIn":0,"SignalLEDRedIn":0,"SignalLEDGreenOut":0,"SignalLEDRedOut":0,"AuthorizationIn":0,"AIRActiveIn":0,"AuthorizationOut":0,"AIRActiveOut":0,"TwoPersonRejection":0,"BiometricRejection":0,"TimeExceededInCabin":0,"SafetyRailActivation":0,"EmergencyButtonActivation":0,"PowerLoss":0,"IRSensorHung":0,"PersonInCabin":null,"BiometricStart":0,"OuterDoorClosed":0,"InnerDoorClosed":0,"EmergencyButtonLED":0,"Voice1":0,"Voice2":0,"SignalGreenInterior":0,"SignalRedInterior":0,"EnableBiometricEntry":null,"EnableBiometricExit":null}],"motorDrive":[{"id":11,"DeviceId":"4","EpochTime":1466584661,"OutputFrequency":1,"BaseFrequency":0,"OutputCurrent":1,"NormalSpeed":1,"OutputVoltage":null,"BaseVoltage":null,"SlowSpeedOuter":null,"SlowSpeedInner":null,"AccelerationTime1st":null,"AccelerationTime2nd":null,"DecelerationTime1st":null,"DecelerationTime2nd":null,"BrakingTime":null,"Braking":null}],"doorStatus":null}
            var editdoor = angular.copy(result.doorMain)
            scope.doordetail = editdoor[0];
            scope.editCampus(true)
            spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise)
            spyOn(mockEditDoorService, 'putDoorData').and.returnValue(deferred.promise);
            spyOn(state, 'go').and.returnValue(true)
            scope.doordetail.real_name = 'testDoor1'
            scope.editFields.editCampus = true
            scope.doordetail.newcampusName = 'CampusA'
            scope.editFields.buildingName =true
            scope.doordetail.newbuildingName = 'BuildingA'
            scope.editFields.editEntrance = true
            scope.doordetail.newentranceName = 'EntranceA'
            scope.editFields.editSubEntrance = true
            scope.doordetail.newsubEntranceName = 'SubEntranceA'
            scope.editFields.editBuilding = true
            scope.UpdateDoorData()
            deferred.resolve(result);
            scope.$digest();
            expect(scope.door_msg).toEqual('Invalid data.')
        });

        it('should test if UpdateDoorData works as expected if invalid values are entered', function() {
          var mockData = {"id":4,"username":"boonadmin","registrationdatetime":"2016-06-17T11:59:01.000Z","level1":1,"level2":1,"level3":1,"enabled":1,"country":null,"campus":"boonCampus","building":null,"entrance":null,"company_ID":null}
          // spyOn(JSON, 'parse').and.returnValue(mockData)
          spyOn(JSON, 'parse').and.returnValue({"accessToken":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw","userName":"BoonAdmin","admin":true,"level1":false,"level2":false,"level3":false,"level4":false,"level5":false,"level6":true,"level7":false,"level8":false,"level9":true,"level10":true});
          var dummyElement = document.createElement('canvas');
          var id = document.createAttribute("id");
          id.value = 'stereovisionCanvas';
          dummyElement.setAttributeNode(id);
          var width = document.createAttribute("width");
          width.value = '176px';
          dummyElement.setAttributeNode(width);
          var height = document.createAttribute("height");
          height.value = '132px';
          dummyElement.setAttributeNode(height);
          spyOn(document, 'getElementById').and.returnValue(dummyElement);
            createController();
            var result = {"message":"Update successful.", "doorMain":[{"id":8,"nodeid":"JAbmykU/TpSIAn6XF6PyP+Ub0JA=","DeviceID":"4","ip_number":"192.168.1.52","mac_address":"00:1f:7b:b2:14:d6","hostname":"","time_first_seen":1454410566,"time_last_seen":1467491252,"lastupdateby":"boonadmin","snoozeExitTime":1467491852,"real_name":"Bylorus RnD Wandbboard","location":"Aambeeldstraat","product_type":"Bylorus","last_state":"OK","users":"boon, walt","ce_number":"","latitude":"","longitude":"","timezone":null,"campusId":"boonCampus","buildingId":"boonBuilding","entranceId":"boonEntrance","subEntranceId":"boonsub","campusName":"boonCampus","buildingName":null,"entranceName":"boonEntrance","subEntranceName":"subEntranceT","companyId":1,"info1":"","info2":"","assigned":1,"flag":0}],"transactionTimes":[],"rejectionCount":[],"timeOfFlight":[{"id":173,"DeviceId":"4","EpochTime":1467364984,"Primary_Log_Capture":0,"Primary_Log_CaptureZero":0,"Primary_Log_CaptureOne":0,"Primary_Log_CaptureMore":0,"Primary_Log_CaptureSus":0,"Primary_Log_Still":0,"Primary_Log_StillZero":0,"Primary_Log_StillOne":0,"Primary_Log_StillMore":0,"Primary_Log_StillSus":0,"Primary_Log_OutputCounts":0,"Primary_OutputStatus_Authorization":0,"Primary_OutputStatus_Zero":0,"Primary_OutputStatus_One":0,"Primary_OutputStatus_More":0,"Primary_OutputStatus_Sus":0,"Primary_OutputStatus_Air":0,"Primary_Sensitivity_Volume":5,"Primary_Sensitivity_Moment":4,"Primary_Sensitivity_LowObject":9,"Primary_Sensitivity_SensorBlinding":8,"Primary_Sensitivity_OnePerson":7,"Primary_Sensitivity_MorePerson":6,"Primary_DoorSetting_SensorDirection":0,"Primary_DoorSetting_HeightUnderCanopy":0,"Primary_DoorSetting_Diameter":0,"Primary_DoorSetting_DoorOpen":0,"Primary_DoorSetting_DoorClose":0,"Primary_DoorSetting_VerificationDevice":0,"Primary_DoorSetting_WheelChair":0,"Primary_DoorSetting_ShaftPosition_X":0,"Primary_DoorSetting_ShaftPosition_Y":0,"Primary_DoorSetting_ShaftPosition1_X":0,"Primary_DoorSetting_ShaftPosition1_Y":0,"Primary_DoorSetting_ShaftPosition2_X":0,"Primary_DoorSetting_ShaftPosition2_Y":0,"Primary_DoorSetting_DoorPosition":0,"Primary_DoorSetting_OffsetAngle":0,"Primary_DoorSetting_TipOfEndPosition_X":0,"Primary_DoorSetting_TipOfEndPosition_Y":0,"Secondary_Log_Capture":0,"Secondary_Log_CaptureZero":0,"Secondary_Log_CaptureOne":0,"Secondary_Log_CaptureMore":0,"Secondary_Log_CaptureSus":0,"Secondary_Log_Still":0,"Secondary_Log_StillZero":0,"Secondary_Log_StillOne":0,"Secondary_Log_StillMore":0,"Secondary_Log_StillSus":0,"Secondary_Log_OutputCounts":0,"Secondary_OutputStatus_Authorization":0,"Secondary_OutputStatus_Zero":0,"Secondary_OutputStatus_One":0,"Secondary_OutputStatus_More":0,"Secondary_OutputStatus_Sus":0,"Secondary_OutputStatus_Air":0,"Secondary_Sensitivity_Volume":0,"Secondary_Sensitivity_Moment":0,"Secondary_Sensitivity_LowObject":0,"Secondary_Sensitivity_SensorBlinding":0,"Secondary_Sensitivity_OnePerson":0,"Secondary_Sensitivity_MorePerson":0,"Secondary_DoorSetting_SensorDirection":0,"Secondary_DoorSetting_HeightUnderCanopy":0,"Secondary_DoorSetting_Diameter":0,"Secondary_DoorSetting_DoorOpen":0,"Secondary_DoorSetting_DoorClose":0,"Secondary_DoorSetting_VerificationDevice":0,"Secondary_DoorSetting_WheelChair":0,"Secondary_DoorSetting_ShaftPosition_X":0,"Secondary_DoorSetting_ShaftPosition_Y":0,"Secondary_DoorSetting_ShaftPosition1_X":0,"Secondary_DoorSetting_ShaftPosition1_Y":0,"Secondary_DoorSetting_ShaftPosition2_X":0,"Secondary_DoorSetting_ShaftPosition2_Y":0,"Secondary_DoorSetting_DoorPosition":0,"Secondary_DoorSetting_OffsetAngle":0,"Secondary_DoorSetting_TipOfEndPosition_X":0,"Secondary_DoorSetting_TipOfEndPosition_Y":0}],"plc":[{"id":3568,"DeviceId":"4","EpochTime":1466584246,"Alarm":0,"BiometricRejectionCount":null,"BothDoorsOpenCount":null,"Cleaning":null,"CleaningTime":0,"DelayTimeNoOutputSV":0,"DoorForcedCount":null,"EndSwitchClosedInnerDoorDefective":0,"EndSwitchClosedOuterDoorDefective":0,"Event1st":0,"Event2nd":0,"Event3rd":0,"Event4th":0,"Event5th":0,"FireAlarmCount":null,"FireAlarmModeSet":0,"IllegalTime":0,"IllegalUse":0,"IRSensorHungCount":null,"IRSSensorDelay":0,"Locking":0,"LuminanceErrorDelay":0,"OnePersonInCount":null,"OpeningCounterInnerDoor":0,"OpeningCounterOuterDoor":null,"OpenTimeIn":0,"OpenTimeOut":0,"OverallTimeClosingInnerDoor":0,"OverallTimeClosingOuterDoor":0,"OverallTimeOpeningInnerDoor":0,"OverallTimeOpeningOuterDoor":0,"PowerLossCount":null,"PresenceDelay":0,"PulsesInCounter":0,"PulsesInSpecialCounter":0,"PulsesOutCounter":0,"PulsesOutSpecialCounter":0,"Reset":0,"ReturnSignalInTime":0,"ReturnSignalOutTime":0,"ReverseButtonActivation":0,"SafetyRailInnerDoorClosing":0,"SafetyRailOuterDoorClosing":null,"TimeExceededinCabinCount":null,"TimeExceededMax":0,"TimeOutTime":0,"TOF0PersonIn":0,"TOF0PersonOut":0,"TOF1PersonIn":null,"TOF1PersonOut":0,"TOF2PersonsIn":null,"TOF2PersonsOut":0,"TOFRejection":0,"TOFRejectionsIn":null,"TOFRejectionsOut":null,"TOFSuspiciousIn":0,"TOFSuspiciousOut":0,"EndSwitchOutsideClosed":0,"EndSwitchOutsideSlow":0,"EndSwitchOutsideOpen":0,"EndSwitchInsideClosed":0,"EndSwitchInsideSlow":0,"EndSwitchInsideOpen":0,"BiometricAccessGranted":0,"FireAlarm":0,"MotorThermalOverload":0,"PowerFailure":0,"EmergencyButton":0,"SafetyRail":0,"PulseIn":0,"PulseOut":0,"PulseInSpecial":0,"PulseOutSpecial":0,"BothDoorsOpen":0,"LockSwitch":0,"IrisScanEntryRejected":null,"InfraRedSensors":0,"SVSInOn":0,"SVSOutOn":0,"CleaningMode":0,"ResetSwitch":0,"EmptyDoorIn":0,"OnePersonIn":0,"TwoPersonIn":0,"SuspiciousIn":0,"AIRSensorsIn":0,"SVSEnabledIn":0,"EmptyDoorOut":0,"OnePersonOut":0,"TwoPersonOut":0,"SuspiciousOut":0,"AIRSensorsOut":0,"SVSEnabledOut":0,"ReturnSignalIn":0,"ReturnSignalOut":0,"MotorOuter":null,"MotorInner":null,"LockOuter":null,"LockInner":null,"MagLockOuter":null,"MagLockInner":null,"VFDForward":0,"VFDReverse":0,"VFDSpeedRef2and4":0,"VFDSpeedRef3and4":0,"VFDSecondAccDec":null,"TOFReset":0,"TOFShutdown":0,"GeneralAlarm":0,"SignalLEDGreenIn":0,"SignalLEDRedIn":0,"SignalLEDGreenOut":0,"SignalLEDRedOut":0,"AuthorizationIn":0,"AIRActiveIn":0,"AuthorizationOut":0,"AIRActiveOut":0,"TwoPersonRejection":0,"BiometricRejection":0,"TimeExceededInCabin":0,"SafetyRailActivation":0,"EmergencyButtonActivation":0,"PowerLoss":0,"IRSensorHung":0,"PersonInCabin":null,"BiometricStart":0,"OuterDoorClosed":0,"InnerDoorClosed":0,"EmergencyButtonLED":0,"Voice1":0,"Voice2":0,"SignalGreenInterior":0,"SignalRedInterior":0,"EnableBiometricEntry":null,"EnableBiometricExit":null}],"motorDrive":[{"id":11,"DeviceId":"4","EpochTime":1466584661,"OutputFrequency":1,"BaseFrequency":0,"OutputCurrent":1,"NormalSpeed":1,"OutputVoltage":null,"BaseVoltage":null,"SlowSpeedOuter":null,"SlowSpeedInner":null,"AccelerationTime1st":null,"AccelerationTime2nd":null,"DecelerationTime1st":null,"DecelerationTime2nd":null,"BrakingTime":null,"Braking":null}],"doorStatus":null}
            var editdoor = angular.copy(result.doorMain)
            scope.doordetail = editdoor[0];
            scope.editCampus(true)
            spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise)
            spyOn(mockEditDoorService, 'putDoorData').and.returnValue(deferred.promise);
            spyOn(state, 'go').and.returnValue(true)
            spyOn($window, 'alert').and.callThrough()
            scope.doordetail.real_name = undefined
            scope.editFields.editCampus = false
            scope.doordetail.newcampusName = ''
            scope.editFields.buildingName =true
            scope.doordetail.newbuildingName = 'BuildingA'
            scope.editFields.editEntrance = true
            scope.doordetail.newentranceName = 'EntranceA'
            scope.editFields.editSubEntrance = true
            scope.doordetail.newsubEntranceName = 'SubEntranceA'
            scope.editFields.editBuilding = true
            scope.UpdateDoorData()
            deferred.resolve(result);
            scope.$digest();
            expect($window.alert).toHaveBeenCalledWith("Enter valid values!")
        });

        it('should test if getChangeLog is working fine with promise resolved', function() {
            spyOn(JSON, 'parse').and.returnValue({
                "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                "userName": "BoonAdmin",
                "admin": true,
                "level1": false,
                "level2": false,
                "level3": false,
                "level4": false,
                "level5": false,
                "level6": false,
                "level7": false,
                "level8": false,
                "level9": true,
                "level10": false
            });
            createController();
            spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise);
            scope.getChangeLog()
            var result = {
                "results": [{
                    "Id": 237,
                    "deviceId": "6",
                    "date": "2016-07-05",
                    "affected_table": "stereovision",
                    "changedfield": "Primary_Log_OutputCounts ",
                    "oldvalue": "0",
                    "newvalue": "1"
                }, {
                    "Id": 238,
                    "deviceId": "6",
                    "date": "2016-07-05",
                    "affected_table": "stereovision",
                    "changedfield": "Primary_Log_OutputCounts ",
                    "oldvalue": "1",
                    "newvalue": "2"
                }, {
                    "Id": 239,
                    "deviceId": "6",
                    "date": "2016-07-05",
                    "affected_table": "stereovision",
                    "changedfield": "Primary_Log_OutputCounts ",
                    "oldvalue": "2",
                    "newvalue": "1"
                }, {
                    "Id": 240,
                    "deviceId": "6",
                    "date": "2016-07-05",
                    "affected_table": "stereovision",
                    "changedfield": "Primary_Log_OutputCounts ",
                    "oldvalue": "1",
                    "newvalue": "3"
                }],
                "success": true,
                "doorMain": [{
                    "id": 8,
                    "nodeid": "JAbmykU/TpSIAn6XF6PyP+Ub0JA=",
                    "DeviceID": "4",
                    "ip_number": "192.168.1.52",
                    "mac_address": "00:1f:7b:b2:14:d6",
                    "hostname": "",
                    "time_first_seen": 1454410566,
                    "time_last_seen": 1467491252,
                    "lastupdateby": "boonadmin",
                    "snoozeExitTime": 1467491852,
                    "real_name": "Bylorus RnD Wandbboard",
                    "location": "Aambeeldstraat",
                    "product_type": "Bylorus",
                    "last_state": "OK",
                    "users": "boon, walt",
                    "ce_number": "",
                    "latitude": "",
                    "longitude": "",
                    "timezone": null,
                    "campusId": "boonCampus",
                    "buildingId": "boonBuilding",
                    "entranceId": "boonEntrance",
                    "subEntranceId": "boonsub",
                    "campusName": "boonCampus",
                    "buildingName": null,
                    "entranceName": "boonEntrance",
                    "subEntranceName": "subEntranceT",
                    "companyId": 1,
                    "info1": "",
                    "info2": "",
                    "assigned": 1,
                    "flag": 0
                }],
                "transactionTimes": [],
                "rejectionCount": [],
                "timeOfFlight": [],
                "plc": [],
                "motorDrive": [],
                "doorStatus": null
            }
            deferred.resolve(result)
            scope.$digest()
            expect(scope.logData).toEqual(result.results)
        });

        it('should test if getChangeLog is working fine with promise rejected lts', function() {
            spyOn(JSON, 'parse').and.returnValue({
                "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                "userName": "BoonAdmin",
                "admin": true,
                "level1": false,
                "level2": false,
                "level3": false,
                "level4": false,
                "level5": false,
                "level6": false,
                "level7": false,
                "level8": false,
                "level9": true,
                "level10": false
            });
            createController();
            spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise);
            spyOn(console, 'log').and.callThrough();
            scope.getChangeLog()
            var result = 'failed'
            deferred.reject(result);
            scope.$digest()
            expect(console.log).toHaveBeenCalledWith('error data', result);
        });

        it('should test if validatePlcData1 works as expected', function() {
          spyOn(JSON, 'parse').and.returnValue({
              "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
              "userName": "BoonAdmin",
              "admin": true,
              "level1": false,
              "level2": false,
              "level3": false,
              "level4": false,
              "level5": false,
              "level6": true,
              "level7": false,
              "level8": false,
              "level9": true,
              "level10": false
          });
          var dummyElement = document.createElement('canvas');
          var id = document.createAttribute("id");
          id.value = 'stereovisionCanvas';
          dummyElement.setAttributeNode(id);
          var width = document.createAttribute("width");
          width.value = '176px';
          dummyElement.setAttributeNode(width);
          var height = document.createAttribute("height");
          height.value = '132px';
          dummyElement.setAttributeNode(height);
          spyOn(document, 'getElementById').and.returnValue(dummyElement);
          createController();
          var result = {"success":true,"message":"Update successful.","doorMain":[{"id":8,"nodeid":"JAbmykU/TpSIAn6XF6PyP+Ub0JA=","DeviceID":"4","ip_number":"192.168.1.52","mac_address":"00:1f:7b:b2:14:d6","hostname":"","time_first_seen":1454410566,"time_last_seen":1467491252,"lastupdateby":"boonadmin","snoozeExitTime":1467491852,"real_name":"Bylorus RnD Wandbboard","location":"Aambeeldstraat","product_type":"Bylorus","last_state":"OK","users":"boon, walt","ce_number":"","latitude":"","longitude":"","timezone":null,"campusId":"boonCampus","buildingId":"boonBuilding","entranceId":"boonEntrance","subEntranceId":"boonsub","campusName":"boonCampus","buildingName":null,"entranceName":"boonEntrance","subEntranceName":"subEntranceT","companyId":1,"info1":"","info2":"","assigned":1,"flag":0}],"transactionTimes":[],"rejectionCount":[],"timeOfFlight":[{"id":173,"DeviceId":"4","EpochTime":1467364984,"Primary_Log_Capture":0,"Primary_Log_CaptureZero":0,"Primary_Log_CaptureOne":0,"Primary_Log_CaptureMore":0,"Primary_Log_CaptureSus":0,"Primary_Log_Still":0,"Primary_Log_StillZero":0,"Primary_Log_StillOne":0,"Primary_Log_StillMore":0,"Primary_Log_StillSus":0,"Primary_Log_OutputCounts":0,"Primary_OutputStatus_Authorization":0,"Primary_OutputStatus_Zero":0,"Primary_OutputStatus_One":0,"Primary_OutputStatus_More":0,"Primary_OutputStatus_Sus":0,"Primary_OutputStatus_Air":0,"Primary_Sensitivity_Volume":5,"Primary_Sensitivity_Moment":4,"Primary_Sensitivity_LowObject":9,"Primary_Sensitivity_SensorBlinding":8,"Primary_Sensitivity_OnePerson":7,"Primary_Sensitivity_MorePerson":6,"Primary_DoorSetting_SensorDirection":0,"Primary_DoorSetting_HeightUnderCanopy":0,"Primary_DoorSetting_Diameter":0,"Primary_DoorSetting_DoorOpen":0,"Primary_DoorSetting_DoorClose":0,"Primary_DoorSetting_VerificationDevice":0,"Primary_DoorSetting_WheelChair":0,"Primary_DoorSetting_ShaftPosition_X":0,"Primary_DoorSetting_ShaftPosition_Y":0,"Primary_DoorSetting_ShaftPosition1_X":0,"Primary_DoorSetting_ShaftPosition1_Y":0,"Primary_DoorSetting_ShaftPosition2_X":0,"Primary_DoorSetting_ShaftPosition2_Y":0,"Primary_DoorSetting_DoorPosition":0,"Primary_DoorSetting_OffsetAngle":0,"Primary_DoorSetting_TipOfEndPosition_X":0,"Primary_DoorSetting_TipOfEndPosition_Y":0,"Secondary_Log_Capture":0,"Secondary_Log_CaptureZero":0,"Secondary_Log_CaptureOne":0,"Secondary_Log_CaptureMore":0,"Secondary_Log_CaptureSus":0,"Secondary_Log_Still":0,"Secondary_Log_StillZero":0,"Secondary_Log_StillOne":0,"Secondary_Log_StillMore":0,"Secondary_Log_StillSus":0,"Secondary_Log_OutputCounts":0,"Secondary_OutputStatus_Authorization":0,"Secondary_OutputStatus_Zero":0,"Secondary_OutputStatus_One":0,"Secondary_OutputStatus_More":0,"Secondary_OutputStatus_Sus":0,"Secondary_OutputStatus_Air":0,"Secondary_Sensitivity_Volume":0,"Secondary_Sensitivity_Moment":0,"Secondary_Sensitivity_LowObject":0,"Secondary_Sensitivity_SensorBlinding":0,"Secondary_Sensitivity_OnePerson":0,"Secondary_Sensitivity_MorePerson":0,"Secondary_DoorSetting_SensorDirection":0,"Secondary_DoorSetting_HeightUnderCanopy":0,"Secondary_DoorSetting_Diameter":0,"Secondary_DoorSetting_DoorOpen":0,"Secondary_DoorSetting_DoorClose":0,"Secondary_DoorSetting_VerificationDevice":0,"Secondary_DoorSetting_WheelChair":0,"Secondary_DoorSetting_ShaftPosition_X":0,"Secondary_DoorSetting_ShaftPosition_Y":0,"Secondary_DoorSetting_ShaftPosition1_X":0,"Secondary_DoorSetting_ShaftPosition1_Y":0,"Secondary_DoorSetting_ShaftPosition2_X":0,"Secondary_DoorSetting_ShaftPosition2_Y":0,"Secondary_DoorSetting_DoorPosition":0,"Secondary_DoorSetting_OffsetAngle":0,"Secondary_DoorSetting_TipOfEndPosition_X":0,"Secondary_DoorSetting_TipOfEndPosition_Y":0}],"plc":[{"id":75328,"DeviceId":"333281f3-6746-481b-b1d1-345bd5ed47b3","EpochTime":1481815581,"Alarm":200,"BiometricRejectionCount":102,"BothDoorsOpenCount":10,"Cleaning":1234,"CleaningTime":10,"DelayTimeNoOutputSV":15,"DoorForcedCount":4323,"EndSwitchClosedInnerDoorDefective":3,"EndSwitchClosedOuterDoorDefective":5,"Event1st":8,"Event2nd":5,"Event3rd":8,"Event4th":5,"Event5th":8,"FireAlarmCount":5,"FireAlarmModeSet":0,"IllegalTime":1,"IllegalUse":300,"IRSensorHungCount":0,"IRSSensorDelay":25,"Locking":0,"LuminanceErrorDelay":150,"OnePersonInCount":0,"OpeningCounterInnerDoor":310,"OpeningCounterOuterDoor":413,"OpenTimeIn":1,"OpenTimeOut":1,"OverallTimeClosingInnerDoor":1,"OverallTimeClosingOuterDoor":0,"OverallTimeOpeningInnerDoor":1,"OverallTimeOpeningOuterDoor":10,"PowerLossCount":2,"PresenceDelay":2,"PulsesInCounter":220,"PulsesInSpecialCounter":0,"PulsesOutCounter":646,"PulsesOutSpecialCounter":1001,"Reset":0,"ReturnSignalInTime":50,"ReturnSignalOutTime":1,"ReverseButtonActivation":0,"SafetyRailInnerDoorClosing":4,"SafetyRailOuterDoorClosing":4,"TimeExceededinCabinCount":0,"TimeExceededMax":10,"TimeOutTime":0,"TOF0PersonIn":1,"TOF0PersonOut":25,"TOF1PersonIn":0,"TOF1PersonOut":11225,"TOF2PersonsIn":7,"TOF2PersonsOut":7,"TOFRejection":12345,"TOFRejectionsIn":0,"TOFRejectionsOut":0,"TOFSuspiciousIn":7,"TOFSuspiciousOut":0,"EndSwitchOutsideClosed":0,"EndSwitchOutsideSlow":0,"EndSwitchOutsideOpen":0,"EndSwitchInsideClosed":0,"EndSwitchInsideSlow":0,"EndSwitchInsideOpen":0,"BiometricAccessGranted":0,"FireAlarm":1,"MotorThermalOverload":0,"PowerFailure":0,"EmergencyButton":0,"SafetyRail":0,"PulseIn":0,"PulseOut":0,"PulseInSpecial":0,"PulseOutSpecial":0,"BothDoorsOpen":0,"LockSwitch":0,"IrisScanEntryRejected":0,"InfraRedSensors":0,"SVSInOn":0,"SVSOutOn":0,"CleaningMode":0,"ResetSwitch":0,"EmptyDoorIn":0,"OnePersonIn":0,"TwoPersonIn":0,"SuspiciousIn":0,"AIRSensorsIn":0,"SVSEnabledIn":0,"EmptyDoorOut":0,"OnePersonOut":0,"TwoPersonOut":0,"SuspiciousOut":0,"AIRSensorsOut":0,"SVSEnabledOut":0,"ReturnSignalIn":0,"ReturnSignalOut":0,"MotorOuter":1,"MotorInner":1,"LockOuter":0,"LockInner":1,"MagLockOuter":0,"MagLockInner":0,"VFDForward":0,"VFDReverse":1,"VFDSpeedRef2and4":0,"VFDSpeedRef3and4":0,"VFDSecondAccDec":0,"TOFReset":0,"TOFShutdown":0,"GeneralAlarm":0,"SignalLEDGreenIn":0,"SignalLEDRedIn":1,"SignalLEDGreenOut":0,"SignalLEDRedOut":1,"AuthorizationIn":0,"AIRActiveIn":0,"AuthorizationOut":0,"AIRActiveOut":0,"TwoPersonRejection":0,"BiometricRejection":0,"TimeExceededInCabin":0,"SafetyRailActivation":0,"EmergencyButtonActivation":0,"PowerLoss":1,"IRSensorHung":0,"PersonInCabin":0,"BiometricStart":0,"OuterDoorClosed":0,"InnerDoorClosed":0,"EmergencyButtonLED":1,"Voice1":0,"Voice2":0,"SignalGreenInterior":0,"SignalRedInterior":0,"EnableBiometricEntry":0,"EnableBiometricExit":0,"AntiLockInButton":1,"AntiLockInButtonActivation":0,"AntiLockInButtonLED":0,"AntiLockInButtonActivationIn":0,"AntiLockInButtonActivationOut":0,"TimeExceededinCabinIn":0,"TimeExceededinCabinOut":0,"BiometricRejectionIn":0,"BiometricRejectionOut":0,"BiometricRejectionEntry":0,"BiometricStartEntry":0,"DoorForcedCountInside":0,"DoorForcedCountOutside":0,"EnableSVIn":0,"EnableSVOut":0,"IRSensorHungInside":0,"IRSensorHungOutside":0,"MaxAuthorisations":0}],"motorDrive":[{"id":11,"DeviceId":"4","EpochTime":1466584661,"OutputFrequency":1,"BaseFrequency":0,"OutputCurrent":1,"NormalSpeed":1,"OutputVoltage":null,"BaseVoltage":null,"SlowSpeedOuter":null,"SlowSpeedInner":null,"AccelerationTime1st":null,"AccelerationTime2nd":null,"DecelerationTime1st":null,"DecelerationTime2nd":null,"BrakingTime":null,"Braking":null}],"doorStatus":null}
          var mockData = {"id":4,"username":"boonadmin","registrationdatetime":"2016-06-17T11:59:01.000Z","level1":1,"level2":1,"level3":1,"enabled":1,"country":null,"campus":"boonCampus","building":null,"entrance":null,"company_ID":null}

                var plc_values = angular.copy(result.plc[0]);

                //valid
                var plc_data1 = [{
                    key: "Open Time Non Secured Side",
                    value: "5.0"

                }, {
                    key: "Presence On Delay",
                    value: "2.2"

                }, {
                    key: "Anti lock-in time",
                    value: "25.0"

                }, {
                    key: "SV Non Secured Side Enabled ",
                    value: '1'

                }, {
                    key: "Open Time Secured Side",
                    value: "5.3"

                }, {
                    key: "Presence Off Delay",
                    value: "2.5"

                }, {
                    key: "Step out before Alarm",
                    value: "2.6"

                }, {
                    key: "SV Secured Side Enabled",
                    value: '1'
                }, {
                    key: "Return Signal Time Non Secured Side",
                    value: "2.9"

                }, {
                    key: "Alarm delay",
                    value: '1.6'

                }, {
                    key: "Cleaning Time",
                    value: "120.0"

                }, {
                    key: "Return Signal Time Secured Side ",
                    value: "2.3"

                }, {
                    key: "Time Exceeded Max",
                    value: "16.0"

                }, {
                    key: "Fire Alarm Mode",
                    value: "2"

                }];
                scope.original_plc_data1 = [{"key":"Open Time Non Secured Side","value":1},{"key":"Presence On Delay","value":2},{"key":"Anti lock-in time","value":0},{"key":"SV Non Secured Side Enabled ","value":0},{"key":"Open Time Secured Side","value":1},{"key":"Presence Off Delay","value":25},{"key":"Step out before Alarm","value":1},{"key":"SV Secured Side Enabled","value":0},{"key":"Return Signal Time Non Secured Side","value":50},{"key":"Alarm delay","value":300},{"key":"Cleaning Time","value":10},{"key":"Return Signal Time Secured Side ","value":1},{"key":"Time Exceeded Max","value":10},{"key":"Fire Alarm Mode","value":0}];
          spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise)
          spyOn(mockEditDoorService, 'putPlcData1').and.returnValue(deferred.promise);
          scope.validatePlcData1(plc_data1)
          deferred.resolve(result);
          scope.$digest();
          expect(scope.plcdata1_message).toEqual(result.message)


          //invalid PLC values
          var plc_data1 = [{
              key: "Open Time Non Secured Side",
              value: "5.25" //two digits after decimal not allowed

          }, {
              key: "Presence On Delay",
              value: "2.23"  //test needs confirmation

          }, {
              key: "Anti lock-in time",
              value: "25.12" //two digits after decimal not allowed

          }, {
              key: "SV Non Secured Side Enabled ",
              value: '1.0' //decimal not allowed

          }, {
              key: "Open Time Secured Side",
              value: "5.35"//two digits after decimal not allowed

          }, {
              key: "Presence Off Delay",
              value: "2.52"  //test needs confirmation

          }, {
              key: "Step out before Alarm",
              value: "2.65"//two digits after decimal not allowed

          }, {
              key: "SV Secured Side Enabled",
              value: '1.0'//decimal not allowed
          }, {
              key: "Return Signal Time Non Secured Side",
              value: "2.95"//two digits after decimal not allowed

          }, {
              key: "Alarm delay",
              value: '1.62'//two digits after decimal not allowed

          }, {
              key: "Cleaning Time",
              value: "120.01"//two digits after decimal not allowed

          }, {
              key: "Return Signal Time Secured Side ",
              value: "2.35"//two digits after decimal not allowed

          }, {
              key: "Time Exceeded Max",
              value: "16.15"//two digits after decimal not allowed

          }, {
              key: "Fire Alarm Mode",
              value: "2.0" //0 or 1 or 2 no decimals allowed

          }];
          scope.original_plc_data1 = [{"key":"Open Time Non Secured Side","value":1},{"key":"Presence On Delay","value":2},{"key":"Anti lock-in time","value":0},{"key":"SV Non Secured Side Enabled ","value":0},{"key":"Open Time Secured Side","value":1},{"key":"Presence Off Delay","value":25},{"key":"Step out before Alarm","value":1},{"key":"SV Secured Side Enabled","value":0},{"key":"Return Signal Time Non Secured Side","value":50},{"key":"Alarm delay","value":300},{"key":"Cleaning Time","value":10},{"key":"Return Signal Time Secured Side ","value":1},{"key":"Time Exceeded Max","value":10},{"key":"Fire Alarm Mode","value":0}];

          scope.validatePlcData1(plc_data1)
          deferred.resolve(result);
          scope.$digest();
          expect(scope.openTimemsg).toEqual(1)
          expect(scope.PresenceOnDelayMsg).toEqual(1)
          expect(scope.antiLockTimeMsg).toEqual(1)
          expect(scope.svNonSecuredMsg).toEqual(1)
          expect(scope.openTimeoutmsg).toEqual(1)
          expect(scope.PresenceOffDelayMsg).toEqual(1)
          expect(scope.stepOutMsg).toEqual(1)
          expect(scope.svSecuredMsg).toEqual(1)
          expect(scope.returnSignalInMsg).toEqual(1)
          expect(scope.alramDelayMsg).toEqual(1)
          expect(scope.cleaningTimeMsg).toEqual(1)
          expect(scope.returnSignalOutMsg).toEqual(1)
          expect(scope.TimeExceededMaxMsg).not.toEqual(result.message)
          expect(scope.fireAlarmMsg).not.toEqual(result.message)

          //invalid PLC values
          var plc_data1 = [{
              key: "Open Time Non Secured Side",
              value: "4.9" //valid value between 5 and 12.5 with resolution of 0,1

          }, {
              key: "Presence On Delay",
              value: "-0.1"  //test needs confirmation

          }, {
              key: "Anti lock-in time",
              value: "9.9" //valid value between 10 and 60 with resolution of 0,1

          }, {
              key: "SV Non Secured Side Enabled ",
              value: '-1' //decimal not allowed

          }, {
              key: "Open Time Secured Side",
              value: "4.9"//valid value between 5 and 12.5 with resolution of 0,1

          }, {
              key: "Presence Off Delay",
              value: "-0.1"  //test needs confirmation

          }, {
              key: "Step out before Alarm",
              value: "2.4"//2.5 and 12.5 with resolution of 0,1

          }, {
              key: "SV Secured Side Enabled",
              value: '-1'//decimal not allowed
          }, {
              key: "Return Signal Time Non Secured Side",
              value: "0.1"//0.2 and 5 with resolution of 0,1

          }, {
              key: "Alarm delay",
              value: '0.1'//0.2 and 5 with resolution of 0,1

          }, {
              key: "Cleaning Time",
              value: "119"//120 and 600 with resolution of 0,1

          }, {
              key: "Return Signal Time Secured Side ",
              value: "0.1"//0.2 and 5 with resolution of 0,1

          }, {
              key: "Time Exceeded Max",
              value: "14"//15 and 90 with resolution of 0,1

          }, {
              key: "Fire Alarm Mode",
              value: "-1" //0 or 1 or 2 no decimals allowed

          }];
          scope.original_plc_data1 = [{"key":"Open Time Non Secured Side","value":1},{"key":"Presence On Delay","value":2},{"key":"Anti lock-in time","value":0},{"key":"SV Non Secured Side Enabled ","value":0},{"key":"Open Time Secured Side","value":1},{"key":"Presence Off Delay","value":25},{"key":"Step out before Alarm","value":1},{"key":"SV Secured Side Enabled","value":0},{"key":"Return Signal Time Non Secured Side","value":50},{"key":"Alarm delay","value":300},{"key":"Cleaning Time","value":10},{"key":"Return Signal Time Secured Side ","value":1},{"key":"Time Exceeded Max","value":10},{"key":"Fire Alarm Mode","value":0}];

          scope.validatePlcData1(plc_data1)
          deferred.resolve(result);
          scope.$digest();
          expect(scope.openTimemsg).toEqual(1)
          expect(scope.PresenceOnDelayMsg).toEqual(1)
          expect(scope.antiLockTimeMsg).toEqual(1)
          expect(scope.svNonSecuredMsg).toEqual(1)
          expect(scope.openTimeoutmsg).toEqual(1)
          expect(scope.PresenceOffDelayMsg).toEqual(1)
          expect(scope.stepOutMsg).toEqual(1)
          expect(scope.svSecuredMsg).toEqual(1)
          expect(scope.returnSignalInMsg).toEqual(1)
          expect(scope.alramDelayMsg).toEqual(1)
          expect(scope.cleaningTimeMsg).toEqual(1)
          expect(scope.returnSignalOutMsg).toEqual(1)
          expect(scope.TimeExceededMaxMsg).not.toEqual(result.message)
          expect(scope.fireAlarmMsg).not.toEqual(result.message)

          //invalid PLC values
          var plc_data1 = [{
              key: "Open Time Non Secured Side",
              value: "12.6" //valid value between 5 and 12.5 with resolution of 0,1

          }, {
              key: "Presence On Delay",
              value: "2.6"  //test needs confirmation

          }, {
              key: "Anti lock-in time",
              value: "60.1" //valid value between 10 and 60 with resolution of 0,1

          }, {
              key: "SV Non Secured Side Enabled ",
              value: '2' //decimal not allowed

          }, {
              key: "Open Time Secured Side",
              value: "12.6"//valid value between 5 and 12.5 with resolution of 0,1

          }, {
              key: "Presence Off Delay",
              value: "2.6"  //test needs confirmation

          }, {
              key: "Step out before Alarm",
              value: "12.6"//2.5 and 12.5 with resolution of 0,1

          }, {
              key: "SV Secured Side Enabled",
              value: '2'//decimal not allowed
          }, {
              key: "Return Signal Time Non Secured Side",
              value: "5.1"//0.2 and 5 with resolution of 0,1

          }, {
              key: "Alarm delay",
              value: '5.1'//0.2 and 5 with resolution of 0,1

          }, {
              key: "Cleaning Time",
              value: "601"//120 and 600 with resolution of 0,1

          }, {
              key: "Return Signal Time Secured Side ",
              value: "5.1"//0.2 and 5 with resolution of 0,1

          }, {
              key: "Time Exceeded Max",
              value: "91"//15 and 90 with resolution of 0,1

          }, {
              key: "Fire Alarm Mode",
              value: "3" //0 or 1 or 2 no decimals allowed
          }];
          scope.original_plc_data1 = [{"key":"Open Time Non Secured Side","value":1},{"key":"Presence On Delay","value":2},{"key":"Anti lock-in time","value":0},{"key":"SV Non Secured Side Enabled ","value":0},{"key":"Open Time Secured Side","value":1},{"key":"Presence Off Delay","value":25},{"key":"Step out before Alarm","value":1},{"key":"SV Secured Side Enabled","value":0},{"key":"Return Signal Time Non Secured Side","value":50},{"key":"Alarm delay","value":300},{"key":"Cleaning Time","value":10},{"key":"Return Signal Time Secured Side ","value":1},{"key":"Time Exceeded Max","value":10},{"key":"Fire Alarm Mode","value":0}];

          scope.validatePlcData1(plc_data1)
          deferred.resolve(result);
          scope.$digest();
          expect(scope.openTimemsg).toEqual(1)
          expect(scope.PresenceOnDelayMsg).toEqual(1)
          expect(scope.antiLockTimeMsg).toEqual(1)
          expect(scope.svNonSecuredMsg).toEqual(1)
          expect(scope.openTimeoutmsg).toEqual(1)
          expect(scope.PresenceOffDelayMsg).toEqual(1)
          expect(scope.stepOutMsg).toEqual(1)
          expect(scope.svSecuredMsg).toEqual(1)
          expect(scope.returnSignalInMsg).toEqual(1)
          expect(scope.alramDelayMsg).toEqual(1)
          expect(scope.cleaningTimeMsg).toEqual(1)
          expect(scope.returnSignalOutMsg).toEqual(1)
          expect(scope.TimeExceededMaxMsg).not.toEqual(result.message)
          expect(scope.fireAlarmMsg).not.toEqual(result.message)
        })

        it('should test if editBrightness and editContrast are defined', function(){
          spyOn(JSON, 'parse').and.returnValue({
              "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
              "userName": "BoonAdmin",
              "admin": true,
              "level1": false,
              "level2": false,
              "level3": false,
              "level4": false,
              "level5": false,
              "level6": true,
              "level7": false,
              "level8": false,
              "level9": true,
              "level10": false
          });
          var dummyElement = document.createElement('canvas');
          var id = document.createAttribute("id");
          id.value = 'stereovisionCanvas';
          dummyElement.setAttributeNode(id);
          var width = document.createAttribute("width");
          width.value = '176px';
          dummyElement.setAttributeNode(width);
          var height = document.createAttribute("height");
          height.value = '132px';
          dummyElement.setAttributeNode(height);
          spyOn(document, 'getElementById').and.returnValue(dummyElement);
          createController();
          expect(scope.brightness).toBeDefined()
          expect(scope.brightness).toEqual(0)
          expect(scope.minBrightness).toEqual(100)
          expect(scope.maxBrightness).toEqual(200)
          expect(scope.contrast).toEqual(0)
          expect(scope.minContrast).toEqual(100)
          expect(scope.maxContrast).toEqual(200)
          scope.editBrightness(150)
          expect(scope.brightness).toEqual(150)
          expect(scope.contrast).toEqual(0)
          scope.editContrast(175)
          expect(scope.brightness).toEqual(150)
          expect(scope.contrast).toEqual(175)
          scope.editBrightness(0);
          expect(scope.brightness).toEqual(0)
          expect(scope.contrast).toEqual(175)
        })

        it('should test if scope.recaptureImage works as expected', function() {
            var deffered_StereovisionImage = q.defer();
            spyOn(JSON, 'parse').and.returnValue({
                "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgyNDcyMjg0LCJleHAiOjE0ODI0NzI4ODR9.eZlzL8MlYyguy5grQK7GpzpMuufqVKOUaPUsLRiq_yw",
                "userName": "BoonAdmin",
                "admin": true,
                "level1": false,
                "level2": false,
                "level3": false,
                "level4": false,
                "level5": false,
                "level6": false,
                "level7": true,
                "level8": false,
                "level9": true,
                "level10": false
            });
            var dummyElement = document.createElement('canvas');
            var id = document.createAttribute("id");
            id.value = 'stereovisionCanvas';
            dummyElement.setAttributeNode(id);
            var width = document.createAttribute("width");
            width.value = '176px';
            dummyElement.setAttributeNode(width);
            var height = document.createAttribute("height");
            height.value = '132px';
            dummyElement.setAttributeNode(height);
            spyOn(document, 'getElementById').and.returnValue(dummyElement);
            createController();
            var result = {
                "success": true,
                "message": "Update successful.",
                "doorMain": [{
                    "id": 8,
                    "nodeid": "JAbmykU/TpSIAn6XF6PyP+Ub0JA=",
                    "DeviceID": "4",
                    "ip_number": "192.168.1.52",
                    "mac_address": "00:1f:7b:b2:14:d6",
                    "hostname": "",
                    "time_first_seen": 1454410566,
                    "time_last_seen": 1467491252,
                    "lastupdateby": "boonadmin",
                    "snoozeExitTime": 1467491852,
                    "real_name": "Bylorus RnD Wandbboard",
                    "location": "Aambeeldstraat",
                    "product_type": "Bylorus",
                    "last_state": "OK",
                    "users": "boon, walt",
                    "ce_number": "",
                    "latitude": "",
                    "longitude": "",
                    "timezone": null,
                    "campusId": "boonCampus",
                    "buildingId": "boonBuilding",
                    "entranceId": "boonEntrance",
                    "subEntranceId": "boonsub",
                    "campusName": "boonCampus",
                    "buildingName": null,
                    "entranceName": "boonEntrance",
                    "subEntranceName": "subEntranceT",
                    "companyId": 1,
                    "info1": "",
                    "info2": "",
                    "assigned": 1,
                    "flag": 0
                }],
                "transactionTimes": [],
                "rejectionCount": [],
                "timeOfFlight": [{
                    "id": 173,
                    "DeviceId": "4",
                    "EpochTime": 1467364984,
                    "Primary_Log_Capture": 0,
                    "Primary_Log_CaptureZero": 0,
                    "Primary_Log_CaptureOne": 0,
                    "Primary_Log_CaptureMore": 0,
                    "Primary_Log_CaptureSus": 0,
                    "Primary_Log_Still": 0,
                    "Primary_Log_StillZero": 0,
                    "Primary_Log_StillOne": 0,
                    "Primary_Log_StillMore": 0,
                    "Primary_Log_StillSus": 0,
                    "Primary_Log_OutputCounts": 0,
                    "Primary_OutputStatus_Authorization": 0,
                    "Primary_OutputStatus_Zero": 0,
                    "Primary_OutputStatus_One": 0,
                    "Primary_OutputStatus_More": 0,
                    "Primary_OutputStatus_Sus": 0,
                    "Primary_OutputStatus_Air": 0,
                    "Primary_Sensitivity_Volume": 5,
                    "Primary_Sensitivity_Moment": 4,
                    "Primary_Sensitivity_LowObject": 9,
                    "Primary_Sensitivity_SensorBlinding": 8,
                    "Primary_Sensitivity_OnePerson": 7,
                    "Primary_Sensitivity_MorePerson": 6,
                    "Primary_DoorSetting_SensorDirection": 0,
                    "Primary_DoorSetting_HeightUnderCanopy": 0,
                    "Primary_DoorSetting_Diameter": 0,
                    "Primary_DoorSetting_DoorOpen": 0,
                    "Primary_DoorSetting_DoorClose": 0,
                    "Primary_DoorSetting_VerificationDevice": 0,
                    "Primary_DoorSetting_WheelChair": 0,
                    "Primary_DoorSetting_ShaftPosition_X": 0,
                    "Primary_DoorSetting_ShaftPosition_Y": 0,
                    "Primary_DoorSetting_ShaftPosition1_X": 0,
                    "Primary_DoorSetting_ShaftPosition1_Y": 0,
                    "Primary_DoorSetting_ShaftPosition2_X": 0,
                    "Primary_DoorSetting_ShaftPosition2_Y": 0,
                    "Primary_DoorSetting_DoorPosition": 0,
                    "Primary_DoorSetting_OffsetAngle": 0,
                    "Primary_DoorSetting_TipOfEndPosition_X": 0,
                    "Primary_DoorSetting_TipOfEndPosition_Y": 0,
                    "Secondary_Log_Capture": 0,
                    "Secondary_Log_CaptureZero": 0,
                    "Secondary_Log_CaptureOne": 0,
                    "Secondary_Log_CaptureMore": 0,
                    "Secondary_Log_CaptureSus": 0,
                    "Secondary_Log_Still": 0,
                    "Secondary_Log_StillZero": 0,
                    "Secondary_Log_StillOne": 0,
                    "Secondary_Log_StillMore": 0,
                    "Secondary_Log_StillSus": 0,
                    "Secondary_Log_OutputCounts": 0,
                    "Secondary_OutputStatus_Authorization": 0,
                    "Secondary_OutputStatus_Zero": 0,
                    "Secondary_OutputStatus_One": 0,
                    "Secondary_OutputStatus_More": 0,
                    "Secondary_OutputStatus_Sus": 0,
                    "Secondary_OutputStatus_Air": 0,
                    "Secondary_Sensitivity_Volume": 0,
                    "Secondary_Sensitivity_Moment": 0,
                    "Secondary_Sensitivity_LowObject": 0,
                    "Secondary_Sensitivity_SensorBlinding": 0,
                    "Secondary_Sensitivity_OnePerson": 0,
                    "Secondary_Sensitivity_MorePerson": 0,
                    "Secondary_DoorSetting_SensorDirection": 0,
                    "Secondary_DoorSetting_HeightUnderCanopy": 0,
                    "Secondary_DoorSetting_Diameter": 0,
                    "Secondary_DoorSetting_DoorOpen": 0,
                    "Secondary_DoorSetting_DoorClose": 0,
                    "Secondary_DoorSetting_VerificationDevice": 0,
                    "Secondary_DoorSetting_WheelChair": 0,
                    "Secondary_DoorSetting_ShaftPosition_X": 0,
                    "Secondary_DoorSetting_ShaftPosition_Y": 0,
                    "Secondary_DoorSetting_ShaftPosition1_X": 0,
                    "Secondary_DoorSetting_ShaftPosition1_Y": 0,
                    "Secondary_DoorSetting_ShaftPosition2_X": 0,
                    "Secondary_DoorSetting_ShaftPosition2_Y": 0,
                    "Secondary_DoorSetting_DoorPosition": 0,
                    "Secondary_DoorSetting_OffsetAngle": 0,
                    "Secondary_DoorSetting_TipOfEndPosition_X": 0,
                    "Secondary_DoorSetting_TipOfEndPosition_Y": 0
                }],
                "plc": [{
                    "id": 3568,
                    "DeviceId": "4",
                    "EpochTime": 1466584246,
                    "Alarm": 0,
                    "BiometricRejectionCount": null,
                    "BothDoorsOpenCount": null,
                    "Cleaning": null,
                    "CleaningTime": 0,
                    "DelayTimeNoOutputSV": 0,
                    "DoorForcedCount": null,
                    "EndSwitchClosedInnerDoorDefective": 0,
                    "EndSwitchClosedOuterDoorDefective": 0,
                    "Event1st": 0,
                    "Event2nd": 0,
                    "Event3rd": 0,
                    "Event4th": 0,
                    "Event5th": 0,
                    "FireAlarmCount": null,
                    "FireAlarmModeSet": 0,
                    "IllegalTime": 0,
                    "IllegalUse": 0,
                    "IRSensorHungCount": null,
                    "IRSSensorDelay": 0,
                    "Locking": 0,
                    "LuminanceErrorDelay": 0,
                    "OnePersonInCount": null,
                    "OpeningCounterInnerDoor": 0,
                    "OpeningCounterOuterDoor": null,
                    "OpenTimeIn": 0,
                    "OpenTimeOut": 0,
                    "OverallTimeClosingInnerDoor": 0,
                    "OverallTimeClosingOuterDoor": 0,
                    "OverallTimeOpeningInnerDoor": 0,
                    "OverallTimeOpeningOuterDoor": 0,
                    "PowerLossCount": null,
                    "PresenceDelay": 0,
                    "PulsesInCounter": 0,
                    "PulsesInSpecialCounter": 0,
                    "PulsesOutCounter": 0,
                    "PulsesOutSpecialCounter": 0,
                    "Reset": 0,
                    "ReturnSignalInTime": 0,
                    "ReturnSignalOutTime": 0,
                    "ReverseButtonActivation": 0,
                    "SafetyRailInnerDoorClosing": 0,
                    "SafetyRailOuterDoorClosing": null,
                    "TimeExceededinCabinCount": null,
                    "TimeExceededMax": 0,
                    "TimeOutTime": 0,
                    "TOF0PersonIn": 0,
                    "TOF0PersonOut": 0,
                    "TOF1PersonIn": null,
                    "TOF1PersonOut": 0,
                    "TOF2PersonsIn": null,
                    "TOF2PersonsOut": 0,
                    "TOFRejection": 0,
                    "TOFRejectionsIn": null,
                    "TOFRejectionsOut": null,
                    "TOFSuspiciousIn": 0,
                    "TOFSuspiciousOut": 0,
                    "EndSwitchOutsideClosed": 0,
                    "EndSwitchOutsideSlow": 0,
                    "EndSwitchOutsideOpen": 0,
                    "EndSwitchInsideClosed": 0,
                    "EndSwitchInsideSlow": 0,
                    "EndSwitchInsideOpen": 0,
                    "BiometricAccessGranted": 0,
                    "FireAlarm": 0,
                    "MotorThermalOverload": 0,
                    "PowerFailure": 0,
                    "EmergencyButton": 0,
                    "SafetyRail": 0,
                    "PulseIn": 0,
                    "PulseOut": 0,
                    "PulseInSpecial": 0,
                    "PulseOutSpecial": 0,
                    "BothDoorsOpen": 0,
                    "LockSwitch": 0,
                    "IrisScanEntryRejected": null,
                    "InfraRedSensors": 0,
                    "SVSInOn": 0,
                    "SVSOutOn": 0,
                    "CleaningMode": 0,
                    "ResetSwitch": 0,
                    "EmptyDoorIn": 0,
                    "OnePersonIn": 0,
                    "TwoPersonIn": 0,
                    "SuspiciousIn": 0,
                    "AIRSensorsIn": 0,
                    "SVSEnabledIn": 0,
                    "EmptyDoorOut": 0,
                    "OnePersonOut": 0,
                    "TwoPersonOut": 0,
                    "SuspiciousOut": 0,
                    "AIRSensorsOut": 0,
                    "SVSEnabledOut": 0,
                    "ReturnSignalIn": 0,
                    "ReturnSignalOut": 0,
                    "MotorOuter": null,
                    "MotorInner": null,
                    "LockOuter": null,
                    "LockInner": null,
                    "MagLockOuter": null,
                    "MagLockInner": null,
                    "VFDForward": 0,
                    "VFDReverse": 0,
                    "VFDSpeedRef2and4": 0,
                    "VFDSpeedRef3and4": 0,
                    "VFDSecondAccDec": null,
                    "TOFReset": 0,
                    "TOFShutdown": 0,
                    "GeneralAlarm": 0,
                    "SignalLEDGreenIn": 0,
                    "SignalLEDRedIn": 0,
                    "SignalLEDGreenOut": 0,
                    "SignalLEDRedOut": 0,
                    "AuthorizationIn": 0,
                    "AIRActiveIn": 0,
                    "AuthorizationOut": 0,
                    "AIRActiveOut": 0,
                    "TwoPersonRejection": 0,
                    "BiometricRejection": 0,
                    "TimeExceededInCabin": 0,
                    "SafetyRailActivation": 0,
                    "EmergencyButtonActivation": 0,
                    "PowerLoss": 0,
                    "IRSensorHung": 0,
                    "PersonInCabin": null,
                    "BiometricStart": 0,
                    "OuterDoorClosed": 0,
                    "InnerDoorClosed": 0,
                    "EmergencyButtonLED": 0,
                    "Voice1": 0,
                    "Voice2": 0,
                    "SignalGreenInterior": 0,
                    "SignalRedInterior": 0,
                    "EnableBiometricEntry": null,
                    "EnableBiometricExit": null
                }],
                "motorDrive": [{
                    "id": 11,
                    "DeviceId": "4",
                    "EpochTime": 1466584661,
                    "OutputFrequency": 1,
                    "BaseFrequency": 0,
                    "OutputCurrent": 1,
                    "NormalSpeed": 1,
                    "OutputVoltage": null,
                    "BaseVoltage": null,
                    "SlowSpeedOuter": null,
                    "SlowSpeedInner": null,
                    "AccelerationTime1st": null,
                    "AccelerationTime2nd": null,
                    "DecelerationTime1st": null,
                    "DecelerationTime2nd": null,
                    "BrakingTime": null,
                    "Braking": null
                }],
                "doorStatus": null
            }
            var timeofflight = {
                "Primary_Log_Capture": 0,
                "Primary_Log_OutputCounts": "1",
                "Primary_DoorSetting_HeightUnderCanopy": 2000,
                "Primary_DoorSetting_Diameter": 1800,
                "Primary_DoorSetting_SensorDirection": 0,
                "Primary_DoorSetting_DoorOpen": 0,
                "Primary_DoorSetting_DoorClose": 0,
                "Primary_DoorSetting_WheelChair": 0,
                "Primary_DoorSetting_VerificationDevice": 0,
                "Primary_Sensitivity_LowObject": 5,
                "Primary_Sensitivity_SensorBlinding": 5,
                "Primary_Sensitivity_OnePerson": 5,
                "Primary_Sensitivity_MorePerson": 4,
                "Primary_Sensitivity_Volume": 6,
                "Primary_Sensitivity_Moment": 5,
                "Primary_DoorSetting_ShaftPosition1_X": 0,
                "Primary_DoorSetting_ShaftPosition2_X": 0,
                "Primary_DoorSetting_ShaftPosition1_Y": 0,
                "Primary_DoorSetting_ShaftPosition2_Y": 0
            }
            scope.sliders = {
                capture_counts: timeofflight.Primary_Log_OutputCounts,
                height_canopy: timeofflight.Primary_DoorSetting_HeightUnderCanopy,
                door_diameter: timeofflight.Primary_DoorSetting_Diameter,
                capture_image: timeofflight.Primary_Log_Capture,
                sensor_direction: timeofflight.Primary_DoorSetting_SensorDirection,
                primary_door_setting_open: timeofflight.Primary_DoorSetting_DoorOpen,
                primary_door_setting_close: timeofflight.Primary_DoorSetting_DoorClose,
                wheel_chair: timeofflight.Primary_DoorSetting_WheelChair,
                verification_device: timeofflight.Primary_DoorSetting_VerificationDevice,
                lowObjValue: timeofflight.Primary_Sensitivity_LowObject,
                blindingValue: timeofflight.Primary_Sensitivity_SensorBlinding,
                onePersonValue: timeofflight.Primary_Sensitivity_OnePerson,
                morePersonValue: timeofflight.Primary_Sensitivity_MorePerson,
                volumeValue: timeofflight.Primary_Sensitivity_Volume,
                momentValue: timeofflight.Primary_Sensitivity_Moment,
                x_shaft_1x: timeofflight.Primary_DoorSetting_ShaftPosition1_X,
                x_shaft_2x: timeofflight.Primary_DoorSetting_ShaftPosition2_X,
                x_shaft_11x: timeofflight.Primary_DoorSetting_ShaftPosition1_Y,
                x_shaft_22x: timeofflight.Primary_DoorSetting_ShaftPosition2_Y,
                min: 1,
                max: 9
            }
            spyOn(mockEditDoorService, 'fetchChangeLog').and.returnValue(deferred.promise)
            spyOn(mockEditDoorService, 'putTimeofFlight').and.returnValue(deferred.promise);
            spyOn(mockEditDoorService, 'updateStereovisionImage').and.returnValue(deffered_StereovisionImage.promise);
            scope.validateTimeFlight()
            deferred.resolve(result); // Resolve the promise.
            scope.$digest();
            scope.validateTimeFlight()
            expect(scope.tof_message).toEqual(result.message)
            expect(scope.status).toEqual('success')
            scope.checkModel.primary = true;
            scope.recaptureImage()
            $timeout.flush();
            scope.checkModel.primary = false;
            scope.recaptureImage()
            $timeout.flush();
            deffered_StereovisionImage.resolve(result);
            scope.$digest();
        });

      })
})
