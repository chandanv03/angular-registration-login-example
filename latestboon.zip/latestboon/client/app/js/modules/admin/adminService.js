/*service to get user data*/
define(['./module'], function(module) {
    'use strict'
    module.factory('adminService', function($rootScope, $window, $q, adminList, TokenService) {
        var factory = {
            /*get user data by id*/
            getUsers: function() {
                var deferred = $q.defer()

                var getUser = adminList.getUsers(TokenService.getToken()).get({}, function() {
                    if (getUser.success === true) {
                        deferred.resolve(getUser.users)
                    } else {
                        deferred.reject(getUser)
                    }
                })
                return deferred.promise
            },

            /*delete user by id*/
            deleteUser: function(id) {
                var deferred = $q.defer()

                var deleteUser = adminList.deleteUser(TokenService.getToken()).delete({
                    "id": id
                }, function() {
                    if (deleteUser.success === true) {
                        deferred.resolve(deleteUser.success)
                    } else {
                        deferred.reject(deleteUser)
                    }
                })
                return deferred.promise
            }
        }
        return factory
    })
})
