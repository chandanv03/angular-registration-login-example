var config = require('./config.js')
var nodeCache = require("node-cache")
var myCache = new nodeCache()

function isIpBlocked(currentTimestamp, ip) {
    var ipCacheObj = myCache.get(ip)
    if (ipCacheObj != null) {
        if (ipCacheObj.blockingStartTime != null) {
            return true
        }
    }
    return false
}

function shouldActivateNow(currentTimestamp, ip) {
    var ipCacheObj = myCache.get(ip)
    if (ipCacheObj != null) {
        if (ipCacheObj.blockingStartTime != null) {
            if ((currentTimestamp - ipCacheObj.blockingStartTime) >= (config.iPBlockingTime* config.timeMillis)) {
                return true
            }
        }
    }
    return false
}

function shouldBlockNow(ip) {
    var ipCacheObj = myCache.get(ip)
    if (ipCacheObj != null) {
        if (ipCacheObj.attempts != null) {
            if (ipCacheObj.attempts.length == config.invalidAttempts) {
                if (ipCacheObj.attempts[0].status == false &&
                    ipCacheObj.attempts[1].status == false &&
                    ipCacheObj.attempts[2].status == false) {
                    return true
                }
            }
        }
    }
    return false
}

function activate(ip) {
    var ipCacheObj = myCache.get(ip)
    if (ipCacheObj != null) {
        ipCacheObj = {}
        myCache.set(ip, ipCacheObj)
    }
}

function blockIp(currentTimestamp, ip) {
    var ipCacheObj = myCache.get(ip)
    if (ipCacheObj != null) {
        ipCacheObj.blockingStartTime = currentTimestamp
        myCache.set(ip, ipCacheObj)
    }
}

function pushAttempt(currentTimestamp, ip, status) {
    var ipCacheObj = myCache.get(ip)
    var currentAttempt = {
        status: status,
        timestamp: currentTimestamp
    }

    if (ipCacheObj == null) {
        ipCacheObj = {}
    }
    if (ipCacheObj.attempts != null) {
        if (ipCacheObj.attempts.length == config.invalidAttempts) {
            ipCacheObj.attempts[0] = ipCacheObj.attempts[1]
            ipCacheObj.attempts[1] = ipCacheObj.attempts[2]
            ipCacheObj.attempts[2] = currentAttempt

        } else {
            ipCacheObj.attempts.push(currentAttempt)

        }
    } else {
        ipCacheObj.attempts = []
        ipCacheObj.attempts.push(currentAttempt)
    }
    myCache.set(ip, ipCacheObj)

}

function invalidAtempts(ip) {
    var invalidAtemptsNo = 0
    var ipCacheObj = myCache.get(ip)
    if (ipCacheObj != null) {
        if (ipCacheObj.attempts != null) {
            for (var i = ipCacheObj.attempts.length; i > 0; i--) {
                if (ipCacheObj.attempts[(i - 1)].status == false) {
                    invalidAtemptsNo++
                } else {
                    break
                }
            }

        }
    }
    return invalidAtemptsNo

}
exports.isIpBlocked = isIpBlocked
exports.shouldActivateNow = shouldActivateNow
exports.shouldBlockNow = shouldBlockNow
exports.activate = activate
exports.blockIp = blockIp
exports.pushAttempt = pushAttempt
exports.invalidAtempts = invalidAtempts
