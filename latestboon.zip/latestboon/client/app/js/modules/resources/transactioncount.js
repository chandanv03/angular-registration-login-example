define([
    'angular',
    'ngResource'
], function(angular) {
    'use strict'

    return angular.module('app.resources.transactioncount', ['ngResource'])
        .service('TransactionCount', function($resource, CONFIG, TokenService) {
            return {
                getTransactionCount: function(token) {

                    return $resource(CONFIG.url + 'doors/transactiontime?id=:id&type=:type', {
                        id: '@id',
                        type: '@type'
                    }, {
                        query: {
                            method: 'GET',
                            isArray: true,
                            headers: {
                                'x-access-token': token
                            },
                            transformResponse: function(data, headers) {
                                //Check the response header for token expiry and new token.
                                var headers = headers()
                                TokenService.setResponseHeader(headers)
                                return angular.fromJson(data)
                            }

                        }
                    })

                }
            }
        })
})
