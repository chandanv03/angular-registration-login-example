define(['./module'], function (module) {
  'use strict'
  module.service('Auth', function ($rootScope, $state, $location, $window, User, EncodeService, $q) {
    var service = {
      goToLogin: function () {
        $state.go('login')
      },
      login: function (userName, password) {
        // Create Base64 Object
        //Base 64 encode to encode the password
        var encodedPassword = EncodeService.encode(password)
        var payload = { user: userName, password: encodedPassword }
        var deferred = $q.defer(), userDetail
        //Send the post request to the server to check the credentials
        var validUser = User.save(payload, function () {
          if (validUser.success === true) {
            userDetail = {
              accessToken: validUser.token,
              userName: userName,
              admin: validUser.admin,
              level1: validUser.level1,
              level2: validUser.level2,
              level3: validUser.level3,
              level4: validUser.level4,
              level5: validUser.level5,
              level6: validUser.level6,
              level7: validUser.level7,
              level8: validUser.level8,
              level9: validUser.level9,
              level10:validUser.level10

            }
            $window.sessionStorage['userInfo'] = JSON.stringify(userDetail)
            $window.location.href = '/#/dashboard'

          } else {
            $rootScope.invalidUser = true
            deferred.reject(validUser)
          }
        }, function (result) {
          // Error
        })

        return deferred.promise
      },
      logout: function () {
        User.logout(function () {})
      },

    }

    return service
  })
})
