/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */

define([
  'angular-mocks',
  'Source/modules/admin/userController',
  'Source/modules/admin/userService',
  'Source/modules/common/locationsService',
  'Source/modules/common/tokenSetter'
], function () {
    describe('UserController', function(){

      var scope, mockuserService, createController, window, timeout, mockLocationsService;

      beforeEach(module('ui.router'));

      beforeEach(angular.mock.module('app.admin'));

      beforeEach(angular.mock.module('app.dashboard'));

      beforeEach(angular.mock.module('app.common.token'));

      beforeEach(angular.mock.module('app.common.locations'));



      beforeEach(module(function($provide) {
        mockuserService = {
          getUsersById: function() {},
          addUser: function() {},
          updateUserById: function() {}
        };

        mockLocationsService = {
          getLocations : function (){}
        }
        $provide.value('userService', mockuserService);
        $provide.value('LocationsService', mockLocationsService);
      }));


      beforeEach(angular.mock.inject(function ($rootScope, $controller, $q, $window, $state, _$timeout_) {

               scope = $rootScope.$new();
               timeout = _$timeout_
               createController = function() {
                  return $controller('userController', {
                    '$scope': scope,
                    'userService' : mockuserService,
                    'LocationsService': mockLocationsService
                  });
               };
               deferred = $q.defer();
               spyOn(mockuserService, 'getUsersById').and.returnValue(deferred.promise);
               spyOn(mockLocationsService, 'getLocations').and.returnValue(deferred.promise);
               spyOn(mockuserService, 'addUser').and.returnValue(deferred.promise);
               spyOn(mockuserService, 'updateUserById').and.returnValue(deferred.promise);
      }));


      it('should test if controller is initiated with scope', function() {
        var mockData1 = {accessToken: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiY…yMDl9.gqSOzp5_fVUGzrn5AREhK11opo-CJsM_m-vMy_K7Xtc", userName: "boonadmin", admin: true}
               spyOn(JSON, 'parse').and.returnValue(mockData1)
          createController()
          expect(scope.user).toBeDefined()
      });

      it('should test if scope.setDefault works fine', function() {
        var mockData1 = {accessToken: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiY…yMDl9.gqSOzp5_fVUGzrn5AREhK11opo-CJsM_m-vMy_K7Xtc", userName: "boonadmin", admin: true}
               spyOn(JSON, 'parse').and.returnValue(mockData1)
          createController()
          scope.setDefault()
          expect(scope.user.password).toEqual("12345");
      });

      it('should test if promise is resolved for scope.getUserById ', function() {
        var mockData1 = {accessToken: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiY…yMDl9.gqSOzp5_fVUGzrn5AREhK11opo-CJsM_m-vMy_K7Xtc", userName: "boonadmin", admin: true}
               spyOn(JSON, 'parse').and.returnValue(mockData1)
          var ctrl = createController();
          scope.getUserById(1)
          var result = [{"id":1,"username":"sogetiVianen@sogeti.nl","registrationdatetime":"2015-12-31T23:00:00.000Z","level1":null,"level2":null,"level3":null,"enabled":null,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":null}]
          deferred.resolve(result)
          scope.$digest()
          expect(mockuserService.getUsersById).toHaveBeenCalled()
          expect(scope.user.username).toEqual('sogetiVianen@sogeti.nl')
          expect(scope.user.registrationdatetime).toEqual("2015-12-31T23:00:00.000Z")

      });

      it('should test if promise is rejected for scope.getUserById', function() {
        var mockData1 = {accessToken: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiY…yMDl9.gqSOzp5_fVUGzrn5AREhK11opo-CJsM_m-vMy_K7Xtc", userName: "boonadmin", admin: true}
               spyOn(JSON, 'parse').and.returnValue(mockData1)
          createController();
          var result =[{"id":1,"username":"sogetiVianen@sogeti.nl","registrationdatetime":"2015-12-31T23:00:00.000Z","level1":null,"level2":null,"level3":null,"enabled":null,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":null}]
          scope.getUserById(100)
          deferred.reject(result); // Resolve the promise.
          scope.$digest();
          expect(scope.errorMessage).toEqual('No Users Found. Redirecting to admin..')
      });

      it('should test if scope.checkUsername works fine', function() {
          var mockData1 = {accessToken: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiY…yMDl9.gqSOzp5_fVUGzrn5AREhK11opo-CJsM_m-vMy_K7Xtc", userName: "boonadmin", admin: true}
          var mockData2 = [{"id":12,"username":"Campusmanager1","registrationdatetime":"2016-06-20T12:41:19.000Z","level1":null,"level2":1,"level3":null,"enabled":null,"country":1,"campus":"1","building":"2","entrance":"2","company_ID":"1"},{"id":13,"username":"Campusmanager2","registrationdatetime":"2016-06-20T12:41:19.000Z","level1":0,"level2":1,"level3":0,"enabled":0,"country":1,"campus":"2","building":"3","entrance":"6","company_ID":"1"},{"id":14,"username":"Buildingmanager1","registrationdatetime":"2016-06-20T12:41:19.000Z","level1":0,"level2":0,"level3":1,"enabled":1,"country":1,"campus":"3","building":"5","entrance":"7","company_ID":"1"},{"id":22,"username":"SuperUser","registrationdatetime":"2016-07-08T07:52:35.000Z","level1":1,"level2":1,"level3":1,"enabled":1,"country":1,"campus":"1","building":"2","entrance":"2","company_ID":"Sogeti"},{"id":23,"username":"superuser2","registrationdatetime":"2016-07-08T08:51:22.000Z","level1":1,"level2":1,"level3":1,"enabled":1,"country":1,"campus":"1","building":"2","entrance":"4","company_ID":"1"},{"id":25,"username":"sectionmanager1","registrationdatetime":"2016-07-18T09:39:04.000Z","level1":0,"level2":0,"level3":0,"enabled":1,"country":1,"campus":"2","building":"3","entrance":"5","company_ID":"1"}]
          spyOn(JSON, 'parse').and.returnValues(mockData1, mockData2)
          createController();
          scope.user.username = 'Campusmanager1'
          scope.checkUsername()
          expect(scope.errorMessage).toEqual('Username Already exists.')
      });



      it('should test if scope.saveuser works fine', function() {
          var mockData1 = {accessToken: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiY…yMDl9.gqSOzp5_fVUGzrn5AREhK11opo-CJsM_m-vMy_K7Xtc", userName: "boonadmin", admin: true}
          spyOn(JSON, 'parse').and.returnValue(mockData1)
          createController();
          scope.countryId = 1
          var result ={"countries":[{"countryId":1,"countryName":"Netherlands","children":[{"companyId":1,"companyName":"Boon Edam","children":[{"campusId":1,"campusName":"CampusA","children":[{"buildingId":1,"buildingName":"BuildingAB","children":[{"entranceId":1,"entranceName":"EntranceABA","children":[{"subentranceId":1,"subentranceName":"SubEntranceABAA"}]},{"entranceId":2,"entranceName":"EntranceAAA","children":[{"subentranceId":2,"subentranceName":"SubEntranceAAAA"}]},{"entranceId":3,"entranceName":"EntranceABB","children":[{"subentranceId":3,"subentranceName":"SubEntranceABBA"}]}]},{"buildingId":2,"buildingName":"BuildingAA","children":[{"entranceId":4,"entranceName":"EntranceAAB","children":[{"subentranceId":4,"subentranceName":"SubEntranceAABA"}]}]}]},{"campusId":2,"campusName":"CampusB","children":[{"buildingId":3,"buildingName":"BuildingBA","children":[{"entranceId":5,"entranceName":"EntranceBAA","children":[{"subentranceId":5,"subentranceName":"SubEntranceBAAA"},{"subentranceId":6,"subentranceName":"SubEntranceBAAB"}]}]},{"buildingId":4,"buildingName":"BuildingBB","children":[{"entranceId":6,"entranceName":"EntranceBAB","children":[{"subentranceId":7,"subentranceName":"SubEntranceBABA"},{"subentranceId":8,"subentranceName":"SubEntranceBABB"}]}]}]},{"campusId":3,"campusName":"CampusC","children":[{"buildingId":5,"buildingName":"BuildingCA","children":[{"entranceId":7,"entranceName":"EntranceCAA","children":[{"subentranceId":9,"subentranceName":"SubEntranceCAAA"}]}]}]},{"campusId":4,"campusName":"CampusD","children":[{"buildingId":6,"buildingName":"BuildingDA","children":[{"entranceId":8,"entranceName":"EntranceDAA","children":[{"subentranceId":10,"subentranceName":"SubEntranceDAAA"}]}]}]},{"campusId":5,"campusName":"CampusE","children":[{"buildingId":7,"buildingName":"BuildingEA","children":[{"entranceId":9,"entranceName":"EntranceEAA","children":[{"subentranceId":11,"subentranceName":"SubEntranceEAAA"}]}]}]},{"campusId":9,"campusName":"NewAddedCampus","children":[{"buildingId":9,"buildingName":"newAddedBuilding","children":[{"entranceId":11,"entranceName":"newAddedEntrance","children":[{"subentranceId":3371,"subentranceName":"newAddedsubEntrance"}]}]}]}]}]}]}
          scope.getLocations()
          scope.countryId = 1
          scope.countrySelected()
          scope.companyId = 1
          scope.companySelected()
          scope.campusId = 1
          scope.campusSelected()
          scope.buildingId = 1
          scope.buildingSelected()
          scope.saveuser()
          var res = true
          deferred.resolve(res)
          scope.$digest()
          expect(scope.successMessage).toEqual("User created successfully.")
          scope.user.id = 1;
          scope.saveuser()
          var res = true
          deferred.resolve(res)
          scope.$digest()
          expect(scope.successMessage).toEqual("User Updated.")
      });

})

})
