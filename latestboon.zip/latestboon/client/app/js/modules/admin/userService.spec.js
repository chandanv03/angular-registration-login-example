/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
 define([
  'angular-mocks',
  'Source/modules/admin/userService',
  'Source/modules/login/encodeService',
  'Source/config'
  ], function(){

  	   describe('userService', function () {  
  	   		var mockeditUser, queryDeferred, q;

  	   		beforeEach(angular.mock.module('app.admin'));

          beforeEach(angular.mock.module('app.login'));

  	   		beforeEach(angular.mock.module('app.common.token'));

          beforeEach(module(function($provide) {
            mockeditUser = {
              getUsersById:  function() {
                  return {get : function(){}}
              },
              addUser:  function() {
                  return {save : function(){}}
              },
              updateUserById:  function() {
                  return {update : function(){}}
              }
            };
            $provide.value('editUser', mockeditUser);
          }));  

          
          beforeEach(angular.mock.module('app.constants', function ($provide) {
          $provide.constant('CONFIG',{
            url: 'http://nlboed01.sgti.nl:3000/'
          });


          }))          

  	   		beforeEach(angular.mock.inject(function(userService, $rootScope, $state, $location, $window, $q){
				      mockuserService = userService   
              q=$q         
			    })) 

  			 it('should test userService is on its place' , function(){
  			 		expect(mockuserService).toBeDefined()
  			 })

         it('should test getUsersById is on its place' , function(){
          expect(mockuserService.getUsersById).toBeDefined()
         })

         it('should test addUser is on its place' , function(){
          expect(mockuserService.addUser).toBeDefined()
         })         

         it('should test updateUserById is on its place' , function(){
          expect(mockuserService.updateUserById).toBeDefined()
         })    

         it('should test getUsersById is on its place' , function(){
          spyOn(mockuserService, 'getUsersById').and.callThrough()
          spyOn(mockeditUser, 'getUsersById').and.callThrough()
           mockuserService.getUsersById(10)
           expect(mockuserService.getUsersById).toHaveBeenCalled()
           expect(mockeditUser.getUsersById).toHaveBeenCalled()
         })

         it('should test addUser is on its place' , function(){
           spyOn(mockuserService, 'addUser').and.callThrough()
           spyOn(mockeditUser, 'addUser').and.callThrough()
           var userDetails = {}
           userDetails.password = 'test'
           mockuserService.addUser(userDetails)
           expect(mockuserService.addUser).toHaveBeenCalled()
           expect(mockeditUser.addUser).toHaveBeenCalled()
         })                 

         it('should test updateUserById is on its place' , function(){
           spyOn(mockuserService, 'updateUserById').and.callThrough()
           spyOn(mockeditUser, 'updateUserById').and.callThrough()
           var userDetails = {}
           userDetails.password = 'test'
           mockuserService.updateUserById(userDetails)
           expect(mockuserService.updateUserById).toHaveBeenCalled()
           expect(mockeditUser.updateUserById).toHaveBeenCalled()
         }) 

  	   })

 })