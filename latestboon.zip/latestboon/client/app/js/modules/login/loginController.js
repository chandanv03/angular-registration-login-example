/**
 * Login controller definition
 */
define(['./module'], function (module) {
  module.controller('LoginController', function ($scope, $window, Auth, CONFIG) {
    var vm = $scope
    vm.title = 'Login Page'
    vm.resetLogin = function(){
      $scope.username=''
      $scope.password=''
    }
    vm.authenticate = function () {
      if ( $scope.username!='') {

        //If the form is valid then we need to check the credentials in the server
        Auth.login($scope.username, $scope.password).then(angular.noop, function (data) {
          $scope.invalid = true
          if(data.hasOwnProperty('message')){
            $scope.message = data.message
          } else {
            $scope.message = 'Invalid User Credentials.'
          }
        })
      }

    }
  })
})
