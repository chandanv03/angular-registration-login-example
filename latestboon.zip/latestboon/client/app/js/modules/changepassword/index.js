/**
 * Loader, contains list of Change Password module components
 */
define([
  './changePasswordController',
  './changePasswordService'
], function () {})
