define(['./module'], function(module) {
    'use strict'
    module.factory('userService', function($rootScope, $window, $q, editUser, EncodeService, TokenService) {
        var factory = {
            /*get user data by id*/
            getUsersById: function(usedId) {
                var deferred = $q.defer()
                var userInfo = {
                    id: usedId
                }

                var userData = editUser.getUsersById(TokenService.getToken()).get(userInfo, function() {
                    if (userData.success === true) {
                        deferred.resolve(userData.users)
                    } else {
                        deferred.reject(userData)
                    }
                })
                return deferred.promise
            },

            /*add user*/
            addUser: function(userDetails) {
                var deferred = $q.defer()
                userDetails.password = EncodeService.encode(userDetails.password)

                var addUser = editUser.addUser(TokenService.getToken()).save(userDetails, function() {
                    if (addUser.success === true) {
                        deferred.resolve(addUser.success)
                    } else {
                        deferred.reject(addUser)
                    }
                })
                return deferred.promise
            },

            /*update user data by id*/
            updateUserById: function(userDetails) {
                var deferred = $q.defer()
                userDetails.password = EncodeService.encode(userDetails.password)

                var updateUserData = editUser.updateUserById(TokenService.getToken()).update(userDetails, function() {
                    if (updateUserData.success === true) {
                        deferred.resolve(updateUserData.success)
                    } else {
                        deferred.reject(updateUserData)
                    }
                })
                return deferred.promise
            }
        }
        return factory
    })
})
