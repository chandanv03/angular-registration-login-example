define(['./module'], function(module) {
    'use strict'
    //Factory method for treeview service
    module.factory('TreeViewService', function() {
        function TreeViewService() {
            var that = this
            this.selectedNode = null
            this.nodes = []
            this.collapsed = []
            this.index = -1

            this.toggleNode = function(node) {
                if (!node.children) return

                // collapse / expand
                if (node.children && node.children.length > 0) {
                    // add the node to our collapsed array
                    var index = that.collapsed.indexOf(node)

                    if (index == -1) {
                        that.collapsed.push(node)
                    } else {
                        that.collapsed.splice(index, 1)
                    }
                }
                that.setIndex(node)
            }

            this.setIndex = function(node) {
                function iterate(list) {
                    for (var i = 0; i < list.length; i++) {
                        var found = false

                        if (list[i] == node) {
                            found = true
                        } else if (angular.isDefined(list[i].children)) {
                            found = iterate(list[i].children)
                        }

                        if (found == true) {
                            that.index = i
                            return true
                        }
                    }

                    return false
                }
                iterate(that.nodes)
            }

            this.reselectNode = function() {
                that.collapseTo(that.nodes[that.index])
            }

            // will search all nodes for this node, and expand each parent node
            this.collapseTo = function(node) {
                function iterate(list) {
                    for (var i = 0; i < list.length; i++) {
                        var found = false

                        if (list[i] == node) {
                            found = true
                        } else if (angular.isDefined(list[i].children)) {
                            found = iterate(list[i].children)
                        }

                        if (found == true) {
                            that.index = i
                            that.collapsed.push(list[i])
                            return true
                        }
                    }

                    return false
                }

                iterate(that.nodes)
            }
        }

        return TreeViewService
    })

    module.directive('treeView', ['$rootScope', '$compile', '$templateCache', function($rootScope, $compile, $templateCache) {
        return {
            restrict: 'E',
            require: '^ngModel',
            scope: {},
            bindToController: {
                treeService: '='
            },
            controller: function($scope) {
                var that = this

                this.isCollapsed = function(node) {
                    return that.treeService.collapsed.indexOf(node) > -1
                }

                // toggle when icon clicked
                this.toggleNode = function(node) {
                    that.treeService.toggleNode(node)
                }


                /* To deselct company item from tree
                    view when campus is selected
                 */
                this.unSelectRoot = function() {
                    $rootScope.setSelected = 0
                }

                this.applySelectedClass = function(element) {
                        if (!element.hasClass('selected')) {
                            element.addClass('selected')
                        }
                    }
                    // select when name clicked
                this.selectNode = function(e, node) {
                    var target = e.target
                    $('.selected-node').removeClass('selected')
                    if ($(target).hasClass('node')) {
                        this.applySelectedClass($(target))
                    } else if ($(target.parentElement).hasClass('node')) {
                        this.applySelectedClass($(target.parentElement))
                    } else if ($(target.parentElement.parentElement).hasClass('node')) {
                        this.applySelectedClass($(target.parentElement.parentElement))
                    }
                    this.unSelectRoot()
                    that.treeService.selectedNode = node
                    that.treeService.lastSelectedNode = node
                    e.stopPropagation()
                    e.preventDefault()
                }
            },
            controllerAs: 'ctrl',
            link: function(scope, element, attrs, ngModel, ctrl) {
                var isRoot = (!attrs.treeRoot ? true : false)
                var nodeLabel = attrs.nodeLabel || 'label'
                var itemClass = attrs.itemClass || ''
                var itemInclude = attrs.itemNgInclude || ''
                var ngModelValue = attrs.ngModel
                var itemIncludeHtml = ''

                if (itemInclude && itemInclude.length > 0) {
                    itemIncludeHtml = $templateCache.get(attrs.itemNgInclude)
                }
                // remove attributes
                element.removeAttr('node-label')
                element.removeAttr('item-class')
                element.removeAttr('item-ng-include')
                element.removeAttr('tree-root')

                // template
                var template =
                    '<ul>' +
                    '<li ng-repeat="node in [REPLACENODES]">' +
                    '<div ng-click="ctrl.selectNode($event, node);ctrl.toggleNode(node);" class="node selected-node" ng-class="{\'selected\' : node == ctrl.treeService.selectedNode}">' +
                    '<div ' + (itemClass != '' ? ' class="' + itemClass + '"' : '') + '>' +
                    '<i ng-click="ctrl.toggleNode(node)" ng-show="node.children && node.children.length > 0" ng-class="!ctrl.isCollapsed(node) ? \'has-child\' : \'has-child-open\'"></i>' +
                    '<i ng-click="ctrl.toggleNode(node)" class="no-child" ng-show="!node.children || node.children.length == 0"></i>' +
                    '<span ng-if="node.buildingName" ng-bind="node.buildingName" ng-class="{\'selected\' : node == ctrl.treeService.selectedNode}"></span>' +
                    '<span ng-if="node.entranceName" ng-bind="node.entranceName" ng-class="{\'selected\' : node == ctrl.treeService.selectedNode}"></span>' +
                    '<span ng-if="node.subentranceName" ng-bind="node.subentranceName" ng-class="{\'selected\' : node == ctrl.treeService.selectedNode}"></span>' +
                    '<span ng-if="node.campusName" ng-bind="node.' + nodeLabel + '" ng-class="{\'selected\' : node == ctrl.treeService.selectedNode}" ng-click="ctrl.unSelectRoot()"></span>' +
                    '</div>' +
                    itemIncludeHtml +
                    '</div>'

                template += '<div ng-if="node.buildingName">' +
                    '<tree-view uib-collapse="!ctrl.isCollapsed(node)" tree-service="ctrl.treeService" data-ng-model="' + ngModelValue + '" node-children="node.children" tree-root="false" node-label="buildingName" item-ng-include="' + itemInclude + '" item-class="' + itemClass + '"></tree-view>' +
                    '</div>' +
                    '<div ng-if="node.entranceName">' +
                    '<tree-view uib-collapse="!ctrl.isCollapsed(node)" tree-service="ctrl.treeService" data-ng-model="' + ngModelValue + '" node-children="node.children" tree-root="false" node-label="entranceName" item-ng-include="' + itemInclude + '" item-class="' + itemClass + '"></tree-view>' +
                    '</div>' +
                    '<div ng-if="node.subentranceName">' +
                    '<tree-view uib-collapse="!ctrl.isCollapsed(node)" tree-service="ctrl.treeService" data-ng-model="' + ngModelValue + '" node-children="node.children" tree-root="false" node-label="subentranceName" item-ng-include="' + itemInclude + '" item-class="' + itemClass + '"></tree-view>' +
                    '</div>' +
                    '<div ng-if="node.campusName">' +
                    '<tree-view uib-collapse="!ctrl.isCollapsed(node)" tree-service="ctrl.treeService" data-ng-model="' + ngModelValue + '" node-children="node.children" tree-root="false" node-label="' + nodeLabel + '" item-ng-include="' + itemInclude + '" item-class="' + itemClass + '"></tree-view>' +
                    '</div>'

                template +=
                    '</li>' +
                    '</ul>'

                if (!isRoot) {
                    template = template.replace('[REPLACENODES]', '$parent.node.children')
                } else {
                    template = template.replace('[REPLACENODES]', 'ctrl.treeService.nodes')
                }

                var compiledHtml = $compile(template)(scope)

                element.append(compiledHtml)
            }
        }
    }])
})
