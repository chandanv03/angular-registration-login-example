# Boon Edam Dashboard - Dashboard application for Boon Edam to show Access details for campus, building, doors.

This project is an dashboard application to show access details for campus, building, doors.