define(['./module'], function(module) {
    'use strict'

    module.service('DashboardTreeView', function($rootScope, $state, $location, $window, Doors, $q, LastChange, DoorParam, TokenService) {
        var service = {
            setDoorBool: false,
            doorData: {
                campuses: [],
                builings: [],
                entrances: [],
                subentrances: []
            },
            mergedDoorData: {
                doors: []
            },
            //Set the selected campus, building, entrance, sub entrance
            setDoorData: function(value) {
                var doorObj = {}
                if (value.hasOwnProperty('campusId')) {
                    doorObj['campusId'] = value.campusId
                    doorObj['campusName'] = value.campusName
                    service.doorData.campuses.push(doorObj)
                } else if (value.hasOwnProperty('buildingId')) {
                    doorObj['buildingId'] = value.buildingId
                    doorObj['buildingName'] = value.buildingName
                    service.doorData.builings.push(doorObj)
                } else if (value.hasOwnProperty('entranceId')) {
                    doorObj['entranceId'] = value.entranceId
                    doorObj['entranceName'] = value.entranceName
                    service.doorData.entrances.push(doorObj)
                } else if (value.hasOwnProperty('subentranceId')) {
                    doorObj['subentranceId'] = value.subentranceId
                    doorObj['subentranceName'] = value.subentranceName
                    service.doorData.subentrances.push(doorObj)
                }
            },
            filterDoorsData: function(nodeData) {
                service.mergedDoorData = {
                    doors: []
                }
                service.setDoorBool = false
                this.mergeDoorsData(nodeData)
                return service.mergedDoorData
            },
            //Merge the doors record for all campus
            mergeDoorsData: function(doorData) {
                var campusData
                angular.forEach(doorData, function(value, key) {
                    if (angular.isObject(doorData[key])) {
                        if (service.setDoorBool) {
                            service.setDoorData(value)
                        }

                        if (key === 'doors') {
                            campusData = doorData[key]
                            angular.forEach(campusData, function(campusValue, campusKey) {
                                service.mergedDoorData.doors.push(campusValue)
                            })
                        } else {
                            service.mergeDoorsData(doorData[key])
                        }
                    }
                })
            },
            fetchDoors: function() {
                var payload = {}
                var deferred = $q.defer()
                    //Get the door record
                var getDoors = Doors.getDoors(TokenService.getToken()).get({
                    path: 'v1'
                }, payload, function(result, headerFun) {
                    service.doorData = {
                        campuses: [],
                        builings: [],
                        entrances: [],
                        subentrances: []
                    }
                    service.mergedDoorData = {
                        doors: []
                    }
                    service.setDoorBool = true
                    service.mergeDoorsData(getDoors.campuses)
                    deferred.resolve(getDoors)
                }, function(result) {
                    if (result.status == 403) {
                        $rootScope.session_flag = 1
                        $rootScope.expiry = "Session Timed Out Kindly Login"
                        $state.go('login')
                    }
                    deferred.reject(getDoors)
                })

                return deferred.promise
            },
            logout: function() {
            },
            checkLastChange: function() {
                var deferred = $q.defer()
                var get = LastChange.getLastChange(TokenService.getToken()).get({}, {}, function() {
                        if (get.success === true) {

                            deferred.resolve(get)
                        } else {
                            deferred.reject(get)
                        }
                    }

                )
                return deferred.promise
            },
            putDoorParam: function(doorParam) {
                var deferred = $q.defer()
                var param_response = DoorParam.updateDoorParams(TokenService.getToken()).update({}, doorParam, function(result) {
                    deferred.resolve(result)
                })

                return deferred.promise
            }

        }

        return service
    })
})
