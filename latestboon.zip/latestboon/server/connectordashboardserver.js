var express = require('express')
var cors = require('cors')
var db = require('./database.js')
var config = require('./config.js')
var auth = require('./logon.js')
var Dooroverview = require('./dooroverview.js')
var Doordetails = require('./doordetails.js')
var Campusoverview = require('./campusoverview.js')
var queries = require('./sqlqueries.js')
var https = require('https')
var fs = require('fs')
var http = require('http')
var request = require('request')
var querystring = require('querystring')

var pk = fs.readFileSync(__dirname + '/privatekey.pem')
var pc = fs.readFileSync(__dirname + '/certificate.pem')
var opts = {
  key: pk,
  cert: pc
}

var connectordashboardserver = express()
connectordashboardserver.options('*', cors()) // include before other routes
https.createServer(opts, connectordashboardserver).listen(config.portNumber, function () {
  console.log('Boon Door Dashboard server connectordashboardserver listening on port: ' + config.portNumber + '!')
  console.log('authorized clients: ' + whitelist)
})

var connectordashboardrouter = express.Router()
var whitelist = config.whitelist
var jwt = require('jsonwebtoken')
var requestip = require('request-ip')
var bodyparser = require('body-parser')
var base64 = require('./base64.js')
var bcrypt = require('bcryptjs')
var doorparametershandler = require('./doorparametershandler.js')
var changepasswordhandler = require('./changepasswordhandler.js')
var kaaServerApi = require('./kaaServerApi.js')

connectordashboardserver.use(bodyparser.urlencoded({
  extended: true
}))
connectordashboardserver.use(bodyparser.json())
var corsOptions = {
  origin: function (origin, callback) {
    var originIsWhitelisted = whitelist.indexOf(origin) !== -1
    callback(null, originIsWhitelisted)
  },
  credentials: true
}
connectordashboardserver.use(cors(corsOptions))

/* GETTERS */

connectordashboardserver.get('/', function (req, res) {

  // send 403 error for / is not to be loaded
  var error = {
    Error: 'Forbidden',
    errnum: '0403',
    cause: 'no access to the webapplicationroot allowed'
  }
  res.status(403).send(error)
})

connectordashboardserver.get('/admin/getuser', tokenVerification, function (req, res) {
  var id = req.query.id
  connectordashboardserver.getUser(id, function (results) {
    res.send(results)
  })
})

connectordashboardserver.get('/admin/listusers', tokenVerification, function (req, res) {
  connectordashboardserver.getUserlist(function (results) {
    res.send(results)
  })
})

connectordashboardserver.post('/checkuser', function (req, res) {
  var user = req.body.user
  var passwd = req.body.password
  var clientIp = requestip.getClientIp(req)

  var post = {
    user,
    passwd,
  clientIp}
  connectordashboardserver.doValidateUser(post, function (result) {
    res.send(result)
  })
})

connectordashboardserver.put('/updatedoorparameters/', tokenVerification, function (req, res) {
  // first we need to put the username from the tokenVerification in the product table
  doorparametershandler.updateDoorParameters(req, function (results) {
    res.send(results)
  })
})

connectordashboardserver.post('/changepassword/', tokenVerification, function (req, res) {
  var user = req.user
  var pwd = req.body.password
  var newPwd = req.body.newpassword
  var post = {
    user,
    pwd,
  newPwd}
  changepasswordhandler.doChangePassword(post, function (results) {
    res.send(results)
  })
})

connectordashboardserver.get('/doors', tokenVerification, function (req, res) {
  connectordashboardserver.getdoors(req.user, function (results) {
    res.send(results)
  })
})

connectordashboardserver.get('/locations', tokenVerification, function (req, res) {
  connectordashboardserver.getlocations(function (results) {
    console.log(results)
    res.send(results)
  })
})

connectordashboardserver.get('/doors/detail', tokenVerification, function (req, res) {
  var deviceId = req.query.id
  var doordetails = new Doordetails()
  connectordashboardserver.getDoorById(deviceId, function (error, result) {
    if (result == null) {
      doordetails.doorMain = 'no record found'
    } else {
      doordetails.doorMain = result
      // transactiontime section
      connectordashboardserver.getTransactionTime(null, deviceId, function (result) {
        if (result == null) {
          doordetails.transactionTimes = 'no transactiontime records'
        } else {
          doordetails.transactionTimes = result
          // rejectioncount section
          connectordashboardserver.getRejectionCount(null, deviceId, function (result) {
            if (result == null) {
              doordetails.rejectionCount = 'no rejections record'
            } else {
              doordetails.rejectionCount = result
              // time_of Flight_section
              connectordashboardserver.getTimeOfFlight(deviceId, function (result) {
                if (result == null) {
                  doordetails.timeOfFlight = 'no timeOfFlight record'
                } else {
                  doordetails.timeOfFlight = result
                  connectordashboardserver.getPlcData(deviceId, function (result) {
                    if (result == null) {
                      doordetials.plc = 'no plc record'
                    } else {
                      doordetails.plc = result
                      connectordashboardserver.getMotorDriveData(deviceId, function (result) {
                        if (result == null) {
                          doordetails.motorDrive = 'no motor_drive record'
                        } else {
                          doordetails.motorDrive = result
                          console.log(doordetails)
                          res.send(doordetails)
                        }
                      })
                    }
                  })
                }
              })
            }
          })
        }
      })
    }
  })
})

connectordashboardserver.get('/doors/rejectioncount', tokenVerification, function (req, res) {
  var type = req.query.type
  var deviceId = req.query.id
  connectordashboardserver.getRejectionCount(type, deviceId, function (result) {
    res.send(result)
  })
})

connectordashboardserver.get('/doors/transactiontime', tokenVerification, function (req, res) {
  var type = req.query.type
  var deviceId = req.query.id
  connectordashboardserver.getTransactionTime(type, deviceId, function (result) {
    res.send(result)
  })
})

connectordashboardserver.get('/doors/timeofflight', tokenVerification, function (req, res) {
  var deviceId = req.query.id
  connectordashboardserver.getTimeOfFlight(deviceId, function (result) {
    res.send(result)
  })
})

connectordashboardserver.get('/doors/doorstatus', tokenVerification, function (req, res) {
  var deviceId = req.query.id
  connectordashboardserver.getDoorStatus(deviceId, function (result) {
    res.send(result)
  })
})

connectordashboardserver.get('/doors/changelog', tokenVerification, function (req, res) {
  var type = req.query.type
  var deviceId = req.query.id
  connectordashboardserver.getEventLog(type, deviceId, function (result) {
    res.send(result)
  })
})

connectordashboardserver.get('/campus/id', tokenVerification, function (req, res) {
  var id = req.query.id
  connectordashboardserver.getCampusById(id, function (error, result) {
    if (result == null) {
      res.status(404).send(error)
    } else {
      res.send(result)
    }
  })
})

connectordashboardserver.get('/doors/campus', tokenVerification, function (req, res) {
  var id = req.query.id
  connectordashboardserver.getDoorByCampusId(id, function (error, result) {
    if (result == null) {
      res.status(404).send(error)
    } else {
      res.send(result)
    }
  })
})

connectordashboardserver.get('/doors/lastchange', function (req, res) {
  connectordashboardserver.getLastChange(function (result) {
    res.send(result)
  })
})
/* PUTTERS */

connectordashboardserver.put('/doors/plc', tokenVerification, function (req, res) {
  kaaServerApi.executeKaaServerApi(req, 'plc', function () {
    console.log('Kaa server updated successfully')
    connectordashboardserver.setLastUpdater(req.user, req.query.deviceId, function (cb) {
      if (cb.success === false) {
        console.log("error updating basetable 'product'.")
        res.send({
          success: false,
          message: 'Invalid Data.'
        })
      } else {
        connectordashboardserver.updatePlc(req.body, req.query.deviceId, function (results) {
          connectordashboardserver.setLastUpdater(null, req.query.deviceId, function (cb2) {
            if (cb2.success === true) {
              console.log("lastupdatedby cleared in 'product'")
            }
          })
          res.send(results)
        })
      }
    })
  },
    function () {
      console.log('plc Kaa server api update failed')
      res.send({
        success: false,
        message: 'User does not have permission to update the data.'
      })
    })
})

connectordashboardserver.put('/doors/motordrive', tokenVerification, function (req, res) {
  kaaServerApi.executeKaaServerApi(req, 'motor_drive', function () {
    console.log('Kaa server updated successfully')
    connectordashboardserver.setLastUpdater(req.user, req.query.deviceId, function (cb) {
      if (cb.success === false) {
        console.log("error updating basetable 'product'.")
        res.send({
          success: false,
          message: 'Invalid Data.'
        })
      } else {
        connectordashboardserver.updateMotorDrive(req.body, req.query.deviceId, function (results) {
          connectordashboardserver.setLastUpdater(null, req.query.deviceId, function (cb2) {
            if (cb2.success === true) {
              console.log("lastupdatedby cleared in 'product'")
            }
          })
          res.send(results)
        })
      }
    })
  }, function () {
    console.log('Kaa server api update failed')
    res.send({
      success: false,
      message: 'User does not have permission to update the data.'
    })
  })
})

connectordashboardserver.put('/doors/stereovision', tokenVerification, function (req, res) {
  console.log('stereo vision update part')
  kaaServerApi.executeKaaServerApi(req, 'stereovision', function () {
    console.log('Kaa server updated successfully')
    connectordashboardserver.setLastUpdater(req.user, req.query.deviceId, function (cb) {
      if (cb.success === false) {
        console.log("error updating basetable 'product'.")
        res.send({
          success: false,
          message: 'Invalid Data.'
        })
      } else {
        connectordashboardserver.updateStereovision(req.body, req.query.deviceId, function (results) {
          connectordashboardserver.setLastUpdater(null, req.query.deviceId, function (cb2) {
            if (cb2.success === true) {
              console.log("lastupdatedby cleared in 'product'")
            }
          })
          res.send(results)
        })
      }
    })
  }, function () {
    console.log('Kaa server api update failed')
    res.send({
      success: false,
      message: 'User does not have permission to update the data.'
    })
  })
})

connectordashboardserver.put('/doors/stereovisionimage', tokenVerification, function (req, res) {
  console.log('In stereovision Image')
  kaaServerApi.executeKaaServerApi(req, 'stereovision', function () {
    console.log('Sent Json command to Kaa server successfully')
    res.send({
      success: true,
      message: 'Sent Json command to Kaa server successfully.'
    })
  }, function () {
    console.log('Kaa server api update failed')
    res.send({
      success: false,
      message: 'User does not have permission to update the data.'
    })
  })
})

connectordashboardserver.put('/doors/product', tokenVerification, function (req, res) {
  var fieldList = req.body
  if (req.body.snoozeExitTime != undefined || req.body.snoozeExitTime != null) {
    console.log('snooze setting')
    connectordashboardserver.getDoorStatus(req.query.deviceId, function (result) {
      var doorstatus = result[0].doorstatus
      if (doorstatus == config.doorStatus_Warning) {
        console.log('snooze setting for orange doors')
        req.body = {
          'ClearWarning': 1
        }
        kaaServerApi.executeKaaServerApi(req, 'Command', function () {
          console.log('Sent Json command to Kaa server successfully')
          connectordashboardserver.setLastUpdater(req.user, req.query.deviceId, function (cb) {
            if (cb.success === false) {
              console.log("error updating basetable 'product'.")
              res.send({
                success: false,
                message: "error updating basetable 'product'."
              })
            } else {
              connectordashboardserver.updateProduct(fieldList, req.query.deviceId, function (results) {
                connectordashboardserver.setLastUpdater(null, req.query.deviceId, function (cb2) {
                  if (cb2.success === true) {
                    console.log("lastupdatedby cleared in 'product'")
                  }
                })
                res.status(200).send(results)
              })
            }
          })
        }, function () {
          console.log('Kaa server api update failed')
        })
      } else {
        console.log('snooze setting for non-orange doors')

        connectordashboardserver.setLastUpdater(req.user, req.query.deviceId, function (cb) {
          if (cb.success === false) {
            console.log("error updating basetable 'product'.")
            res.send({
              success: false,
              message: "error updating basetable 'product'."
            })
          } else {
            connectordashboardserver.updateProduct(fieldList, req.query.deviceId, function (results) {
              connectordashboardserver.setLastUpdater(null, req.query.deviceId, function (cb2) {
                if (cb2.success === true) {
                  console.log("lastupdatedby cleared in 'product'")
                }
              })
              res.status(200).send(results)
            })
          }
        })
      }
    })
  }
// connectordashboardserver.setLastUpdater(req.user, req.query.deviceId, function (cb) {
//   if (cb.success === false) {
//     console.log("error updating basetable 'product'.")
//     res.send({
//       success: false,
//       message: "error updating basetable 'product'."
//     })
//   } else {
//     var fieldList = req.body
//     connectordashboardserver.getDoorStatus(req.query.deviceId, function (result) {
//       var doorstatus = result[0].doorstatus
//       if (doorstatus == config.doorStatus_Warning) {
//         req.body = {'ClearWarning': 1}
//         kaaServerApi.executeKaaServerApi(req, 'Command', function () {
//           console.log('Sent Json command to Kaa server successfully')
//         }, function () {
//           console.log('Kaa server api update failed')
//         })
//       }
//       connectordashboardserver.updateProduct(fieldList, req.query.deviceId, function (results) {
//         connectordashboardserver.setLastUpdater(null, req.query.deviceId, function (cb2) {
//           if (cb2.success === true) {
//             console.log("lastupdatedby cleared in 'product'")
//           }
//         })
//         res.status(200).send(results)
//       })
//     })
//   }
// })
})

connectordashboardserver.put('/doors/location', tokenVerification, function (req, res) {
  connectordashboardserver.updateDoorLocation(req.body, req.query.deviceId, req.user, function (results) {
    res.send(results)
  })
})

connectordashboardserver.put('/admin/changeuser', tokenVerification, function (req, res) {
  connectordashboardserver.updateUser(req.body, req.query.id, function (results) {
    res.send(results)
  })
})

/* POSTERS */

connectordashboardserver.post('/admin/adduser', tokenVerification, function (req, res) {
  connectordashboardserver.createUser(req.body, function (results) {
    res.send(results)
  })
})

/* DELETE */
connectordashboardserver.delete('/admin/deleteuser', tokenVerification, function (req, res) {
  connectordashboardserver.deleteUser(req.query.id, function (results) {
    res.send(results)
  })
})

/* internal implementation for getters */

connectordashboardserver.getdoors = function (user, cb) {
  var doorOverviewSql
  var campusByUserSql = queries.campusbyuserquery
  var type
  var campusId

  db.executeSelect(campusByUserSql, user, function (err, rows, fields) {
    if (err) {
      console.log("error while performing query for user's campus.", err)
    } else {
      if ((rows.length > 0) && (rows[0].campus == null)) {
        doorOverviewSql = queries.dooroverviewquery
        type = 'all'
        campusId = 'dummy'
        connectordashboardserver.getdoorsafterqueryselection(doorOverviewSql, user, type, campusId, function (callback) {
          cb(callback)
        })
      } else {
        doorOverviewSql = queries.dooroverviewqueryByUser
        type = 'campus'
        campusId = rows[0].campus
        connectordashboardserver.getdoorsafterqueryselection(doorOverviewSql, user, type, campusId, function (callback) {
          cb(callback)
        })
      }
    }
  })
}

connectordashboardserver.getdoorsafterqueryselection = function (dooroverviewquery, user, type, campusId, cb) {
  var doorOverviewSql = dooroverviewquery
  var connection = db.getConnection()
  var dooroverview = new Dooroverview()
  var values = [
    user,
    user
  ]

  connection.connect()
  connection.query(doorOverviewSql, values, function (err, rows, fields) {
    if (err) {
      console.log('error while performing query.', err)
      cb(err)
    } else {
      if (rows.length > 0) {
        dooroverview.populate(rows)
        connectordashboardserver.getRejectionCount(type, campusId, function (result) {
          dooroverview.fillRejections(result)
          if (dooroverview.rejections !== null) {
            connectordashboardserver.getTransactionTime(type, campusId, function (result) {
              dooroverview.fillTransactions(result)
              cb(dooroverview)
            })
          }
        })
      } else {
        cb(err, dooroverview)
      }
    }
    connection.end()
  })
}

connectordashboardserver.getlocations = function (cb) {
  var locationsOverviewSql = queries.locationsoverviewquery
  var locationsoverview = new Campusoverview()

  db.executeSelect(locationsOverviewSql, 'dummy', function (err, rows, fields) {
    if (err) {
      console.log('error while performing query for locations', err)
    } else {
      console.log(rows)
      if (rows.length > 0) {
        locationsoverview.populate(rows)
        cb(locationsoverview)
      } else {
        cb(err, locationsoverview)
      }
    }
  })
}

connectordashboardserver.getDoorById = function (id, cb) {
  var post = id
  var doorByIdSql = queries.doorbyidquery
  db.executeSelect(doorByIdSql, post, function (err, rows, fields) {
    if (err) {
      console.log('error while performing query for single door.')
    }
    cb(err, rows)
  })
}

connectordashboardserver.getCampusById = function (id, cb) {
  var post = id
  var campusByIdSql = campusbyidquery
  db.executeSelect(campusByIdSql, post, function (err, rows, fields) {
    if (err) {
      console.log('error while performing query for single campus.')
    }
    cb(err, rows)
  })
}

connectordashboardserver.getDoorDetails = function (id, cb) {
  var post = id
  var doorDetailsSql = queries.doordetailquery
  db.executeSelect(doorDetailsSql, post, function (err, rows, fields) {
    if (err) {
      console.log('error while performing query for doors on campus.')
    }
    cb(err, rows)
  })
}

connectordashboardserver.getTransactionTime = function (type, deviceId, cb) {
  var post = deviceId
  var transactiontimeSql = null
  if (type === 'all') {
    transactiontimeSql = queries.transactiontimequeryTotals
  } else {
    if (type === 'campus') {
      transactiontimeSql = queries.transactiontimequeryByCampus
    } else {
      if (type === 'building') {
        transactiontimeSql = queries.transactiontimequeryByBuilding
      } else {
        if (type === 'entrance') {
          transactiontimeSql = queries.transactiontimequeryByEntrance
        } else {
          if (type === 'subentrance') {
            transactiontimeSql = queries.transactiontimequeryBySubEntrance
          } else {
            transactiontimeSql = queries.transactiontimequeryByDevice
          }
        }
      }
    }
  }

  db.executeSelect(transactiontimeSql, post, function (err, rows, fields) {
    if (err) {
      console.log('error while performing query for transactiontime.')
    }
    cb(rows)
  })
}

connectordashboardserver.getEventLog = function (type, deviceId, cb) {
  var post = deviceId
  var eventlogSql = null
  if (type === 'all') {
    eventlogSql = queries.eventlogqueryTotals
  } else {
    if (type === 'campus') {
      eventlogSql = queries.eventlogqueryByCampus
    } else {
      if (type === 'building') {
        eventlogSql = queries.eventlogqueryByBuilding
      } else {
        if (type === 'entrance') {
          eventlogSql = queries.eventlogqueryByEntrance
        } else {
          if (type === 'subentrance') {
            eventlogSql = queries.eventlogqueryBySubEntrance
          } else {
            eventlogSql = queries.eventlogqueryByDevice
          }
        }
      }
    }
  }

  db.executeSelect(eventlogSql, post, function (err, rows, fields) {
    if (err) {
      console.log('error while performing query for eventlog.')
      cb({
        success: false
      })
    } else {
      cb({
        results: rows,
        success: true
      })
    }
  })
}

connectordashboardserver.getTimeOfFlight = function (deviceId, cb) {
  // optex of sterovision table
  var post = deviceId
  var timeOfFlightSql = queries.timeofflightquery
  db.executeSelect(timeOfFlightSql, post, function (err, rows, fields) {
    if (err) {
      console.log('error while performing query for optex/stereovision doordetails.')
    }

    cb(rows)
  })
}

connectordashboardserver.getDoorStatus = function (deviceId, cb) {
  var post = deviceId
  var doorStatusSql = queries.doorstatusquery
  db.executeSelect(doorStatusSql, post, function (err, rows, fields) {
    if (err) {
      console.log('error while performing query for optex/stereovision doordetails.')
    }
    cb(rows)
  })
}

connectordashboardserver.getPlcData = function (deviceId, cb) {
  // plc table
  var post = deviceId
  var plcSql = queries.plcquery
  db.executeSelect(plcSql, post, function (err, rows, fields) {
    if (err) {
      console.log('error while performing query for optex/stereovision doordetails.')
    }
    cb(rows)
  })
}

connectordashboardserver.getMotorDriveData = function (deviceId, cb) {
  // plc table
  var post = deviceId
  var motorDriveSql = queries.motordrivequery
  db.executeSelect(motorDriveSql, post, function (err, rows, fields) {
    if (err) {
      console.log('error while performing query for motor_drive doordetails.')
    }
    cb(rows)
  })
}

connectordashboardserver.getUser = function (id, cb) {
  // user table
  var post = id
  var userSql = queries.userquery
  db.executeSelect(userSql, post, function (err, rows, fields) {
    if (err) {
      console.log('error while performing query for get user.')
      cb({
        success: false
      })
    } else {
      console.log('success while performing query for get user.')

      cb({
        users: rows,
        success: true
      })
    }
  })
}

connectordashboardserver.getUserlist = function (cb) {
  // user table
  var post = 'dummy'
  var userlistSql = queries.userlistquery
  db.executeSelect(userlistSql, post, function (err, rows, fields) {
    if (err) {
      console.log('error while performing query for get user list.')
      cb({
        success: false
      })
    } else {
      cb({
        users: rows,
        success: true
      })
    }
  })
}

connectordashboardserver.getRejectionCount = function (type, deviceId, cb) {
  var post = deviceId
  var rejectionCountSql = null
  if (type === 'all') {
    rejectionCountSql = queries.rejectioncountqueryTotals
  } else {
    if (type === 'campus') {
      rejectionCountSql = queries.rejectioncountqueryByCampus
    } else {
      if (type === 'building') {
        rejectionCountSql = queries.rejectioncountqueryByBuilding
      } else {
        if (type === 'entrance') {
          rejectionCountSql = queries.rejectioncountqueryByEntrance
        } else {
          if (type === 'subentrance') {
            rejectionCountSql = queries.rejectioncountqueryBySubEntrance
          } else {
            rejectionCountSql = queries.rejectioncountqueryByDevice
          }
        }
      }
    }
  }
  db.executeSelect(rejectionCountSql, post, function (err, rows, fields) {
    if (err) {
      console.log('error while performing query for rejectioncount.')
    }
    cb(rows)
  })
}

connectordashboardserver.getLastChange = function (cb) {
  var post = 'dummy'
  var lastchangeSql = queries.lastchangequery
  db.executeSelect(lastchangeSql, post, function (err, rows, fields) {
    if (err) {
      console.log('error while fetching the last change date')
      cb({
        success: false
      })
    } else {
      cb({
        success: true,
        results: rows
      })
    }
  })
}

/* internal implementation of posters */

connectordashboardserver.updatePlc = function (fieldlist, deviceId, cb) {
  var deviceId = deviceId
  var data = fieldlist
  var post = [data, deviceId]
  var plcUpdateSql = queries.plcupdatequery
  db.executeUpdate(plcUpdateSql, post, function (err, result) {
    if (err) {
      console.log('error while performing update plc table.')
      cb({
        success: false,
        message: 'Update failed.'
      })
    } else {
      cb({
        success: true,
        message: 'Update successful.'
      })
    }
  })
}

connectordashboardserver.updateMotorDrive = function (fieldlist, deviceId, cb) {
  var deviceId = deviceId
  var data = fieldlist
  var post = [data, deviceId]
  var motorDriveUpdateSql = queries.motordriveupdatequery
  db.executeUpdate(motorDriveUpdateSql, post, function (err, result) {
    if (err) {
      console.log('error while performing update on motor_drive table.', err)
      cb({
        success: false,
        message: 'Update failed.'
      })
    } else {
      cb({
        success: true,
        message: 'Update successful.'
      })
    }
  })
}

connectordashboardserver.updateStereovision = function (fieldlist, deviceId, cb) {
  var deviceId = deviceId
  var data = fieldlist
  var post = [data, deviceId]
  var stereovisionUpdateSql = queries.stereovisionupdatequery
  db.executeUpdate(stereovisionUpdateSql, post, function (err, result) {
    if (err) {
      console.log('error while performing update on Stereovision table.', err)
      cb({
        success: false,
        message: 'Update failed.'
      })
    } else {
      cb({
        success: true,
        message: 'Update successful.'
      })
    }
  })
}

connectordashboardserver.updateProduct = function (fieldlist, deviceId, cb) {
  var deviceId = deviceId
  var data = fieldlist
  var post = [data, deviceId]
  var productUpdateSql = queries.productupdatequery
  db.executeUpdate(productUpdateSql, post, function (err, result) {
    if (err) {
      console.log('error while performing update on product table.', err)
      cb({
        success: false,
        message: 'Update failed.'
      })
    } else {
      cb({
        success: true,
        message: 'Update successful.'
      })
    }
  })
}

connectordashboardserver.updateUser = function (fieldlist, id, cb) {
  var id = id
  var data = fieldlist
  var userUpdateSql = queries.userupdatequery
  var decodedPwd = base64.decode(data.password)
  var hash = bcrypt.hashSync(decodedPwd, config.saltLength)
  data.password = hash
  var post = [data, id]
  db.executeUpdate(userUpdateSql, post, function (err, result) {
    if (err) {
      console.log('error while performing update on user table.', err)
      cb({
        success: false,
        message: 'Update failed.'
      })
    } else {
      cb({
        success: true,
        message: 'Update successful.'
      })
    }
  })
}

connectordashboardserver.updateDoorLocation = function (fieldlist, deviceId, user, cb) {
  var campusId = fieldlist.campusId
  var buildingId = fieldlist.buildingId
  var entranceId = fieldlist.entranceId
  var subentranceId = fieldlist.subEntranceId

  if (subentranceId === -1) {
    if (entranceId === -1) {
      if (buildingId === -1) {
        if (campusId === -1) {
          db.executeInsert(queries.addcampusquery, [{
            campusName: fieldlist.campusName,
            companyId: 1,
            countryid: 1
          }], function (err, result) {
            if (err) {
              console.log('error while performing insert in campus table', err)
              cb({
                success: false,
                message: 'Create campus failed.'
              })
            } else {
              fieldlist.campusId = result.insertId
              connectordashboardserver.updateDoorLocation(fieldlist, deviceId, user, function (result) {
                cb(result)
              })
            }
          })
        } else { // campusId already known
          db.executeInsert(queries.addbuildingquery, [{
            buildingName: fieldlist.buildingName,
          campusId}], function (err, result) {
            if (err) {
              console.log('error while performing insert in building table', err)
              cb({
                success: false,
                message: 'Create building failed.'
              })
            } else {
              fieldlist.buildingId = result.insertId
              connectordashboardserver.updateDoorLocation(fieldlist, deviceId, user, function (result) {
                cb(result)
              })
            }
          })
        }
      } else { // buildingId already known
        db.executeInsert(queries.addentrancequery, [{
          entranceName: fieldlist.entranceName,
        buildingId}], function (err, result) {
          if (err) {
            console.log('error while performing insert in entrance table', err)
            cb({
              success: false,
              message: 'Create entrance failed.'
            })
          } else {
            fieldlist.entranceId = result.insertId
            connectordashboardserver.updateDoorLocation(fieldlist, deviceId, user, function (result) {
              cb(result)
            })
          }
        })
      }
    } else { // entranceId already known
      db.executeInsert(queries.addsubentrancequery, [{
        subentranceName: fieldlist.subEntranceName,
      entranceId}], function (err, result) {
        if (err) {
          console.log('error while performing insert in subentrance table', err)
          cb({
            success: false,
            message: 'Create subentrance failed.'
          })
        } else {
          fieldlist.subEntranceId = result.insertId
          connectordashboardserver.updateDoorLocation(fieldlist, deviceId, user, function (result) {
            cb(result)
          })
        }
      })
    }
  } else { // all id's known

    connectordashboardserver.setLastUpdater(user, deviceId, function (cb1) {
      if (cb1.success === false) {
        console.log("error updating basetable 'product'.")
        cb({
          success: false,
          message: 'Update failed.'
        })
      } else {
        connectordashboardserver.updateProduct(fieldlist, deviceId, function (results) {
          connectordashboardserver.setLastUpdater(null, deviceId, function (cb2) {
            if (cb2.success === true) {
              console.log("lastupdatedby cleared in 'product'")
            }
          })
          cb({
            success: true,
            message: 'Update successful.'
          })
        })
      }
    })
  }
}

/* internal implementation of posters */

connectordashboardserver.createUser = function (fieldlist, cb) {
  console.log('### Create User ###')
  console.log(fieldlist)
  var post = fieldlist

  console.log(post)
  var userinsertSql = queries.userinsertquery
  console.log('## Insert query ', userinsertSql)
  var decodedPwd = base64.decode(post.password)
  var hash = bcrypt.hashSync(decodedPwd, config.saltLength)
  post.password = hash
  db.executeInsert(userinsertSql, post, function (err, result) {
    if (err) {
      console.log('error while performing create on user table.', err)
      cb({
        success: false,
        message: 'Create user failed.'
      })
    } else {
      cb({
        success: true,
        message: 'Create successful.'
      })
    }
  })
}

connectordashboardserver.updateLevels = function (fieldList) {
  console.log('if')
  fieldList['level5'] = 1
  fieldList['level6'] = 1
  fieldList['level7'] = 1
  fieldList['level8'] = 1
  return fieldList
}

/* internal implementation of delete */
connectordashboardserver.deleteUser = function (id, cb) {
  var id = id
  var userdeleteSQL = queries.userdeletequery
  var post = [id]
  db.executeDelete(userdeleteSQL, post, function (err, result) {
    if (err) {
      console.log('error while performing delete on user table.', err)
      cb({
        success: false,
        message: 'Delete user failed.'
      })
    } else {
      cb({
        success: true,
        message: 'Delete successful.'
      })
    }
  })
}

/* internal implementation of special functions */

connectordashboardserver.doValidateUser = function (post, cb) {
  auth.doLogin(post, function (isValid) {
    cb(isValid)
  })
}

function tokenVerification (req, res, next) {
  var token = req.query.token || req.headers['x-access-token']

  // decode token
  if (token) {
    // verifies secret and checks exp
    jwt.verify(token, config.tokenSecret, function (err, decoded) {
      if (err) {
        console.log(err)
        if (err.name === 'TokenExpiredError') {
          res.set('Token-Expired', true)
          res.set('Access-Control-Expose-Headers', 'Token-Expired')
          return res.status(403).send({
            success: false,
            message: 'Token expired.'
          })
        } else {
          res.set('Access-Control-Expose-Headers', 'Invalid-Token')
          res.set('Invalid-Token', true)
          return res.status(403).send({
            success: false,
            message: 'Invalid token.'
          })
        }
      } else {
        var refreshedToken = jwt.sign({
          user: decoded.user
        }, config.tokenSecret, {
          expiresIn: config.tokenExpiryTime
        })
        res.set('Refreshed-Token', refreshedToken)
        res.set('Access-Control-Expose-Headers', 'Refreshed-Token')
        req.user = decoded.user
        next()
      }
    })
  } else {

    // if there is no token
    // return an error
    res.set('No-Token-Provided', true)
    res.set('Access-Control-Expose-Headers', 'No-Token-Provided')
    return res.status(403).send({
      success: false,
      message: 'No token provided.'
    })
  }
}
connectordashboardserver.setLastUpdater = function (username, deviceId, callback) {
  var fieldlist = {
    'lastupdateby': username
  }
  console.log('username: ', username)
  console.log('fieldlist: ', fieldlist)
  connectordashboardserver.updateProduct(fieldlist, deviceId, function (cb) {
    callback(cb)
  })
}
