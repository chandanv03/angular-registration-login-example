define([
    'angular',
    'ngResource'
], function(angular) {
    'use strict'

    return angular.module('app.resources.admin', ['ngResource'])
        .service('adminList', function($resource, CONFIG, TokenService) {

            return {
                getUsers: function(token) {
                    return $resource(CONFIG.url + 'admin/listusers', {}, {
                        get: {
                            method: 'GET',
                            isArray: false,
                            headers: {
                                'x-access-token': token
                            },
                            transformResponse: function(data, headers) {
                                //Check the response header for token expiry and new token.
                                var headers = headers()
                                TokenService.setResponseHeader(headers)
                                return angular.fromJson(data)
                            }
                        }
                    })
                },
                deleteUser: function(token) {
                    return $resource(CONFIG.url + 'admin/deleteuser', {
                        id: '@id'
                    }, {
                        delete: {
                            method: 'DELETE',
                            headers: {
                                'x-access-token': token
                            },
                            transformResponse: function(data, headers) {
                                //Check the response header for token expiry and new token.
                                var headers = headers()
                                TokenService.setResponseHeader(headers)
                                return angular.fromJson(data)
                            }
                        }
                    })
                }
            }
        })
})
