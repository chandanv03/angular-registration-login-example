module.exports = function (config) {
    config.set({

        files: [
      'tests-main.js',
            {
                pattern: 'app/js/**/*.js',
                included: false
            },
      //{ pattern: 'app/js/**/*.coffee', included: false },
      //{ pattern: 'app/js/**/*.map', included: false },
            {
                pattern: 'app/vendor/**/*.js',
                included: false
            },
      //{ pattern: 'app/vendor/**/*.map', included: false },
    ],
        exclude: [
      'app/vendor/**/*spec.js',
      'app/vendor/**/*spec.coffee'
    ],

        browsers: ['PhantomJS'],
        // Chrome, ChromeCanary, Firefox, IE (only Windows), Opera, PhantomJS, Safari (only Mac)

        reporters: [
      'progress',
      'coverage',
    ],
        preprocessors: {
            'app/js/modules/**/!(*spec|history|requirejs-config|common).js': 'coverage',
            //'app/js/modules/**/*.spec.coffee': 'coffee'
        },
        // coffeePreprocessor: {
        //   options: { sourceMap: true },
        //   transformPath: function (filepath) {
        //     return filepath.replace(/spec\.coffee$/, 'coffee.spec.js');
        //   }
        // },
        // Optionally, configure the reporter:
        //
        coverageReporter: {
            type: 'html',
            dir: 'test/',
        },
        htmlReporter: {
            outputDir: 'test/unit/tests', // where to put the reports

            focusOnFailures: true, // reports show failures on start
            namedFiles: false, // name files instead of creating sub-directories
            pageTitle: 'Karma unit test report', // page title for reports; browser info by default
            urlFriendlyName: false // simply replaces spaces with _ for files/dirs
        },

        basePath: './',
        captureTimeout: 60000,
        colors: true,
        frameworks: ['jasmine', 'requirejs'],
        logLevel: config.LOG_INFO,
        port: 9876,
        reportSlowerThan: 500,
        runnerPort: 9100,
        singleRun: false,
        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: true
    });
};
