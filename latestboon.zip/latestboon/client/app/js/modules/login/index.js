/**
 * Loader, contains list of Login module components
 */
define([
  './authService',
  './encodeService',
  './loginController'
], function () {})
