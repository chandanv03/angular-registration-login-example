// this file will handle the logon request.
// it is a seperate file because in the future it will be a pretty large function.
var config = require('./config.js')
var db = require('./database.js')
var base64 = require('./base64.js')
var ipBlockHandler = require("./ipblockhandler.js")
var jwt = require('jsonwebtoken')
var bcrypt = require('bcryptjs')
var queries = require('./sqlqueries.js')

function doLogin(post, cb) {
    //check if IP is blocked
    var currentTimestamp = (new Date).getTime()
    if (ipBlockHandler.isIpBlocked(currentTimestamp, post.clientIp) &&
        !ipBlockHandler.shouldActivateNow(currentTimestamp, post.clientIp)) {
        cb({
            success: false,
            message: 'IP is temporarily blocked.'
        })
    } else {
        if (ipBlockHandler.isIpBlocked(currentTimestamp, post.clientIp)) {
            if (ipBlockHandler.shouldActivateNow(currentTimestamp, post.clientIp)) {
                ipBlockHandler.activate(post.clientIp)
            }
        }
        var invalidAttempt = false
        var query = queries.usernamebasedquery
        db.executeSelect(query, post.user, function(err, rows, columns) {
            if (err || rows.length === 0 || rows.length > 1) {
                console.log('An error occured, or the user does not exist.')
                invalidAttempt = true

            } else {
                console.log(rows)

                var decodedPwd = base64.decode(post.passwd)
                if (!bcrypt.compareSync(decodedPwd, rows[0].password)) {
                    console.log('The password is incorrect.')
                    invalidAttempt = true
                } else {
                    // if user is found and password is right
                    // create a token
                    var token = jwt.sign({
                        user: post.user
                    }, config.tokenSecret, {
                        expiresIn: config.tokenExpiryTime // expires in 10 minutes
                    })
                    ipBlockHandler.pushAttempt(currentTimestamp, post.clientIp, true)
                    var admin = false
                    if (rows[0].level9 == 1) {
                        admin = true
                    }
                    // return the information including token as JSON
                    cb({
                        success: true,
                        token: token,
                        admin: admin,
                        level1: rows[0].level1 == 1?true:false,
                        level2: rows[0].level2 == 1?true:false,
                        level3: rows[0].level3 == 1?true:false,
                        level4: rows[0].level4 == 1?true:false,
                        level5: rows[0].level5 == 1?true:false,
                        level6: rows[0].level6 == 1?true:false,
                        level7: rows[0].level7 == 1?true:false,
                        level8: rows[0].level8 == 1?true:false,
                        level9: rows[0].level9 == 1?true:false,
                        level10: rows[0].level10 == 1?true:false
                    })
                }
            }

            if (invalidAttempt) {
                ipBlockHandler.pushAttempt(currentTimestamp, post.clientIp, false)
                var invalidAttemptNo = ipBlockHandler.invalidAtempts(post.clientIp)
                if (ipBlockHandler.shouldBlockNow(post.clientIp)) {
                    ipBlockHandler.blockIp(currentTimestamp, post.clientIp)
                    cb({
                        success: false,
                        message: 'Reached maximum invalid attempts, IP is getting temporarily blocked for '+  config.iPBlockingTime +' mins.'
                    })
                } else {
                    cb({
                        success: false,
                        invalidAttemptNo: invalidAttemptNo,
                        message: 'After ' + (config.invalidAttempts - invalidAttemptNo) + ' more invalid attempt(s), IP will get temporarily blocked for '+  config.iPBlockingTime +' mins.'

                    })
                }

            }
        })

    }

}

exports.doLogin = doLogin
