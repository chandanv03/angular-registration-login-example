/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
 define([
  'angular-mocks',
  'Source/modules/resources/transactioncount',
  'Source/modules/common/tokenSetter',
  'Source/config'
  ], function(){

   describe('TransactionCount', function () {
  	var mockTransactionCount, $httpBackend, url, token;

	  	beforeEach(angular.mock.module('app.resources.transactioncount'));

	  	beforeEach(module('ui.router'));

	  	beforeEach(angular.mock.module('app.common.token'));

	  	beforeEach(angular.mock.module('app.constants', function ($provide) {
	    $provide.constant('CONFIG',{
	      url: 'http://localhost:3000/'
	    });


		}))

	  	var state;
	  	beforeEach(angular.mock.inject(function (TransactionCount, _$httpBackend_, CONFIG, $state, TokenService) {
	  		url = CONFIG.url;
	  		$httpBackend = _$httpBackend_;
	        mockTransactionCount = TransactionCount;
	        state = $state;
          token= TokenService.getToken();
		}))

	  	it('should test if resource is defined', function(){
	  		expect(mockTransactionCount).toBeDefined();
	  	})

	  	it('should test if resource is defined', function(){
	  		expect(mockTransactionCount.getTransactionCount).toBeDefined();
	  	})

      it('should test the URL', function(){
        $httpBackend.expect('GET', url + 'doors/transactiontime?id=10&type=1&path=v1').respond(200, [1,2]);
        mockTransactionCount.getTransactionCount(token).query({
            path: 'v1'
        },{id: 10, type:1});
        $httpBackend.flush();
      })
   })

 })
