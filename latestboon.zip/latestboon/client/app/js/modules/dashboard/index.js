/**
 * Loader, contains list of Dashboard module components
 */
define([
  './dashboardTreeviewService',
  './treeviewDirective',
  './dashboardController',
  './graphService',
  './snoozeService'
], function () {})
