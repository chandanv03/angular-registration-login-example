/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
 define([
  'angular-mocks',
  'Source/modules/resources/changeLog',
  'Source/modules/common/tokenSetter',
  'Source/config'
  ], function(){

   describe('ChangeLog', function () {
  	var mockChangeLog, $httpBackend, url, token;

	  	beforeEach(angular.mock.module('app.resources.changeLog'));

	  	beforeEach(module('ui.router'));

	  	beforeEach(angular.mock.module('app.common.token'));

	  	beforeEach(angular.mock.module('app.constants', function ($provide) {
	    $provide.constant('CONFIG',{
	      url: 'http://nlboed01.sgti.nl:3000/'
	    });


		}))

	  	var state;
	  	beforeEach(angular.mock.inject(function (ChangeLog, _$httpBackend_, CONFIG, $state, TokenService,  _$http_) {
	  		url = CONFIG.url;
	  		$httpBackend = _$httpBackend_;
	        mockChangeLog = ChangeLog;
	        state = $state;
            $http = _$http_;
            token = TokenService.getToken();
		}))

	  	it('should test if resource is defined', function(){
	  		expect(mockChangeLog).toBeDefined();
	  	})

	  	it('should test if resource is defined', function(){
	  		expect(mockChangeLog.getChangeLog).toBeDefined();
	  	})

      it('should test the URL', function(){
        $httpBackend.expect('GET', url + 'doors/changelog?id=10').respond(200, {result:'success'});
        mockChangeLog.getChangeLog(token).get({id:10});
        $httpBackend.flush();
      })

   })

 })
