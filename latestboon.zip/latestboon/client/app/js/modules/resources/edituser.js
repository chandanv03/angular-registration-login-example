define([
    'angular',
    'ngResource'
], function(angular) {
    'use strict'

    return angular.module('app.resources.edituser', ['ngResource'])
        .service('editUser', function($resource, CONFIG, TokenService) {
            return {
                getUsersById: function(token) {

                    return $resource(CONFIG.url + 'admin/getuser', {
                        id: '@id'
                    }, {
                        get: {
                            method: 'GET',
                            isArray: false,
                            headers: {
                                'x-access-token': token
                            },
                            transformResponse: function(data, headers) {
                                //Check the response header for token expiry and new token.
                                var headers = headers()
                                TokenService.setResponseHeader(headers)
                                return angular.fromJson(data)
                            }
                        }
                    })
                },
                addUser: function(token) {

                    return $resource(CONFIG.url + 'admin/adduser', {}, {
                        save: {
                            method: 'POST',
                            headers: {
                                'x-access-token': token
                            },
                            transformResponse: function(data, headers) {
                                //Check the response header for token expiry and new token.
                                var headers = headers()
                                TokenService.setResponseHeader(headers)
                                return angular.fromJson(data)
                            }
                        }
                    })
                },
                updateUserById: function(token) {

                    return $resource(CONFIG.url + 'admin/changeuser', {
                        id: '@id'
                    }, {
                        update: {
                            method: 'PUT',
                            headers: {
                                'x-access-token': token
                            },
                            transformResponse: function(data, headers) {
                                //Check the response header for token expiry and new token.
                                var headers = headers()
                                TokenService.setResponseHeader(headers)
                                return angular.fromJson(data)
                            }
                        }
                    })
                }
            }
        })
})
