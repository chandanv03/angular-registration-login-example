/**
 * user controller definition
 */
define(['./module'], function(module) {
    module.controller('userController', function($scope, CONFIG, $window, $state, $timeout, $stateParams, $location, userService, LocationsService) {

        /*Fetch username from session*/
        var userName = JSON.parse($window.sessionStorage.getItem('userInfo')).userName

        /*check if user logged in*/
        if (userName == '' || userName == null) {
            $state.go('login')
        }


        $scope.user = {
            "username": "",
            "password": "",
            "usertype": "admin",
            "country": "",
            "campus": "",
            "building": "",
            "entrance": "",
            "company_id": "",
            "enabled": "1",
            "registrationdatetime": "",
            "id": ""
        }
        $scope.countries = []
        $scope.companies = []
        $scope.campuses = []
        $scope.buildings = []
        $scope.entrances = []
        $scope.countryId = null
        $scope.companyId = null
        $scope.campusId = null
        $scope.buildingId = null
        $scope.entranceId = null

        $scope.getLocations = function() {
            LocationsService.getLocations().then(function(results) {

                $scope.companies = []
                $scope.countries = []
                $scope.campuses = []
                $scope.buildings = []
                $scope.entrances = []
                $scope.countryId = null
                $scope.companyId = null
                $scope.campusId = null
                $scope.buildingId = null
                $scope.entranceId = null
                if (results.companies != null) {
                    $scope.companies = results.companies
                    $scope.companySelected()
                }

            })
        }
        $scope.getLocations()
        $scope.companySelected = function() {
            $scope.buildings = []
            $scope.entrances = []
            $scope.companyId = null
            $scope.campusId = null
            $scope.buildingId = null
            $scope.entranceId = null
            for (var i = 0; i < $scope.companies.length; i++) {
                $scope.countries = $scope.companies[i].children
                break
            }
        }


        $scope.countrySelected = function() {
            $scope.campuses = []
            $scope.buildings = []
            $scope.entrances = []
            $scope.campusId = null
            $scope.buildingId = null
            $scope.entranceId = null

            for (var i = 0; i < $scope.countries.length; i++) {
                if ($scope.countries[i].countryId == $scope.countryId) {
                    $scope.campuses = $scope.countries[i].children
                    break
                }
            }


            for (var i = 0; i < $scope.campuses.length; i++) {
                if ($scope.campuses[i].campusName == 'notassigned~') {
                    $scope.campuses.splice(i, 1)
                }
                if ($scope.campuses[i].campusName == null) {
                    $scope.campuses.splice(i, 1)
                }
            }
        }

        $scope.campusSelected = function() {
            $scope.buildings = []
            $scope.entrances = []
            $scope.buildingId = null
            $scope.entranceId = null
            for (var i = 0; i < $scope.campuses.length; i++) {
                if ($scope.campuses[i].campusId == $scope.campusId) {
                    $scope.buildings = $scope.campuses[i].children
                    break
                }
            }
        }
        $scope.buildingSelected = function() {
                $scope.entranceId = null
                $scope.entrances = []
                for (var i = 0; i < $scope.buildings.length; i++) {
                    if ($scope.buildings[i].buildingId == $scope.buildingId) {
                        $scope.entrances = $scope.buildings[i].children
                        break
                    }
                }
            }
            /*setting default password*/
        $scope.setDefault = function() {
            $scope.user.password = "12345"
        }



        /*check if username is already exists*/
        $scope.checkUsername = function() {

            var allUsers = JSON.parse($window.sessionStorage.getItem('usernamelist'))
            var currentUser = $scope.user.username

            angular.forEach(allUsers, function(value, key) {
                if (value.username === currentUser) {
                    $scope.user.username = ""
                    $scope.errorMessage = "Username Already exists."
                    $timeout(function() {
                        $scope.errorMessage = false
                    }, CONFIG.LONG_VISUAL_DELAY)
                }
            })
        }

        /*function to get users by id */
        $scope.getUserById = function(id) {

            userService.getUsersById(id).then(function(res) {
                    // if response is not null then show saved data to user edit
                    if (res != null) {
                        angular.forEach(res, function(value, key) {
                            if (value.id == id) {
                                var utype = ''
                                if (value.level2 == null && value.level5 == null && value.level6 == null && value.level7 == null && value.level9 == 1 && value.level10 == null) {
                                    utype = "admin"

                                } else if (value.level2 == 1 && value.level5 == 1 && value.level6 == 1 && value.level7 == 1 && value.level9 == null && value.level10 == 1) {
                                    utype = "servicemgr"
                                } else if (value.level2 == 1 && value.level5 == 1 && value.level6 == null && value.level7 == 1 && value.level9 == null && value.level10 == 1) {
                                    utype = "cust"
                                } else if (value.level2 == 1 && value.level5 == 1 && value.level6 == null && value.level7 == null && value.level9 == null && value.level10 == null) {
                                    utype = "sectionmgr"
                                }
                                if (value.level2 == null && value.level5 == null && value.level6 == null && value.level7 == null && value.level9 == null && value.level10 == null) {
                                    utype = "securitymgr"
                                }


                                $scope.user = {
                                    "username": value.username,
                                    "password": "",
                                    "usertype": utype,
                                    "country": value.country,
                                    "campus": value.campus,
                                    "building": value.building,
                                    "entrance": value.entrance,
                                    "company_id": value.company_ID,
                                    "enabled": value.enabled,
                                    "registrationdatetime": value.registrationdatetime,
                                    "id": value.id
                                }


                                LocationsService.getLocations().then(function(results) {
                                    $scope.countries = []
                                    $scope.companies = []
                                    $scope.campuses = []
                                    $scope.buildings = []
                                    $scope.entrances = []
                                    $scope.countryId = null
                                    $scope.companyId = null
                                    $scope.campusId = null
                                    $scope.buildingId = null
                                    $scope.entranceId = null
                                    if (results.companies != null) {
                                        $scope.companies = results.companies


                                            for (var i = 0; i < $scope.companies.length; i++) {
                                                $scope.countries = $scope.companies[i].children
                                            }
                                        for (var i = 0; i < $scope.countries.length; i++) {

                                            if ($scope.countries[i].countryId == $scope.user.country) {
                                                $scope.countryId = $scope.countries[i].countryId
                                                $scope.campuses = $scope.countries[i].children
                                                break
                                            }
                                        }
                                    }
                                    for (var i = 0; i < $scope.campuses.length; i++) {
                                        if ($scope.campuses[i].campusName == 'notassigned~') {
                                            $scope.campuses.splice(i, 1)
                                        }
                                        if ($scope.campuses[i].campusName == null) {
                                            $scope.campuses.splice(i, 1)
                                        }
                                    }

                                    if ($scope.user.campus != null) {
                                        for (var i = 0; i < $scope.campuses.length; i++) {
                                            if ($scope.campuses[i].campusId == $scope.user.campus) {
                                                $scope.campusId = $scope.campuses[i].campusId
                                                $scope.buildings = $scope.campuses[i].children
                                                break
                                            }
                                        }
                                    }
                                    if ($scope.user.building != null) {
                                        for (var i = 0; i < $scope.buildings.length; i++) {
                                            if ($scope.buildings[i].buildingId == $scope.user.building) {
                                                $scope.buildingId = $scope.buildings[i].buildingId
                                                $scope.entrances = $scope.buildings[i].children
                                                break
                                            }
                                        }
                                    }

                                    if ($scope.user.entrance != null) {
                                        for (var i = 0; i < $scope.entrances.length; i++) {
                                            if ($scope.entrances[i].entranceId == $scope.user.entrance) {
                                                $scope.entranceId = $scope.entrances[i].entranceId
                                                break
                                            }
                                        }
                                    }
                                    //} end of $scope.user.company_id

                                })

                            }
                        })
                    }
                },
                function(error) {
                    // Manage error page
                    $scope.errorMessage = 'No Users Found. Redirecting to admin..'
                    $timeout(function() {
                        $state.go('admin')
                    }, CONFIG.LONG_VISUAL_DELAY)

                })
        }

        /*loading user data by id*/
        if ($stateParams.id != null) {
            $scope.getUserById($stateParams.id)
        }

        /*Function to save user data*/
        $scope.saveuser = function() {


            var level2 = null
            var level5 = null
            var level6 = null
            var level7 = null
            var level9 = null
            var level10 = null
            if ($scope.user.usertype == 'servicemgr') {
                level2 = 1
                level5 = 1
                level6 = 1
                level7 = 1
                level10 = 1
            }
            if ($scope.user.usertype == 'sectionmgr') {
                level2 = 1
                level5 = 1
            }
            if ($scope.user.usertype == 'cust') {
                level2 = 1
                level5 = 1
                level7 = 1
                level10 = 1
            }
            if ($scope.user.usertype == 'admin') {
                level9 = 1
            }
            if ($scope.user.usertype == 'securitymgr') {
                var userDetails = {
                    "username": $scope.user.username,
                    "password": $scope.user.password,
                    "country": $scope.countryId,
                    "campus": $scope.campusId,
                    "building": $scope.buildingId,
                    "entrance": $scope.entranceId,
                    "enabled": $scope.user.enabled
                }
            } else {

                var userDetails = {
                    "username": $scope.user.username,
                    "password": $scope.user.password,
                    "level2": level2,
                    "level5": level5,
                    "level6": level6,
                    "level7": level7,
                    "level9": level9,
                    "level10": level10,
                    "country": $scope.countryId,
                    "campus": $scope.campusId,
                    "building": $scope.buildingId,
                    "entrance": $scope.entranceId,
                    "enabled": $scope.user.enabled
                }
            }



            /*check if user id is available or not*/
            if ($scope.user.id == '') {
                userService.addUser(userDetails).then(function(res) {
                    if (res === true) {
                        $scope.successMessage = "User created successfully."
                        $timeout(function() {
                            $scope.successMessage = false
                            $scope.errorMessage = ""
                            $scope.user = {}
                            $location.path('admin')
                        }, CONFIG.SHORT_VISUAL_DELAY)
                    }
                }, function(err) {
                    $scope.errorMessage = "ERROR : User cann't be saved."
                })
            } else {
                //add user id to update data based on user id
                userDetails.id = $scope.user.id

                userService.updateUserById(userDetails).then(function(res) {
                    if (res === true) {
                        $scope.successMessage = "User Updated."
                        $timeout(function() {
                            $scope.successMessage = false
                            $scope.errorMessage = ""
                            $scope.user = {}
                            $location.path('admin')
                        }, CONFIG.SHORT_VISUAL_DELAY)
                    }
                }, function(err) {
                    $scope.errorMessage = "ERROR : User cann't be updated."
                })
            }
        }
    })
})
