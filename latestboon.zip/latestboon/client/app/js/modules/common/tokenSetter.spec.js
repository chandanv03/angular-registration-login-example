/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */

 'use strict';

  define([
  'angular-mocks',
  'Source/modules/common/tokenSetter'
  ], function(){

  	describe('TokenService', function () {
  		var q, mockTokenService, state, deferred; 

  		beforeEach(angular.mock.module('app.common.token'));

  		beforeEach(module('ui.router'));

		beforeEach(angular.mock.inject(function(TokenService){
	      mockTokenService = TokenService

		})) 

		it('should exist', function(){
       		expect(mockTokenService).toBeDefined()
		})

		it('should check if setResponseHeader defined ', function(){
       		expect(mockTokenService.setResponseHeader).toBeDefined()
		})

		it('should check if logoutUser defined ', function(){
       		expect(mockTokenService.logoutUser).toBeDefined()
		})

		it('should check if getToken defined ', function(){
       		expect(mockTokenService.getToken).toBeDefined()
		})

		it('should check if setToken defined ', function(){
       		expect(mockTokenService.setToken).toBeDefined()
		})				     
  	})
  })	