var mysql = require('mysql')
var config = require('./config.js')

function getConnection () {
  var connection = mysql.createConnection(
    {
      host: config.databaseIP,
      user: config.dbUser,
      password: config.dbPasswd,
      database: config.developmentDb
    }
    )
  return connection
}

// general functions section. Here the functions that are easily reusable for different queries are stored

// function to execute a select query.
// @input         sqlQuery      the query to be executed with '?' for all values
// @input         post          the data to populate the query with
// @input/output  cb            the callback function used to transport the data back to the calling function
// @return        cb            the data for the callback function
function executeSelect (sqlQuery, post, cb) {
  if (post == null || Object.keys(post).length === 0) {
    cb({Error: 'Cannot execute query without searchvalue(s)',
    errno: '0001'}, null) // end of callback
  } else {
    var con = getConnection()
    var query = con.query(sqlQuery, post,
    function (err, rows, fields) {
      if (err) {
        console.log('error while performing select query.', query.sql,
                    ', error: ', err)
      }
      con.end()
      cb(err, rows)
    })// end of callback
  }
}

// function to execute an insert query.
// @input         sqlQuery      the query to be executed with '?' for all values
// @input         post          the data to populate the query with
// @input/output  cb            the callback function used to transport the data back to the calling function
// @return        cb            the data for the callback function
function executeInsert (sqlQuery, post, cb) {
  if (post == null || Object.keys(post).length === 0) {
    cb({Error: 'Cannot execute query without searchvalue(s)',
      errno: '0001'}, null)// end of callback
  } else {
    var con = getConnection()
    var query = con.query(sqlQuery, post,
    function (err, result) {
      if (err) {
        console.log('error while performing insert into the database.', query.sql)
      }
      con.end()
      cb(err, result)
    })
  }
}

// function to execute an update query.
// @input         sqlQuery      the query to be executed with '?' for all values
// @input         post          the data to populate the query with
// @input/output  cb            the callback function used to transport the data back to the calling function
// @return        cb            the data for the callback function
function executeUpdate (sqlQuery, post, cb) {
  if (post.data === null || post.deviceId === null) {
    cb({Error: 'Cannot execute query without searchvalue(s) and update data',
        errno: '0001'}, null)
  } else {
    var con = getConnection()
    var query = con.query(sqlQuery, post,
    function (err, result) {
      if (err) {
        console.log('error while performing query.:', query.sql)
      }
      con.end()
      cb(err, result)
    })
  }  // end of else
}

// function to execute an delete query.
// @input         sqlQuery      the query to be executed with '?' for all values
// @input         post          the data to populate the query with
// @input/output  cb            the callback function used to transport the data back to the calling function
// @return        cb            the data for the callback function
function executeDelete (sqlQuery, post, cb) {
  if (post == null || Object.keys(post).length === 0) {
    cb({Error: 'Cannot execute query without searchvalue(s) and delete data',
      errno: '0001'}, null)// end of callback
  } else {
    var con = getConnection()
    var query = con.query(sqlQuery, post,
    function (err, result) {
      if (err) {
        console.log('error while performing delete.', query.sql)
      }
      con.end()
      cb(err, result)
    })
  }
}


// initialization functions
exports.getConnection = getConnection

// general functions
exports.executeInsert = executeInsert
exports.executeSelect = executeSelect
exports.executeUpdate = executeUpdate
exports.executeDelete = executeDelete
// specific functions
