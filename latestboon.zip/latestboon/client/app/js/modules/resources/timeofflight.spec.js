/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
 define([
  'angular-mocks',
  'Source/modules/resources/timeofflight',
  'Source/modules/common/tokenSetter',
  'Source/config'
  ], function(){

   describe('TransactionCount', function () {
  	var mockTimeOfFlight, $httpBackend, url, token;

	  	beforeEach(angular.mock.module('app.resources.timeofflight'));

	  	beforeEach(module('ui.router'));

	  	beforeEach(angular.mock.module('app.common.token'));

	  	beforeEach(angular.mock.module('app.constants', function ($provide) {
	    $provide.constant('CONFIG',{
	      url: 'http://nlboed01.sgti.nl:3000/'
	    });


		}))

	  	var state;
	  	beforeEach(angular.mock.inject(function (TimeOfFlight, _$httpBackend_, CONFIG, $state, TokenService) {
	  		url = CONFIG.url;
	  		$httpBackend = _$httpBackend_;
	        mockTimeOfFlight = TimeOfFlight;
	        state = $state;
          token = TokenService.getToken();
		}))

	  	it('should test if resource is defined', function(){
	  		expect(mockTimeOfFlight).toBeDefined();
	  	})

	  	it('should test if resource is defined', function(){
	  		expect(mockTimeOfFlight.updateTOF).toBeDefined();
	  	})

      it('should test the URL', function(){
        var payload = {
            deviceId: 10
        }
        var tofArray= [];
        $httpBackend.expect('PUT', url + 'doors/stereovision?deviceId=10').respond(200, {result:'success'});
        mockTimeOfFlight.updateTOF(token).update(payload, tofArray);
        $httpBackend.flush();
      })
   })

 })
