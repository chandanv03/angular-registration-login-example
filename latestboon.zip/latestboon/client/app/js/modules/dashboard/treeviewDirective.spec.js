 'use strict';

  define([
  'angular-mocks',
  'Source/modules/dashboard/treeviewDirective'
  ], function(){

  	describe('treeviewDirective', function(){

		var compile, scope, directiveElem, controller;

  		beforeEach(angular.mock.module('app.dashboard'));

  		beforeEach(angular.mock.inject(function($compile, $rootScope){
  			compile = $compile;
  			scope = $rootScope.$new();
		}));


  		function getCompiledElement(temp){
  			var element = angular.element(temp);
  			var compiledElement = compile(element)(scope);
  			scope.$digest();
  			controller = compiledElement.controller('treeView');
  			var mockData ={
  "campuses": [
    {
      "campusId": "boonCampus",
      "campusName": "boonCampus",
      "children": [
        {
          "buildingId": "boonBuilding",
          "buildingName": null,
          "children": [
            {
              "entranceId": "boonEntrance",
              "entranceName": "boonEntrance",
              "children": [
                {
                  "subentranceId": "boonsub",
                  "subentranceName": "subEntranceT",
                  "doors": [
                    {
                      "id": 1,
                      "name": "Red door",
                      "nodeid": "+n+o8BvGI2e1UHlmoIa7s1l6m2c=",
                      "deviceID": "100",
                      "ip_number": "192.168.1.56",
                      "mac_address": "12:23:32:12:12:12",
                      "time_first_seen": 1448887937,
                      "time_last_seen": 1466518405,
                      "location": "Main building",
                      "product_type": "Tourlock",
                      "last_state": "OK",
                      "ce_number": "",
                      "hostname": "",
                      "latitude": "",
                      "longitude": "",
                      "timeZone": null,
                      "flag": 0,
                      "assigned": 1,
                      "doorstatus": 0
                    },
                    {
                      "id": 2,
                      "name": "Green door",
                      "nodeid": "FFDkfXfR0FeDivRvupdHg1znDDY=",
                      "deviceID": "101",
                      "ip_number": "192.168.1.22",
                      "mac_address": "12:23:32:12:12:34",
                      "time_first_seen": 1448887930,
                      "time_last_seen": 1466518405,
                      "location": "Main building",
                      "product_type": "Tourlock",
                      "last_state": "OK",
                      "ce_number": "",
                      "hostname": "",
                      "latitude": "",
                      "longitude": "",
                      "timeZone": null,
                      "flag": 0,
                      "assigned": 1,
                      "doorstatus": 0
                    },
                    {
                      "id": 3,
                      "name": "Yellow Door",
                      "nodeid": "23",
                      "deviceID": "102",
                      "ip_number": "192.169.0.12",
                      "mac_address": "12:12:33:34:33:34",
                      "time_first_seen": 1449479403,
                      "time_last_seen": 1467183890,
                      "location": "Main",
                      "product_type": "Cicle",
                      "last_state": "OK",
                      "ce_number": "",
                      "hostname": "",
                      "latitude": "",
                      "longitude": "",
                      "timeZone": null,
                      "flag": 0,
                      "assigned": 1,
                      "doorstatus": 1
                    },
                    {
                      "id": 4,
                      "name": "Bylorus RnD",
                      "nodeid": "uJjwO/cHKLEAN796FhFCkuEeKwU=",
                      "deviceID": "2",
                      "ip_number": "192.168.1.145",
                      "mac_address": "b8:ac:6f:2a:84:49",
                      "time_first_seen": 1454410367,
                      "time_last_seen": 1466518405,
                      "location": "Aambeeldstraat ",
                      "product_type": "Bylorus",
                      "last_state": "OK",
                      "ce_number": "",
                      "hostname": "",
                      "latitude": "",
                      "longitude": "",
                      "timeZone": null,
                      "flag": 0,
                      "assigned": 1,
                      "doorstatus": 0
                    },
                    {
                      "id": 6,
                      "name": "CppApp",
                      "nodeid": "aprg29ubXv3yOmxEXC9sBCabfgs=",
                      "deviceID": "3",
                      "ip_number": "192.168.1.121",
                      "mac_address": "00:00:00:00:00:00",
                      "time_first_seen": 1454410566,
                      "time_last_seen": 1466518405,
                      "location": "Walt",
                      "product_type": "None",
                      "last_state": "OK",
                      "ce_number": "",
                      "hostname": "",
                      "latitude": "",
                      "longitude": "",
                      "timeZone": null,
                      "flag": 0,
                      "assigned": 1,
                      "doorstatus": 0
                    },
                    {
                      "id": 7,
                      "name": "Wandboard Raymond",
                      "nodeid": "1wBCcz0aSFuKcUVbWJRsJCm6NaY=",
                      "deviceID": "5",
                      "ip_number": "192.168.1.150",
                      "mac_address": "00:00:00:00:00:00",
                      "time_first_seen": 2,
                      "time_last_seen": 1466518405,
                      "location": "Tafel Aambeeldstraat",
                      "product_type": "Bylorus",
                      "last_state": "OK",
                      "ce_number": "",
                      "hostname": "",
                      "latitude": "",
                      "longitude": "",
                      "timeZone": null,
                      "flag": 0,
                      "assigned": 1,
                      "doorstatus": 0
                    },
                    {
                      "id": 8,
                      "name": "Bylorus RnD Wandbboard",
                      "nodeid": "JAbmykU/TpSIAn6XF6PyP+Ub0JA=",
                      "deviceID": "4",
                      "ip_number": "192.168.1.52",
                      "mac_address": "00:1f:7b:b2:14:d6",
                      "time_first_seen": 1454410566,
                      "time_last_seen": 1466518405,
                      "location": "Aambeeldstraat",
                      "product_type": "Bylorus",
                      "last_state": "OK",
                      "ce_number": "",
                      "hostname": "",
                      "latitude": "",
                      "longitude": "",
                      "timeZone": null,
                      "flag": 0,
                      "assigned": 1,
                      "doorstatus": 0
                    },
                    {
                      "id": 9,
                      "name": "Bylorus RnD Wandbboard",
                      "nodeid": "CBZFdyMDg6KBbcF1GnuAUzAEwNY=",
                      "deviceID": "6",
                      "ip_number": "192.168.1.52",
                      "mac_address": "00:1f:7b:b2:14:d6",
                      "time_first_seen": 1454410566,
                      "time_last_seen": 1466518405,
                      "location": "Aambeeldstraat",
                      "product_type": "Bylorus",
                      "last_state": "OK",
                      "ce_number": "",
                      "hostname": "",
                      "latitude": "",
                      "longitude": "",
                      "timeZone": null,
                      "flag": 0,
                      "assigned": 1,
                      "doorstatus": 0
                    },
                    {
                      "id": 10,
                      "name": "Walt QT",
                      "nodeid": "epLVmKkUuw95mkR93o0HixFsrNU=",
                      "deviceID": "8",
                      "ip_number": "1",
                      "mac_address": "1",
                      "time_first_seen": 2,
                      "time_last_seen": 1466518405,
                      "location": "Bureau",
                      "product_type": "Bylorus",
                      "last_state": "",
                      "ce_number": "",
                      "hostname": "",
                      "latitude": "",
                      "longitude": "",
                      "timeZone": null,
                      "flag": 0,
                      "assigned": 1,
                      "doorstatus": 0
                    },
                    {
                      "id": 11,
                      "name": "cpp8",
                      "nodeid": "z7Mfqvc0JF858GhnQ8BduUcgkSE=",
                      "deviceID": "8881",
                      "ip_number": "2",
                      "mac_address": "2",
                      "time_first_seen": 21212,
                      "time_last_seen": 1466677434,
                      "location": "Erik",
                      "product_type": "TL",
                      "last_state": "OK",
                      "ce_number": "",
                      "hostname": "",
                      "latitude": "",
                      "longitude": "",
                      "timeZone": null,
                      "flag": 0,
                      "assigned": 1,
                      "doorstatus": 0
                    },
                    {
                      "id": 12,
                      "name": "Tony",
                      "nodeid": "jW+tcM+CyYj0f1SHpyqWR2KQvPQ=",
                      "deviceID": "999",
                      "ip_number": "1",
                      "mac_address": "1",
                      "time_first_seen": 1,
                      "time_last_seen": 1466677434,
                      "location": "Bureau",
                      "product_type": "Virtual",
                      "last_state": "OK",
                      "ce_number": "CE123",
                      "hostname": "",
                      "latitude": "",
                      "longitude": "",
                      "timeZone": null,
                      "flag": 0,
                      "assigned": 1,
                      "doorstatus": 0
                    },
                    {
                      "id": 13,
                      "name": "2theloo R&D",
                      "nodeid": "qdgvlkShMGNlRXV7bjjQmtJyeRw=",
                      "deviceID": "space",
                      "ip_number": "192.168.1.105",
                      "mac_address": "00:1F:7B:B2:14:D5",
                      "time_first_seen": 1460463903,
                      "time_last_seen": 1466581696,
                      "location": "R&D",
                      "product_type": "Bylorus",
                      "last_state": "",
                      "ce_number": "",
                      "hostname": "",
                      "latitude": "",
                      "longitude": "",
                      "timeZone": null,
                      "flag": 0,
                      "assigned": 1,
                      "doorstatus": 0
                    },
                    {
                      "id": 15,
                      "name": "Bylorus RnD Wandboard",
                      "nodeid": "cRx/9ZSD3Q9BdM3iLcSF+U9/5yY=",
                      "deviceID": "9",
                      "ip_number": "192.168.1.102",
                      "mac_address": "00:0C:29:79:18:69",
                      "time_first_seen": 2,
                      "time_last_seen": 1466518405,
                      "location": "Bas",
                      "product_type": "Bylorus",
                      "last_state": "",
                      "ce_number": "",
                      "hostname": "",
                      "latitude": "",
                      "longitude": "",
                      "timeZone": null,
                      "flag": 0,
                      "assigned": 1,
                      "doorstatus": 0
                    },
                    {
                      "id": 66,
                      "name": "BeConnect",
                      "nodeid": "m5BHuhq2jo7O4WtQGrxSW6DRXwU=",
                      "deviceID": "234",
                      "ip_number": "192.168.11.130",
                      "mac_address": "00:0C:29:E4:AE:41",
                      "time_first_seen": 3,
                      "time_last_seen": 1466518405,
                      "location": null,
                      "product_type": "Tourlock",
                      "last_state": "",
                      "ce_number": "",
                      "hostname": "",
                      "latitude": "",
                      "longitude": "",
                      "timeZone": null,
                      "flag": 0,
                      "assigned": 1,
                      "doorstatus": 0
                    },
                    {
                      "id": 67,
                      "name": "WaltBeConnect",
                      "nodeid": "dUEPULHAXR6szGQcqE+qbbOPXhY=",
                      "deviceID": "90001",
                      "ip_number": "192.168.136.147",
                      "mac_address": "00:0C:29:B9:B8:C2",
                      "time_first_seen": 1464160949,
                      "time_last_seen": 1466677434,
                      "location": null,
                      "product_type": "Tourlock",
                      "last_state": "",
                      "ce_number": "",
                      "hostname": "",
                      "latitude": "",
                      "longitude": "",
                      "timeZone": null,
                      "flag": 0,
                      "assigned": 1,
                      "doorstatus": 0
                    },
                    {
                      "id": 69,
                      "name": null,
                      "nodeid": "V1r0D1stvBUtcPfsqC+d0DgoOFg=",
                      "deviceID": "9009",
                      "ip_number": null,
                      "mac_address": null,
                      "time_first_seen": 0,
                      "time_last_seen": 1466677434,
                      "location": null,
                      "product_type": null,
                      "last_state": null,
                      "ce_number": "",
                      "hostname": "",
                      "latitude": null,
                      "longitude": null,
                      "timeZone": null,
                      "flag": 0,
                      "assigned": 1,
                      "doorstatus": 0
                    },
                    {
                      "id": 70,
                      "name": "Hasan",
                      "nodeid": "ie6UHv6qto5gtO51ytL8HvG4124=",
                      "deviceID": "666",
                      "ip_number": "1",
                      "mac_address": "1",
                      "time_first_seen": 1,
                      "time_last_seen": 1466518405,
                      "location": "Bureau",
                      "product_type": "Virtual",
                      "last_state": "OK",
                      "ce_number": "CE123",
                      "hostname": "",
                      "latitude": "",
                      "longitude": "",
                      "timeZone": null,
                      "flag": 0,
                      "assigned": 1,
                      "doorstatus": 0
                    }
                  ]
                }
              ]
            }
          ]
        }
      ]
    }
  ],
  "rejections": [
    {
      "date": "2016-05-25",
      "TOF0PersonIn": 0,
      "TOF0PersonOut": 0,
      "TOF1PersonIn": 0,
      "TOF1PersonOut": 0,
      "TOF2PersonsIn": 90,
      "TOF2PersonsOut": 0,
      "BiometricRejection": 0,
      "SafetyRail": 126,
      "EmergencyButton": 186,
      "TOFSuspiciousIn": 0,
      "TOFSuspiciousOut": 0,
      "TOFRejection": 0,
      "TimeExceededinCabinCount": 0,
      "IllegalUse": 0
    },
    {
      "date": "2016-05-26",
      "TOF0PersonIn": 0,
      "TOF0PersonOut": 0,
      "TOF1PersonIn": 0,
      "TOF1PersonOut": 0,
      "TOF2PersonsIn": 180,
      "TOF2PersonsOut": 0,
      "BiometricRejection": 0,
      "SafetyRail": 252,
      "EmergencyButton": 372,
      "TOFSuspiciousIn": 0,
      "TOFSuspiciousOut": 0,
      "TOFRejection": 0,
      "TimeExceededinCabinCount": 0,
      "IllegalUse": 0
    },
    {
      "date": "2016-05-27",
      "TOF0PersonIn": 0,
      "TOF0PersonOut": 0,
      "TOF1PersonIn": 0,
      "TOF1PersonOut": 0,
      "TOF2PersonsIn": 180,
      "TOF2PersonsOut": 0,
      "BiometricRejection": 0,
      "SafetyRail": 252,
      "EmergencyButton": 372,
      "TOFSuspiciousIn": 0,
      "TOFSuspiciousOut": 0,
      "TOFRejection": 0,
      "TimeExceededinCabinCount": 0,
      "IllegalUse": 0
    },
    {
      "date": "2016-05-28",
      "TOF0PersonIn": 0,
      "TOF0PersonOut": 0,
      "TOF1PersonIn": 0,
      "TOF1PersonOut": 0,
      "TOF2PersonsIn": 180,
      "TOF2PersonsOut": 0,
      "BiometricRejection": 0,
      "SafetyRail": 252,
      "EmergencyButton": 372,
      "TOFSuspiciousIn": 0,
      "TOFSuspiciousOut": 0,
      "TOFRejection": 0,
      "TimeExceededinCabinCount": 0,
      "IllegalUse": 0
    },
    {
      "date": "2016-05-29",
      "TOF0PersonIn": 0,
      "TOF0PersonOut": 0,
      "TOF1PersonIn": 0,
      "TOF1PersonOut": 0,
      "TOF2PersonsIn": 90,
      "TOF2PersonsOut": 0,
      "BiometricRejection": 0,
      "SafetyRail": 126,
      "EmergencyButton": 186,
      "TOFSuspiciousIn": 0,
      "TOFSuspiciousOut": 0,
      "TOFRejection": 0,
      "TimeExceededinCabinCount": 0,
      "IllegalUse": 0
    }
  ],
  "transactions": []
}
  		controller.treeService = {}
			controller.treeService.nodes = [mockData.campuses[0], mockData.campuses[1]]
			controller.treeService.collapsed = []
			scope.$digest();
  			return compiledElement;
		}

		it('should fail if ngModel is not specified', function () {
			expect(function(){
    					getCompiledElement('<tree-view tree-service="ctrl.myService"  node-label="campusName"></tree-view>');
  					}).toThrow();
		});

		it('should applied template', function () {

			directiveElem = getCompiledElement('<tree-view tree-service="ctrl.myService" node-label="campusName" ng-model="treeviewval"></tree-view>')
			console.log('ssdfs',directiveElem);
		  	expect(directiveElem.html()).not.toEqual('');
		});

		// it('should test if \'toggleNode()\' and \'isCollapsed()\' is working fine ', function () {
		// 	directiveElem = getCompiledElement('<tree-view tree-service="ctrl.myService" node-label="campusName" ng-model="treeviewval"></tree-view>')
		// 	var node = {};
		// 	node = controller.treeService.nodes[1]
		// 	expect(controller.treeService.collapsed.length).toEqual(0)
		// 	controller.toggleNode(node)
		// 	expect(controller.treeService.collapsed.length).toEqual(1)
		// 	controller.isCollapsed(node)
		// 	expect(controller.treeService.collapsed.indexOf(node) > -1).toBeTruthy()
		// 	controller.toggleNode(node)
		// 	expect(controller.treeService.collapsed.length).toEqual(0)
		// 	controller.isCollapsed(node)
		// 	expect(controller.treeService.collapsed.indexOf(node) > -1).toBeFalsy()
		// });

		it('should test if toggle node is working fine ', function () {
			directiveElem = getCompiledElement('<tree-view tree-service="ctrl.myService" node-label="campusName" ng-model="treeviewval"></tree-view>')
			var node = {};
			node = controller.treeService.nodes[0]
			controller.isCollapsed(node)
		});


		// it('should have ul element', function () {
		//   directiveElem = getCompiledElement('<tree-view tree-service="ctrl.myService" node-label="campusName" ng-model="treeviewval"></tree-view>')
		//   expect(directiveElem.find('ul').length > 0).toBeTruthy();
		//   expect(directiveElem.find('li').length > 0).toBeTruthy();
		//   expect(directiveElem.hasClass("ng-pristine")).toBeTruthy()
		//   expect(directiveElem.hasClass("ng-untouched")).toBeTruthy()
		//   expect(directiveElem.hasClass("ng-valid")).toBeTruthy()
		//   expect(directiveElem.hasClass("ng-isolate-scope")).toBeTruthy()
		//   expect(directiveElem.hasClass("ng-empty")).toBeTruthy()
		// });

		it('should test if \'applySelectedClass()\' is working fine ', function () {
			directiveElem = getCompiledElement('<tree-view tree-service="ctrl.myService" node-label="campusName" ng-model="treeviewval"></tree-view>')
			var node = {};
			node = controller.treeService.nodes[0]
			expect(directiveElem.hasClass('selected')).toBeFalsy()
			controller.applySelectedClass(directiveElem)
			expect(directiveElem.hasClass('selected')).toBeTruthy()
		});

		it('should test if \'selectNode()\' is working fine ', function () {
			directiveElem = getCompiledElement('<tree-view tree-service="ctrl.myService" class= "node" node-label="campusName" ng-model="treeviewval"></tree-view>')
			var node = {};
			node = controller.treeService.nodes[0]
			var $event = jasmine.createSpyObj('$event', ['preventDefault','stopPropagation']);
			$event.target = directiveElem
			expect(directiveElem.hasClass('selected')).toBeFalsy()
			controller.selectNode($event, node)
			expect(directiveElem.hasClass('selected')).toBeTruthy()
			expect($event.preventDefault).toHaveBeenCalled()
			expect($event.stopPropagation).toHaveBeenCalled()
		});
  	})


  })
