/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */

 'use strict';

  define([
  'angular-mocks',
  'Source/modules/login/authService',
  'Source/modules/login/encodeService',
  'Source/modules/resources/user'
  ], function(){

  	describe('authService', function () {
  		var q, mockAuth, state, httpBackend, deferred, mockencodeService, mockUser; 

  		beforeEach(angular.mock.module('app.login'));

  		beforeEach(module(function($provide) {
        mockUser = {
          save: function() {},
          logout : function(){}
        };
        $provide.value('User', mockUser);
      }));

		beforeEach(angular.mock.inject(function(Auth, $state, _$httpBackend_, _$q_, User){
	      mockAuth = Auth
	      state = $state
	      httpBackend = _$httpBackend_
	      deferred = _$q_.defer();
	      mockUser = User;

		})) 

		it('should exist', function(){
       		expect(!!mockAuth).toBe(true)
		})

	    it('should test if goToLogin is in called', function(){
	       spyOn(mockAuth, 'goToLogin').and.returnValue(true);
	       mockAuth.goToLogin();
	       expect(mockAuth.goToLogin).toHaveBeenCalled()
	    })

	    it('should test if login is in called', function(){
	       spyOn(mockAuth, 'login').and.callThrough();
	       spyOn(mockUser, 'save').and.callThrough()
	       var userName = 'boonuser' ;
	       var password = '1234567'
	       mockAuth.login(userName, password);
	       expect(mockAuth.login).toHaveBeenCalled()
	       expect(mockUser.save).toHaveBeenCalled()
	    })    


	    it('should test if logout is in called', function(){
	       spyOn(mockAuth, 'logout').and.callThrough();
	       mockAuth.logout();
	       expect(mockAuth.logout).toHaveBeenCalled()
	    })

	    it('should test if logout is in called', function(){
	       spyOn(mockAuth, 'logout').and.callThrough();
	       spyOn(mockUser, 'logout').and.callThrough()
	       mockAuth.logout();
	       expect(mockAuth.logout).toHaveBeenCalled()
	       expect(mockUser.logout).toHaveBeenCalled()
	    })	        
  	})
  })	