/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
 define([
  'angular-mocks',
  'Source/modules/changepassword/changePasswordService',
  'Source/modules/login/encodeService',
  'Source/config'
  ], function(){

  	   describe('changePasswordService', function () {  
  	   		var mockchangePasswordService, queryDeferred, q, mockchangePassword;

  	   		beforeEach(angular.mock.module('app.changePassword'));

          beforeEach(angular.mock.module('app.login'));

  	   		beforeEach(angular.mock.module('app.common.token'));
          
          beforeEach(module(function($provide) {
            mockchangePassword = {
              updatePassword: function() {
                return {save : function(){}}
              }
            };
            $provide.value('changePassword', mockchangePassword);
          }));



          beforeEach(angular.mock.module('app.constants', function ($provide) {
          $provide.constant('CONFIG',{
            url: 'http://nlboed01.sgti.nl:3000/'
          });


          }))          

  	   		beforeEach(angular.mock.inject(function(changePasswordService, $rootScope, $state, $location, $window, $q){
				      mockchangePasswordService = changePasswordService   
              q=$q         
			    })) 

  			 it('should test changePasswordService is on its place' , function(){
  			 		expect(mockchangePasswordService).toBeDefined()
  			 })

         it('should test updatePassword is on its place' , function(){
          expect(mockchangePasswordService.updatePassword).toBeDefined()
         })

         it('should test updatePassword is on its place' , function(){
          spyOn(mockchangePasswordService, 'updatePassword').and.callThrough()
          spyOn(mockchangePassword, 'updatePassword').and.callThrough()
          var userDetails = {}
          userDetails.userId = 'testId'
          userDetails.password = 'testPassword'
          userDetails.oldpassword = 'testPassword'
          mockchangePasswordService.updatePassword(userDetails)
          expect(mockchangePasswordService.updatePassword).toHaveBeenCalled()
          expect(mockchangePassword.updatePassword).toHaveBeenCalled()
         })         

       
  	   })

 })