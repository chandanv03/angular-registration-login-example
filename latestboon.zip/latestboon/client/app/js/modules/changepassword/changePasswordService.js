/**
 * Change Password services definition
 */
define(['./module'], function(module) {
    'use strict'
    module.factory('changePasswordService', function($rootScope, $window, $q, changePassword, EncodeService, TokenService) {
        var factory = {
            /*function to update user password*/
            updatePassword: function(userDetails) {

                //Base 64 encode to encode the password
                var encodedPassword = EncodeService.encode(userDetails.password)
                var encodedOldPassword = EncodeService.encode(userDetails.oldpassword)

                var userData = {
                    username: userDetails.userName,
                    newpassword: encodedPassword,
                    password: encodedOldPassword
                }
                var deferred = $q.defer()

                //Send the post request to the server to check the credentials
                var updateUser = changePassword.updatePassword(TokenService.getToken()).save(userData, function() {
                    if (updateUser.success === true) {
                        deferred.resolve(updateUser.success)
                    } else {
                        deferred.reject(updateUser)
                    }
                })

                return deferred.promise
            }
        }
        return factory
    })
})
