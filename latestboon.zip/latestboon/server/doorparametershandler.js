var db = require('./database.js')
var kaaServerApi = require('./kaaServerApi.js')
var plcUpdateQuery = 'update plc set ? where deviceID = ?'
var lastUpdatedBy = 'update product set ? where deviceID = ?'
var stereoVisionUpdateQuery = 'update stereovision set ? where deviceID = ?'

var campusBasedQuery = 'select DeviceId from product where campusID = ?'
var buildingBasedQuery = 'select DeviceId from product where campusID = ? and buildingID = ?'
var entranceBasedQuery = 'select DeviceId from product where campusID = ? and buildingID = ? and entranceID = ?'
var subEntranceBasedQuery = 'select DeviceId from product where campusID = ? and buildingID = ? and entranceID = ? and subEntranceID = ?'

var plcParameters = ['CleaningTime', 'OpenTimeIn', 'OpenTimeOut', 'ReturnSignalInTime', 'ReturnSignalOutTime', 'IllegalTime', 'TimeOutTime','LockSwitch']
var stereovisionParameters = [
    ['Primary_Sensitivity_LowObject',
        'Secondary_Sensitivity_LowObject'
    ],
    ['Primary_Sensitivity_SensorBlinding',
        'Secondary_Sensitivity_SensorBlinding'
    ],
    ['Primary_Sensitivity_OnePerson',
        'Secondary_Sensitivity_OnePerson'
    ],
    ['Primary_Sensitivity_MorePerson',
        'Secondary_Sensitivity_MorePerson'
    ],
]


function updateDoorParameters(req, cb) {
    var post = req.body
    var parameterIndex = post.parameterIndex
    var parameterValue = post.parameterValue
    var table = ''
    var updateQuery = ''
    var updateValues = {}
    if (parameterIndex >= 0 && parameterIndex <= 7) {
        table = 'plc'
        updateQuery = plcUpdateQuery
        var parameterName = plcParameters[parameterIndex]
        updateValues[parameterName] = parameterValue

    } else if (parameterIndex >= 8 && parameterIndex < 12) {
        table = 'stereovision'
        updateQuery = stereoVisionUpdateQuery
        var index = parameterIndex - 8
        var parameterName1 = stereovisionParameters[index][0]
        var parameterName2 = stereovisionParameters[index][1]
        updateValues[parameterName1] = parameterValue
        updateValues[parameterName2] = parameterValue

    }
    var deviceQuery = ''
    var deviceQueryValues = []


    if (post.campusID != null && post.buildingID != null && post.entranceID != null && post.subEntranceID != null) {
        deviceQuery = subEntranceBasedQuery
        deviceQueryValues = [post.campusID, post.buildingID, post.entranceID, post.subEntranceID]
    } else if (post.campusID != null && post.buildingID != null && post.entranceID != null && post.subEntranceID == null) {
        deviceQuery = entranceBasedQuery
        deviceQueryValues = [post.campusID, post.buildingID, post.entranceID]
    } else if (post.campusID != null && post.buildingID != null && post.entranceID == null && post.subEntranceID == null) {
        deviceQuery = buildingBasedQuery
        deviceQueryValues = [post.campusID, post.buildingID]
    } else if (post.campusID != null && post.buildingID == null && post.entranceID == null && post.subEntranceID == null) {
        deviceQuery = campusBasedQuery
        deviceQueryValues = [post.campusID]
    }

    db.executeSelect(deviceQuery, deviceQueryValues, function(err, rows, fields) {
        if (err) {
            console.log('error while performing query.', err)
            cb(err)
        } else {
            if (rows.length > 0) {

                var user = req.user
                var error = 0
                var success = 0

                function updater(i) {
                    console.log("updater " + i)
                    if (i < rows.length) {
                        var deviceId = rows[i].DeviceId
                        var productValues = [{
                            "lastupdateby": user
                        }, deviceId]
                        var values = [updateValues, deviceId]
                        var newReq = {}
                        newReq.user = user
                        newReq.query = {}
                        newReq.query.deviceId = deviceId
                        newReq.body = updateValues
                        kaaServerApi.executeKaaServerApi(newReq, table, function() {
                                console.log("Kaa server updated successfully")

                                var productValues = [{
                                    "lastupdateby": user
                                }, deviceId]
                                db.executeUpdate(lastUpdatedBy, productValues, function(err, result) {
                                    if (err) {
                                        console.log('error while performing update on product table.', err)
                                        error++
                                        updater(i + 1)
                                    } else {
                                        db.executeUpdate(updateQuery, values, function(err, result) {
                                            db.executeUpdate(lastUpdatedBy, [{
                                                "lastupdateby": null
                                            }, deviceId], function(err, result) {})
                                            if (err) {
                                                console.log(err)
                                                error++
                                                updater(i + 1)
                                            } else {
                                                success++
                                                updater(i + 1)
                                            }
                                        })
                                    }

                                })
                            },
                            function() {
                                console.log("Kaa server api update failed")
                                error++
                                updater(i + 1)
                            })
                    } else {
                        cb({
                            success: true,
                            message: success + ' update(s) successful.'
                        })
                    }
                }

                updater(0)


            }

        }
    })
}


exports.updateDoorParameters = updateDoorParameters
