/**
 * Change Password controller definition
 */
define(['./module'], function(module) {
    module.controller('changePasswordController', function($scope, $state, CONFIG, $window, $timeout, $location, changePasswordService) {

        /*Fetch username from session*/
        var userName = JSON.parse($window.sessionStorage.getItem('userInfo')).userName

        /*check if user logged in*/
        if (userName == '' || userName == null) {
            $state.go('login')
        }

        /*initialize the data*/
        $scope.user = {
            oldpassword: '',
            password: '',
            cpassword: ''
        }

        /*function to check user password and then update the password*/
        $scope.changepassword = function() {
            /*user detail object*/
            var userDetails = {
                userName: userName,
                password: $scope.user.password,
                oldpassword: $scope.user.oldpassword
            }


            if (/^[a-zA-Z0-9]*$/.test($scope.user.password)==false) {
                $scope.errorMessage = 'ERROR : Spaces and special characters !@#$%^&*()(, are not allowed for password.'
            }else if (/^[a-zA-Z0-9]*$/.test($scope.user.cpassword)==false) {
                $scope.errorMessage = 'ERROR : Spaces and special characters !@#$%^&*()(, are not allowed for password.'
            }else if ($scope.user.password != $scope.user.cpassword) {
                $scope.errorMessage = 'ERROR : Password can not be changed. New password and confirm password doesnt not match.'
            } else if ($scope.user.password === $scope.user.oldpassword) {
                $scope.errorMessage = 'ERROR : Password can not be changed. New password and old password cannot be same.'
            } else {
                /*calling change password service to update the password*/
                changePasswordService.updatePassword(userDetails).then(function(res) {
                    if (res === true) {
                        $scope.successMessage = 'Password has been changed'
                        $timeout(function() {
                            $scope.successMessage = false
                            $scope.errorMessage = ''
                            $scope.user = {}
                            $location.path('dashboard')
                        }, CONFIG.LONG_VISUAL_DELAY)
                    }
                }, function(err) {
                    $scope.errorMessage = 'ERROR : Password can not be changed. Please enter the correct old password.'
                    $scope.user = {}
                })
            }


        }
    })
})
