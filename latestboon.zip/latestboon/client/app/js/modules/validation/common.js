define([
  'angular'
], function (angular) {
  'use strict'

  return angular.module('app.validation.common', [])
    // http://nlboed01.sgti.nl:3000/checkuser?user=:user&password=:password
    .directive('validUsername', function () {
      return {
        require: 'ngModel',
        link: function (scope, elm, attrs, ctrl) {
          ctrl.$parsers.unshift(function (viewValue) {
            // Any way to read the results of a "required" angular validator here?
            var isBlank = viewValue === ''
            ctrl.$setValidity('isBlank', !isBlank)
            scope.userValid = !isBlank
          })
        }
      }
    })
    .directive('validPassword', function () {
      return {
        require: 'ngModel',
        link: function (scope, elm, attrs, ctrl) {
          ctrl.$parsers.unshift(function (viewValue) {
            // Any way to read the results of a "required" angular validator here?
            var isBlank = viewValue === ''
            ctrl.$setValidity('isBlank', !isBlank)
            scope.passValid = !isBlank
          })
        }
      }
    })

    /*Directive for confirm the password */
    .directive('compareTo', function () {
      return {
        require: 'ngModel',
        scope: {
          otherModelValue: '=compareTo'
        },
        link: function (scope, element, attributes, ngModel) {
          ngModel.$validators.compareTo = function (modelValue) {
            return modelValue == scope.otherModelValue
          }

          scope.$watch('otherModelValue', function () {
            ngModel.$validate()
          })
        }
      }
    })

    .directive('numberOnly', function () {
      return {
        require: 'ngModel',
        link: function (scope, elm, attrs, ctrl) {
          var parseValue
          parseValue = function (value) {
            if (value != null) {
              return value.toUpperCase().replace(/\D/g, '')
            } else {
              return void 0
            }
          }
          ctrl.$parsers.unshift(function (viewValue) {
            var parsed, valid
            if (viewValue != null) {
              parsed = parseValue(viewValue)
              if (parsed !== viewValue) {
                ctrl.$setViewValue(parsed)
                ctrl.$render()
              }
              return viewValue
            }
          })
        }
      }
    })
})
