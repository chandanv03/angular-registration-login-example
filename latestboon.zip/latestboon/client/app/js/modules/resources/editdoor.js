define([
    'angular',
    'ngResource'
], function(angular) {
    'use strict'

    return angular.module('app.resources.editdoor', ['ngResource'])
        .service('EditDoor', function($resource, CONFIG, TokenService) {
            return {
                getDoor: function(token) {

                    return $resource(CONFIG.url + 'doors/detail?id=:id', {
                        id: '@id'
                    }, {
                        query: {
                            method: 'GET',
                            isArray: true
                        },
                        get: {
                            method: 'GET',
                            headers: {
                                'x-access-token': token
                            },
                            transformResponse: function(data, headers) {
                                //Check the response header for token expiry and new token.
                                var headers = headers()
                                TokenService.setResponseHeader(headers)
                                return angular.fromJson(data)
                            }

                        }
                    })

                }
            }
        })
})
