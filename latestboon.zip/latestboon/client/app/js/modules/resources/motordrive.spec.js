/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
 define([
  'angular-mocks',
  'Source/modules/resources/motordrive',
  'Source/modules/common/tokenSetter',
  'Source/config'
  ], function(){

   describe('MotorDrive', function () {
  	var mockMotorDrive, $httpBackend, url, token;

	  	beforeEach(angular.mock.module('app.resources.motordrive'));

	  	beforeEach(module('ui.router'));

	  	beforeEach(angular.mock.module('app.common.token'));

	  	beforeEach(angular.mock.module('app.constants', function ($provide) {
	    $provide.constant('CONFIG',{
	      url: 'http://nlboed01.sgti.nl:3000/'
	    });


		}))

	  	var state;
	  	beforeEach(angular.mock.inject(function (MotorDrive, _$httpBackend_, CONFIG, $state, TokenService) {
	  		url = CONFIG.url;
	  		$httpBackend = _$httpBackend_;
	        mockMotorDrive = MotorDrive;
	        state = $state;
          token= TokenService.getToken();
		}))

	  	it('should test if resource is defined', function(){
	  		expect(mockMotorDrive).toBeDefined();
	  	})

	  	it('should test if resource is defined', function(){
	  		expect(mockMotorDrive.updateMotor).toBeDefined();
	  	})

      it('should test the URL', function(){
        var payload = {
            deviceId: 10
        }
        var mtrArray = []
        $httpBackend.expect('PUT', url + 'doors/motordrive?deviceId=10').respond(200, {result:'success'});
        mockMotorDrive.updateMotor(token).update(payload, mtrArray);
        $httpBackend.flush();
      })
   })

 })
