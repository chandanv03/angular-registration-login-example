/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
 define([
  'angular-mocks',
  'Source/modules/resources/admin',
  'Source/modules/common/tokenSetter',
  'Source/config'
  ], function(){

   describe('adminList', function () {
  	var mockadminList, $httpBackend, url, token;

	  	beforeEach(angular.mock.module('app.resources.admin'));

	  	beforeEach(module('ui.router'));

	  	beforeEach(angular.mock.module('app.common.token'));

	  	beforeEach(angular.mock.module('app.constants', function ($provide) {
	    $provide.constant('CONFIG',{
	      url: 'http:/localhost:3000/'
	    });
		}))

	  	var state;
	  	beforeEach(angular.mock.inject(function (adminList, _$httpBackend_, CONFIG, $state, TokenService) {
	  		url = CONFIG.url;
	  		$httpBackend = _$httpBackend_;
	        mockadminList = adminList;
	        state = $state;
          token = TokenService.getToken();
		}))


	  	it('should test if resource is defined', function(){
	  		expect(mockadminList).toBeDefined();
	  	})


	  	it('should test if adminList.getUsers is defined', function(){
	  		expect(mockadminList.getUsers).toBeDefined();
        mockadminList.getUsers()
	  	})

	  	it('should test if adminList.deleteUser is defined', function(){
	  		expect(mockadminList.deleteUser).toBeDefined();
	  	})

      it('should test if getUsers works as expected', function(){
        $httpBackend.expect('GET', url + 'admin/listusers').respond(200, {result:'success'});
        mockadminList.getUsers(token).get();
        $httpBackend.flush();
      })

      it('should test if deleteUser works as expected', function(){
        $httpBackend.expect('DELETE', url + 'admin/deleteuser').respond(200, {result:'success'});
        mockadminList.deleteUser(token).delete();
        $httpBackend.flush();
      })

   })

 })
