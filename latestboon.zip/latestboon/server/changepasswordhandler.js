var config = require('./config.js')
var db = require('./database.js')
var base64 = require('./base64.js')
var bcrypt = require('bcryptjs')
var queries = require('./sqlqueries.js')
var config = require('./config.js')

function isPasswordCorrect(post, cb) {
    var validAttempt = false
    var passwordSql = queries.usernamebasedquery
    console.log('isPasswordCorrect ' + post.user)
    db.executeSelect(passwordSql, post.user, function(err, rows, columns) {
        if (err || rows.length === 0 || rows.length > 1) {
            console.log('An error occured, or the user does not exist.')
            cb({
                success: false
            })
        } else {
            console.log(rows)
            var decodedPwd = base64.decode(post.pwd)
            if (!bcrypt.compareSync(decodedPwd, rows[0].password)) {
                console.log('The password is incorrect.')
                cb({
                    success: false
                })
            } else {
                cb({
                    id: rows[0].id,
                    success: true
                })
            }
        }
    })
}

function changePassword(values, cb) {
    var userUpdateSql = queries.userupdatequery

    db.executeUpdate(userUpdateSql, values, function(err, result) {
        if (err) {
            console.log('error while changing password.', err)
            cb({
                success: false
            })
        } else {
            cb({
                success: true
            })
        }

    })

}

function doChangePassword(post, cb) {
    var opPerformed = false

    isPasswordCorrect(post, function(isPasswordCorrectResults) {
        if (isPasswordCorrectResults.success) {
            var decodedPwd = base64.decode(post.newPwd)
            var bcryptedPwd = ''
            bcrypt.hash(decodedPwd, config.saltLength, function(err, hash) {
                if (!err) {
                    var values = [{
                        password: hash
                    }, isPasswordCorrectResults.id]
                    changePassword(values, function(changePasswordResults) {
                        cb(changePasswordResults)
                    })

                } else {
                    cb({
                        success: false
                    })
                }
            })
        } else {
            cb({
                success: false
            })
        }
    })
}

exports.doChangePassword = doChangePassword
