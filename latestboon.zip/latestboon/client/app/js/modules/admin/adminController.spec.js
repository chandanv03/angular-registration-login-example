/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */

define([
  'angular-mocks',
  'Source/modules/admin/adminController',
  'Source/modules/admin/adminService',
  'Source/modules/common/locationsService',
  'Source/modules/common/tokenSetter'
], function () {
    describe('AdminController', function(){

      var scope, mockAdminService, mockDashboardTreeView, createController, $window;

      beforeEach(angular.mock.module('app.admin'));

      beforeEach(angular.mock.module('app.dashboard'));

      beforeEach(angular.mock.module('app.common.token'));

      beforeEach(angular.mock.module('app.common.locations'));


      beforeEach(module(function($provide) {
        mockAdminService = {
          getUsers: function() {},
          deleteUser: function(){}
        };
        $provide.value('adminService', mockAdminService);
      }));

      // beforeEach(angular.mock.module('app.constants', function ($provide) {
      //   $provide.constant('userName', 'test');
      // }))


      beforeEach(angular.mock.inject(function ($rootScope, $controller, $q, $state, _$window_) {
               var mockData = {accessToken: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiY…3NDF9.WkzeQ4LCP0mmiGf7EXgh4BpkeGUsv1buOJnN8NjOLbY", userName: "boonadmin", admin: true}
               state = $state
               $window = _$window_
               spyOn(state, 'go').and.returnValue(true)
               spyOn(JSON, 'parse').and.returnValue(mockData)
               scope = $rootScope.$new();
               createController = function() {
                  return $controller('adminController', {
                    '$scope': scope,
                    'adminService' : mockAdminService
                  });
               };
               deferred = $q.defer();
               spyOn(mockAdminService, 'getUsers').and.returnValue(deferred.promise);

      }));


      it('should test if controller is initiated with scope', function() {
          createController()
          scope.getUsersList()
          expect(mockAdminService.getUsers).toHaveBeenCalled()
      });

      it('should test if scope.getUsersList() works fine when promise is resolved', function() {
          var ctrl = createController();
          expect(scope.users).toBeDefined()
          scope.getUsersList()
          expect(mockAdminService.getUsers).toHaveBeenCalled()
          var result = [{"id":1,"username":"sogetiVianen@sogeti.nl","registrationdatetime":"2015-12-31T23:00:00.000Z","level1":null,"level2":null,"level3":null,"enabled":null,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":null},{"id":3,"username":"boonuser1","registrationdatetime":"2015-12-31T23:00:00.000Z","level1":null,"level2":null,"level3":null,"enabled":null,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":null},{"id":4,"username":"boonadmin","registrationdatetime":"2016-06-17T11:59:01.000Z","level1":1,"level2":1,"level3":1,"enabled":1,"country":null,"campus":"boonCampus","building":null,"entrance":null,"company_ID":null},{"id":5,"username":"boonservice","registrationdatetime":"2016-06-17T12:05:32.000Z","level1":0,"level2":1,"level3":1,"enabled":0,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":null},{"id":6,"username":"boonmanager","registrationdatetime":"2016-06-17T12:05:53.000Z","level1":0,"level2":0,"level3":1,"enabled":0,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":null},{"id":7,"username":"Bad Wolf","registrationdatetime":"2016-06-17T12:50:46.000Z","level1":1,"level2":1,"level3":1,"enabled":1,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":"1"},{"id":8,"username":"googleuser","registrationdatetime":"2016-06-17T13:13:26.000Z","level1":1,"level2":1,"level3":1,"enabled":0,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":"1"},{"id":9,"username":"googleadmin","registrationdatetime":"2016-06-17T13:16:05.000Z","level1":1,"level2":1,"level3":1,"enabled":0,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":"1"},{"id":10,"username":"sogetigenie","registrationdatetime":"2016-06-17T14:40:45.000Z","level1":1,"level2":1,"level3":1,"enabled":0,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":"1"},{"id":12,"username":"sogetigenie from india","registrationdatetime":"2016-06-17T14:41:31.000Z","level1":1,"level2":1,"level3":1,"enabled":1,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":"1"},{"id":13,"username":"admin","registrationdatetime":"2016-06-29T12:21:52.000Z","level1":1,"level2":1,"level3":1,"enabled":1,"country":"admin","campus":"admin","building":"Admin","entrance":"admin","company_ID":"admin"},{"id":15,"username":"user","registrationdatetime":"2016-07-01T10:02:52.000Z","level1":0,"level2":1,"level3":1,"enabled":1,"country":"con","campus":"camp","building":"buil","entrance":"ent","company_ID":"comp"},{"id":17,"username":"Nermin","registrationdatetime":"2016-07-01T12:10:19.000Z","level1":0,"level2":1,"level3":0,"enabled":0,"country":"Netherlands","campus":"Campus1","building":"Building1","entrance":"Entrance1","company_ID":"1"},{"id":18,"username":"testadduser","registrationdatetime":"2016-07-01T13:45:47.000Z","level1":0,"level2":0,"level3":0,"enabled":1,"country":"netherlands","campus":"boonCampus","building":"boonBuilding","entrance":"boonEntrance","company_ID":"1"},{"id":19,"username":"Test2","registrationdatetime":"2016-07-01T15:18:16.000Z","level1":1,"level2":1,"level3":1,"enabled":1,"country":"netherlands","campus":"Campus1","building":"Building11","entrance":"Entrance111","company_ID":"1"}]
          result  = JSON.parse(result)
          deferred.resolve(result); // Resolve the promise.
          scope.$digest();
          expect(JSON.stringify(scope.users)).toEqual(JSON.stringify(result))
      });

      it('should test if scope.getUsersList() works fine when promise is rejected', function() {
          createController();
          expect(scope.users).toBeDefined()
          scope.getUsersList()
          expect(mockAdminService.getUsers).toHaveBeenCalled()
          var result = [{"id":1,"username":"sogetiVianen@sogeti.nl","registrationdatetime":"2015-12-31T23:00:00.000Z","level1":null,"level2":null,"level3":null,"enabled":null,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":null},{"id":3,"username":"boonuser1","registrationdatetime":"2015-12-31T23:00:00.000Z","level1":null,"level2":null,"level3":null,"enabled":null,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":null},{"id":4,"username":"boonadmin","registrationdatetime":"2016-06-17T11:59:01.000Z","level1":1,"level2":1,"level3":1,"enabled":1,"country":null,"campus":"boonCampus","building":null,"entrance":null,"company_ID":null},{"id":5,"username":"boonservice","registrationdatetime":"2016-06-17T12:05:32.000Z","level1":0,"level2":1,"level3":1,"enabled":0,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":null},{"id":6,"username":"boonmanager","registrationdatetime":"2016-06-17T12:05:53.000Z","level1":0,"level2":0,"level3":1,"enabled":0,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":null},{"id":7,"username":"Bad Wolf","registrationdatetime":"2016-06-17T12:50:46.000Z","level1":1,"level2":1,"level3":1,"enabled":1,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":"1"},{"id":8,"username":"googleuser","registrationdatetime":"2016-06-17T13:13:26.000Z","level1":1,"level2":1,"level3":1,"enabled":0,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":"1"},{"id":9,"username":"googleadmin","registrationdatetime":"2016-06-17T13:16:05.000Z","level1":1,"level2":1,"level3":1,"enabled":0,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":"1"},{"id":10,"username":"sogetigenie","registrationdatetime":"2016-06-17T14:40:45.000Z","level1":1,"level2":1,"level3":1,"enabled":0,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":"1"},{"id":12,"username":"sogetigenie from india","registrationdatetime":"2016-06-17T14:41:31.000Z","level1":1,"level2":1,"level3":1,"enabled":1,"country":null,"campus":null,"building":null,"entrance":null,"company_ID":"1"},{"id":13,"username":"admin","registrationdatetime":"2016-06-29T12:21:52.000Z","level1":1,"level2":1,"level3":1,"enabled":1,"country":"admin","campus":"admin","building":"Admin","entrance":"admin","company_ID":"admin"},{"id":15,"username":"user","registrationdatetime":"2016-07-01T10:02:52.000Z","level1":0,"level2":1,"level3":1,"enabled":1,"country":"con","campus":"camp","building":"buil","entrance":"ent","company_ID":"comp"},{"id":17,"username":"Nermin","registrationdatetime":"2016-07-01T12:10:19.000Z","level1":0,"level2":1,"level3":0,"enabled":0,"country":"Netherlands","campus":"Campus1","building":"Building1","entrance":"Entrance1","company_ID":"1"},{"id":18,"username":"testadduser","registrationdatetime":"2016-07-01T13:45:47.000Z","level1":0,"level2":0,"level3":0,"enabled":1,"country":"netherlands","campus":"boonCampus","building":"boonBuilding","entrance":"boonEntrance","company_ID":"1"},{"id":19,"username":"Test2","registrationdatetime":"2016-07-01T15:18:16.000Z","level1":1,"level2":1,"level3":1,"enabled":1,"country":"netherlands","campus":"Campus1","building":"Building11","entrance":"Entrance111","company_ID":"1"}]
          deferred.reject(result); // Resolve the promise.
          scope.$digest();
          expect(scope.errorNoDataMessage).toEqual('No Users Found')
      });


      it('should test if scope.editUser is working fine', function() {
          createController()
          var event = {}
          var dummyElement = document.createElement('div');
          var att = document.createAttribute("class");
          att.value = 10;
          dummyElement.setAttributeNode(att);
          event.currentTarget = dummyElement;
          spyOn(event.currentTarget, 'getAttribute').and.returnValue(1)
          scope.editUser(event)
          expect(state.go).toHaveBeenCalledWith('edituser', { id: 1 })
      });

      it('should test if scope.deleteUser is working fine', function() {
          createController()
          var event = {}
          var dummyElement = document.createElement('div');
          var att = document.createAttribute("class");
          att.value = 1;
          dummyElement.setAttributeNode(att);
          event.currentTarget = dummyElement;
          event.preventDefault = {}
          spyOn(event.currentTarget, 'getAttribute').and.returnValue(1)
          spyOn(event, 'preventDefault').and.returnValue(1)
          spyOn($window, 'confirm').and.returnValue(true)
          spyOn(scope, 'deleteUser').and.callThrough()
          scope.deleteUser(event)
          expect(scope.deleteUser).toHaveBeenCalled()
      });

      it('should test if scope.getTypeOfAccount is working fine for all levels', function() {
          createController()

          var  user = {"id":68,"username":"BoonAdmin","registrationdatetime":"2016-08-25T07:17:19.000Z","level1":null,"level2":null,"level3":null,"level4":null,"level5":null,"level6":null,"level7":null,"level8":null,"level9":1,"level10":null,"enabled":1,"country":1,"campus":null,"building":null,"entrance":null,"company_ID":"1","$$hashKey":"object:10"}
          result = scope.getTypeOfAccount(user)
          expect(result).toEqual('Admin')
          user = {"id":69,"username":"ServiceManager","registrationdatetime":"2016-08-25T07:18:14.000Z","level1":null,"level2":1,"level3":null,"level4":null,"level5":1,"level6":1,"level7":1,"level8":null,"level9":null,"level10":1,"enabled":1,"country":1,"campus":null,"building":null,"entrance":null,"company_ID":"1","$$hashKey":"object:11"}
          var result = scope.getTypeOfAccount(user)
          expect(result).toEqual('Service Engineer')
          user = {"id":71,"username":"SectionManager","registrationdatetime":"2016-08-25T07:19:00.000Z","level1":null,"level2":1,"level3":null,"level4":null,"level5":1,"level6":null,"level7":null,"level8":null,"level9":null,"level10":null,"enabled":1,"country":1,"campus":null,"building":null,"entrance":null,"company_ID":"1","$$hashKey":"object:12"}
          result = scope.getTypeOfAccount(user)
          expect(result).toEqual('Section Manager')
          user = {"id":72,"username":"Customer","registrationdatetime":"2016-08-25T07:19:41.000Z","level1":null,"level2":1,"level3":null,"level4":null,"level5":1,"level6":null,"level7":1,"level8":null,"level9":null,"level10":1,"enabled":1,"country":1,"campus":null,"building":null,"entrance":null,"company_ID":"1","$$hashKey":"object:13"}
          result = scope.getTypeOfAccount(user)
          expect(result).toEqual('Customer Highest Level')
          user = {"id":73,"username":"SecutiryManager","registrationdatetime":"2016-08-25T07:19:56.000Z","level1":null,"level2":null,"level3":null,"level4":null,"level5":null,"level6":null,"level7":null,"level8":null,"level9":null,"level10":null,"enabled":1,"country":1,"campus":null,"building":null,"entrance":null,"company_ID":"1","$$hashKey":"object:14"}
          result = scope.getTypeOfAccount(user)
          expect(result).toEqual('Security Manager')
          user = {"id":72,"username":"Customer","registrationdatetime":"2016-08-25T07:19:41.000Z","level1":null,"level2":1,"level3":null,"level4":null,"level5":1,"level6":null,"level7":1,"level8":null,"level9":null,"level10":1,"enabled":1,"country":1,"campus":null,"building":null,"entrance":null,"company_ID":"1","$$hashKey":"object:13"}
          result = scope.getTypeOfAccount(user)
          expect(result).toEqual('Customer Highest Level')
      });

})

})
