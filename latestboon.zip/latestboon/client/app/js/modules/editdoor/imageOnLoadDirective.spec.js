/* File:whyReportDirective Spec
 *
 */
define([
    'angular-mocks',
    'Source/modules/editdoor/imageOnLoadDirective'
], function () {

    describe('imageOnLoadDirective', function () {
        var compile, scope, directiveElem, controller, element;

        beforeEach(angular.mock.module('app.editdoor'));

        beforeEach(angular.mock.inject(function ($compile, $rootScope) {
            compile = $compile;
            scope = $rootScope.$new();
            directiveElem = getCompiledElement();
        }));

        function getCompiledElement() {
            element = angular.element('<img  ng-src="../style/images/image_primary.png" imageonload/>');
            var compiledElement = compile(element)(scope);
            scope.$digest();
            controller = compiledElement.controller('imageonload');
            return compiledElement;
        }

      it('should emit the resizeContent signal when the load event occurs with primary true', function() {
          scope.drawShapeOnPrimary = function(){};
          spyOn(scope, 'drawShapeOnPrimary');
          scope.checkModel = {primary:true}
          element.trigger('load');
          expect(scope.drawShapeOnPrimary).toHaveBeenCalled()
       });

       it('should emit the resizeContent signal when the load event occurs with secondary true', function() {
           scope.drawShapeOnSecondary = function(){};
           spyOn(scope, 'drawShapeOnSecondary');
           scope.checkModel = {primary:false}
           element.trigger('load');
           expect(scope.drawShapeOnSecondary).toHaveBeenCalled()
        });
    });
});
