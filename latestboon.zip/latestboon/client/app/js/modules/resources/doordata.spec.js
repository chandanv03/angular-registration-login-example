/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
 define([
  'angular-mocks',
  'Source/modules/resources/doordata',
  'Source/modules/common/tokenSetter',
  'Source/config'
  ], function(){

   describe('DoorData', function () {
  	var mockDoorData, $httpBackend, url, token;

	  	beforeEach(angular.mock.module('app.resources.doordata'));

	  	beforeEach(module('ui.router'));

	  	beforeEach(angular.mock.module('app.common.token'));

	  	beforeEach(angular.mock.module('app.constants', function ($provide) {
	    $provide.constant('CONFIG',{
	      url: 'http://localhost:3000/'
	    });
		}))

	  	var state;
	  	beforeEach(angular.mock.inject(function (DoorData, _$httpBackend_, CONFIG, $state, TokenService) {
	  		url = CONFIG.url;
	  		$httpBackend = _$httpBackend_;
	        mockDoorData = DoorData;
	        state = $state;
          token = TokenService.getToken();
		}))

	  	it('should test if resource is defined', function(){
	  		expect(mockDoorData).toBeDefined();
	  	})

	  	it('should test if resource is defined', function(){
	  		expect(mockDoorData.updateDoor).toBeDefined();
	  	})

      it('should test the URL', function(){
        $httpBackend.expect('PUT', url + 'doors/location?deviceId=10').respond(200, {result:'success'});
        mockDoorData.updateDoor(token).update({deviceId: 10});
        $httpBackend.flush();
      })

   })

 })
