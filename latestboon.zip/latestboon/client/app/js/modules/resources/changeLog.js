define([
    'angular',
    'ngResource'
], function(angular) {
    'use strict'

    return angular.module('app.resources.changeLog', ['ngResource'])
        .service('ChangeLog', function($resource, CONFIG, TokenService) {
            return {
                getChangeLog: function(token) {

                    return $resource(CONFIG.url + 'doors/changelog?id=:id', {
                        id: '@id'
                    }, {
                        query: {
                            method: 'GET'
                        },
                        get: {
                            method: 'GET',
                            headers: {
                                'x-access-token': token
                            },
                            transformResponse: function(data, headers) {
                                //Check the response header for token expiry and new token.
                                var headers = headers()
                                TokenService.setResponseHeader(headers)
                                return angular.fromJson(data)
                            }

                        }
                    })

                }
            }
        })
})
