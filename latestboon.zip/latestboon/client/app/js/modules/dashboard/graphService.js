define(['./module'], function(module) {
    'use strict'

    module.service('GraphService', function($http, $window, CONFIG, $timeout, $filter, RejectionCount, TransactionCount, TokenService) {
        var graphService = {
            rejectionTwoPersData: [],
            rejectionBioData: [],
            rejectionSrdData: [],
            rejectionEmgData: [],
            passageMinsecData: [],
            passageAvgsecData: [],
            passageMaxsecData: [],
            rejectionLabels: [],
            passageLabels: [],
            data: [],
            dataset: {},
            rejectionData: [],
            transactionData: [],
            lastThirtydaysJson: [],
            lastSevendaysJson: [],
            lastThirtydaysTranscJson: [],
            lastSevendaysTranscJson: [],
            selectedId: '',
            campusId: '',
            buildingId: '',
            entranceId: '',
            subentranceId: '',
            campusName: '',
            buildingName: '',
            entranceName: '',
            subentranceName: '',
            selectedType: '',
            chartContext: '',
            kpiRejections: function(value) {},
            kpiPassages: function(value) {},
            //Fetch rejection count for selected tr
            getRejectionCount: function(selectedNode) {
                var payload = {
                    id: graphService.selectedId,
                    type: graphService.selectedType
                }

                var getRejCount = RejectionCount.getRejectionCount(TokenService.getToken()).query({
                    path: 'v1'
                }, payload, function() {
                    graphService.setRejectionData(getRejCount)
                    graphService.kpiRejections(selectedNode)
                })
            },
            //Fetch transaction count for selected treeview data
            getTransactionCount: function(selectedNode) {
                var payload = {
                    id: graphService.selectedId,
                    type: graphService.selectedType
                }

                var getTransCount = TransactionCount.getTransactionCount(TokenService.getToken()).query({
                    path: 'v1'
                }, payload, function() {
                    graphService.setTransactionData(getTransCount)
                    graphService.kpiPassages(selectedNode)
                })
            },
            //Set the selected node from the treeview
            setSelectedNodeType: function(selectedNode, transaction) {
                if (angular.isArray(selectedNode)) {
                    if (selectedNode[0].hasOwnProperty('campusId')) {
                        graphService.selectedId = selectedNode[0].campusId
                        graphService.campusId = selectedNode[0].campusId
                        graphService.campusName = selectedNode[0].campusName
                        graphService.selectedType = 'campus'
                    } else if (selectedNode[0].hasOwnProperty('buildingId')) {
                        graphService.selectedId = selectedNode[0].buildingId
                        graphService.buildingId = selectedNode[0].buildingId
                        graphService.buildingName = selectedNode[0].buildingName
                        graphService.selectedType = 'building'
                    } else if (selectedNode[0].hasOwnProperty('entranceId')) {
                        graphService.selectedId = selectedNode[0].entranceId
                        graphService.entranceId = selectedNode[0].entranceId
                        graphService.entranceName = selectedNode[0].entranceName
                        graphService.selectedType = 'entrance'
                    } else if (selectedNode[0].hasOwnProperty('subentranceId')) {
                        graphService.selectedId = selectedNode[0].subentranceId
                        graphService.subentranceId = selectedNode[0].subentranceId
                        graphService.subentranceName = selectedNode[0].subentranceName
                        graphService.selectedType = 'subentrance'
                    }
                    if(transaction == 'activeKpiPass'){
                      graphService.getTransactionCount(selectedNode)
                    }
                    else{
                      graphService.getRejectionCount(selectedNode)
                    }


                }
            },
            //set transaction data
            setTransactionData: function(transactionData) {

                graphService.transactionData = transactionData
                graphService.setLastSevenThirtyDayTransaction(graphService.transactionData)
            },



            //set the 7 and thirty days transaction data
            setLastSevenThirtyDayTransaction: function(data) {

                var now = new Date()
                var curdate = new Date(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds())

                var days30 = []
                var days7 = []
                for (var i = 29; i >= 0; i--) {
                    var thirtydys = curdate - 1000 * 60 * 60 * 24 * i
                    days30.push($filter('date')(new Date(thirtydys), 'yyyy-MM-dd'))

                }
                for (var i = 6; i >= 0; i--) {
                    var sevendys = curdate - 1000 * 60 * 60 * 24 * i
                    days7.push($filter('date')(new Date(sevendys), 'yyyy-MM-dd'))

                }


                var d7 = curdate - 1000 * 60 * 60 * 24 * 6
                d7 = new Date(d7)
                var d30 = curdate - 1000 * 60 * 60 * 24 * 29
                d30 = new Date(d30)

                var date7To = $filter('date')(d7, 'yyyy-MM-dd')
                var date30To = $filter('date')(d30, 'yyyy-MM-dd')
                var dateFrom = $filter('date')(curdate, 'yyyy-MM-dd')

                var kpiTransarray = {}
                var kpiTransarray1 = {}


                graphService.lastThirtydaysTranscJson = []
                graphService.lastSevendaysTranscJson = []
                var dbarray30 = []
                var dbarray7 = []


                for (var j = 0; j <= data.length; j++) {

                    if (data[j]) {
                        if (graphService.dateCheck(date30To, dateFrom, data[j].date)) {
                            graphService.lastThirtydaysTranscJson.push(data[j])
                            dbarray30.push(data[j].date)

                        }

                        if (graphService.dateCheck(date7To, dateFrom, data[j].date)) {
                            graphService.lastSevendaysTranscJson.push(data[j])
                            dbarray7.push(data[j].date)

                        }

                    }

                }



                if (data.length != 30) {
                    for (var i = 0; i < 30; i++) {

                        kpiTransarray = {
                            "minimumTransactionTime": 0,
                            "averageTransactionTime": 0,
                            "maximumTransactionTime": 0,
                            "date": days30[i]
                        }

                        if (dbarray30.indexOf(days30[i]) == -1) {
                            graphService.lastThirtydaysTranscJson.push(kpiTransarray)
                        }

                    }

                    for (var i = 0; i < 7; i++) {

                        kpiTransarray1 = {
                            "minimumTransactionTime": 0,
                            "averageTransactionTime": 0,
                            "maximumTransactionTime": 0,
                            "date": days7[i]
                        }

                        if (dbarray7.indexOf(days7[i]) == -1) {
                            graphService.lastSevendaysTranscJson.push(kpiTransarray1)
                        }

                    }

                }

                graphService.lastThirtydaysTranscJson.sort(function(a, b) {
                    var c = new Date(a.date)
                    var d = new Date(b.date)
                    return c - d
                })

                graphService.lastSevendaysTranscJson.sort(function(a, b) {
                    var c = new Date(a.date)
                    var d = new Date(b.date)
                    return c - d
                })
            },
            //Set the rejection data
            setRejectionData: function(rejectionData) {
                graphService.rejectionData = rejectionData
                graphService.setLastSevenThirtyDayRejection(graphService.rejectionData)
            },


            //Set last seven thirty days rejection
            setLastSevenThirtyDayRejection: function(data) {


                var now = new Date()
                var curdate = new Date(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds())

                var days30 = []
                var days7 = []
                for (var i = 29; i >= 0; i--) {
                    var thirtydys = curdate - 1000 * 60 * 60 * 24 * i
                    days30.push($filter('date')(new Date(thirtydys), 'yyyy-MM-dd'))

                }
                for (var i = 6; i >= 0; i--) {
                    var sevendys = curdate - 1000 * 60 * 60 * 24 * i
                    days7.push($filter('date')(new Date(sevendys), 'yyyy-MM-dd'))

                }


                var d7 = curdate - 1000 * 60 * 60 * 24 * 6
                d7 = new Date(d7)
                var d30 = curdate - 1000 * 60 * 60 * 24 * 29
                d30 = new Date(d30)

                var date7To = $filter('date')(d7, 'yyyy-MM-dd')
                var date30To = $filter('date')(d30, 'yyyy-MM-dd')
                var dateFrom = $filter('date')(curdate, 'yyyy-MM-dd')

                var kpirejarray = {}
                var kpirejarray1 = {}


                graphService.lastThirtydaysJson = []
                graphService.lastSevendaysJson = []
                var dbarray30 = []
                var dbarray7 = []


                for (var j = 0; j <= data.length; j++) {

                    if (data[j]) {
                        if (graphService.dateCheck(date30To, dateFrom, data[j].date)) {
                            graphService.lastThirtydaysJson.push(data[j])
                            dbarray30.push(data[j].date)

                        }

                        if (graphService.dateCheck(date7To, dateFrom, data[j].date)) {
                            graphService.lastSevendaysJson.push(data[j])
                            dbarray7.push(data[j].date)

                        }

                    }

                }



                if (data.length != 30) {
                    for (var i = 0; i < 30; i++) {

                        kpirejarray = {
                            "TOF2PersonsIn": 0,
                            "BiometricRejection": 0,
                            "SafetyRail": 0,
                            "EmergencyButton": 0,
                            "date": days30[i]
                        }

                        if (dbarray30.indexOf(days30[i]) == -1) {
                            graphService.lastThirtydaysJson.push(kpirejarray)
                        }

                    }

                    for (var i = 0; i < 7; i++) {

                        kpirejarray1 = {
                            "TOF2PersonsIn": 0,
                            "BiometricRejection": 0,
                            "SafetyRail": 0,
                            "EmergencyButton": 0,
                            "date": days7[i]
                        }

                        if (dbarray7.indexOf(days7[i]) == -1) {
                            graphService.lastSevendaysJson.push(kpirejarray1)
                        }

                    }

                }

                graphService.lastThirtydaysJson.sort(function(a, b) {
                    var c = new Date(a.date)
                    var d = new Date(b.date)
                    return c - d
                })

                graphService.lastSevendaysJson.sort(function(a, b) {
                    var c = new Date(a.date)
                    var d = new Date(b.date)
                    return c - d
                })


            },



            /* To Check date is between two given dates*/
            dateCheck: function(from, to, check) {
                var fDate, lDate, cDate
                fDate = Date.parse(from)
                lDate = Date.parse(to)
                cDate = Date.parse(check)

                if ((cDate >= fDate && cDate <= lDate)) {
                    return true
                }
                return false
            },


            //Set the rejection data from the json
            setRejData: function(data) {
                graphService.rejectionLabels = data.map(function(item) {
                    return $filter('date')(item.date, 'dd-MMM')
                })
                graphService.rejectionTwoPersData = data.map(function(item) {
                    return Number(item.TOF2PersonsIn)
                })
                graphService.rejectionBioData = data.map(function(item) {
                    return Number(item.BiometricRejection)
                })
                graphService.rejectionSrdData = data.map(function(item) {
                    return Number(item.SafetyRail)
                })
                graphService.rejectionEmgData = data.map(function(item) {
                    return Number(item.EmergencyButton)
                })
            },
            //Set the passage data from the json
            setPassageData: function(data) {
                graphService.passageLabels = data.map(function(item) {
                    return $filter('date')(item.date, 'dd-MMM')
                })
                graphService.passageMinsecData = data.map(function(item) {
                    return Number(item.minimumTransactionTime)
                })
                graphService.passageAvgsecData = data.map(function(item) {
                    return Number(item.averageTransactionTime)
                })
                graphService.passageMaxsecData = data.map(function(item) {
                    return Number(item.maximumTransactionTime)
                })
            },


            //Set rejection data set for the graph
            setRejDataset: function(chartDays) {

                var now = new Date()
                var curdate = new Date(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds())

                if (graphService.rejectionLabels.length == 0) {
                    if (chartDays == 'rejectionSeven') {
                        graphService.rejectionLabels = []
                        for (var i = 6; i >= 0; i--) {
                            var svndys = curdate - 1000 * 60 * 60 * 24 * i
                            graphService.rejectionLabels.push($filter('date')(new Date(svndys), 'dd-MMM'))
                        }
                    } else if (chartDays == 'rejectionThirty') {

                        for (var i = 29; i >= 0; i--) {
                            var thirtydys = curdate - 1000 * 60 * 60 * 24 * i
                            graphService.rejectionLabels.push($filter('date')(new Date(thirtydys), 'dd-MMM'))
                        }
                    }
                }


                graphService.dataset = {
                    labels: graphService.rejectionLabels,
                    datasets: [{
                        label: 'TwoPersonRejectionCount',
                        backgroundColor: '#00ff2e',
                        borderColor: '#00ff2e',
                        highlightFill: '#00ff2e',
                        highlightStroke: '#00ff2e',
                        pointBorderWidth: 1.5,
                        data: graphService.rejectionTwoPersData
                    }, {
                        label: 'BiometricRejectionCount',
                        backgroundColor: '#f21313',
                        borderColor: '#f21313',
                        highlightFill: '#f21313',
                        highlightStroke: '#f21313',
                        hoverBackgroundColor: '#f21313',
                        pointBorderWidth: 1.5,
                        data: graphService.rejectionBioData
                    }, {
                        label: 'SrdRejectionCount',
                        backgroundColor: '#c3c3c3',
                        borderColor: '#c3c3c3',
                        highlightFill: '#c3c3c3',
                        highlightStroke: '#c3c3c3',
                        hoverBackgroundColor: '#c3c3c3',
                        pointBorderWidth: 1.5,
                        data: graphService.rejectionSrdData
                    }, {
                        label: 'EmergencyRejectionCount',
                        backgroundColor: '#2ee8bc',
                        borderColor: '#2ee8bc',
                        highlightFill: '#2ee8bc',
                        highlightStroke: '#2ee8bc',
                        hoverBackgroundColor: '#2ee8bc',
                        pointBorderWidth: 1.5,
                        data: graphService.rejectionEmgData
                    }]
                }
            },
            //Set passage dataset for the graph
            setPassageDataset: function(chartDays) {
                var now = new Date()
                var curdate = new Date(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds())

                if (graphService.passageLabels.length == 0) {
                    if (chartDays == 'passageSeven') {

                        for (var i = 6; i >= 0; i--) {
                            var svndys = curdate - 1000 * 60 * 60 * 24 * i
                            graphService.passageLabels.push($filter('date')(new Date(svndys), 'dd-MMM'))
                        }
                    } else if (chartDays == 'passageThirty') {
                        for (var i = 29; i >= 0; i--) {
                            var thirtydys = curdate - 1000 * 60 * 60 * 24 * i
                            graphService.passageLabels.push($filter('date')(new Date(thirtydys), 'dd-MMM'))
                        }
                    }
                }



                graphService.dataset = {
                    labels: graphService.passageLabels,
                    datasets: [{
                        label: 'Minimum Seconds',
                        backgroundColor: '#00ff2e',
                        borderColor: '#00ff2e',
                        pointBorderColor: '#00ff2e',
                        pointBackgroundColor: '#00ff2e',
                        pointBorderWidth: 1,
                        fill: false,
                        lineTension: 0,
                        data: graphService.passageMinsecData
                    }, {
                        label: 'Average Seconds',
                        backgroundColor: '#c3c3c3',
                        borderColor: '#c3c3c3',
                        pointBorderColor: '#c3c3c3',
                        pointBackgroundColor: '#c3c3c3',
                        pointBorderWidth: 1,
                        fill: false,
                        lineTension: 0,
                        data: graphService.passageAvgsecData
                    }, {
                        label: 'Maximum Seconds',
                        backgroundColor: '#f21313',
                        borderColor: '#f21313',
                        pointBorderColor: '#f21313',
                        pointBackgroundColor: '#f21313',
                        pointBorderWidth: 1,
                        fill: false,
                        lineTension: 0,
                        data: graphService.passageMaxsecData
                    }]
                }
            },
            //Draw the chart based on type and records
            drawChart: function(chartType, chartDays) {
                var chartElement, chartContext = null
                Chart.defaults.global.tooltips.enabled = true
                if (chartDays === 'rejectionSeven') {
                    graphService.setRejData(graphService.lastSevendaysJson)
                    graphService.setRejDataset(chartDays)
                } else if (chartDays === 'rejectionThirty') {
                    graphService.setRejData(graphService.lastThirtydaysJson)
                    graphService.setRejDataset(chartDays)
                } else if (chartDays === 'passageSeven') {
                    graphService.setPassageData(graphService.lastSevendaysTranscJson)
                    graphService.setPassageDataset(chartDays)
                } else if (chartDays === 'passageThirty') {
                    graphService.setPassageData(graphService.lastThirtydaysTranscJson)
                    graphService.setPassageDataset(chartDays)
                }

                chartElement = document.getElementById(chartDays)
                if (chartElement) {
                    chartContext = chartElement.getContext('2d')
                }

                if (chartType === 'bar') {
                    Chart.defaults.bar.scales.xAxes[0].categoryPercentage = 0.5
                    Chart.defaults.bar.scales.xAxes[0].barPercentage = 1.0
                    Chart.defaults.bar.scales.xAxes[0].stacked = true
                    Chart.defaults.bar.scales.yAxes[0].stacked = true
                }
                if (chartContext) {
                    $timeout(function() {
                        $window.myBar = new Chart(chartContext, {
                            type: chartType,
                            data: graphService.dataset,
                            options: {
                                responsive: true,
                            }
                        })
                    }, CONFIG.CHART_DELAY)
                }
            }
        }
        return graphService
    })
})
