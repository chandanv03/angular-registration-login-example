define(['./module'], function(module) {
    'use strict'

    module.directive('confirmOnExit', function($window, userLevelService) {
        return {
            link: function($scope, elem, attrs, ctrl) {


                $scope.$on('$stateChangeStart', function(event, next, current) {
                    var formname = ''
                    if ($scope[attrs["name"]].$dirty) {
                        if ($scope[attrs["name"]].$name == 'editDoorForm') {
                            formname = 'Door Data'
                        } else if ($scope[attrs["name"]].$name == 'StereoVision') {
                            formname = 'StereoVision'
                        } else if ($scope[attrs["name"]].$name == 'motorDrive') {
                            formname = 'Motor Drive'
                        }  else if ($scope[attrs["name"]].$name == 'plcdataform1') {
                            formname = 'Setting registers'
                        }

                        var level6 = JSON.parse($window.sessionStorage.getItem('userInfo')).level6
                        var level10 = JSON.parse($window.sessionStorage.getItem('userInfo')).level10
                        var flag1 = userLevelService.confirmExit(level10)
                        var falg2 = userLevelService.canSetPlcMotorDrive(level6)

                        if ((flag1.isserviceEmployee == 1 || flag1.iscustomerHighestLevel == 1)) {

                            if ($scope.isDorDataSaved == false && formname == 'Door Data') {

                                if (!confirm("You have unsaved data in " + formname + " section, do you want to leave the page?")) {
                                    event.preventDefault()
                                }
                            } else if ($scope.tofSaved == false && formname == 'StereoVision') {
                                if (!confirm("You have unsaved data in " + formname + " section, do you want to leave the page?")) {
                                    event.preventDefault()
                                }

                            }
                        }
                        if (falg2.isserviceEmployee == 1) {

                            if ($scope.mtrSaved == false && formname == 'Motor Drive') {
                                if (!confirm("You have unsaved data in " + formname + " section, do you want to leave the page?")) {
                                    event.preventDefault()
                                }

                            } else if ($scope.settingReg == false && formname == 'Setting registers') {
                                if (!confirm("You have unsaved data in " + formname + " section, do you want to leave the page?")) {
                                    event.preventDefault()
                                }

                            }

                        } //user condition
                    }
                })

            }
        }
    })
})
