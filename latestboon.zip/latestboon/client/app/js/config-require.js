if (typeof define !== 'function') {
  // to be able to require file from node
  var define = require('amdefine')(module)
}

define({
  baseUrl: '.',
  // Here paths are set relative to `/source` folder
  paths: {
    'angular': 'vendor/angular/angular',
    'async': 'vendor/requirejs-plugins/src/async',
    'jquery': 'vendor/jquery/dist/jquery',
    'ngResource': 'vendor/angular-resource/angular-resource',
    'ui.router': 'vendor/angular-ui-router/release/angular-ui-router',
    'ngRoute': 'vendor/angular-route/angular-route',
    'ngMessages': 'vendor/angular-messages/angular-messages',
    'ui.bootstrap': 'vendor/angular-bootstrap/ui-bootstrap',
    'ui.bootstrap.tpl': 'vendor/angular-bootstrap/ui-bootstrap-tpls',
    'ui.bootstrap.treeview': 'vendor/bootstrap-ui-treeview/dist/tree-view',
    'smart-table': 'vendor/angular-smart-table/dist/smart-table',
    'chart-js': 'vendor/Chart.js/dist/Chart.bundle',
    'angular-slider': 'vendor/angular-bootstrap-slider/slider',
    'bootstrap-slider': 'vendor/seiyria-bootstrap-slider/dist/bootstrap-slider.min',
    'base-64': 'vendor/base64/base64',
    'ngSanitize':'vendor/angular-sanitize/angular-sanitize.min',
    'ngCsv': 'vendor/ng-csv/ng-csv.min'
  },

  shim: {
    'angular': {
      'deps': ['jquery'],
      'exports': 'angular'
    },
    'ngResource': ['angular'],
    'ngRoute': ['angular'],
    'ngMessages': ['angular'],
    'ui.router': ['angular'],
    'ui.bootstrap': ['angular'],
    'ui.bootstrap.tpl': ['ui.bootstrap'],
    'ui.bootstrap.treeview': ['angular'],
    'smart-table': ['angular'],
    'chart-js':[],
    'angular-slider': ['angular', 'bootstrap-slider'],
    'base-64': [],
    'ngSanitize':['angular'],
    'ngCsv':['angular','ngSanitize']
  }
})
