define([
    'angular'
], function(angular) {
    'use strict'

    return angular.module('app.common.userlevel', [])
        .service('userLevelService', function() {
            var iscustomerAdmin = ''
            var isserviceEmployee = ''
            var iscustomerHighestLevel = ''
            var issectionManager = ''
            var issecurityManager = ''

            var service = {
                canSnooze: function(level2) {

                    if (level2 == true) {

                        var snoozeflag = {
                            iscustomerAdmin:0,
                            isserviceEmployee:1,
                            iscustomerHighestLevel:1,
                            issectionManager:1
                        }
                    } else {
                        var snoozeflag = {
                            iscustomerAdmin:1
                        }
                    }
                    return snoozeflag
                },


                canSetParameters: function(level5) {

                    if (level5 == true) {

                        var paramflag = {
                            iscustomerAdmin:0,
                            isserviceEmployee:1,
                            iscustomerHighestLevel:1,
                            issectionManager:1
                        }
                    } else {
                        var paramflag = {
                            iscustomerAdmin:1
                        }
                    }
                    return paramflag
                },

                canSetTimeOfFlight: function(level7) {

                    if (level7 == true) {

                        var tofflag = {
                            iscustomerAdmin:0,
                            isserviceEmployee:1,
                            iscustomerHighestLevel:1,
                            issectionManager:0
                        }

                    } else {
                        var tofflag = {
                            iscustomerAdmin:1,
                            issectionManager:1
                        }
                    }
                    return tofflag
                },
                canSetPlcMotorDrive: function(level6) {

                    if (level6 == true) {
                        var mdflag = {
                            isserviceEmployee:1
                        }
                    } else {
                        var mdflag = {
                          isserviceEmployee:0

                        }
                    }
                    return mdflag
                },
                canSetDoorData: function(level10) {

                    if (level10 == true) {
                        var doorflag = {
                            isserviceEmployee:1,
                            iscustomerHighestLevel:1
                        }
                    } else {
                        var doorflag = {
                          isserviceEmployee:0,
                          iscustomerHighestLevel:0

                        }
                    }
                    return doorflag
                },
                confirmExit: function(level10) {

                    if (level10 == true) {
                        var flag1 = {
                            isserviceEmployee:1,
                            iscustomerHighestLevel:1
                        }
                    } else {
                        var flag1 = {
                          isserviceEmployee:0,
                          iscustomerHighestLevel:0

                        }
                    }
                    return flag1
                }

            }

            return service
        })
})
