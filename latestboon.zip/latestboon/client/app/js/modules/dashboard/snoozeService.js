define(['./module'], function(module) {
    'use strict'
    module.service('SnoozeService', function($rootScope, $resource, $state, $location, Snooze, CONFIG, $q, TokenService) {
        var service = {
            setSnooze: function(snoozeData, deviceId) {

                var payload = {
                    snoozeExitTime: snoozeData
                }
                var deferred = $q.defer()
                var update = Snooze.putSnooze(TokenService.getToken()).update({
                    deviceId: deviceId
                }, payload, function() {
                    if (update.success === true) {
                        deferred.resolve(update)
                    } else {
                        deferred.reject(update)
                    }
                })
                return deferred.promise
            }
        }

        return service
    })
})
