define([
  'angular-mocks',
  'Source/modules/dashboard/dashboardController',
  'Source/modules/dashboard/graphService',
  'Source/modules/dashboard/dashboardTreeviewService',
  'Source/modules/resources/doors'
  ], function(){

  		describe('DashboardTreeView', function(){
  			var dashboardTreeViewService, httpBackend, window, mockLastChange, mockDoorParam, mockTokenService;
  			beforeEach(angular.mock.module('app.dashboard'));

        beforeEach(angular.mock.module('app.common.token'));

        beforeEach(module(function($provide) {
        mockLastChange = {
          getLastChange: function() {
            return {get : function(){}}
          }
        };
        mockDoorParam = {
          updateDoorParams: function() {
            return {update : function(){}}
          }
        };
         mockTokenService = {
          getToken: function() {}
        };
        $provide.value('LastChange', mockLastChange);
        $provide.value('DoorParam', mockDoorParam);
        $provide.value('TokenService', mockTokenService);

      }));

  			// beforeEach(function() {
     //    		module('app.dashboard.graphService');
    	// 	});

    		beforeEach(angular.mock.inject(function(DashboardTreeView, $window){
    			dashboardTreeViewService = DashboardTreeView;			
          window = $window
			  })) 

    		it('should test if service is in its place', function(){
            expect(dashboardTreeViewService).toBeDefined()
        })

        it('should test if setDoorData is being called successfully', function(){
          spyOn(dashboardTreeViewService, 'setDoorData').and.callThrough()
          var value = {}
          value.campusId = 'boon'
          value.campusName = 'boon'
          dashboardTreeViewService.setDoorData(value)
          expect(dashboardTreeViewService.setDoorData).toHaveBeenCalledWith(value)
        })       

        it('should test if filterDoorsData is being called successfully', function(){
          spyOn(dashboardTreeViewService, 'filterDoorsData').and.callThrough()
          var nodeData = {}
          dashboardTreeViewService.filterDoorsData(nodeData)
          expect(dashboardTreeViewService.filterDoorsData).toHaveBeenCalledWith(nodeData)
        }) 

        it('should test if mergeDoorsData is being called successfully', function(){
          spyOn(dashboardTreeViewService, 'mergeDoorsData').and.callThrough()
          var doorData = {}
          dashboardTreeViewService.mergeDoorsData(doorData)
          expect(dashboardTreeViewService.mergeDoorsData).toHaveBeenCalledWith(doorData)
        })             

        it('should test if fetchDoors is being called successfully', function(){
          spyOn(dashboardTreeViewService, 'fetchDoors').and.callThrough()
          dashboardTreeViewService.fetchDoors()
          expect(dashboardTreeViewService.fetchDoors).toHaveBeenCalled()
        })

        it('should test if logout is being called successfully', function(){
          spyOn(dashboardTreeViewService, 'logout').and.callThrough()
          dashboardTreeViewService.logout()
          expect(dashboardTreeViewService.logout).toHaveBeenCalled()
        })

        it('should test if setDoorData is working as expected if value has own property campusId', function(){
          spyOn(dashboardTreeViewService, 'setDoorData').and.callThrough()
          var value = {}
          value.campusId = 'boon'
          value.campusName = 'boon'
          expect(dashboardTreeViewService.doorData.campuses.length === 0).toBeTruthy()
          dashboardTreeViewService.setDoorData(value)
          expect(dashboardTreeViewService.setDoorData).toHaveBeenCalledWith(value)
          expect(dashboardTreeViewService.doorData.campuses.length > 0).toBeTruthy()
        })

        it('should test if setDoorData is working as expected if value has own property buildingId', function(){
          spyOn(dashboardTreeViewService, 'setDoorData').and.callThrough()
          var value = {}
          value.buildingId = 'boon'
          value.buildingName = 'boon'
          expect(dashboardTreeViewService.doorData.builings.length === 0).toBeTruthy()
          dashboardTreeViewService.setDoorData(value)
          expect(dashboardTreeViewService.setDoorData).toHaveBeenCalledWith(value)
          expect(dashboardTreeViewService.doorData.builings.length > 0).toBeTruthy()
        })     

        it('should test if setDoorData is working as expected if value has own property entranceId', function(){
          spyOn(dashboardTreeViewService, 'setDoorData').and.callThrough()
          var value = {}
          value.entranceId = 'boon'
          value.entranceName = 'boon'
          expect(dashboardTreeViewService.doorData.entrances.length === 0).toBeTruthy()
          dashboardTreeViewService.setDoorData(value)
          expect(dashboardTreeViewService.setDoorData).toHaveBeenCalledWith(value)
          expect(dashboardTreeViewService.doorData.entrances.length > 0).toBeTruthy()
        })     

        it('should test if setDoorData is working as expected if value has own property subentranceId', function(){
          spyOn(dashboardTreeViewService, 'setDoorData').and.callThrough()
          var value = {}
          value.subentranceId = 'boon'
          value.subentranceName = 'boon'
          expect(dashboardTreeViewService.doorData.subentrances.length === 0).toBeTruthy()
          dashboardTreeViewService.setDoorData(value)
          expect(dashboardTreeViewService.setDoorData).toHaveBeenCalledWith(value)
          expect(dashboardTreeViewService.doorData.subentrances.length > 0).toBeTruthy()
        }) 

        it('should test if checkLastChange is working as expected', function(){
          spyOn(dashboardTreeViewService, 'checkLastChange').and.callThrough()
          spyOn(mockLastChange, 'getLastChange').and.callThrough()
          dashboardTreeViewService.checkLastChange()
          expect(dashboardTreeViewService.checkLastChange).toHaveBeenCalled()
          expect(mockLastChange.getLastChange).toHaveBeenCalled()
        })

        it('should test if putDoorParam is working as expected', function(){
          spyOn(dashboardTreeViewService, 'putDoorParam').and.callThrough()
          spyOn(mockDoorParam, 'updateDoorParams').and.callThrough()
          dashboardTreeViewService.putDoorParam()
          expect(dashboardTreeViewService.putDoorParam).toHaveBeenCalled()
          expect(mockDoorParam.updateDoorParams).toHaveBeenCalled()
        })  

  		})
  })