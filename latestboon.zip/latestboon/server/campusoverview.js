class Subentrance {
    constructor() {
        this.subentranceId = null
        this.subentranceName = null
    }
    populate(row) {
        this.subentranceId = row.subentranceId
        this.subentranceName = row.subentranceName
    }
}

class Entrance {
    constructor() {
        this.entranceId = null
        this.entranceName = null
        this.children = []
    }
    populate(row) {
        this.entranceId = row.entranceId
        this.entranceName = row.entranceName
    }
}

class Building {
    constructor() {
        this.buildingId = null
        this.buildingName = null
        this.children = []
    }
    populate(row) {
        this.buildingId = row.buildingId
        this.buildingName = row.buildingName
    }
}
class Campus {
    constructor() {
        this.campusId = null
        this.campusName = null
        this.children = []
    }
    populate(row) {
        this.campusId = row.campusId
        this.campusName = row.campusName
    }
}

class Company {
    constructor() {
        this.companyId = null
        this.companyName = null
        this.children = []
    }
    populate(row) {
        this.companyId = row.companyId
        this.companyName = row.companyName
    }
}

class Country {
    constructor() {
        this.countryId = null
        this.countryName = null
        this.children = []
    }
    populate(row) {
        this.countryId = row.countryId
        this.countryName = row.countryName
    }
}

module.exports =
    class Campusoverview {
        constructor() {
            this.companies = []
        }
        populate(rows) {
            var i = 0
            var lastCountryId = null
            var lastCompanyId = null
            var lastCampusId = null
            var lastBuildingId = null
            var lastEntranceId = null
            var lastSubEntranceId = null
            var countryId
            var companyId
            var campusId
            var buildingId
            var entranceId
            var subentranceId
            var doorId
            var country
            var company
            var building
            var entrance
            var subentrance
            var door
            var campus

            while (rows[i]) {

                subentranceId = rows[i].subentranceId
                entranceId = rows[i].entranceId
                buildingId = rows[i].buildingId
                campusId = rows[i].campusId
                companyId = rows[i].companyId
                countryId = rows[i].countryId

                if ((subentranceId !== lastSubEntranceId) || (entranceId !== lastEntranceId) || (buildingId !== lastBuildingId) || (countryId !== lastCountryId) || (companyId) || (lastCompanyId)) {
                    if (lastSubEntranceId !== null) {
                        entrance['children'].push(subentrance)
                    }


                    lastSubEntranceId = subentranceId
                    subentrance = new Subentrance()
                    subentrance.populate(rows[i])
                }

                if ((entranceId !== lastEntranceId) || (buildingId !== lastBuildingId) || (campusId !== lastCampusId) || (companyId !== lastCompanyId) || (countryId !== lastCountryId)) {
                    if (lastEntranceId !== null) {
                        building['children'].push(entrance)
                    }
                    lastEntranceId = entranceId
                    entrance = new Entrance()
                    entrance.populate(rows[i])
                }

                if ((buildingId !== lastBuildingId) || (campusId !== lastCampusId) || (companyId !== lastCompanyId) || (countryId !== lastCountryId)) {
                    if (lastBuildingId !== null) {
                        campus['children'].push(building)
                    }
                    lastBuildingId = buildingId
                    building = new Building()
                    building.populate(rows[i])
                }

                if ((campusId !== lastCampusId) || (companyId !== lastCompanyId) || (countryId !== lastCountryId)) {
                    if (lastCampusId !== null) {
                        country['children'].push(campus)
                    }
                    lastCampusId = campusId
                    campus = new Campus()
                    campus.populate(rows[i])
                }

                if ((companyId !== lastCompanyId) || (countryId !== lastCountryId)) {
                    if (lastCountryId !== null) {
                        company['children'].push(country)
                    }
                    lastCountryId = countryId
                    country = new Country()
                    country.populate(rows[i])
                }

                if ((companyId !== lastCompanyId)) {
                    if (lastCompanyId !== null) {
                        this.companies['children'].push(company)
                    }
                    lastCompanyId = companyId
                    company = new Company()
                    company.populate(rows[i])
                }

                i++
            }
            //last row actions

            entrance['children'].push(subentrance)
            building['children'].push(entrance)
            campus['children'].push(building)

            country['children'].push(campus) //push last campus
            company['children'].push(country)
            this.companies.push(company)

        }
    }
