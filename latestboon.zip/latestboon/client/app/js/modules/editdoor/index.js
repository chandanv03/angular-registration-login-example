/**
 * Loader, contains list of Doors module components
 */
define([
  './editdoorService',
  './editdoorController' ,
  './confirmOnExitDirective',
  './imageOnLoadDirective'
], function () {})
