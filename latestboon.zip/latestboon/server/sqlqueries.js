/* This file is to store queries needed by the connectordashboard. */

function define(name, value) {
    Object.defineProperty(exports, name, {
        value: value,
        enumerable: true
    })
}
//dooroverview is queried in the vw_productoverview, including doorstatus
define("dooroverviewqueryByUser", "select * from  vw_productoverview_v2 where campusid = (select campus from users where username = ? ) union select * from vw_productoverview_v2  where exists (select  * from  users where username = ? and level10=1) and campusid=1 ")

define("dooroverviewquery", "select * from vw_productoverview_v2 where exists (select * from users where username = ? and level10=1) and campusid=1 union select * from vw_productoverview_v2 where exists (select * from users where username = ? and campus is null) and campusId !=1")

define("locationsoverviewquery", "select * from vw_locations")

define("campusbyuserquery", "select campus from users where username = ?")

define("")
define("deviceIdbyEntranceQuery", "select distinct \
    deviceid \
      from \
        connectivity_management.product \
      where \
        entranceid = ? ")

define("rejectioncountqueryTotals", "select \
    date_format(from_unixtime(epochtime),'%Y-%m-%d') AS date, \
      sum(TOF0PersonIn) as TOF0PersonIn, \
      sum(TOF0PersonOut) as TOF0PersonOut, \
      sum(TOF1PersonIn) as TOF1PersonIn, \
      sum(TOF1PersonOut) as TOF1PersonOut, \
      sum(TOF2PersonsIn) as TOF2PersonsIn, \
      sum(TOF2PersonsOut) as TOF2PersonsOut, \
      sum(BiometricRejection) as BiometricRejection, \
      sum(SafetyRail) as SafetyRail, \
      sum(EmergencyButton) as EmergencyButton, \
      sum(TOFSuspiciousIn) as TOFSuspiciousIn, \
      sum(TOFSuspiciousOut) as TOFSuspiciousOut, \
      sum(TOFRejection) as TOFRejection, \
      sum(TimeExceededinCabinCount) as TimeExceededinCabinCount, \
      sum(IllegalUse) as IllegalUse \
    from event_rejections \
    where  \
      (date_format(from_unixtime(epochtime),'%Y-%m-%d')) \
    in \
      (select distinct (date_format(from_unixtime(epochtime),'%Y-%m-%d'))from event_rejections) \
    group by date_format(from_unixtime(epochtime),'%Y-%m-%d')")

define("rejectioncountqueryByDevice", "select \
    date_format(from_unixtime(epochtime),'%Y-%m-%d') AS date, \
      sum(TOF0PersonIn) as TOF0PersonIn, \
      sum(TOF0PersonOut) as TOF0PersonOut, \
      sum(TOF1PersonIn) as TOF1PersonIn, \
      sum(TOF1PersonOut) as TOF1PersonOut, \
      sum(TOF2PersonsIn) as TOF2PersonsIn, \
      sum(TOF2PersonsOut) as TOF2PersonsOut, \
      sum(BiometricRejection) as BiometricRejection, \
      sum(SafetyRail) as SafetyRail, \
      sum(EmergencyButton) as EmergencyButton, \
      sum(TOFSuspiciousIn) as TOFSuspiciousIn, \
      sum(TOFSuspiciousOut) as TOFSuspiciousOut, \
      sum(TOFRejection) as TOFRejection, \
      sum(TimeExceededinCabinCount) as TimeExceededinCabinCount, \
      sum(IllegalUse) as IllegalUse \
    from event_rejections \
    where  deviceId = ? \
    and \
      (date_format(from_unixtime(epochtime),'%Y-%m-%d')) \
    in \
      (select distinct (date_format(from_unixtime(epochtime),'%Y-%m-%d'))from event_rejections) \
    group by date_format(from_unixtime(epochtime),'%Y-%m-%d')")

define("rejectioncountqueryByCampus", "select \
      date_format(from_unixtime(epochtime),'%Y-%m-%d') AS date, \
      sum(TOF0PersonIn) as TOF0PersonIn, \
      sum(TOF0PersonOut) as TOF0PersonOut, \
      sum(TOF1PersonIn) as TOF1PersonIn, \
      sum(TOF1PersonOut) as TOF1PersonOut, \
      sum(TOF2PersonsIn) as TOF2PersonsIn, \
      sum(TOF2PersonsOut) as TOF2PersonsOut, \
      sum(BiometricRejection) as BiometricRejection, \
      sum(SafetyRail) as SafetyRail, \
      sum(EmergencyButton) as EmergencyButton, \
      sum(TOFSuspiciousIn) as TOFSuspiciousIn, \
      sum(TOFSuspiciousOut) as TOFSuspiciousOut, \
      sum(TOFRejection) as TOFRejection, \
      sum(TimeExceededinCabinCount) as TimeExceededinCabinCount, \
      sum(IllegalUse) as IllegalUse \
    from event_rejections \
    where  deviceId in (select distinct \
                                deviceid \
                                from \
                                vw_productoverview_v2 \
                                where \
                                  campusid = ? ) \
    and \
      (date_format(from_unixtime(epochtime),'%Y-%m-%d')) \
    in \
      (select distinct (date_format(from_unixtime(epochtime),'%Y-%m-%d'))from event_rejections) \
    group by date_format(from_unixtime(epochtime),'%Y-%m-%d')")

define("rejectioncountqueryByBuilding", "select \
      date_format(from_unixtime(epochtime),'%Y-%m-%d') AS date, \
      sum(TOF0PersonIn) as TOF0PersonIn, \
      sum(TOF0PersonOut) as TOF0PersonOut, \
      sum(TOF1PersonIn) as TOF1PersonIn, \
      sum(TOF1PersonOut) as TOF1PersonOut, \
      sum(TOF2PersonsIn) as TOF2PersonsIn, \
      sum(TOF2PersonsOut) as TOF2PersonsOut, \
      sum(BiometricRejection) as BiometricRejection, \
      sum(SafetyRail) as SafetyRail, \
      sum(EmergencyButton) as EmergencyButton, \
      sum(TOFSuspiciousIn) as TOFSuspiciousIn, \
      sum(TOFSuspiciousOut) as TOFSuspiciousOut, \
      sum(TOFRejection) as TOFRejection, \
      sum(TimeExceededinCabinCount) as TimeExceededinCabinCount, \
      sum(IllegalUse) as IllegalUse \
    from event_rejections \
    where  deviceId in (select distinct \
                                deviceid \
                                from \
                                vw_productoverview_v2 \
                                where \
                                  buildingid = ? ) \
    and \
      (date_format(from_unixtime(epochtime),'%Y-%m-%d')) \
    in \
      (select distinct (date_format(from_unixtime(epochtime),'%Y-%m-%d'))from event_rejections) \
    group by date_format(from_unixtime(epochtime),'%Y-%m-%d')")

define("rejectioncountqueryByEntrance", "select \
      date_format(from_unixtime(epochtime),'%Y-%m-%d') AS date, \
      sum(TOF0PersonIn) as TOF0PersonIn, \
      sum(TOF0PersonOut) as TOF0PersonOut, \
      sum(TOF1PersonIn) as TOF1PersonIn, \
      sum(TOF1PersonOut) as TOF1PersonOut, \
      sum(TOF2PersonsIn) as TOF2PersonsIn, \
      sum(TOF2PersonsOut) as TOF2PersonsOut, \
      sum(BiometricRejection) as BiometricRejection, \
      sum(SafetyRail) as SafetyRail, \
      sum(EmergencyButton) as EmergencyButton, \
      sum(TOFSuspiciousIn) as TOFSuspiciousIn, \
      sum(TOFSuspiciousOut) as TOFSuspiciousOut, \
      sum(TOFRejection) as TOFRejection, \
      sum(TimeExceededinCabinCount) as TimeExceededinCabinCount, \
      sum(IllegalUse) as IllegalUse \
    from event_rejections \
    where  deviceId in (select distinct \
                                deviceid \
                                from \
                                vw_productoverview_v2 \
                                where \
                                  entranceid = ? ) \
    and \
      (date_format(from_unixtime(epochtime),'%Y-%m-%d')) \
    in \
      (select distinct (date_format(from_unixtime(epochtime),'%Y-%m-%d'))from event_rejections) \
    group by date_format(from_unixtime(epochtime),'%Y-%m-%d')")

define("rejectioncountqueryBySubEntrance", "select \
      date_format(from_unixtime(epochtime),'%Y-%m-%d') AS date, \
      sum(TOF0PersonIn) as TOF0PersonIn, \
      sum(TOF0PersonOut) as TOF0PersonOut, \
      sum(TOF1PersonIn) as TOF1PersonIn, \
      sum(TOF1PersonOut) as TOF1PersonOut, \
      sum(TOF2PersonsIn) as TOF2PersonsIn, \
      sum(TOF2PersonsOut) as TOF2PersonsOut, \
      sum(BiometricRejection) as BiometricRejection, \
      sum(SafetyRail) as SafetyRail, \
      sum(EmergencyButton) as EmergencyButton, \
      sum(TOFSuspiciousIn) as TOFSuspiciousIn, \
      sum(TOFSuspiciousOut) as TOFSuspiciousOut, \
      sum(TOFRejection) as TOFRejection, \
      sum(TimeExceededinCabinCount) as TimeExceededinCabinCount, \
      sum(IllegalUse) as IllegalUse \
    from event_rejections \
    where  deviceId in (select distinct \
                                deviceid \
                                from \
                                vw_productoverview_v2 \
                                where \
                                  subentranceid = ? ) \
    and \
      (date_format(from_unixtime(epochtime),'%Y-%m-%d')) \
    in \
      (select distinct (date_format(from_unixtime(epochtime),'%Y-%m-%d'))from event_rejections) \
    group by date_format(from_unixtime(epochtime),'%Y-%m-%d')")

define("doorstatusquery", "select doorstatus from vw_doorstatus_v1 where deviceId = ?")

define("transactiontimequeryTotals", "select \
  date_format(from_unixtime(epochtime),'%Y-%m-%d') AS date, \
  avg(TransactionTime) as averageTransactionTime, \
  min(TransactionTime) as minimumTransactionTime, \
  max(TransactionTime) as maximumTransactionTime \
  from \
    event_transaction_time \
  where \
    epochtime > unix_timestamp(curdate())-30*86400 \
  and \
    (date_format(from_unixtime(epochtime),'%Y-%m-%d')) \
  in \
    (select distinct (date_format(from_unixtime(epochtime),'%Y-%m-%d'))from event_transaction_time) \
  group by date_format(from_unixtime(epochtime),'%Y-%m-%d')")

define("transactiontimequeryByCampus", "select \
  date_format(from_unixtime(epochtime),'%Y-%m-%d') AS date, \
  avg(TransactionTime) as averageTransactionTime, \
  min(TransactionTime) as minimumTransactionTime, \
  max(TransactionTime) as maximumTransactionTime \
  from \
    event_transaction_time \
  where  deviceId in (select distinct \
                                deviceid \
                              from \
                                vw_productoverview_v2 \
                              where \
                                campusid = ? ) \
  and \
    epochtime > unix_timestamp(curdate())-30*86400 \
  and \
    (date_format(from_unixtime(epochtime),'%Y-%m-%d')) \
  in \
    (select distinct (date_format(from_unixtime(epochtime),'%Y-%m-%d'))from event_transaction_time) \
  group by date_format(from_unixtime(epochtime),'%Y-%m-%d')")

define("transactiontimequeryByBuilding", "select \
  date_format(from_unixtime(epochtime),'%Y-%m-%d') AS date, \
  avg(TransactionTime) as averageTransactionTime, \
  min(TransactionTime) as minimumTransactionTime, \
  max(TransactionTime) as maximumTransactionTime \
  from \
    event_transaction_time \
  where  deviceId in (select distinct \
                                deviceid \
                              from \
                                vw_productoverview_v2 \
                              where \
                                buildingid = ? ) \
  and \
    epochtime > unix_timestamp(curdate())-30*86400 \
  and \
    (date_format(from_unixtime(epochtime),'%Y-%m-%d')) \
  in \
    (select distinct (date_format(from_unixtime(epochtime),'%Y-%m-%d'))from event_transaction_time) \
  group by date_format(from_unixtime(epochtime),'%Y-%m-%d')")

define("transactiontimequeryByEntrance", "select \
  date_format(from_unixtime(epochtime),'%Y-%m-%d') AS date, \
  avg(TransactionTime) as averageTransactionTime, \
  min(TransactionTime) as minimumTransactionTime, \
  max(TransactionTime) as maximumTransactionTime \
  from \
    event_transaction_time \
  where  deviceId in (select distinct \
                                deviceid \
                              from \
                                vw_productoverview_v2 \
                              where \
                                entranceid = ? ) \
  and \
    epochtime > unix_timestamp(curdate())-30*86400 \
  and \
    (date_format(from_unixtime(epochtime),'%Y-%m-%d')) \
  in \
    (select distinct (date_format(from_unixtime(epochtime),'%Y-%m-%d'))from event_transaction_time) \
  group by date_format(from_unixtime(epochtime),'%Y-%m-%d')")

define("transactiontimequeryBySubEntrance", "select \
  date_format(from_unixtime(epochtime),'%Y-%m-%d') AS date, \
  avg(TransactionTime) as averageTransactionTime, \
  min(TransactionTime) as minimumTransactionTime, \
  max(TransactionTime) as maximumTransactionTime \
  from \
    event_transaction_time \
  where  deviceId in (select distinct \
                                deviceid \
                              from \
                                vw_productoverview_v2 \
                              where \
                                subentranceid = ? ) \
  and \
    epochtime > unix_timestamp(curdate())-30*86400 \
  and \
    (date_format(from_unixtime(epochtime),'%Y-%m-%d')) \
  in \
    (select distinct (date_format(from_unixtime(epochtime),'%Y-%m-%d'))from event_transaction_time) \
  group by date_format(from_unixtime(epochtime),'%Y-%m-%d')")

define("transactiontimequeryByDevice", "select \
  date_format(from_unixtime(epochtime),'%Y-%m-%d') AS date, \
  avg(TransactionTime) as averageTransactionTime, \
  min(TransactionTime) as minimumTransactionTime, \
  max(TransactionTime) as maximumTransactionTime \
  from \
    event_transaction_time \
  where \
    deviceid = ? \
  and \
    epochtime > unix_timestamp(curdate())-30*86400 \
  and \
    (date_format(from_unixtime(epochtime),'%Y-%m-%d')) \
  in \
    (select distinct (date_format(from_unixtime(epochtime),'%Y-%m-%d'))from event_transaction_time) \
  group by date_format(from_unixtime(epochtime),'%Y-%m-%d')")

define("eventlogqueryTotals", "select \
  Id, \
  deviceId, \
  epochtime AS date, \
 username,\
  affected_table, \
  changedfield, \
  oldvalue, \
  newvalue \
  from \
    event_log \
  where \
    epochtime > unix_timestamp(curdate())-30*86400")


define("eventlogqueryByCampus", "select \
  Id, \
  deviceId, \
 epochtime AS date, \
   username,\
  affected_table, \
  changedfield, \
  oldvalue, \
  newvalue \
  from \
    event_log \
  where  deviceId in (select distinct \
                                deviceid \
                              from \
                                vw_productoverview_v2 \
                              where \
                                campusid = ? ) \
  and \
    epochtime > unix_timestamp(curdate())-30*86400")

define("eventlogqueryByBuilding", "select \
  Id, \
  deviceId, \
  epochtime AS date, \
   username,\
  affected_table, \
  changedfield, \
  oldvalue, \
  newvalue \
  from \
    event_log \
  where  deviceId in (select distinct \
                                deviceid \
                              from \
                                vw_productoverview_v2 \
                              where \
                                buildingid = ? ) \
  and \
    epochtime > unix_timestamp(curdate())-30*86400")

define("eventlogqueryByEntrance", "select \
  Id, \
  deviceId, \
  epochtime AS date, \
   username,\
  affected_table, \
  changedfield, \
  oldvalue, \
  newvalue \
  from \
    event_log \
  where  deviceId in (select distinct \
                                deviceid \
                              from \
                                vw_productoverview_v2 \
                              where \
                                entranceid = ? ) \
  and \
    epochtime > unix_timestamp(curdate())-30*86400")

define("eventlogqueryBySubEntrance", "select \
  Id, \
  deviceId, \
  epochtime AS date, \
   username,\
  affected_table, \
  changedfield, \
  oldvalue, \
  newvalue \
  from \
    event_log \
  where  deviceId in (select distinct \
                                deviceid \
                              from \
                                vw_productoverview_v2 \
                              where \
                                subentranceid = ? ) \
  and \
    epochtime > unix_timestamp(curdate())-30*86400")

define("eventlogqueryByDevice", "select \
  Id, \
  deviceId, \
  epochtime AS date, \
   username,\
  affected_table, \
  changedfield, \
  oldvalue, \
  newvalue \
  from \
    event_log \
  where  deviceId  = ?  \
  and \
    epochtime > unix_timestamp(curdate())-30*86400")



define("doorbyidquery", "select * from product where deviceId = ?")

define("campusbyidquery", "select * from product where campusId = ?")

define("timeofflightquery", "select * from stereovision where deviceId = ?")

define("plcquery", "select * from plc where deviceId = ?")

define("motordrivequery", "select * from motor_drive where deviceId = ?")

define("doordetailquery", "select * from product where deviceid = ?")

define("userquery", "select id,username,registrationdatetime,level1, level2, level3, level4,level5,level6,level7, level8, level9, level10, enabled, country,campus,building,entrance,company_ID from users where id = ?")

define("userlistquery", "select id,username,registrationdatetime,level1, level2, level3, level4,level5,level6,level7, level8, level9, level10,enabled, country,campus,building,entrance,company_ID from users")

define("usernamebasedquery", "select password, level1, level2, level3, level4,level5,level6,level7, level8, level9, level10, id from users where username = ? ")

define("lastchangequery", "select max(changes.lastChange) as 'max(epochtime)' from ( \
select max(epochtime) as lastchange from plc   \
union all \
select max(epochtime) as lastchange from stereovision   \
union all \
select max(epochtime) as lastchange from motor_drive   \
union all \
select max(epochtime) as lastchange from event_log   \
union all \
select max(snoozeexittime) as lastchange from product  where product.snoozeexittime < unix_timestamp(current_timestamp()) ) changes")

/*
 UPDATE QUERIES
*/

define("plcupdatequery", "update plc set ? where deviceId = ?")

define("motordriveupdatequery", "update motor_drive set ? where deviceId = ?")

define("stereovisionupdatequery", "update stereovision set ? where deviceId = ?")

define("productupdatequery", "update product set ? where deviceId = ?")

define("userupdatequery", "update users set ? where id = ?")

/*
INSERT QUERIES
*/

define("userinsertquery", "insert into users set ?")

define("addcampusquery", "insert into campus set ?")
define("addbuildingquery", "insert into building set ?")
define("addentrancequery", "insert into entrance set ?")
define("addsubentrancequery", "insert into subentrance set ?")
    /*
    DELETE QUERIES
    */
define("userdeletequery", "delete from users where id = ?")
