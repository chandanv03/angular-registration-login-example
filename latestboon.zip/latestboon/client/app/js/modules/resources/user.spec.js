/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
 define([
  'angular-mocks',
  'Source/modules/resources/user',
  'Source/config'
  ], function(){

   describe('User', function () {
  	var mockUser, $httpBackend, url;

	  	beforeEach(angular.mock.module('app.resources.user'));

	  	beforeEach(angular.mock.module('app.constants', function ($provide) {
	    $provide.constant('CONFIG',{
	      url: 'http://localhost:3000/'
	    });
		}))

	  	beforeEach(angular.mock.inject(function (User, _$httpBackend_, CONFIG) {
	  		url = CONFIG.url;
	  		$httpBackend = _$httpBackend_;
	        mockUser = User;
		}))


	  	it('should test if resource is defined', function(){
	  		expect(mockUser).toBeDefined();
	  	})


   })



 })
