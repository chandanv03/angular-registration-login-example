/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
 define([
  'angular-mocks',
  'Source/modules/resources/snooze',
  'Source/modules/common/tokenSetter',
  'Source/config'
  ], function(){

   describe('TransactionCount', function () {
  	var mockSnooze, $httpBackend, url, token;

	  	beforeEach(angular.mock.module('app.resources.snooze'));

	  	beforeEach(module('ui.router'));

	  	beforeEach(angular.mock.module('app.common.token'));

	  	beforeEach(angular.mock.module('app.constants', function ($provide) {
	    $provide.constant('CONFIG',{
	      url: 'http://localhost:3000/'
	    });

		}))

	  	var state;
	  	beforeEach(angular.mock.inject(function (Snooze, _$httpBackend_, CONFIG, $state, TokenService) {
	  		url = CONFIG.url;
	  		$httpBackend = _$httpBackend_;
	        mockSnooze = Snooze;
	        state = $state;
          token= TokenService.getToken();
		}))

	  	it('should test if resource is defined', function(){
	  		expect(mockSnooze).toBeDefined();
	  	})

	  	it('should test if resource is defined', function(){
	  		expect(mockSnooze.putSnooze).toBeDefined();
	  	})

      it('should test the URL', function(){
        var payload = {
            snoozeExitTime: 10
        }
        $httpBackend.expect('PUT', url + 'doors/product?deviceId=10').respond(200, {result:'success'});
        mockSnooze.putSnooze(token).update({
            deviceId: 10
        }, payload);
        $httpBackend.flush();
      })
   })

 })
