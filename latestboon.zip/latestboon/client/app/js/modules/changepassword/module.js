define([
  'angular',
  'ui.router',
  'ui.bootstrap',
  'ui.bootstrap.treeview',
  '../validation/common',
  '../../config',
  '../resources/changepassword',
], function (angular) {
  return angular.module('app.changePassword', [
    'app.constants',
    'app.validation.common',
    'app.resources.changepassword',
    'ui.router',
    'ui.bootstrap',
  ])
})
