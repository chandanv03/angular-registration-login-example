/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
define([
    'angular-mocks',
    'Source/modules/editdoor/editdoorService',
    'Source/config'
], function() {

    describe('EditDoorService', function() {
        var mockEditDoorService, queryDeferred, mockEditDoor, q, mockChangeLog, mockTimeOfFlight, mockMotorDrive,
            mockPlcData, mockDoorData;

        beforeEach(angular.mock.module('app.editdoor'));

        beforeEach(angular.mock.module('app.common.token'));

        beforeEach(module(function($provide) {
            mockEditDoor = {
                getDoor: function() {
                    return {
                        get: function() {}
                    }
                }
            };
            mockChangeLog = {
                getChangeLog: function() {
                    return {
                        get: function() {}
                    }
                }
            }
            mockTimeOfFlight = {
                updateTOF: function() {
                    return {
                        update: function() {}
                    }
                },
                updateStereovisionImage: function() {
                    return {
                        update: function() {}
                    }
                }
            }
            mockMotorDrive = {
                updateMotor: function() {
                    return {
                        update: function() {}
                    }
                }
            }
            mockPlcData = {
                updatePlc: function() {
                    return {
                        update: function() {}
                    }
                }
            }
            mockDoorData = {
                updateDoor: function() {
                    return {
                        update: function() {}
                    }
                }
            }
            $provide.value('EditDoor', mockEditDoor);
            $provide.value('ChangeLog', mockChangeLog);
            $provide.value('TimeOfFlight', mockTimeOfFlight);
            $provide.value('MotorDrive', mockMotorDrive);
            $provide.value('PlcData', mockPlcData);
            $provide.value('DoorData', mockDoorData);
        }));

        beforeEach(angular.mock.inject(function(EditDoorService, $rootScope, $state, $location, $window, EditDoor, $q) {
            mockEditDoorService = EditDoorService
            q = $q
        }))

        it('should test EditDoorService is on its place', function() {
            expect(mockEditDoorService).toBeDefined()
        })

        it('should test if fetchDoorDetail is defined and called', function() {
            spyOn(mockEditDoorService, 'fetchDoorDetail').and.callThrough();
            spyOn(mockEditDoor, 'getDoor').and.callThrough()
            expect(mockEditDoorService.fetchDoorDetail).toBeDefined()
            mockEditDoorService.fetchDoorDetail()
            expect(mockEditDoorService.fetchDoorDetail).toHaveBeenCalled()
            expect(mockEditDoor.getDoor).toHaveBeenCalled()

        })

        it('should test if fetchChangeLog is defined and called', function() {
            spyOn(mockEditDoorService, 'fetchChangeLog').and.callThrough();
            spyOn(mockChangeLog, 'getChangeLog').and.callThrough()
            expect(mockEditDoorService.fetchChangeLog).toBeDefined()
            mockEditDoorService.fetchChangeLog()
            expect(mockEditDoorService.fetchChangeLog).toHaveBeenCalled()
            expect(mockChangeLog.getChangeLog).toHaveBeenCalled()
        })

        it('should test if putTimeofFlight is defined and called', function() {
            spyOn(mockEditDoorService, 'putTimeofFlight').and.callThrough();
            spyOn(mockTimeOfFlight, 'updateTOF').and.callThrough()
            expect(mockEditDoorService.putTimeofFlight).toBeDefined()
            mockEditDoorService.putTimeofFlight()
            expect(mockEditDoorService.putTimeofFlight).toHaveBeenCalled()
            expect(mockTimeOfFlight.updateTOF).toHaveBeenCalled()
        })

        it('should test if putMotorDrive is defined and called', function() {
            spyOn(mockEditDoorService, 'putMotorDrive').and.callThrough();
            spyOn(mockMotorDrive, 'updateMotor').and.callThrough()
            expect(mockEditDoorService.putMotorDrive).toBeDefined()
            mockEditDoorService.putMotorDrive()
            expect(mockEditDoorService.putMotorDrive).toHaveBeenCalled()
            expect(mockMotorDrive.updateMotor).toHaveBeenCalled()
        })


        it('should test if putDoorData is defined and called', function() {
            spyOn(mockEditDoorService, 'putDoorData').and.callThrough();
            spyOn(mockDoorData, 'updateDoor').and.callThrough()
            expect(mockEditDoorService.putDoorData).toBeDefined()
            mockEditDoorService.putDoorData()
            expect(mockEditDoorService.putDoorData).toHaveBeenCalled()
            expect(mockDoorData.updateDoor).toHaveBeenCalled()
        })

        it('should test if updateStereovisionImage is defined and called LTS', function() {
            spyOn(mockEditDoorService, 'updateStereovisionImage').and.callThrough();
            spyOn(mockTimeOfFlight, 'updateStereovisionImage').and.callThrough()
            expect(mockEditDoorService.updateStereovisionImage).toBeDefined()
            mockEditDoorService.updateStereovisionImage()
            expect(mockEditDoorService.updateStereovisionImage).toHaveBeenCalled()
            expect(mockTimeOfFlight.updateStereovisionImage).toHaveBeenCalled();
        })

    })

})
