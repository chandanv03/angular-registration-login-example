/**
 * Loader, user list of admin module components
 */
define([
'./adminController',
'./adminService',
'./userController',
'./userService'
], function () {})
