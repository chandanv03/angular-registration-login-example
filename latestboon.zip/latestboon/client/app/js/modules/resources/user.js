define([
  'angular',
  'ngResource'
], function (angular) {
  'use strict'

  return angular.module('app.resources.user', ['ngResource'])
    .service('User', function ($resource, CONFIG) {
      var checkUser = $resource(CONFIG.url + 'checkuser', { user: '@username', password: '@password' }, {
        method: 'GET',
        logout: {
          method: 'GET',
          params: {

          }
        },
        post: {
          method: 'POST',
          params: {
            user: '@username',
            password: '@password'
          }
        }
      })
      return checkUser
    })
})
