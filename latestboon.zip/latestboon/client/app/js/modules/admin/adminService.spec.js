/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
 define([
  'angular-mocks',
  'Source/modules/admin/adminService',
  'Source/config'
  ], function(){

  	   describe('adminService', function () {  
  	   		var mockAdminService, queryDeferred, q, mockadminList;

  	   		beforeEach(angular.mock.module('app.admin'));

  	   		beforeEach(angular.mock.module('app.common.token'));

          beforeEach(module(function($provide) {
            mockadminList = {
              getUsers: function() {
                return {get : function(){}}
              },

              deleteUser: function() {
                return {delete : function(){}}
              }
            };
            $provide.value('adminList', mockadminList);
          }));            
          
          beforeEach(angular.mock.module('app.constants', function ($provide) {
          $provide.constant('CONFIG',{
            url: 'http://nlboed01.sgti.nl:3000/'
          });


          }))          

  	   		beforeEach(angular.mock.inject(function(adminService, $rootScope, $state, $location, $window, $q){
				      mockAdminService = adminService   
              q=$q         
              deferred = $q.defer();
			    })) 

  			 it('should test adminService is on its place' , function(){
  			 		expect(mockAdminService).toBeDefined()
  			 })

         it('should test getUsers is on its place' , function(){
          expect(mockAdminService.getUsers).toBeDefined()
         })


         it('should test deleteUser is on its place' , function(){
          expect(mockAdminService.deleteUser).toBeDefined()
         })

         it('should test getUsers is called' , function(){
          spyOn(mockAdminService, 'getUsers').and.callThrough()
          spyOn(mockadminList, 'getUsers').and.callThrough()
          mockAdminService.getUsers()
          expect(mockAdminService.getUsers).toHaveBeenCalled()
          expect(mockadminList.getUsers).toHaveBeenCalled()
         })         

         it('should test deleteUser is called' , function(){
          spyOn(mockAdminService, 'deleteUser').and.callThrough()
          spyOn(mockadminList, 'deleteUser').and.callThrough()
          mockAdminService.deleteUser()
          expect(mockAdminService.deleteUser).toHaveBeenCalled()
          expect(mockadminList.deleteUser).toHaveBeenCalled()
         }) 
       
  	   })

 })