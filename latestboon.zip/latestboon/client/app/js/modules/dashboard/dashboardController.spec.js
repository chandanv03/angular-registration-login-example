define([
  'angular-mocks',
  'Source/modules/dashboard/dashboardController',
  'Source/modules/dashboard/graphService',
  'Source/modules/dashboard/dashboardTreeviewService',
  'Source/modules/dashboard/snoozeService',
  'Source/modules/dashboard/treeviewDirective',
  'Source/modules/common/tokenSetter',
  'Source/modules/common/userLevelService'
], function () {
    describe('DashboardController', function(){

      var scope, createController, q, state;

      beforeEach(angular.mock.module('app.dashboard'));

      beforeEach(angular.mock.module('app.common.token'));

	  beforeEach(angular.mock.module('app.common.userlevel'));


      var rootScope, mockGraphService, mockdashboardTreeviewService, mockTreeViewService, mockRejectionCount, mockTransactionCount, mockSnoozeService;

      var result = {
                                "campuses": [
                                  {
                                    "campusId": "boonCampus",
                                    "campusName": "boonCampus",
                                    "children": [
                                      {
                                        "buildingId": "boonBuilding",
                                        "buildingName": null,
                                        "children": [
                                          {
                                            "entranceId": "boonEntrance",
                                            "entranceName": "boonEntrance",
                                            "children": [
                                              {
                                                "subentranceId": "boonsub",
                                                "subentranceName": "subEntranceT",
                                                "doors": [
                                                  {
                                                    "id": 1,
                                                    "name": "Red door",
                                                    "nodeid": "+n+o8BvGI2e1UHlmoIa7s1l6m2c=",
                                                    "deviceID": "100",
                                                    "ip_number": "192.168.1.56",
                                                    "mac_address": "12:23:32:12:12:12",
                                                    "time_first_seen": 1448887937,
                                                    "time_last_seen": 1466518405,
                                                    "location": "Main building",
                                                    "product_type": "Tourlock",
                                                    "last_state": "OK",
                                                    "ce_number": "",
                                                    "hostname": "",
                                                    "latitude": "",
                                                    "longitude": "",
                                                    "timeZone": null,
                                                    "flag": 0,
                                                    "assigned": 1,
                                                    "doorstatus": 0
                                                  },
                                                  {
                                                    "id": 2,
                                                    "name": "Green door",
                                                    "nodeid": "FFDkfXfR0FeDivRvupdHg1znDDY=",
                                                    "deviceID": "101",
                                                    "ip_number": "192.168.1.22",
                                                    "mac_address": "12:23:32:12:12:34",
                                                    "time_first_seen": 1448887930,
                                                    "time_last_seen": 1466518405,
                                                    "location": "Main building",
                                                    "product_type": "Tourlock",
                                                    "last_state": "OK",
                                                    "ce_number": "",
                                                    "hostname": "",
                                                    "latitude": "",
                                                    "longitude": "",
                                                    "timeZone": null,
                                                    "flag": 0,
                                                    "assigned": 1,
                                                    "doorstatus": 0
                                                  },
                                                  {
                                                    "id": 3,
                                                    "name": "Yellow Door",
                                                    "nodeid": "23",
                                                    "deviceID": "102",
                                                    "ip_number": "192.169.0.12",
                                                    "mac_address": "12:12:33:34:33:34",
                                                    "time_first_seen": 1449479403,
                                                    "time_last_seen": 1467183890,
                                                    "location": "Main",
                                                    "product_type": "Cicle",
                                                    "last_state": "OK",
                                                    "ce_number": "",
                                                    "hostname": "",
                                                    "latitude": "",
                                                    "longitude": "",
                                                    "timeZone": null,
                                                    "flag": 0,
                                                    "assigned": 1,
                                                    "doorstatus": 1
                                                  },
                                                  {
                                                    "id": 4,
                                                    "name": "Bylorus RnD",
                                                    "nodeid": "uJjwO/cHKLEAN796FhFCkuEeKwU=",
                                                    "deviceID": "2",
                                                    "ip_number": "192.168.1.145",
                                                    "mac_address": "b8:ac:6f:2a:84:49",
                                                    "time_first_seen": 1454410367,
                                                    "time_last_seen": 1466518405,
                                                    "location": "Aambeeldstraat ",
                                                    "product_type": "Bylorus",
                                                    "last_state": "OK",
                                                    "ce_number": "",
                                                    "hostname": "",
                                                    "latitude": "",
                                                    "longitude": "",
                                                    "timeZone": null,
                                                    "flag": 0,
                                                    "assigned": 1,
                                                    "doorstatus": 0
                                                  },
                                                  {
                                                    "id": 6,
                                                    "name": "CppApp",
                                                    "nodeid": "aprg29ubXv3yOmxEXC9sBCabfgs=",
                                                    "deviceID": "3",
                                                    "ip_number": "192.168.1.121",
                                                    "mac_address": "00:00:00:00:00:00",
                                                    "time_first_seen": 1454410566,
                                                    "time_last_seen": 1466518405,
                                                    "location": "Walt",
                                                    "product_type": "None",
                                                    "last_state": "OK",
                                                    "ce_number": "",
                                                    "hostname": "",
                                                    "latitude": "",
                                                    "longitude": "",
                                                    "timeZone": null,
                                                    "flag": 0,
                                                    "assigned": 1,
                                                    "doorstatus": 0
                                                  },
                                                  {
                                                    "id": 7,
                                                    "name": "Wandboard Raymond",
                                                    "nodeid": "1wBCcz0aSFuKcUVbWJRsJCm6NaY=",
                                                    "deviceID": "5",
                                                    "ip_number": "192.168.1.150",
                                                    "mac_address": "00:00:00:00:00:00",
                                                    "time_first_seen": 2,
                                                    "time_last_seen": 1466518405,
                                                    "location": "Tafel Aambeeldstraat",
                                                    "product_type": "Bylorus",
                                                    "last_state": "OK",
                                                    "ce_number": "",
                                                    "hostname": "",
                                                    "latitude": "",
                                                    "longitude": "",
                                                    "timeZone": null,
                                                    "flag": 0,
                                                    "assigned": 1,
                                                    "doorstatus": 0
                                                  },
                                                  {
                                                    "id": 8,
                                                    "name": "Bylorus RnD Wandbboard",
                                                    "nodeid": "JAbmykU/TpSIAn6XF6PyP+Ub0JA=",
                                                    "deviceID": "4",
                                                    "ip_number": "192.168.1.52",
                                                    "mac_address": "00:1f:7b:b2:14:d6",
                                                    "time_first_seen": 1454410566,
                                                    "time_last_seen": 1466518405,
                                                    "location": "Aambeeldstraat",
                                                    "product_type": "Bylorus",
                                                    "last_state": "OK",
                                                    "ce_number": "",
                                                    "hostname": "",
                                                    "latitude": "",
                                                    "longitude": "",
                                                    "timeZone": null,
                                                    "flag": 0,
                                                    "assigned": 1,
                                                    "doorstatus": 0
                                                  },
                                                  {
                                                    "id": 9,
                                                    "name": "Bylorus RnD Wandbboard",
                                                    "nodeid": "CBZFdyMDg6KBbcF1GnuAUzAEwNY=",
                                                    "deviceID": "6",
                                                    "ip_number": "192.168.1.52",
                                                    "mac_address": "00:1f:7b:b2:14:d6",
                                                    "time_first_seen": 1454410566,
                                                    "time_last_seen": 1466518405,
                                                    "location": "Aambeeldstraat",
                                                    "product_type": "Bylorus",
                                                    "last_state": "OK",
                                                    "ce_number": "",
                                                    "hostname": "",
                                                    "latitude": "",
                                                    "longitude": "",
                                                    "timeZone": null,
                                                    "flag": 0,
                                                    "assigned": 1,
                                                    "doorstatus": 0
                                                  },
                                                  {
                                                    "id": 10,
                                                    "name": "Walt QT",
                                                    "nodeid": "epLVmKkUuw95mkR93o0HixFsrNU=",
                                                    "deviceID": "8",
                                                    "ip_number": "1",
                                                    "mac_address": "1",
                                                    "time_first_seen": 2,
                                                    "time_last_seen": 1466518405,
                                                    "location": "Bureau",
                                                    "product_type": "Bylorus",
                                                    "last_state": "",
                                                    "ce_number": "",
                                                    "hostname": "",
                                                    "latitude": "",
                                                    "longitude": "",
                                                    "timeZone": null,
                                                    "flag": 0,
                                                    "assigned": 1,
                                                    "doorstatus": 0
                                                  },
                                                  {
                                                    "id": 11,
                                                    "name": "cpp8",
                                                    "nodeid": "z7Mfqvc0JF858GhnQ8BduUcgkSE=",
                                                    "deviceID": "8881",
                                                    "ip_number": "2",
                                                    "mac_address": "2",
                                                    "time_first_seen": 21212,
                                                    "time_last_seen": 1466677434,
                                                    "location": "Erik",
                                                    "product_type": "TL",
                                                    "last_state": "OK",
                                                    "ce_number": "",
                                                    "hostname": "",
                                                    "latitude": "",
                                                    "longitude": "",
                                                    "timeZone": null,
                                                    "flag": 0,
                                                    "assigned": 1,
                                                    "doorstatus": 0
                                                  },
                                                  {
                                                    "id": 12,
                                                    "name": "Tony",
                                                    "nodeid": "jW+tcM+CyYj0f1SHpyqWR2KQvPQ=",
                                                    "deviceID": "999",
                                                    "ip_number": "1",
                                                    "mac_address": "1",
                                                    "time_first_seen": 1,
                                                    "time_last_seen": 1466677434,
                                                    "location": "Bureau",
                                                    "product_type": "Virtual",
                                                    "last_state": "OK",
                                                    "ce_number": "CE123",
                                                    "hostname": "",
                                                    "latitude": "",
                                                    "longitude": "",
                                                    "timeZone": null,
                                                    "flag": 0,
                                                    "assigned": 1,
                                                    "doorstatus": 0
                                                  },
                                                  {
                                                    "id": 13,
                                                    "name": "2theloo R&D",
                                                    "nodeid": "qdgvlkShMGNlRXV7bjjQmtJyeRw=",
                                                    "deviceID": "space",
                                                    "ip_number": "192.168.1.105",
                                                    "mac_address": "00:1F:7B:B2:14:D5",
                                                    "time_first_seen": 1460463903,
                                                    "time_last_seen": 1466581696,
                                                    "location": "R&D",
                                                    "product_type": "Bylorus",
                                                    "last_state": "",
                                                    "ce_number": "",
                                                    "hostname": "",
                                                    "latitude": "",
                                                    "longitude": "",
                                                    "timeZone": null,
                                                    "flag": 0,
                                                    "assigned": 1,
                                                    "doorstatus": 0
                                                  },
                                                  {
                                                    "id": 15,
                                                    "name": "Bylorus RnD Wandboard",
                                                    "nodeid": "cRx/9ZSD3Q9BdM3iLcSF+U9/5yY=",
                                                    "deviceID": "9",
                                                    "ip_number": "192.168.1.102",
                                                    "mac_address": "00:0C:29:79:18:69",
                                                    "time_first_seen": 2,
                                                    "time_last_seen": 1466518405,
                                                    "location": "Bas",
                                                    "product_type": "Bylorus",
                                                    "last_state": "",
                                                    "ce_number": "",
                                                    "hostname": "",
                                                    "latitude": "",
                                                    "longitude": "",
                                                    "timeZone": null,
                                                    "flag": 0,
                                                    "assigned": 1,
                                                    "doorstatus": 0
                                                  },
                                                  {
                                                    "id": 66,
                                                    "name": "BeConnect",
                                                    "nodeid": "m5BHuhq2jo7O4WtQGrxSW6DRXwU=",
                                                    "deviceID": "234",
                                                    "ip_number": "192.168.11.130",
                                                    "mac_address": "00:0C:29:E4:AE:41",
                                                    "time_first_seen": 3,
                                                    "time_last_seen": 1466518405,
                                                    "location": null,
                                                    "product_type": "Tourlock",
                                                    "last_state": "",
                                                    "ce_number": "",
                                                    "hostname": "",
                                                    "latitude": "",
                                                    "longitude": "",
                                                    "timeZone": null,
                                                    "flag": 0,
                                                    "assigned": 1,
                                                    "doorstatus": 0
                                                  },
                                                  {
                                                    "id": 67,
                                                    "name": "WaltBeConnect",
                                                    "nodeid": "dUEPULHAXR6szGQcqE+qbbOPXhY=",
                                                    "deviceID": "90001",
                                                    "ip_number": "192.168.136.147",
                                                    "mac_address": "00:0C:29:B9:B8:C2",
                                                    "time_first_seen": 1464160949,
                                                    "time_last_seen": 1466677434,
                                                    "location": null,
                                                    "product_type": "Tourlock",
                                                    "last_state": "",
                                                    "ce_number": "",
                                                    "hostname": "",
                                                    "latitude": "",
                                                    "longitude": "",
                                                    "timeZone": null,
                                                    "flag": 0,
                                                    "assigned": 1,
                                                    "doorstatus": 0
                                                  },
                                                  {
                                                    "id": 69,
                                                    "name": null,
                                                    "nodeid": "V1r0D1stvBUtcPfsqC+d0DgoOFg=",
                                                    "deviceID": "9009",
                                                    "ip_number": null,
                                                    "mac_address": null,
                                                    "time_first_seen": 0,
                                                    "time_last_seen": 1466677434,
                                                    "location": null,
                                                    "product_type": null,
                                                    "last_state": null,
                                                    "ce_number": "",
                                                    "hostname": "",
                                                    "latitude": null,
                                                    "longitude": null,
                                                    "timeZone": null,
                                                    "flag": 0,
                                                    "assigned": 1,
                                                    "doorstatus": 0
                                                  },
                                                  {
                                                    "id": 70,
                                                    "name": "Hasan",
                                                    "nodeid": "ie6UHv6qto5gtO51ytL8HvG4124=",
                                                    "deviceID": "666",
                                                    "ip_number": "1",
                                                    "mac_address": "1",
                                                    "time_first_seen": 1,
                                                    "time_last_seen": 1466518405,
                                                    "location": "Bureau",
                                                    "product_type": "Virtual",
                                                    "last_state": "OK",
                                                    "ce_number": "CE123",
                                                    "hostname": "",
                                                    "latitude": "",
                                                    "longitude": "",
                                                    "timeZone": null,
                                                    "flag": 0,
                                                    "assigned": 1,
                                                    "doorstatus": 0
                                                  }
                                                ]
                                              }
                                            ]
                                          }
                                        ]
                                      }
                                    ]
                                  }
                                ],
                                "rejections": [
                                  {
                                    "date": "2016-05-25",
                                    "TOF0PersonIn": 0,
                                    "TOF0PersonOut": 0,
                                    "TOF1PersonIn": 0,
                                    "TOF1PersonOut": 0,
                                    "TOF2PersonsIn": 90,
                                    "TOF2PersonsOut": 0,
                                    "BiometricRejection": 0,
                                    "SafetyRail": 126,
                                    "EmergencyButton": 186,
                                    "TOFSuspiciousIn": 0,
                                    "TOFSuspiciousOut": 0,
                                    "TOFRejection": 0,
                                    "TimeExceededinCabinCount": 0,
                                    "IllegalUse": 0
                                  },
                                  {
                                    "date": "2016-05-26",
                                    "TOF0PersonIn": 0,
                                    "TOF0PersonOut": 0,
                                    "TOF1PersonIn": 0,
                                    "TOF1PersonOut": 0,
                                    "TOF2PersonsIn": 180,
                                    "TOF2PersonsOut": 0,
                                    "BiometricRejection": 0,
                                    "SafetyRail": 252,
                                    "EmergencyButton": 372,
                                    "TOFSuspiciousIn": 0,
                                    "TOFSuspiciousOut": 0,
                                    "TOFRejection": 0,
                                    "TimeExceededinCabinCount": 0,
                                    "IllegalUse": 0
                                  },
                                  {
                                    "date": "2016-05-27",
                                    "TOF0PersonIn": 0,
                                    "TOF0PersonOut": 0,
                                    "TOF1PersonIn": 0,
                                    "TOF1PersonOut": 0,
                                    "TOF2PersonsIn": 180,
                                    "TOF2PersonsOut": 0,
                                    "BiometricRejection": 0,
                                    "SafetyRail": 252,
                                    "EmergencyButton": 372,
                                    "TOFSuspiciousIn": 0,
                                    "TOFSuspiciousOut": 0,
                                    "TOFRejection": 0,
                                    "TimeExceededinCabinCount": 0,
                                    "IllegalUse": 0
                                  },
                                  {
                                    "date": "2016-05-28",
                                    "TOF0PersonIn": 0,
                                    "TOF0PersonOut": 0,
                                    "TOF1PersonIn": 0,
                                    "TOF1PersonOut": 0,
                                    "TOF2PersonsIn": 180,
                                    "TOF2PersonsOut": 0,
                                    "BiometricRejection": 0,
                                    "SafetyRail": 252,
                                    "EmergencyButton": 372,
                                    "TOFSuspiciousIn": 0,
                                    "TOFSuspiciousOut": 0,
                                    "TOFRejection": 0,
                                    "TimeExceededinCabinCount": 0,
                                    "IllegalUse": 0
                                  },
                                  {
                                    "date": "2016-05-29",
                                    "TOF0PersonIn": 0,
                                    "TOF0PersonOut": 0,
                                    "TOF1PersonIn": 0,
                                    "TOF1PersonOut": 0,
                                    "TOF2PersonsIn": 90,
                                    "TOF2PersonsOut": 0,
                                    "BiometricRejection": 0,
                                    "SafetyRail": 126,
                                    "EmergencyButton": 186,
                                    "TOFSuspiciousIn": 0,
                                    "TOFSuspiciousOut": 0,
                                    "TOFRejection": 0,
                                    "TimeExceededinCabinCount": 0,
                                    "IllegalUse": 0
                                  }
                                ],
                                "transactions": []
                              }

      beforeEach(module(function($provide) {
        mockGraphService = {
          setSelectedNodeType: function() {},
          setRejectionData: function() {},
          setTransactionData: function() {},
          setSelectedNodeType: function() {},
          drawChart : function() {}
        };
        $provide.value('GraphService', mockGraphService);

        mockdashboardTreeviewService = {
          fetchDoors: function() {},
          filterDoorsData: function() {},
          setTransactionData: function() {},
          setSelectedNodeType: function() {}
        };
        $provide.value('DashboardTreeView', mockdashboardTreeviewService);

        mockSnoozeService = {
            setSnooze: function(){}
        }
        $provide.value('SnoozeService', mockSnoozeService);

        mockRejectionCount = {

        };
        $provide.value('RejectionCount', mockRejectionCount);


        mockTransactionCount = {

        };
        $provide.value('TransactionCount', mockTransactionCount);
      }));

      beforeEach(angular.mock.inject(function ($rootScope, $controller, $q, TreeViewService, $state, _$window_) {
               $window = _$window_
               rootScope = $rootScope;
               scope = $rootScope.$new();
               state = $state;
               createController = function() {
                  return $controller('DashboardController', {
                    '$scope': scope,
                    'GraphService' : mockGraphService,
                    'DashboardTreeView' : mockdashboardTreeviewService,
                    'TreeViewService' : TreeViewService
                  });
               };
               deferred = $q.defer();
               q= $q
               spyOn(mockdashboardTreeviewService, 'fetchDoors').and.returnValue(deferred.promise);
      }));

            it('should test if scope is on its place ', function(){
              createController();
              expect(scope).toBeDefined()
              expect(scope.title).toEqual('Dashboard Page')
            })

            it('should test if $scope.editDoor is called', function(){
              createController();
              var editDoor = {}
              expect(scope.editDoor).toBeDefined()
              var event = {}
              event.target = {}
              spyOn(state, 'go').and.returnValue(true)
              scope.editDoor(event)
              expect(state.go).toHaveBeenCalled()
            })

            it('should test if $scope.validateProperty is defined', function(){
              createController();
              expect(scope.validateProperty).toBeDefined()
            })

            it('should test if $scope.kpiRejections is defined', function(){
              var rejSeven = true;
              createController();
              expect(scope.kpiRejections).toBeDefined()
              spyOn(scope, 'last7days').and.callThrough()
              // spyOn(mockGraphService, 'drawChart').and.callThrough()
              scope.kpiRejections()
              expect(scope.activeMenu).toEqual('KPI Rejections')
              expect(scope.selc).toEqual(1)
              expect(scope.last7days).toHaveBeenCalled()
            })


            it('should test if $scope.last7days is defined and called', function(){
              createController();
              spyOn(mockGraphService, 'drawChart').and.callThrough()
              expect(scope.last7days).toBeDefined()
              scope.activeMenu = 'KPI Rejections';
              scope.last7days();
              expect(mockGraphService.drawChart).toHaveBeenCalled()
            })


            it('should test if $scope.last30days is defined and called', function(){
              createController();
              spyOn(mockGraphService, 'drawChart').and.callThrough()
              expect(scope.last30days).toBeDefined()
              scope.last30days();
              expect(mockGraphService.drawChart).toHaveBeenCalled()
              expect(scope.selc).toEqual(0)
            })

            it('should test if $scope.kpiPassages is defined and called', function(){
              createController();
              spyOn(mockGraphService, 'drawChart').and.callThrough()
              expect(scope.kpiPassages).toBeDefined()
              scope.kpiPassages();
              expect(scope.activeMenu).toEqual('KPI Passages')
              expect(scope.selc).toEqual(1)
              expect(scope.activeKpiRej).toEqual(0)
            })

            it('should test if promise is resolved if new value hasOwnProperty subentranceId', function() {
                var obj1 = {}
                var obj2 = {}
                obj1.subentranceId = {}
                obj1.doors = {}
                createController();
                spyOn(scope, '$watch').and.callThrough()
                spyOn(mockGraphService, 'setSelectedNodeType').and.callThrough()
                deferred.resolve(result); // Resolve the promise.
                scope.doorData = [obj1]
                scope.$digest();
                expect(scope.$watch).toHaveBeenCalled()
                expect(mockGraphService.setSelectedNodeType).toHaveBeenCalledWith(scope.doorData)
            });

            it('should test if promise is resolved if new value is undefined', function() {
                createController();
                spyOn(scope, '$watch').and.callThrough()
                spyOn(mockdashboardTreeviewService, 'filterDoorsData').and.callThrough()
                spyOn(mockGraphService, 'setRejectionData').and.callThrough()
                spyOn(mockGraphService, 'setTransactionData').and.callThrough()
                deferred.resolve(result); // Resolve the promise.
                scope.$digest();
                expect(scope.$watch).toHaveBeenCalled()
                expect(mockdashboardTreeviewService.filterDoorsData).toHaveBeenCalledWith(result.campuses)
                expect(mockGraphService.setRejectionData).toHaveBeenCalledWith(result.rejections)
                expect(mockGraphService.setTransactionData).toHaveBeenCalledWith(result.transactions)
            });

            it('should test if promise is resolved if newValue && !newValue[0].hasOwnProperty(\'doors\')', function() {
                var obj1 = {}
                createController();
                spyOn(scope, '$watch').and.callThrough()
                spyOn(mockGraphService, 'setSelectedNodeType').and.callThrough()
                deferred.resolve(result); // Resolve the promise.
                scope.doorData = [obj1]
                scope.$digest();
                expect(scope.$watch).toHaveBeenCalled()
                expect(mockGraphService.setSelectedNodeType).toHaveBeenCalledWith(scope.doorData)
            });

            it('should test exportRejectionSeven works fine', function() {
                createController();
                mockGraphService.lastSevendaysJson = [{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-16"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-17"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-18"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-19"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-20"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-21"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-22"}]
                result = scope.exportRejectionSeven()
                expect(result.length>0).toBeTruthy()
            });

            it('should test exportRejectionThirty works fine', function() {
                createController();
                mockGraphService.lastThirtydaysJson = [{"date":"2016-06-23","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-24","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-25","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-26","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-27","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-28","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-29","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-30","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-01","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-02","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-03","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-04","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-05"},{"date":"2016-07-06","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-07","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-08"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-09"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-10"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-11"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-12"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-13"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-14"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-15"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-16"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-17"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-18"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-19"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-20"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-21"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-22"}]
                result = scope.exportRejectionThirty()
                expect(result.length>0).toBeTruthy()
            });

            it('should test exportTransactionSeven works fine', function() {
                createController();
                mockGraphService.lastSevendaysTranscJson =[{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-16"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-17"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-18"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-19"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-20"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-21"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-22"}]
                result = scope.exportTransactionSeven()
                expect(result.length>0).toBeTruthy()
            });

            it('should test exportTransactionThirty works fine', function() {
                createController();
                mockGraphService.lastThirtydaysTranscJson = [{"date":"2016-06-23","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-24","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-25","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-26","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-27","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-28","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-29","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-30","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-01","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-02","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-03","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-04","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-05"},{"date":"2016-07-06","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-07","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-08"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-09"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-10"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-11"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-12"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-13"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-14"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-15"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-16"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-17"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-18"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-19"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-20"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-21"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-22"}]
                result = scope.exportTransactionThirty()
                expect(result.length>0).toBeTruthy()
            });

            it('should test toggleTree works fine', function() {
                createController();
                spyOn(state, 'go').and.returnValue(true)
                scope.toggleTree()
                expect(state.go).toHaveBeenCalledWith(state.current, {}, {reload: true})
                expect(rootScope.setSelected).toEqual(0)
            });

            it('should test fetchDoors works fine', function() {
                createController();
                spyOn(scope, '$watch').and.callThrough()
                spyOn(mockGraphService, 'setSelectedNodeType').and.callThrough()
                spyOn(mockGraphService, 'setRejectionData').and.callThrough()
                spyOn(mockGraphService, 'setTransactionData').and.callThrough()
                scope.treeselection = true
                var result = {"campuses":[{"campusId":1,"campusName":"CampusA","children":[{"buildingId":1,"buildingName":"BuildingAB","children":[{"entranceId":1,"entranceName":"EntranceABA","children":[{"subentranceId":1,"subentranceName":"SubEntranceABAA","doors":[{"id":146,"name":"TestDoor4","nodeid":"Node_id_2","deviceID":"879","ip_number":"123.123.123.124","mac_address":"AB12-EEFA-1234-1236","time_first_seen":2016,"time_last_seen":1469012713,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":3}]}]},{"entranceId":2,"entranceName":"EntranceAAA","children":[{"subentranceId":2,"subentranceName":"SubEntranceAAAA","doors":[{"id":143,"name":"TestDoor1","nodeid":"Node_id_1","deviceID":"876","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469101466,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4}]}]},{"entranceId":3,"entranceName":"EntranceABB","children":[{"subentranceId":3,"subentranceName":"SubEntranceABBA","doors":[{"id":144,"name":"TestDoor2","nodeid":"Node_id_2","deviceID":"877","ip_number":"123.123.123.124","mac_address":"AB12-EEFA-1234-1236","time_first_seen":2016,"time_last_seen":1469018053,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":3},{"id":147,"name":"TestDoor5","nodeid":"Node_id_1","deviceID":"880","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469016007,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4}]}]}]},{"buildingId":2,"buildingName":"BuildingAA","children":[{"entranceId":4,"entranceName":"EntranceAAB","children":[{"subentranceId":4,"subentranceName":"SubEntranceAABA","doors":[{"id":145,"name":"TestDoor4","nodeid":"Node_id_1","deviceID":"878","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469190220,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4}]}]}]}]}],"rejections":[{"date":"2016-05-28","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-05-29","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-05-30","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-05-31","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-01","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-02","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-03","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-04","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-05","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-06","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-07","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-08","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-09","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-10","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-11","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-12","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-13","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-14","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-15","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-16","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-17","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-18","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-19","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-20","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-21","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-22","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-23","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-24","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-25","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-26","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-27","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-28","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-29","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-30","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-01","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-02","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-03","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-04","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-06","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-07","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4}],"transactions":[{"date":"2016-06-25","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-26","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-27","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-28","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-29","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-30","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-01","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-02","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-03","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-04","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-06","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-07","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2}]}
                scope.fetchDoors()
                deferred.resolve(result)
                scope.$digest()

                // scope.doorData = [{"doors":[{"id":146,"name":"TestDoor4","nodeid":"Node_id_2","deviceID":"879","ip_number":"123.123.123.124","mac_address":"AB12-EEFA-1234-1236","time_first_seen":2016,"time_last_seen":1469012713,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":3,"$$hashKey":"object:145"},{"id":143,"name":"TestDoor1","nodeid":"Node_id_1","deviceID":"876","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469101466,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4,"$$hashKey":"object:141"},{"id":144,"name":"TestDoor2","nodeid":"Node_id_2","deviceID":"877","ip_number":"123.123.123.124","mac_address":"AB12-EEFA-1234-1236","time_first_seen":2016,"time_last_seen":1469018053,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":3,"$$hashKey":"object:144"},{"id":147,"name":"TestDoor5","nodeid":"Node_id_1","deviceID":"880","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469016007,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4,"$$hashKey":"object:143"},{"id":145,"name":"TestDoor4","nodeid":"Node_id_1","deviceID":"878","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469190220,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4,"$$hashKey":"object:142"}]}]
                scope.doorData = [{"campusId":1,"campusName":"CampusA","children":[{"buildingId":1,"buildingName":"BuildingAB","children":[{"entranceId":1,"entranceName":"EntranceABA","children":[{"subentranceId":1,"subentranceName":"SubEntranceABAA","doors":[{"id":146,"name":"TestDoor4","nodeid":"Node_id_2","deviceID":"879","ip_number":"123.123.123.124","mac_address":"AB12-EEFA-1234-1236","time_first_seen":2016,"time_last_seen":1469012713,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":3,"$$hashKey":"object:362"}],"$$hashKey":"object:300"}],"$$hashKey":"object:288"},{"entranceId":2,"entranceName":"EntranceAAA","children":[{"subentranceId":2,"subentranceName":"SubEntranceAAAA","doors":[{"id":143,"name":"TestDoor1","nodeid":"Node_id_1","deviceID":"876","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469101466,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4,"$$hashKey":"object:358"}],"$$hashKey":"object:314"}],"$$hashKey":"object:289"},{"entranceId":3,"entranceName":"EntranceABB","children":[{"subentranceId":3,"subentranceName":"SubEntranceABBA","doors":[{"id":144,"name":"TestDoor2","nodeid":"Node_id_2","deviceID":"877","ip_number":"123.123.123.124","mac_address":"AB12-EEFA-1234-1236","time_first_seen":2016,"time_last_seen":1469018053,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":3,"$$hashKey":"object:361"},{"id":147,"name":"TestDoor5","nodeid":"Node_id_1","deviceID":"880","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469016007,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4,"$$hashKey":"object:360"}],"$$hashKey":"object:328"}],"$$hashKey":"object:290"}],"$$hashKey":"object:278"},{"buildingId":2,"buildingName":"BuildingAA","children":[{"entranceId":4,"entranceName":"EntranceAAB","children":[{"subentranceId":4,"subentranceName":"SubEntranceAABA","doors":[{"id":145,"name":"TestDoor4","nodeid":"Node_id_1","deviceID":"878","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469190220,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4,"$$hashKey":"object:359"}],"$$hashKey":"object:350"}],"$$hashKey":"object:342"}],"$$hashKey":"object:279"}],"$$hashKey":"object:270"}]
                scope.$digest()
                expect(scope.treeselection).toBe(false)
                expect(mockGraphService.setSelectedNodeType).toHaveBeenCalledWith(scope.doorData)

                scope.doorData = undefined
                scope.$digest()
                if(result.hasOwnProperty('rejections')) {
                    expect(mockGraphService.setRejectionData).toHaveBeenCalledWith(result.rejections)
                }

                if (result.hasOwnProperty('transactions')) {
                    expect(mockGraphService.setTransactionData).toHaveBeenCalledWith(result.transactions)
                }

                scope.doorData = [{"subentranceId":1,"subentranceName":"SubEntranceABAA","doors":[{"id":146,"name":"TestDoor4","nodeid":"Node_id_2","deviceID":"879","ip_number":"123.123.123.124","mac_address":"AB12-EEFA-1234-1236","time_first_seen":2016,"time_last_seen":1469012713,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":3,"$$hashKey":"object:145"}],"$$hashKey":"object:83"}]
                scope.$digest()
                expect(mockGraphService.setSelectedNodeType).toHaveBeenCalledWith(scope.doorData)
            });


            it('should test if scope.validateProperty works fine', function(){
                    var ctrl = createController()
                    var reset = function(){
                      scope.param_msg = ''
                      scope.param_error_message = ''
                    }
                    ctrl.myService.selectedNode = {"doors":[{"id":146,"name":"TestDoor4","nodeid":"Node_id_2","deviceID":"879","ip_number":"123.123.123.124","mac_address":"AB12-EEFA-1234-1236","time_first_seen":2016,"time_last_seen":1469443119,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4,"$$hashKey":"object:143"},{"id":143,"name":"TestDoor1","nodeid":"Node_id_1","deviceID":"876","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469443119,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4,"$$hashKey":"object:141"},{"id":144,"name":"TestDoor2","nodeid":"Node_id_2","deviceID":"877","ip_number":"123.123.123.124","mac_address":"AB12-EEFA-1234-1236","time_first_seen":2016,"time_last_seen":1469443119,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4,"$$hashKey":"object:142"},{"id":147,"name":"TestDoor5","nodeid":"Node_id_1","deviceID":"880","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469443119,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4,"$$hashKey":"object:145"},{"id":145,"name":"TestDoor4","nodeid":"Node_id_1","deviceID":"878","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469443119,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4,"$$hashKey":"object:144"}]}
                    spyOn($window,'confirm').and.returnValue(true)
                    mockGraphService.selectedId = false
                    var mockData = {"accessToken":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiQm9vbkFkbWluIiwiaWF0IjoxNDgzNjAyNzczLCJleHAiOjE0ODM2MDMzNzN9.E1v0gpP8lg8nHMwRzJJGwOjUz-GP3dS9YhYH8swF1Ho","userName":"BoonAdmin","admin":true,"level1":false,"level2":false,"level3":false,"level4":false,"level5":true,"level6":false,"level7":false,"level8":false,"level9":true,"level10":false}
                    spyOn(JSON, 'parse').and.returnValue(mockData)
                    scope.paramform = {}
                    scope.paramform.$valid = {}
                    scope.parameter = 0
                    scope.newvalue = '119'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 120.0 to 600.0 (single digit after decimal)")
                    reset()

                    //negative test for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = '119.1'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 120.0 to 600.0 (single digit after decimal)")
                    reset()


                    //negative test for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = '119.11'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 120.0 to 600.0 (single digit after decimal)")
                    reset()


                    //negative test for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = '601'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 120.0 to 600.0 (single digit after decimal)")
                    reset()


                    //negative test for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = '601.1'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 120.0 to 600.0 (single digit after decimal)")
                    reset()


                    //negative test for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = '601.12'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 120.0 to 600.0 (single digit after decimal)")
                    reset()


                    //negative test for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = '599.11'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 120.0 to 600.0 (single digit after decimal)")
                    reset()

                    //negative test for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = '601'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 120.0 to 600.0 (single digit after decimal)")
                    reset()


                    //negative test for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = '600.11'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 120.0 to 600.0 (single digit after decimal)")
                    reset()

                    //negative test for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = '599.10'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 120.0 to 600.0 (single digit after decimal)")
                    reset()

                    //negative test for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = '600.00'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 120.0 to 600.0 (single digit after decimal)")
                    reset()

                    //negative test for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = '120.11'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 120.0 to 600.0 (single digit after decimal)")
                    reset()

                    //negative test for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = '-1'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 120.0 to 600.0 (single digit after decimal)")
                    reset()

                    //negative test for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = 'ADf'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 120.0 to 600.0 (single digit after decimal)")
                    reset()

                    //positive value for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = '120'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(1)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //positive value for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = '120.1'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(1)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //positive value for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = '599.1'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(1)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //positive value for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = '500'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(1)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //positive value for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = '600'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(1)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //positive value for CleaningTime
                    scope.parameter = 0
                    scope.newvalue = '600.0'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(1)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //negative test for open Time non-secured
                    scope.parameter = 1
                    scope.newvalue = '0.11'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual('Value should be between 5.0 to 12.5 (single digit after decimal)')
                    reset()

                    //negative test for open Time non-secured
                    scope.parameter = 1
                    scope.newvalue = '4.99'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 5.0 to 12.5 (single digit after decimal)")
                    reset()

                    //negative test for open Time non-secured
                    scope.parameter = 1
                    scope.newvalue = '13'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 5.0 to 12.5 (single digit after decimal)")
                    reset()

                    //negative test for open Time non-secured
                    scope.parameter = 1
                    scope.newvalue = '5.55'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 5.0 to 12.5 (single digit after decimal)")
                    reset()

                    //negative test for open Time non-secured
                    scope.parameter = 1
                    scope.newvalue = '12.55'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 5.0 to 12.5 (single digit after decimal)")
                    reset()

                    //negative test for open Time non-secured
                    scope.parameter = 1
                    scope.newvalue = '13'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 5.0 to 12.5 (single digit after decimal)")
                    reset()

                    //negative test for open Time non-secured
                    scope.parameter = 1
                    scope.newvalue = '13.55'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 5.0 to 12.5 (single digit after decimal)")
                    reset()

                    //negative test for open Time non-secured
                    scope.parameter = 1
                    scope.newvalue = '-5.0'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 5.0 to 12.5 (single digit after decimal)")
                    reset()

                    //negative test for open Time non-secured
                    scope.parameter = 1
                    scope.newvalue = 'A'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 5.0 to 12.5 (single digit after decimal)")
                    reset()

                    //positive test for open Time non-secured
                    scope.parameter = 1
                    scope.newvalue = '12.5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual('')
                    reset()


                    //positive test for open Time non-secured
                    scope.parameter = 1
                    scope.newvalue = '5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual('')
                    reset()

                    //positive test for open Time non-secured
                    scope.parameter = 1
                    scope.newvalue = '5.0'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual('')
                    reset()

                    //positive test for open Time non-secured
                    scope.parameter = 1
                    scope.newvalue = '12.5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual('')
                    reset()

                    //positive test for open Time non-secured
                    scope.parameter = 1
                    scope.newvalue = '8'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual('')
                    reset()

                    //positive test for open Time non-secured
                    scope.parameter = 1
                    scope.newvalue = '8.5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual('')
                    reset()


                    //negative test for open time secured
                    scope.parameter = 2
                    scope.newvalue = '0.11'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual('Value should be between 5.0 to 12.5 (single digit after decimal)')
                    reset()

                    //negative test for open Time secured
                    scope.parameter = 2
                    scope.newvalue = '4.99'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 5.0 to 12.5 (single digit after decimal)")
                    reset()

                    //negative test for open time secured
                    scope.parameter = 2
                    scope.newvalue = '13'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 5.0 to 12.5 (single digit after decimal)")
                    reset()

                    //negative test for open Time secured
                    scope.parameter = 2
                    scope.newvalue = '5.55'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 5.0 to 12.5 (single digit after decimal)")
                    reset()

                    //negative test for open Time secured
                    scope.parameter = 2
                    scope.newvalue = '12.55'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 5.0 to 12.5 (single digit after decimal)")
                    reset()

                    //negative test for open Time secured
                    scope.parameter = 2
                    scope.newvalue = '13'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 5.0 to 12.5 (single digit after decimal)")
                    reset()

                    //negative test for open Time secured
                    scope.parameter = 2
                    scope.newvalue = '13.55'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 5.0 to 12.5 (single digit after decimal)")
                    reset()

                    //negative test for open Time secured
                    scope.parameter = 2
                    scope.newvalue = '-5.0'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 5.0 to 12.5 (single digit after decimal)")
                    reset()

                    //negative test for open Time secured
                    scope.parameter = 2
                    scope.newvalue = 'A'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 5.0 to 12.5 (single digit after decimal)")
                    reset()

                    //positive test for open Time secured
                    scope.parameter = 2
                    scope.newvalue = '12.5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual('')
                    reset()


                    //positive test for open Time secured
                    scope.parameter = 2
                    scope.newvalue = '5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual('')
                    reset()

                    //positive test for open Time secured
                    scope.parameter = 2
                    scope.newvalue = '5.0'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual('')
                    reset()

                    //positive test for open Time secured
                    scope.parameter = 2
                    scope.newvalue = '12.5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual('')
                    reset()

                    //positive test for open Time secured
                    scope.parameter = 2
                    scope.newvalue = '8'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual('')
                    reset()

                    //positive test for open Time secured
                    scope.parameter = 2
                    scope.newvalue = '8.5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual('')
                    reset()

                    //negative test for return Signal time non-secured
                    scope.parameter = 3
                    scope.newvalue = '0.1'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 0.2 to 5.0 (single digit after decimal)")

                    //negative test for return Signal time non-secured
                    scope.parameter = 3
                    scope.newvalue = '6'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 0.2 to 5.0 (single digit after decimal)")

                    //negative test for return Signal time non-secured
                    scope.parameter = 3
                    scope.newvalue = 'A'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 0.2 to 5.0 (single digit after decimal)")

                    //negative test for return Signal time non-secured
                    scope.parameter = 3
                    scope.newvalue = '0.1A'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 0.2 to 5.0 (single digit after decimal)")

                    //negative test for return Signal time non-secured
                    scope.parameter = 3
                    scope.newvalue = '-0.5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 0.2 to 5.0 (single digit after decimal)")


                    //negative test for return Signal time non-secured
                    scope.parameter = 3
                    scope.newvalue = '4.55'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 0.2 to 5.0 (single digit after decimal)")
                    reset()

                    //positive test for return Signal time non-secured
                    scope.parameter = 3
                    scope.newvalue = '4.5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.param_msg).toEqual(1)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //positive test for return Signal time non-secured
                    scope.parameter = 3
                    scope.newvalue = '0.5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.param_msg).toEqual(1)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //positive test for return Signal time non-secured
                    scope.parameter = 3
                    scope.newvalue = '0.2'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.param_msg).toEqual(1)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //positive test for return Signal time non-secured
                    scope.parameter = 3
                    scope.newvalue = '4.9'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.param_msg).toEqual(1)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //positive test for return Signal time non-secured
                    scope.parameter = 3
                    scope.newvalue = '5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.param_msg).toEqual(1)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //positive test for return Signal time non-secured
                    scope.parameter = 3
                    scope.newvalue = '5.0'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.param_msg).toEqual(1)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //negative test for return Signal time secured
                    scope.parameter = 4
                    scope.newvalue = '0.1'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 0.2 to 5.0 (single digit after decimal)")

                    //negative test for return Signal time secured
                    scope.parameter = 4
                    scope.newvalue = '6'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 0.2 to 5.0 (single digit after decimal)")

                    //negative test for return Signal time secured
                    scope.parameter = 4
                    scope.newvalue = 'A'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 0.2 to 5.0 (single digit after decimal)")

                    //negative test for return Signal time secured
                    scope.parameter = 4
                    scope.newvalue = '0.1A'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 0.2 to 5.0 (single digit after decimal)")

                    //negative test for return Signal time secured
                    scope.parameter = 4
                    scope.newvalue = '-0.5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 0.2 to 5.0 (single digit after decimal)")


                    //negative test for return Signal time secured
                    scope.parameter = 4
                    scope.newvalue = '4.55'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 0.2 to 5.0 (single digit after decimal)")
                    reset()

                    //positive test for return Signal time secured
                    scope.parameter = 4
                    scope.newvalue = '4.5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.param_msg).toEqual(1)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //positive test for return Signal time secured
                    scope.parameter = 4
                    scope.newvalue = '0.5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.param_msg).toEqual(1)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //positive test for return Signal time secured
                    scope.parameter = 4
                    scope.newvalue = '0.2'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.param_msg).toEqual(1)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //positive test for return Signal time secured
                    scope.parameter = 4
                    scope.newvalue = '4.9'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.param_msg).toEqual(1)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //positive test for return Signal time secured
                    scope.parameter = 4
                    scope.newvalue = '5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.param_msg).toEqual(1)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //positive test for return Signal time secured
                    scope.parameter = 4
                    scope.newvalue = '5.0'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.param_msg).toEqual(1)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //negative test for step out before Alarm
                    scope.parameter = 5
                    scope.newvalue = '2.4'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual('Value should be between 2.5 to 12.5 (single digit after decimal)')
                    reset()

                    //negative test for step out before Alarm
                    scope.parameter = 5
                    scope.newvalue = '12.6'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual('Value should be between 2.5 to 12.5 (single digit after decimal)')

                    //negative test for step out before Alarm
                    scope.parameter = 5
                    scope.newvalue = '2.55'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual('Value should be between 2.5 to 12.5 (single digit after decimal)')

                    //negative test for step out before Alarm
                    scope.parameter = 5
                    scope.newvalue = '-2.5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual('Value should be between 2.5 to 12.5 (single digit after decimal)')

                    //negative test for step out before Alarm
                    scope.parameter = 5
                    scope.newvalue = 'A2.5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual('Value should be between 2.5 to 12.5 (single digit after decimal)')
                    reset()

                    //positive test for step out before Alarm
                    scope.parameter = 5
                    scope.newvalue = '2.5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual('')
                    reset()

                    //positive test for step out before Alarm
                    scope.parameter = 5
                    scope.newvalue = '12.5'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual('')
                    reset()

                    //positive test for step out before Alarm
                    scope.parameter = 5
                    scope.newvalue = '12.4'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual('')
                    reset()

                    //positive test for step out before Alarm
                    scope.parameter = 5
                    scope.newvalue = '2.6'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual('')
                    reset()


                    //negative test for Anti lock-in time
                    scope.parameter = 6
                    scope.newvalue = '9.0'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 10.0 to 60.0 (single digit after decimal)")
                    reset()

                    //negative test for Anti lock-in time
                    scope.parameter = 6
                    scope.newvalue = '10.11'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 10.0 to 60.0 (single digit after decimal)")
                    reset()

                    //negative test for Anti lock-in time
                    scope.parameter = 6
                    scope.newvalue = '60.1'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 10.0 to 60.0 (single digit after decimal)")
                    reset()

                    //negative test for Anti lock-in time
                    scope.parameter = 6
                    scope.newvalue = '60.00'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 10.0 to 60.0 (single digit after decimal)")
                    reset()

                    //negative test for Anti lock-in time
                    scope.parameter = 6
                    scope.newvalue = '-10.0'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 10.0 to 60.0 (single digit after decimal)")
                    reset()

                    //negative test for Anti lock-in time
                    scope.parameter = 6
                    scope.newvalue = '10.0A'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 10.0 to 60.0 (single digit after decimal)")
                    reset()

                    //negative test for Anti lock-in time
                    scope.parameter = 6
                    scope.newvalue = 'A'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 10.0 to 60.0 (single digit after decimal)")
                    reset()

                    //negative test for Anti lock-in time
                    scope.parameter = 6
                    scope.newvalue = '13.11'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 10.0 to 60.0 (single digit after decimal)")
                    reset()

                    //negative test for Anti lock-in time
                    scope.parameter = 6
                    scope.newvalue = '61'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 10.0 to 60.0 (single digit after decimal)")
                    reset()

                    //negative test for Anti lock-in time
                    scope.parameter = 6
                    scope.newvalue = '61.11'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 10.0 to 60.0 (single digit after decimal)")
                    reset()

                    //positive test for Anti lock-in time
                    scope.parameter = 6
                    scope.newvalue = '10.1'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //positive test for Anti lock-in time
                    scope.parameter = 6
                    scope.newvalue = '40'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //negative test for Lock switch
                    scope.parameter = 7
                    scope.newvalue = 1.1
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be either 0 or 1 (no decimals).")
                    reset()

                    //negative test for Lock switch
                    scope.parameter = 7
                    scope.newvalue = 0.1
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be either 0 or 1 (no decimals).")
                    reset()

                    //negative test for Lock switch
                    scope.parameter = 7
                    scope.newvalue = 1.9
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be either 0 or 1 (no decimals).")
                    reset()

                    //negative test for Lock switch
                    scope.parameter = 7
                    scope.newvalue = 10.1
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be either 0 or 1 (no decimals).")
                    reset()

                    //negative test for Lock switch
                    scope.parameter = 7
                    scope.newvalue = '-1'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be either 0 or 1 (no decimals).")
                    reset()

                    //negative test for Lock switch
                    scope.parameter = 7
                    scope.newvalue = 'A'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be either 0 or 1 (no decimals).")
                    reset()

                    //positive test for Lock switch
                    scope.parameter = 7
                    scope.newvalue = 1
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    //positive test for Lock switch
                    scope.parameter = 7
                    scope.newvalue = 0
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    expect(scope.param_error_message).toEqual("")
                    reset()

                    scope.parameter = 8
                    scope.newvalue = 0
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 1 to 9 (no decimals).")
                    reset()

                    scope.parameter = 8
                    scope.newvalue = 1.1
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 1 to 9 (no decimals).")
                    reset()

                    scope.parameter = 8
                    scope.newvalue = 9
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    reset()

                    scope.parameter = 8
                    scope.newvalue = 10
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 1 to 9 (no decimals).")
                    reset()

                    scope.parameter = 9
                    scope.newvalue = 0
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 1 to 9 (no decimals).")

                    scope.parameter = 9
                    scope.newvalue = 10
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 1 to 9 (no decimals).")
                    reset()

                    scope.parameter = 9
                    scope.newvalue = 9
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    reset()


                    scope.parameter = 9
                    scope.newvalue = 1
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    reset()

                    scope.parameter = 9
                    scope.newvalue = 5
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    reset()

                    scope.parameter = 9
                    scope.newvalue = 5.2
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 1 to 9 (no decimals).")
                    reset()

                    scope.parameter = 10
                    scope.newvalue = 0
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 1 to 9 (no decimals).")

                    scope.parameter = 10
                    scope.newvalue = -1
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 1 to 9 (no decimals).")

                    scope.parameter = 10
                    scope.newvalue = 'A'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 1 to 9 (no decimals).")

                    scope.parameter = 10
                    scope.newvalue = 10
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 1 to 9 (no decimals).")
                    reset()

                    scope.parameter = 10
                    scope.newvalue = 9
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    reset()


                    scope.parameter = 10
                    scope.newvalue = 1
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    reset()

                    scope.parameter = 10
                    scope.newvalue = 5
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    reset()

                    scope.parameter = 10
                    scope.newvalue = 5.2
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 1 to 9 (no decimals).")
                    reset()

                    scope.parameter = 11
                    scope.newvalue = 0
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 1 to 9 (no decimals).")

                    scope.parameter = 11
                    scope.newvalue = -1
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 1 to 9 (no decimals).")

                    scope.parameter = 11
                    scope.newvalue = 'A'
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 1 to 9 (no decimals).")

                    scope.parameter = 11
                    scope.newvalue = 10
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 1 to 9 (no decimals).")
                    reset()

                    scope.parameter = 11
                    scope.newvalue = 9
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    reset()


                    scope.parameter = 11
                    scope.newvalue = 1
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    reset()

                    scope.parameter = 11
                    scope.newvalue = 5
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).not.toEqual(3)
                    reset()

                    scope.parameter = 11
                    scope.newvalue = 5.2
                    rootScope.setSelected = false
                    scope.validateProperty()
                    expect(scope.treeselection).toEqual(true)
                    expect(scope.param_msg).toEqual(3)
                    expect(scope.param_error_message).toEqual("Value should be between 1 to 9 (no decimals).")
                    reset()
            })

            it('should test if $scope.last7days is defined and called', function(){
              createController();
              spyOn(mockGraphService, 'drawChart').and.callThrough()
              expect(scope.last7days).toBeDefined()
              scope.activeMenu = 'KPI Rejections';
              scope.last7days();
              expect(mockGraphService.drawChart).toHaveBeenCalled()
            })


            it('should test if $scope.last30days is defined and called', function(){
              createController();
              spyOn(mockGraphService, 'drawChart').and.callThrough()
              expect(scope.last30days).toBeDefined()
              scope.last30days();
              expect(mockGraphService.drawChart).toHaveBeenCalled()
              expect(scope.selc).toEqual(0)
            })

            it('should test if $scope.kpiPassages is defined and called', function(){
              createController();
              spyOn(mockGraphService, 'drawChart').and.callThrough()
              expect(scope.kpiPassages).toBeDefined()
              scope.kpiPassages();
              expect(scope.activeMenu).toEqual('KPI Passages')
              expect(scope.selc).toEqual(1)
              expect(scope.activeKpiPass).toEqual(0)
            })

            it('should test if promise is resolved if new value hasOwnProperty subentranceId', function() {
                var obj1 = {}
                var obj2 = {}
                obj1.subentranceId = {}
                obj1.doors = {}
                createController();
                spyOn(scope, '$watch').and.callThrough()
                spyOn(mockGraphService, 'setSelectedNodeType').and.callThrough()
                deferred.resolve(result); // Resolve the promise.
                scope.doorData = [obj1]
                scope.$digest();
                expect(scope.$watch).toHaveBeenCalled()
                expect(mockGraphService.setSelectedNodeType).toHaveBeenCalledWith(scope.doorData)
            });

            it('should test if promise is resolved if new value is undefined', function() {
                createController();
                spyOn(scope, '$watch').and.callThrough()
                spyOn(mockdashboardTreeviewService, 'filterDoorsData').and.callThrough()
                spyOn(mockGraphService, 'setRejectionData').and.callThrough()
                spyOn(mockGraphService, 'setTransactionData').and.callThrough()
                deferred.resolve(result); // Resolve the promise.
                scope.$digest();
                expect(scope.$watch).toHaveBeenCalled()
                expect(mockdashboardTreeviewService.filterDoorsData).toHaveBeenCalledWith(result.campuses)
            });

            it('should test if promise is resolved if newValue && !newValue[0].hasOwnProperty(\'doors\')', function() {
                var obj1 = {}
                createController();
                spyOn(scope, '$watch').and.callThrough()
                spyOn(mockGraphService, 'setSelectedNodeType').and.callThrough()
                deferred.resolve(result); // Resolve the promise.
                scope.doorData = [obj1]
                scope.$digest();
                expect(scope.$watch).toHaveBeenCalled()
                expect(mockGraphService.setSelectedNodeType).toHaveBeenCalledWith(scope.doorData)
            });


            it('should test exportRejectionSeven works fine', function() {
                createController();
                mockGraphService.lastSevendaysJson = [{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-16"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-17"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-18"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-19"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-20"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-21"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-22"}]
                result = scope.exportRejectionSeven()
                expect(result.length>0).toBeTruthy()
            });


            it('should test exportRejectionThirty works fine', function() {
                createController();
                mockGraphService.lastThirtydaysJson = [{"date":"2016-06-23","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-24","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-25","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-26","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-27","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-28","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-29","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-30","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-01","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-02","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-03","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-04","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-05"},{"date":"2016-07-06","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-07","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-08"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-09"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-10"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-11"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-12"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-13"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-14"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-15"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-16"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-17"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-18"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-19"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-20"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-21"},{"TOF2PersonsIn":0,"BiometricRejection":0,"SafetyRail":0,"EmergencyButton":0,"date":"2016-07-22"}]
                result = scope.exportRejectionThirty()
                expect(result.length>0).toBeTruthy()
            });

            it('should test exportTransactionSeven works fine', function() {
                createController();
                mockGraphService.lastSevendaysTranscJson =[{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-16"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-17"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-18"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-19"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-20"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-21"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-22"}]
                result = scope.exportTransactionSeven()
                expect(result.length>0).toBeTruthy()
            });

            it('should test exportTransactionThirty works fine', function() {
                createController();
                mockGraphService.lastThirtydaysTranscJson = [{"date":"2016-06-23","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-24","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-25","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-26","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-27","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-28","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-29","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-30","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-01","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-02","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-03","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-04","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-05"},{"date":"2016-07-06","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-07","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-08"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-09"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-10"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-11"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-12"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-13"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-14"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-15"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-16"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-17"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-18"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-19"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-20"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-21"},{"minimumTransactionTime":0,"averageTransactionTime":0,"maximumTransactionTime":0,"date":"2016-07-22"}]
                result = scope.exportTransactionThirty()
                expect(result.length>0).toBeTruthy()
            });

            it('should test toggleTree works fine', function() {
                createController();
                spyOn(state, 'go').and.returnValue(true)
                scope.toggleTree()
                expect(state.go).toHaveBeenCalledWith(state.current, {}, {reload: true})
                expect(rootScope.setSelected).toEqual(0)
            });

            it('should test fetchDoors works fine', function() {
                createController();
                spyOn(scope, '$watch').and.callThrough()
                spyOn(mockGraphService, 'setSelectedNodeType').and.callThrough()
                spyOn(mockGraphService, 'setRejectionData').and.callThrough()
                spyOn(mockGraphService, 'setTransactionData').and.callThrough()
                scope.treeselection = true
                var result = {"campuses":[{"campusId":1,"campusName":"CampusA","children":[{"buildingId":1,"buildingName":"BuildingAB","children":[{"entranceId":1,"entranceName":"EntranceABA","children":[{"subentranceId":1,"subentranceName":"SubEntranceABAA","doors":[{"id":146,"name":"TestDoor4","nodeid":"Node_id_2","deviceID":"879","ip_number":"123.123.123.124","mac_address":"AB12-EEFA-1234-1236","time_first_seen":2016,"time_last_seen":1469012713,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":3}]}]},{"entranceId":2,"entranceName":"EntranceAAA","children":[{"subentranceId":2,"subentranceName":"SubEntranceAAAA","doors":[{"id":143,"name":"TestDoor1","nodeid":"Node_id_1","deviceID":"876","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469101466,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4}]}]},{"entranceId":3,"entranceName":"EntranceABB","children":[{"subentranceId":3,"subentranceName":"SubEntranceABBA","doors":[{"id":144,"name":"TestDoor2","nodeid":"Node_id_2","deviceID":"877","ip_number":"123.123.123.124","mac_address":"AB12-EEFA-1234-1236","time_first_seen":2016,"time_last_seen":1469018053,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":3},{"id":147,"name":"TestDoor5","nodeid":"Node_id_1","deviceID":"880","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469016007,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4}]}]}]},{"buildingId":2,"buildingName":"BuildingAA","children":[{"entranceId":4,"entranceName":"EntranceAAB","children":[{"subentranceId":4,"subentranceName":"SubEntranceAABA","doors":[{"id":145,"name":"TestDoor4","nodeid":"Node_id_1","deviceID":"878","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469190220,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4}]}]}]}]}],"rejections":[{"date":"2016-05-28","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-05-29","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-05-30","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-05-31","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-01","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-02","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-03","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-04","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-05","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-06","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-07","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-08","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-09","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-10","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-11","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-12","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-13","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-14","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-15","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-16","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-17","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-18","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-19","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-20","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-21","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-22","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-23","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-24","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-25","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-26","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-27","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-28","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-29","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-06-30","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-01","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-02","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-03","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-04","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-06","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4},{"date":"2016-07-07","TOF0PersonIn":4,"TOF0PersonOut":4,"TOF1PersonIn":4,"TOF1PersonOut":4,"TOF2PersonsIn":4,"TOF2PersonsOut":4,"BiometricRejection":4,"SafetyRail":4,"EmergencyButton":4,"TOFSuspiciousIn":4,"TOFSuspiciousOut":4,"TOFRejection":4,"TimeExceededinCabinCount":4,"IllegalUse":4}],"transactions":[{"date":"2016-06-25","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-26","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-27","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-28","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-29","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-06-30","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-01","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-02","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-03","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-04","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-06","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2},{"date":"2016-07-07","averageTransactionTime":2,"minimumTransactionTime":2,"maximumTransactionTime":2}]}
                scope.fetchDoors()
                deferred.resolve(result)
                scope.$digest()

                // scope.doorData = [{"doors":[{"id":146,"name":"TestDoor4","nodeid":"Node_id_2","deviceID":"879","ip_number":"123.123.123.124","mac_address":"AB12-EEFA-1234-1236","time_first_seen":2016,"time_last_seen":1469012713,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":3,"$$hashKey":"object:145"},{"id":143,"name":"TestDoor1","nodeid":"Node_id_1","deviceID":"876","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469101466,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4,"$$hashKey":"object:141"},{"id":144,"name":"TestDoor2","nodeid":"Node_id_2","deviceID":"877","ip_number":"123.123.123.124","mac_address":"AB12-EEFA-1234-1236","time_first_seen":2016,"time_last_seen":1469018053,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":3,"$$hashKey":"object:144"},{"id":147,"name":"TestDoor5","nodeid":"Node_id_1","deviceID":"880","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469016007,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4,"$$hashKey":"object:143"},{"id":145,"name":"TestDoor4","nodeid":"Node_id_1","deviceID":"878","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469190220,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4,"$$hashKey":"object:142"}]}]
                scope.doorData = [{"campusId":1,"campusName":"CampusA","children":[{"buildingId":1,"buildingName":"BuildingAB","children":[{"entranceId":1,"entranceName":"EntranceABA","children":[{"subentranceId":1,"subentranceName":"SubEntranceABAA","doors":[{"id":146,"name":"TestDoor4","nodeid":"Node_id_2","deviceID":"879","ip_number":"123.123.123.124","mac_address":"AB12-EEFA-1234-1236","time_first_seen":2016,"time_last_seen":1469012713,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":3,"$$hashKey":"object:362"}],"$$hashKey":"object:300"}],"$$hashKey":"object:288"},{"entranceId":2,"entranceName":"EntranceAAA","children":[{"subentranceId":2,"subentranceName":"SubEntranceAAAA","doors":[{"id":143,"name":"TestDoor1","nodeid":"Node_id_1","deviceID":"876","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469101466,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4,"$$hashKey":"object:358"}],"$$hashKey":"object:314"}],"$$hashKey":"object:289"},{"entranceId":3,"entranceName":"EntranceABB","children":[{"subentranceId":3,"subentranceName":"SubEntranceABBA","doors":[{"id":144,"name":"TestDoor2","nodeid":"Node_id_2","deviceID":"877","ip_number":"123.123.123.124","mac_address":"AB12-EEFA-1234-1236","time_first_seen":2016,"time_last_seen":1469018053,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":3,"$$hashKey":"object:361"},{"id":147,"name":"TestDoor5","nodeid":"Node_id_1","deviceID":"880","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469016007,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4,"$$hashKey":"object:360"}],"$$hashKey":"object:328"}],"$$hashKey":"object:290"}],"$$hashKey":"object:278"},{"buildingId":2,"buildingName":"BuildingAA","children":[{"entranceId":4,"entranceName":"EntranceAAB","children":[{"subentranceId":4,"subentranceName":"SubEntranceAABA","doors":[{"id":145,"name":"TestDoor4","nodeid":"Node_id_1","deviceID":"878","ip_number":"123.123.123.123","mac_address":"AB12-EEFA-1234-1235","time_first_seen":2016,"time_last_seen":1469190220,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":4,"$$hashKey":"object:359"}],"$$hashKey":"object:350"}],"$$hashKey":"object:342"}],"$$hashKey":"object:279"}],"$$hashKey":"object:270"}]
                scope.$digest()
                expect(scope.treeselection).toBe(false)
                expect(mockGraphService.setSelectedNodeType).toHaveBeenCalledWith(scope.doorData)

                scope.doorData = undefined
                scope.$digest()
                if(result.hasOwnProperty('rejections')) {
                    expect(mockGraphService.setRejectionData).toHaveBeenCalledWith(result.rejections)
                }

                if (result.hasOwnProperty('transactions')) {
                    expect(mockGraphService.setTransactionData).toHaveBeenCalledWith(result.transactions)
                }

                scope.doorData = [{"subentranceId":1,"subentranceName":"SubEntranceABAA","doors":[{"id":146,"name":"TestDoor4","nodeid":"Node_id_2","deviceID":"879","ip_number":"123.123.123.124","mac_address":"AB12-EEFA-1234-1236","time_first_seen":2016,"time_last_seen":1469012713,"location":"location_1","product_type":" deur","last_state":"closed","ce_number":"ce_#01","hostname":"NLBOED01","latitude":null,"longitude":null,"timeZone":null,"flag":0,"assigned":1,"doorstatus":3,"$$hashKey":"object:145"}],"$$hashKey":"object:83"}]
                scope.$digest()
                expect(mockGraphService.setSelectedNodeType).toHaveBeenCalledWith(scope.doorData)
            });


            it('should test if scope.getColor works as expected', function(){
                createController()
                var res = scope.getColor(0)
                expect(res).toEqual('green')
                res = scope.getColor(1)
                expect(res).toEqual('grey')
                res = scope.getColor(2)
                expect(res).toEqual('yellow')
                res = scope.getColor(3)
                expect(res).toEqual('orange')
                res = scope.getColor(4)
                expect(res).toEqual('red')
                res = scope.getColor(5)
                expect(res).toEqual('blue')

            })

            it('should test if scope.getDoorStatus works as expected', function(){
                createController()
                var res = scope.getDoorStatus(0)
                expect(res).toEqual('Normal')
                res = scope.getDoorStatus(1)
                expect(res).toEqual('Snooze')
                res = scope.getDoorStatus(2)
                expect(res).toEqual('Notification')
                res = scope.getDoorStatus(3)
                expect(res).toEqual('Warning')
                res = scope.getDoorStatus(4)
                expect(res).toEqual('Alert')
                res = scope.getDoorStatus(5)
                expect(res).toEqual('Unassigned')

            })

            it('should test if scope.getSnoozeClass works as expected', function(){
                createController()
                var res = scope.getSnoozeClass(0)
                expect(res).toEqual('faSnoozeIcon')
                res = scope.getSnoozeClass(1)
                expect(res).toEqual('faUnsnoozeIcon')
                res = scope.getSnoozeClass(2)
                expect(res).toEqual('faSnoozeIcon')
                res = scope.getSnoozeClass(3)
                expect(res).toEqual('faSnoozeIcon')
                res = scope.getSnoozeClass(4)
                expect(res).toEqual('faSnoozeIcon')

            })

            it('should test if scope.snooze works as expected', function(){
                createController()
                var mockData = {"id":4,"username":"boonadmin","registrationdatetime":"2016-06-17T11:59:01.000Z","level1":1,"level2":1,"level3":1,"enabled":1,"country":null,"campus":"boonCampus","building":null,"entrance":null,"company_ID":null}
                spyOn(JSON, 'parse').and.returnValue(mockData);
                spyOn(mockSnoozeService, 'setSnooze').and.returnValue(deferred.promise)
                spyOn(scope, 'fetchDoors').and.callThrough()
                var dummyElement = document.createElement('a');
                var att = document.createAttribute("data-door-id");
                att.value = 877;
                var att = document.createAttribute("data-door-status");
                att.value = "4";
                dummyElement.setAttributeNode(att);
                var event = {}
                event.target = {};
                event.target.parentNode = dummyElement
                var data = {"success":true,"message":"Update successful."}
                scope.snooze(event)
                deferred.resolve(data)
                scope.$digest()
                expect(scope.fetchDoors).toHaveBeenCalled()

            })

            it('should check if current tab is active', function(){
              createController();
              scope.setActiveTab('activeKpiRej');
              var result = scope.isActiveTab('activeKpiRej');
              expect(result).toBeTruthy();
              scope.setActiveTab('activeKpiPass');
              result = scope.isActiveTab('activeKpiPass');
              expect(result).toBeTruthy();
              scope.setActiveTab('activeKpiPass');
              result = scope.isActiveTab('activeKpiRej');
              expect(result).not.toBeTruthy();
              scope.setActiveTab('activeKpiRej');
              result = scope.isActiveTab('activeKpiPass');
              expect(result).not.toBeTruthy();
            })

    })
})
