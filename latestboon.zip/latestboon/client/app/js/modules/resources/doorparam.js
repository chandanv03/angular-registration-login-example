define([
    'angular',
    'ngResource'
], function(angular) {
    'use strict'

    return angular.module('app.resources.doorparam', ['ngResource'])
        .service('DoorParam', function($resource, CONFIG, TokenService) {
            return {
                updateDoorParams: function(token) {
                    return $resource(CONFIG.url + 'updatedoorparameters ', {}, {
                        update: {
                            method: 'PUT',
                            isArray: false,
                            headers: {
                                'x-access-token': token,
                                'Content-Type': 'application/json'
                            },
                            params: {
                                doorParam: '@doorParam'
                            },
                            transformResponse: function(data, headers) {
                                //Check the response header for token expiry and new token.
                                var headers = headers()
                                TokenService.setResponseHeader(headers)
                                return angular.fromJson(data)
                            }

                        }
                    })

                }
            }
        })
})
