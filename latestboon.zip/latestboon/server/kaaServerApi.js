var config = require('./config.js')
var db = require('./database.js')
var queries = require('./sqlqueries.js')
var config = require('./config.js')
var request = require('request')
var querystring = require('querystring')

var motorKeyData = function (reqObj) {
  var motorData = {
    OutputFrequency: reqObj.OutputFrequency * 1,
    BaseFrequency: reqObj.BaseFrequency * 1,
    OutputCurrent: reqObj.OutputCurrent * 1,
    NormalSpeed: reqObj.NormalSpeed * 1,
    OutputVoltage: reqObj.OutputVoltage * 1,
    BaseVoltage: reqObj.BaseVoltage * 1,
    SlowSpeedOuter: reqObj.SlowSpeedOuter * 1,

  }
  return motorData
}

var executeKaaServerApi = function (req,  type, successCallback, errorCallback) {
  console.log('execute kaa server api')
  var user = req.user
  var deviceId = req.query.deviceId
  var passwordSql = queries.usernamebasedquery
  console.log('isPasswordCorrect ' + user)
  var returnPassword = null

  var cmdrows
  db.executeSelect('select command,type from notification_commands', 'nothing', function (err, cmdrows, columns) {
    if (err || cmdrows.length === 0) {
      console.log('no commands available')
      successCallback()
    } else {
      console.log('first row: ' , cmdrows[0].command)

      db.executeSelect(passwordSql, user, function (err, rows, columns) {
        if (err || rows.length === 0 || rows.length > 1) {
          console.log('An error occured, or the user does not exist.')
          returnPassword = null
        } else {
          var password = rows[0].password
          var updateData = req.body

          var myreq = {}
          for (var k in req.body) {
                  console.log('veld: ', k, 'value: ', req.body[k])
            var vk = req.body[k] * 1
            var keynaam = k.toLowerCase()
            var i = 0
            while (cmdrows[i]){
              if (cmdrows[i].command.toLowerCase() == k.toLowerCase()) {
                console.log('found: ', cmdrows[i].command)
                myreq[cmdrows[i].command] = vk

                /*Verify value of type from notification_commands is not empty or undefined
                  overwrite type from notification_commands
                */
                if(cmdrows[i].type!='' && cmdrows[i].type!='undefined'){
                  type=cmdrows[i].type
                }
              }
              i++
            }
          }
          console.log('myreq: ', myreq)
          console.log('Request ', req.body)
          updateData = myreq
          var responseBody = {
            'Header': {
              'user': user,
              'password': password,
              'deviceid': deviceId,
              'topic': 'Generic',
              'Type': type,
              'SubType': '0'
            },
            'KeyValueData': updateData
          }
          console.log('responseBody:', responseBody)
          request({
           // url: 'http://nlboed01.sgti.nl:9002/notification',
		    //url: 'http://kaaserver2.cloudapp.net:9002/notification',
			url: config.serverURL,
            method: 'POST',
            json: true, // <--Very important!!!
            body: responseBody
          }, function (error, response, body) {
            console.log(body)
            if (body !== undefined && body === 'Error') {
              errorCallback()
              console.log('error error')
            } else {
              console.log('match!')
              successCallback()
            }
          })
        }
      })

    }
  })

}
exports.executeKaaServerApi = executeKaaServerApi
