/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
 define([
  'angular-mocks',
  'Source/modules/resources/editdoor',
  'Source/modules/common/tokenSetter',
  'Source/config'
  ], function(){

   describe('EditDoor', function () {
  	var mockEditDoor, $httpBackend, url, token;

	  	beforeEach(angular.mock.module('app.resources.editdoor'));

	  	beforeEach(module('ui.router'));

	  	beforeEach(angular.mock.module('app.common.token'));

	  	beforeEach(angular.mock.module('app.constants', function ($provide) {
	    $provide.constant('CONFIG',{
	      url: 'http://localhost:3000/'
	    });


		}))

	  	var state;
	  	beforeEach(angular.mock.inject(function (EditDoor, _$httpBackend_, CONFIG, $state, TokenService, _$http_) {
	  		url = CONFIG.url;
        $http = _$http_
	  		$httpBackend = _$httpBackend_;
	        mockEditDoor = EditDoor;
	        state = $state
          token = TokenService.getToken();
		}))

	  	it('should test if resource is defined', function(){
	  		expect(mockEditDoor).toBeDefined();
	  	})

	  	it('should test if resource is defined', function(){
	  		expect(mockEditDoor.getDoor).toBeDefined();
	  	})

      // it('should test the URL', function(){
      //   $httpBackend.expect('GET', url + 'doors/detail?id=10').respond(200, {result:'success'});
      //   // mockEditDoor.getDoor(token).get();
      //   $http({
      //     url: url + 'doors/detail',
      //     method: "GET",
      //     params: {id: 10}
      //   });
      //   $httpBackend.flush();
      // })

      it('should test the URL', function(){
        $httpBackend.expect('GET', url + 'doors/detail?id=10').respond(200, {result:'success'});
        mockEditDoor.getDoor(token).get({id: 10});
        $httpBackend.flush();
      })

   })

 })
