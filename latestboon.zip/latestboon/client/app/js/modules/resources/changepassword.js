define([
    'angular',
    'ngResource'
], function(angular) {
    'use strict'
    return angular.module('app.resources.changepassword', ['ngResource'])
        .service('changePassword', function($resource, CONFIG, TokenService) {
            return {
                updatePassword: function(token) {

                    return $resource(CONFIG.url + 'changepassword', {}, {
                        save: {
                            method: 'POST',
                            headers: {
                                'x-access-token': token
                            },
                            transformResponse: function(data, headers) {
                                //Check the response header for token expiry and new token.
                                var headers = headers()
                                TokenService.setResponseHeader(headers)
                                return angular.fromJson(data)
                            }

                        }
                    })

                }
            }
        })
})
