/**
 * Dashboard controller definition
 */
define(['./module'], function(module) {
    module.controller('DashboardController', function($rootScope, $scope, $timeout, $window, $state, CONFIG, $interval, TreeViewService, DashboardTreeView, Doors, RejectionCount, TransactionCount, GraphService, SnoozeService, userLevelService, $filter) {
        $scope.title = 'Dashboard Page'
        $scope.kpi_graph = 0;
        $scope.kpi_transc_graph = 0;
        var self = this
        $rootScope.setSelected = 1
        $scope.param_error_message = ''
        self.myService = new TreeViewService
        self.treeselection = false
        var start = performance.now()


        $scope.exportRejectionSeven = function() {
            var rejSevenData = []
            var rejection = ''

            for (var i = 0; i < GraphService.lastSevendaysJson.length; i++) {
                var dte = $filter('date')(GraphService.lastSevendaysJson[i].date, 'dd-MMM')

                rejection = {
                    'campusName': GraphService.campusName,
                    'buildingName': GraphService.buildingName,
                    'entranceName': GraphService.entranceName,
                    'subentranceName': GraphService.subentranceName,
                    'Date': dte,
                    'BiometricRejectionCount': GraphService.lastSevendaysJson[i].BiometricRejection,
                    'TwoPersonRejectionCount': GraphService.lastSevendaysJson[i].TOF2PersonsIn,
                    'SrdRejectionCount': GraphService.lastSevendaysJson[i].SafetyRail,
                    'EmergencyRejectionCount': GraphService.lastSevendaysJson[i].EmergencyButton

                }
                rejSevenData.push(rejection)
            }

            return rejSevenData
        }

        $scope.exportRejectionThirty = function() {
            var rejThirtyData = []
            var rejection = ''

            for (var i = 0; i < GraphService.lastThirtydaysJson.length; i++) {
                var dte = $filter('date')(GraphService.lastThirtydaysJson[i].date, 'dd-MMM')

                rejection = {
                    'campusName': GraphService.campusName,
                    'buildingName': GraphService.buildingName,
                    'entranceName': GraphService.entranceName,
                    'subentranceName': GraphService.subentranceName,
                    'Date': dte,
                    'BiometricRejectionCount': GraphService.lastThirtydaysJson[i].BiometricRejection,
                    'TwoPersonRejectionCount': GraphService.lastThirtydaysJson[i].TOF2PersonsIn,
                    'SrdRejectionCount': GraphService.lastThirtydaysJson[i].SafetyRail,
                    'EmergencyRejectionCount': GraphService.lastThirtydaysJson[i].EmergencyButton

                }
                rejThirtyData.push(rejection)
            }

            return rejThirtyData
        }

        $scope.exportTransactionSeven = function() {
            var transSevenData = []
            var transaction = ''

            for (var i = 0; i < GraphService.lastSevendaysTranscJson.length; i++) {
                var dte = $filter('date')(GraphService.lastSevendaysTranscJson[i].date, 'dd-MMM')

                transaction = {
                    'campusName': GraphService.campusName,
                    'buildingName': GraphService.buildingName,
                    'entranceName': GraphService.entranceName,
                    'subentranceName': GraphService.subentranceName,
                    'Date': dte,
                    'Minimum duration': GraphService.lastSevendaysTranscJson[i].maximumTransactionTime,
                    'Maximum duration': GraphService.lastSevendaysTranscJson[i].minimumTransactionTime,
                    'Average duration': GraphService.lastSevendaysTranscJson[i].averageTransactionTime

                }
                transSevenData.push(transaction)
            }

            return transSevenData
        }

        $scope.exportTransactionThirty = function() {
            var transThirtyData = []
            var transaction = ''

            for (var i = 0; i < GraphService.lastThirtydaysTranscJson.length; i++) {
                var dte = $filter('date')(GraphService.lastThirtydaysTranscJson[i].date, 'dd-MMM')

                transaction = {
                    'campusName': GraphService.campusName,
                    'buildingName': GraphService.buildingName,
                    'entranceName': GraphService.entranceName,
                    'subentranceName': GraphService.subentranceName,
                    'Date': dte,
                    'Minimum duration': GraphService.lastThirtydaysTranscJson[i].maximumTransactionTime,
                    'Maximum duration': GraphService.lastThirtydaysTranscJson[i].minimumTransactionTime,
                    'Average duration': GraphService.lastThirtydaysTranscJson[i].averageTransactionTime

                }
                transThirtyData.push(transaction)
            }

            return transThirtyData
        }

        $scope.toggleTree = function() {
            $rootScope.setSelected = 0
            $state.go($state.current, {}, {
                reload: true
            })
        }

        var duration = '';
        // Watch the ngmodel scope value to apply range
        $scope.fetchDoors = function(node) {
            DashboardTreeView.fetchDoors().then(function(result) {
                self.myService.nodes = result.campuses
                duration = performance.now() - start;
                console.log('fetchDoors duration', duration)


                $scope.$watch('myService.selectedNode', function(newValue, oldValue) {
                    if (newValue && newValue[0] && !newValue[0].hasOwnProperty('doors')) {
                        $scope.treeselection = false
                        // Setting the selected capus,building,entrance,subentrance
                        GraphService.setSelectedNodeType(newValue, $scope.getActiveTab())
                        var selectedNode = DashboardTreeView.filterDoorsData(newValue)

                        self.myService.selectedNode = selectedNode
                    } else if (newValue === undefined) {
                        // Filter the door data for the selected campus,building, entrance, sub entrance
                        var selectedNode = DashboardTreeView.filterDoorsData(self.myService.nodes)
                        self.myService.selectedNode = selectedNode
                        // Set the rejection count graph data
                        if (result.hasOwnProperty('rejections')) {
                            GraphService.setRejectionData(result.rejections)
                        }
                        // Set the transaction data
                        if (result.hasOwnProperty('transactions')) {
                            GraphService.setTransactionData(result.transactions)
                        }

                        // check active tab
                        var activeKpiTab = $scope.getActiveTab()
                        if (activeKpiTab == 'activeKpiPass') {
                            if ($scope.kpi_transc_graph != 1) {
                                $scope.kpi_transc_graph = 0
                            }

                        } else {
                            if ($scope.kpi_graph != 1) {
                                $scope.kpi_graph = 0
                            }
                        }
                    } else if (newValue[0] && newValue[0].hasOwnProperty('subentranceId')) {
                        GraphService.setSelectedNodeType(newValue, $scope.getActiveTab())
                    }
                    if (self.myService.index >= 0) {
                        self.myService.reselectNode()
                        var selectedNode = DashboardTreeView.filterDoorsData(self.myService.nodes[self.myService.index])
                        self.myService.selectedNode = selectedNode
                    }
                }, true)

                $scope.$watch('doorData', function(newValue, oldValue) {
                    if (newValue && newValue[0] && !newValue[0].hasOwnProperty('doors')) {
                        $scope.treeselection = false
                        // Setting the selected capus,building,entrance,subentrance
                        GraphService.setSelectedNodeType(newValue, $scope.getActiveTab())
                        var selectedNode = DashboardTreeView.filterDoorsData(newValue)
                        self.myService.selectedNode = selectedNode
                    } else if (newValue === undefined) {
                        // Filter the door data for the selected campus,building, entrance, sub entrance
                        var selectedNode = DashboardTreeView.filterDoorsData(self.myService.nodes)
                        self.myService.selectedNode = selectedNode
                        // Set the rejection count graph data
                        if (result.hasOwnProperty('rejections')) {
                            GraphService.setRejectionData(result.rejections)
                        }
                        // Set the transaction data
                        if (result.hasOwnProperty('transactions')) {
                            GraphService.setTransactionData(result.transactions)
                        }
                        GraphService.kpiPassages = $scope.kpiPassages
                        GraphService.kpiRejections = $scope.kpiRejections
                        $scope.kpi_graph = 0
                        $scope.kpi_transc_graph = 0
                    } else if (newValue[0] && newValue[0].hasOwnProperty('subentranceId')) {
                        GraphService.setSelectedNodeType(newValue, $scope.getActiveTab())
                    }
                }, true)
            }, function(errorReult) {
                // TODO: Manage error page
                console.log('error', errorReult)
            })
        }
        $scope.fetchDoors()
        var interval = $interval(checkLastChange, CONFIG.CHECK_LAST_CHANGE)

        // Navigates to edit door/ door detail page
        $scope.editDoor = function(event) {
            var target = event.target
            var doorId = $(target.parentNode).data('door-id')
            $state.go('editdoor', {
                id: doorId
            })
        }

        setParameter = function() {
            if (!GraphService.selectedId) {
                $scope.treeselection = true
                $scope.param_msg = 1
            } else {
                var newvalue = $scope.newvalue
                if ($scope.parameter >= 0 && $scope.parameter <= 6) {
                    newvalue = $scope.newvalue * 10
                }

                if (GraphService.campusId != '' && GraphService.buildingId != '' && GraphService.entranceId != '' &&
                    GraphService.subentranceId != '') {
                    var doorParam = {
                        'parameterIndex': $scope.parameter,
                        'parameterValue': newvalue,
                        'campusID': GraphService.campusId,
                        'buildingID': GraphService.buildingId,
                        'entranceID': GraphService.entranceId,
                        'subEntranceID': GraphService.subentranceId
                    }
                } else if (GraphService.campusId != '' && GraphService.buildingId != '' && GraphService.entranceId != '' &&
                    GraphService.subentranceId == '') {
                    var doorParam = {
                        'parameterIndex': $scope.parameter,
                        'parameterValue': newvalue,
                        'campusID': GraphService.campusId,
                        'buildingID': GraphService.buildingId,
                        'entranceID': GraphService.entranceId
                    }
                } else if (GraphService.campusId != '' && GraphService.buildingId != '' && GraphService.entranceId == '' &&
                    GraphService.subentranceId == '') {
                    var doorParam = {
                        'parameterIndex': $scope.parameter,
                        'parameterValue': newvalue,
                        'campusID': GraphService.campusId,
                        'buildingID': GraphService.buildingId

                    }
                } else if (GraphService.campusId != '' && GraphService.buildingId == '' && GraphService.entranceId == '' &&
                    GraphService.subentranceId == '') {
                    var doorParam = {
                        'parameterIndex': $scope.parameter,
                        'parameterValue': newvalue,
                        'campusID': GraphService.campusId

                    }
                }

                DashboardTreeView.putDoorParam(doorParam).then(function(data) {
                        if (data.success == true) {
                            $scope.door_msg = data.message
                            $scope.param_msg = 0
                            $scope.decimal_msg = 0
                            $rootScope.setSelected = 0
                            $scope.treeselection = true
                        } else {
                            $scope.door_msg = 'Invalid data.'
                            $scope.param_msg = 1
                            $scope.decimal_msg = 1
                        }
                    },
                    function(error) {
                        console.log('Error Data', error)
                    })
            }
        }

        // To set the parameters to the selected campus,building,entrance,sub-ent
        $scope.validateProperty = function() {
            if ($scope.paramform.$valid) {
                if ($rootScope.setSelected) {
                    $scope.treeselection = true
                    $scope.param_msg = 1
                    $scope.decimal_msg = 1
                } else {
                    var parameterNames = [
                        'Cleaning Time',
                        'Open Time Non Secured Side',
                        'Open Time Secured Side',
                        'Return Signal Time Non Secured Side',
                        'Return Signal Time Secured Side',
                        'Step out before Alarm',
                        'Anti lock-in time',
                        'Lock Switch',
                        'SV Low Object Sensitivity',
                        'SV Sensor Blinding Sensitivity',
                        'SV One Person Sensitivity',
                        'SV More Person Sensitivity'
                    ]

                    var level5 = JSON.parse($window.sessionStorage.getItem('userInfo')).level5
                    var paramflag = userLevelService.canSetParameters(level5)

                    if (paramflag.iscustomerAdmin == 0 || paramflag.isserviceEmployee == 1 || paramflag.iscustomerHighestLevel == 1 || paramflag.issectionManager == 1) {
                        var valid = true
                        var nodecimal = /^\d*\.?0{0,1}$/
                        var oneDecimal = /^\d*\.?\d{0,1}$/ // to allow 1 digit after decimal

                        // CleaningTime
                        if ($scope.parameter == 0) { // Cleaning Time
                            if (!($scope.newvalue >= 120 && $scope.newvalue <= 600 && oneDecimal.test($scope.newvalue) == true)) {
                                $scope.param_msg = 3
                                $scope.param_error_message = 'Value should be between 120.0 to 600.0 (single digit after decimal)'
                                valid = false
                            }
                        } else if ($scope.parameter == 1) { // open Time non-secured
                            if (!($scope.newvalue >= 5 && $scope.newvalue <= 12.5 && oneDecimal.test($scope.newvalue) == true)) {
                                $scope.param_msg = 3
                                $scope.param_error_message = 'Value should be between 5.0 to 12.5 (single digit after decimal)'
                                valid = false
                            }
                        } else if ($scope.parameter == 2) { // open time secured
                            if (!($scope.newvalue >= 5 && $scope.newvalue <= 12.5 && oneDecimal.test($scope.newvalue) == true)) {
                                $scope.param_msg = 3
                                $scope.param_error_message = 'Value should be between 5.0 to 12.5 (single digit after decimal)'
                                valid = false
                            }
                        } else if ($scope.parameter == 3) { // return Signal time non-secured
                            if (!($scope.newvalue >= 0.2 && $scope.newvalue <= 5.0 && oneDecimal.test($scope.newvalue) == true)) {
                                $scope.param_msg = 3
                                $scope.param_error_message = 'Value should be between 0.2 to 5.0 (single digit after decimal)'
                                valid = false
                            }
                        } else if ($scope.parameter == 4) { // return Signal secured side
                            if (!($scope.newvalue >= 0.2 && $scope.newvalue <= 5.0 && oneDecimal.test($scope.newvalue) == true)) {
                                $scope.param_msg = 3
                                $scope.param_error_message = 'Value should be between 0.2 to 5.0 (single digit after decimal)'
                                valid = false
                            }
                        } else if ($scope.parameter == 5) { // step out before Alarm
                            if (!($scope.newvalue >= 2.5 && $scope.newvalue <= 12.5 && oneDecimal.test($scope.newvalue) == true)) {
                                $scope.param_msg = 3
                                $scope.param_error_message = 'Value should be between 2.5 to 12.5 (single digit after decimal)'
                                valid = false
                            }
                        } else if ($scope.parameter == 6) { // Anti lock-in time
                            if (!($scope.newvalue >= 10.0 && $scope.newvalue <= 60.0 && oneDecimal.test($scope.newvalue) == true)) {
                                $scope.param_msg = 3
                                $scope.param_error_message = 'Value should be between 10.0 to 60.0 (single digit after decimal)'
                                valid = false
                            }
                        } else if ($scope.parameter == 7) { // Lock switch
                            if (!($scope.newvalue >= 0 && $scope.newvalue <= 1 && nodecimal.test($scope.newvalue) == true)) {
                                $scope.param_msg = 3
                                $scope.param_error_message = 'Value should be either 0 or 1 (no decimals).'
                                valid = false
                            }
                        } else if ($scope.parameter >= 8 & $scope.parameter <= 11) {
                            if (!($scope.newvalue >= 1 && $scope.newvalue <= 9 && /^\d\.?0{0,1}$/.test($scope.newvalue))) {
                                $scope.param_msg = 3
                                $scope.param_error_message = 'Value should be between 1 to 9 (no decimals).'
                                valid = false
                            }
                        }

                        if (valid) {
                            var answer = confirm('Are you sure you want to update field ' + parameterNames[$scope.parameter] + ' with Value ' + $scope.newvalue + ' for ' + self.myService.selectedNode.doors.length + ' doors')
                            if (answer) {
                                setParameter()
                            } else {
                                event.preventDefault()
                            }
                        } else {
                            $scope.treeselection = true
                        }
                    } else {
                        alert('You need to be Customer Highest level or Service Engineer or Section Manager to modify data.')
                    }
                }
            }
        }


        var chartType = '',
            chartSevenDays = '',
            chartThirtyDays = '',
            rejSeven = true,
            passSeven = true
        // To reset the previous graph data
        var redrawChart = function(chartId) {
            var chartContainer = document.querySelector('#' + chartId + 'Cont')
            angular.element(chartContainer).html('')
            angular.element(chartContainer).html('<canvas id="' + chartId + '" class="responsive-class"></canvas>')
        }

        var kpiRejections = function() {
            $scope.kpi_graph = 1
            //$scope.kpi_transc_graph=0
            $scope.setActiveTab('activeKpiRej')
            $scope.activeMenu = 'KPI Rejections'
            $scope.selc = 1
            if (rejSeven) {
                $scope.last7days()
            } else {
                $scope.last30days()
            }
        }

        var kpiPassages = function() {
            $scope.kpi_graph = 0;
            // $scope.kpi_transc_graph=1
            $scope.setActiveTab('activeKpiPass')
            $scope.activeMenu = 'KPI Passages'
            $scope.selc = 1

            if (passSeven) {
                $scope.last7days()
            } else {
                $scope.last30days()
            }
        }

        // Save active tab to localStorage
        $scope.setActiveTab = function(activeTab) {
            $window.sessionStorage.setItem('activeTab', activeTab)
        }

        // Get active tab from localStorage
        $scope.getActiveTab = function() {
            return $window.sessionStorage.getItem('activeTab')
        }

        // Check if current tab is active
        $scope.isActiveTab = function(tabName) {
            var activeTab = $scope.getActiveTab()

            return (activeTab === tabName || (activeTab === null))
        }

        // KPI reject tab is selected
        $scope.kpiRejections = function(value) {
            if ($scope.currentValue != value) {
                kpiRejections()
            }
            $scope.currentValue = value
        }

        // KPI rejections clicked
        $scope.kpiRejectionsUI = function() {
            kpiRejections()
        }
        // Last 7 days tab selection for KPI rejection and passage
        $scope.last7days = function() {
            $scope.kpi_graph = 1
            $scope.kpi_transc_graph = 1
            if ($scope.activeMenu == 'KPI Rejections') {
                chartType = 'bar'
                chartSevenDays = 'rejectionSeven'
                rejSeven = true
            } else {
                chartType = 'line'
                chartSevenDays = 'passageSeven'
                passSeven = true
            }
            redrawChart(chartSevenDays)
            GraphService.drawChart(chartType, chartSevenDays)
        }
        // Last 30 days tab selection for KPI rejection and passage
        $scope.last30days = function() {
            $scope.kpi_graph = 1
            $scope.kpi_transc_graph = 1
            if ($scope.activeMenu == 'KPI Rejections') {
                chartType = 'bar'
                chartThirtyDays = 'rejectionThirty'
                rejSeven = false
            } else {
                chartType = 'line'
                chartThirtyDays = 'passageThirty'
                passSeven = false
            }
            $scope.selc = 0
            redrawChart(chartThirtyDays)
            GraphService.drawChart(chartType, chartThirtyDays)
        }
        // KPI passage tab is selected
        $scope.kpiPassages = function(value) {
            if ($scope.currentValue != value) {
                kpiPassages()
            }
            $scope.currentValue = value
        }

        //KPI Passeages clicked
        $scope.kpiPassagesUI = function() {
            kpiPassages()
        }


        $scope.getColor = function(doorStatus) {
            if (doorStatus == 0) {
                return 'green'
            } else if (doorStatus == 1) {
                return 'grey'
            } else if (doorStatus == 2) {
                return 'yellow'
            } else if (doorStatus == 3) {
                return 'orange'
            } else if (doorStatus == 4) {
                return 'red'
            } else if (doorStatus == 5) {
                return 'blue'
            }
        }
        $scope.getDoorStatus = function(doorStatus) {
            if (doorStatus == 0) {
                return 'Normal'
            } else if (doorStatus == 1) {
                return 'Snooze'
            } else if (doorStatus == 2) {
                return 'Notification'
            } else if (doorStatus == 3) {
                return 'Warning'
            } else if (doorStatus == 4) {
                return 'Alert'
            } else if (doorStatus == 5) {
                return 'Unassigned'
            }
        }
        $scope.getSnoozeClass = function(doorStatus) {
            if (doorStatus == CONFIG.DOOR_STATUS_NORMAL || doorStatus == CONFIG.DOOR_STATUS_NOTIFICATION || doorStatus == CONFIG.DOOR_STATUS_WARNING || doorStatus == CONFIG.DOOR_STATUS_ALERT) {
                return 'faSnoozeIcon'
            } else if (doorStatus == CONFIG.DOOR_STATUS_SNOOZE) {
                return 'faUnsnoozeIcon'
            }
        }
        $scope.snooze = function(event) {
            var level2 = JSON.parse($window.sessionStorage.getItem('userInfo')).level2
            var snoozeflag = userLevelService.canSnooze(level2)

            if (snoozeflag.iscustomerAdmin == 0 || snoozeflag.isserviceEmployee == 1 || snoozeflag.iscustomerHighestLevel == 1 || snoozeflag.issectionManager == 1) {
                var target = event.target
                var doorId = $(target.parentNode).data('door-id')
                var doorStatus = $(target.parentNode).data('door-status')
                var snoozeExitTime = (new Date).getTime()
                if (doorStatus == CONFIG.DOOR_STATUS_NORMAL || doorStatus == CONFIG.DOOR_STATUS_NOTIFICATION || doorStatus == CONFIG.DOOR_STATUS_WARNING || doorStatus == CONFIG.DOOR_STATUS_ALERT) {
                    snoozeExitTime = (new Date).getTime() + CONFIG.SNOOZE_TIME * CONFIG.TIME_MILLIS
                } else {
                    snoozeExitTime = snoozeExitTime - 1
                }
                snoozeExitTime = snoozeExitTime / 1000
                // set snooze
                SnoozeService.setSnooze(snoozeExitTime, doorId).then(function(data) {
                        if (data.success == true) {
                            var duration = performance.now() - start;
                            console.log('Snooze duration', duration)
                            $scope.fetchDoors()
                        } else {}
                    },
                    function(result) {
                        console.log('error data', result)
                    })
            } else {
                alert('You need to be Customer Highest level or Service Engineer or Section Manager to modify data.')
            }
        }

        // check selected tab and set tab
        var activeKpiTab = $window.sessionStorage.getItem('activeTab')
        if (activeKpiTab == 'activeKpiPass') {
            $scope.activeKpi = 1
            $scope.activeKpiPass = 0
        } else {
            $scope.activeKpi = 0
            $scope.activeKpiRej = 0
        }

        function checkLastChange() {
            DashboardTreeView.checkLastChange().then(function(data) {
                    if (data.success == true) {
                        // compare with stored value if different call fetchdoors
                        if (data.results != null) {
                            var time = data.results[0]['max(epochtime)']
                            var storedTime = $window.sessionStorage.getItem('lastChange')
                            if (storedTime == null) {
                                storedTime = 0
                            }

                            if (time > storedTime) {
                                $window.sessionStorage['lastChange'] = time
                                $scope.fetchDoors()
                            }
                        }
                    } else {}
                },
                function(result) {
                    console.log('error data', result)
                })
        }
    })
})
