// var express = require('express');
// var server = express();
// server.use(express.static(__dirname + '/app'));
// var port =  4000;
// server.listen(port, function(){
//    console.log("server listening on port " + port);
// });
var express = require('express')
var server = express()
server.use(express.static(__dirname + '/app'))
var port =  4000
var https = require('https')
var fs = require('fs')

var pk = fs.readFileSync(__dirname + '/privatekey.pem')
var pc = fs.readFileSync(__dirname + '/certificate.pem')
var opts = { key: pk, cert: pc }
https.createServer(opts,server).listen(port,  function() {
    console.log('https listening on: ' + port + '!')
})
