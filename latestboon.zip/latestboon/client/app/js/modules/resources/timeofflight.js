define([
    'angular',
    'ngResource'
], function(angular) {
    'use strict'

    return angular.module('app.resources.timeofflight', ['ngResource'])
        .service('TimeOfFlight', function($resource, CONFIG, TokenService) {
            return {
                updateTOF: function(token) {

                    return $resource(CONFIG.url + 'doors/stereovision', {
                        deviceId: '@id'
                    }, {
                        update: {
                            method: 'PUT',
                            isArray: false,
                            headers: {
                                'x-access-token': token,
                                'Content-Type': 'application/json'
                            },
                            params: {
                                tofData: '@tofData'
                            },
                            transformResponse: function(data, headers) {
                                //Check the response header for token expiry and new token.
                                var headers = headers()
                                TokenService.setResponseHeader(headers)
                                return angular.fromJson(data)
                            }

                        }
                    })

                },
                updateStereovisionImage: function(token) {

                    return $resource(CONFIG.url + 'doors/stereovisionimage', {
                        deviceId: '@id'
                    }, {
                        update: {
                            method: 'PUT',
                            isArray: false,
                            headers: {
                                'x-access-token': token,
                                'Content-Type': 'application/json'
                            },
                            params: {
                                jsonCommand: '@jsonCommand'
                            },
                            transformResponse: function(data, headers) {
                                //Check the response header for token expiry and new token.
                                var headers = headers()
                                TokenService.setResponseHeader(headers)
                                return angular.fromJson(data)
                            }

                        }
                    })

                }
            }
        })
})
