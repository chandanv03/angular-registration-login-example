/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
 define([
  'angular-mocks',
  'Source/modules/resources/changepassword',
  'Source/modules/common/tokenSetter',
  'Source/config'
  ], function(){

   describe('changePassword', function () {
  	var mockadminList, $httpBackend, url, token;

	  	beforeEach(angular.mock.module('app.resources.changepassword'));

	  	beforeEach(module('ui.router'));

	  	beforeEach(angular.mock.module('app.common.token'));

	  	beforeEach(angular.mock.module('app.constants', function ($provide) {
	    $provide.constant('CONFIG',{
	      url: 'http://localhost:3000/'
	    });


		}))

	  	var state;
	  	beforeEach(angular.mock.inject(function (changePassword, _$httpBackend_, CONFIG, $state, TokenService) {
	  		url = CONFIG.url;
	  		$httpBackend = _$httpBackend_;
	        mockchangePassword = changePassword;
	        state = $state;
          token = TokenService.getToken();
		}))


	  	it('should test if resource is defined', function(){
	  		expect(mockchangePassword).toBeDefined();
	  	})

      it('should test if resource is defined', function(){
        expect(mockchangePassword.updatePassword).toBeDefined();
      })

      it('should test the URL', function(){
        $httpBackend.expect('POST', url + 'changepassword').respond(200, {result:'success'});
        mockchangePassword.updatePassword(token).save();
        $httpBackend.flush();
      })

   })



 })
