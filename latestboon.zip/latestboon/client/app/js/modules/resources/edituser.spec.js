/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
 define([
  'angular-mocks',
  'Source/modules/resources/edituser',
  'Source/modules/common/tokenSetter',
  'Source/config'
  ], function(){

   describe('adminList', function () {
  	var mockeditUser, $httpBackend, url, token;

	  	beforeEach(angular.mock.module('app.resources.edituser'));

	  	beforeEach(module('ui.router'));

	  	beforeEach(angular.mock.module('app.common.token'));

	  	beforeEach(angular.mock.module('app.constants', function ($provide) {
	    $provide.constant('CONFIG',{
	      url: 'http://nlboed01.sgti.nl:3000/'
	    });


		}))

	  	var state;
	  	beforeEach(angular.mock.inject(function (editUser, _$httpBackend_, CONFIG, $state, TokenService) {
	  		url = CONFIG.url;
	  		$httpBackend = _$httpBackend_;
	        mockeditUser = editUser;
	        state = $state,
          token= TokenService.getToken();
		}))

	  	it('should test if resource is defined', function(){
	  		expect(mockeditUser).toBeDefined();
	  	})

	  	it('should test if adminList.getUsers is defined', function(){
	  		expect(mockeditUser.getUsersById).toBeDefined();
	  	})

	  	it('should test if adminList.getUsers.query is defined', function(){
	  		expect(mockeditUser.addUser).toBeDefined();
	  	})

	  	it('should test if adminList.getUsers.query is defined', function(){
	  		expect(mockeditUser.updateUserById).toBeDefined();
	  	})

      it('should test the URL', function(){
        $httpBackend.expect('GET', url + 'admin/getuser?id=10').respond(200, {result:'success'});
        mockeditUser.getUsersById(token).get({id: 10});
        $httpBackend.flush();
      })

      it('should test the URL', function(){
        $httpBackend.expect('POST', url + 'admin/adduser').respond(200, {result:'success'});
        mockeditUser.addUser(token).save();
        $httpBackend.flush();
      })

      it('should test the URL', function(){
        var payload = {
          id : 10
        }
        $httpBackend.expect('PUT', url + 'admin/changeuser?id=10').respond(200, {result:'success'});
        mockeditUser.updateUserById(token).update(payload);
        $httpBackend.flush();
      })
   })



 })
