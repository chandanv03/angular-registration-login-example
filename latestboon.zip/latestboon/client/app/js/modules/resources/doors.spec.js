/**
 * You can also write tests in CoffeeScript, see home-ctrl.spec.coffee
 */
 define([
  'angular-mocks',
  'Source/modules/resources/doors',
  'Source/modules/common/tokenSetter',
  'Source/config'
  ], function(){

   describe('Doors', function () {
  	var mockDoors, $httpBackend, url, token;

	  	beforeEach(angular.mock.module('app.resources.doors'));

		beforeEach(module('ui.router'));

		beforeEach(angular.mock.module('app.common.token'));

	  	beforeEach(angular.mock.module('app.constants', function ($provide) {
	    $provide.constant('CONFIG',{
	      url: 'https://localhost:3010/'
	    });


		}))

	  	beforeEach(angular.mock.inject(function (Doors, _$httpBackend_, CONFIG, TokenService) {
	  		url = CONFIG.url;
	  		$httpBackend = _$httpBackend_;
	        mockDoors = Doors;
          token = TokenService.getToken();
		}))


	  	it('should test if resource is defined', function(){
	  		expect(mockDoors).toBeDefined();
	  	})

	  	it('should test if resource is defined', function(){
	  		expect(mockDoors.getDoors).toBeDefined();
	  	})

	  	it('should test the URL', function(){
	  		$httpBackend.expect('GET', url + 'doors?path=v1').respond(200, {result:'success'});
        mockDoors.getDoors(token).get();
        $httpBackend.flush();
	  	})


   })



 })
