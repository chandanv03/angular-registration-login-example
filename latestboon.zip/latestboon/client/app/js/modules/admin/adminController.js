/**
 * Admin controller definition
 */
define(['./module'], function(module) {
    module.controller('adminController', function($scope, CONFIG, $window, $timeout, $state, adminService) {

        /*Fetch username from session*/
        if ($window.sessionStorage.getItem('userInfo') == null || $window.sessionStorage.getItem('userInfo') === 'null') {
            $state.go('login')
        }
        var userName = JSON.parse($window.sessionStorage.getItem('userInfo')).userName
        var isAdmin = JSON.parse($window.sessionStorage.getItem('userInfo')).admin

        /*check if user logged in*/
        if (userName == '' || userName == null) {
            $state.go('login')
        }

        if (isAdmin != true) {
            $state.go('dashboard')
        }

        /*initializing the user object*/
        $scope.users = ''

        /*function to get users list */
        $scope.getUsersList = function() {
            adminService.getUsers().then(function(res) {
                //if response is not null then assigned it to users
                if (res != null) {
                    $scope.users = res
                    $window.sessionStorage['usernamelist'] = JSON.stringify(res)

                }
            }, function(error) {
                //Manage error page
                $scope.errorNoDataMessage = 'No Users Found'
            })
        }
        //load users list
        $scope.getUsersList()
        $scope.getTypeOfAccount = function(user) {
            var message = ''

            if (user.level9 == 1) {
                message = 'Admin'
            } else if (user.level2 == 1 && user.level5 == 1 && user.level6 == null && user.level7 == null && user.level9 == null && user.level10 == null) {
                message = 'Section Manager'
            } else if (user.level2 == 1 && user.level5 == 1 && user.level6 == 1 && user.level7 == 1 && user.level9 == null && user.level10 == 1) {
                message = 'Service Engineer'
            } else if (user.level2 == 1 && user.level5 == 1 && user.level6 == null && user.level7 == 1 && user.level9 == null && user.level10 == 1) {
                message = 'Customer Highest Level'
            } else if (user.level2 == null && user.level5 == null && user.level6 == null && user.level7 == null && user.level9 == null && user.level10 == null) {
                message = 'Security Manager'
            }

            return message
        }


        /*function to load user by id for update*/
        $scope.editUser = function(event) {
            var id = event.currentTarget.getAttribute("data-id")
            $state.go('edituser', {
                id: id
            })
        }

        /*function to delete user by id*/
        $scope.deleteUser = function(event) {
            var answer = confirm("Are you sure you want to delete this user ?")
            if (answer) {
                var id = event.currentTarget.getAttribute("data-id")
                var allUsers = JSON.parse($window.sessionStorage.getItem('usernamelist'))

                angular.forEach(allUsers, function(value, key) {
                    if (id == value.id) {
                        //check if user tries to delete own account
                        if (value.username === userName) {
                            $scope.errorMessage = "User cann't delete his own account"
                            $timeout(function() {
                                $scope.errorMessage = false
                            }, CONFIG.LONG_VISUAL_DELAY)
                        } else {
                            adminService.deleteUser(id).then(function(res) {
                                //if response is not null then assigned it to users
                                if (res === true) {
                                    $scope.successMessage = "User deleted sucessfully."

                                    $scope.getUsersList()
                                    $timeout(function() {
                                        $scope.successMessage = false
                                    }, CONFIG.LONG_VISUAL_DELAY)
                                }
                            }, function(error) {
                                //Manage error page
                                $scope.errorMessage = "User cann't be deleted"
                                $timeout(function() {
                                    $scope.errorMessage = false
                                }, CONFIG.LONG_VISUAL_DELAY)
                            })
                        }
                    }
                })
            } else {
                event.preventDefault()
            }

        }
    })
})
