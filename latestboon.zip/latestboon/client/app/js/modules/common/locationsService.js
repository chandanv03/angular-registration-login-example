define([
    'angular',
    '../resources/locations'
], function(angular) {
    'use strict'

    return angular.module('app.common.locations', ['app.resources.locations'])
        .service('LocationsService', function($rootScope, $state, $q, TokenService, Locations) {
            var service = {
                getLocations: function() {

                    var payload = {

                    }
                    var deferred = $q.defer()
                    var get = Locations.getLocations(TokenService.getToken()).get({

                    }, payload, function(result) {
                        deferred.resolve(get)
                    }, function(result) {
                        if (result.status == 403) {
                            $rootScope.session_flag = 1
                            $rootScope.expiry = "Session Timed Out Kindly Login"
                            $state.go('login')
                        }
                        deferred.reject(get)
                    })

                    return deferred.promise
                }
            }

            return service
        })
})
