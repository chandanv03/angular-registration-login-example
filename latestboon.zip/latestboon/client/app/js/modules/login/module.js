define([
  'angular',
  'ui.router',
  'ngMessages',
  'base-64',
  '../resources/user',
  '../validation/common',
  '../../config'
], function (angular) {
  return angular.module('app.login', [
    'app.validation.common',
    'app.resources.user',
    'app.constants',
    'ui.router',
    'ngMessages'
  ])
})
