define([
    'angular',
    'ui.router',
    'ui.bootstrap',
    'smart-table',
    '../resources/admin',
    '../resources/edituser'
], function(angular) {
    return angular.module('app.admin', [
        'ui.router',
        'ui.bootstrap',
        'smart-table',
        'app.resources.admin',
        'app.resources.edituser'
    ])
})
