/**
 * Edit door controller definition
 */
define(['./module'], function(module) {
    module.controller('EditDoorController', function($rootScope, $scope, CONFIG, $http, $window, $state, $stateParams, $timeout, EditDoorService, DashboardTreeView, LocationsService, userLevelService) {
        var doorId = $stateParams.id
        $scope.isDorDataSaved = false
        $scope.tofSecondarySaved = false
        $scope.tofSaved = false
        $scope.mtrSaved = false
        $scope.settingReg = false

        $scope.countries = []
        $scope.campuses = []
        $scope.campusId = null
        $scope.buildings = []
        $scope.buildingId = null
        $scope.entrances = []
        $scope.entranceId = null
        $scope.subEntrances = []
        $scope.subEntranceId = null

        $scope.hide_door_fields = 0
        $scope.invaildrealName = 0
        $scope.invalidCamp = 0
        $scope.invalidBldng = 0
        $scope.invalidEntr = 0
        $scope.invalidSubEntr = 0

        $scope.loadingImg = false
        $scope.stereovisionCanvasSection = true
        $scope.brightness = 0
        $scope.minBrightness = 100
        $scope.maxBrightness = 200
        $scope.contrast = 0
        $scope.minContrast = 100
        $scope.maxContrast = 200

        $scope.editBrightness = function(brightness) {
            $scope.brightness = parseInt(brightness)
            $scope.processedImage()
        }
        $scope.editContrast = function(contrast) {
            $scope.contrast = parseInt(contrast)
            $scope.processedImage()
        }

        $scope.processedImage = function() {
            document.getElementById('stereovisionCanvas').style.filter = 'brightness(' + (100 + $scope.brightness) + '%)' + 'contrast(' + (100 + $scope.contrast) + '%)'
        }

        $scope.editFields = {
            editCampus: false,
            editEntrance: false,
            editBuilding: false,
            editSubEntrance: false
        }
        $scope.checkModel = {
            primary: true,
            secondary: false
        }

        $scope.original_time_of_flight_prim = []
        $scope.original_time_of_flight_sec = []
        $scope.original_motor_drive = []
        $scope.original_plc_data1 = []
        $scope.logData = []

        $scope.getChangeLog = function() {
            EditDoorService.fetchChangeLog(doorId).then(function(data) {
                    if (data.success == true) {
                        // compare with stored value if different call fetchdoors
                        if (data.results != null) {
                            $scope.logData = data.results
                        }
                    }
                },
                function(result) {
                    console.log('error data', result)
                })
        }
        var TimeOfFlightData = {}
        var TimeOfFlightData_sec = {}
        $scope.resetmsg = function() {
            $scope.plcdata1_message = ''
            $scope.mtrdrve_message = ''
            $scope.tof_message = ''
            $scope.tof_message_sec = ''
        }

        $scope.validateTimeFlight = function() {
            var level7 = JSON.parse($window.sessionStorage.getItem('userInfo')).level7
            var tofflag = userLevelService.canSetTimeOfFlight(level7)

            if (tofflag.iscustomerAdmin == 1 || tofflag.issectionManager == 1) {
                alert('You need to be Customer Highest level or Service Engineer to modify data.')
            } else {
                if ($scope.checkModel.secondary === false) {
                    var capture_counts = $scope.sliders.capture_counts
                    var height_canopy = $scope.sliders.height_canopy
                    var door_diameter = $scope.sliders.door_diameter
                    var x_shaft_1x = $scope.sliders.x_shaft_1x
                    var x_shaft_2x = $scope.sliders.x_shaft_2x
                    var x_shaft_11x = $scope.sliders.x_shaft_11x
                    var x_shaft_22x = $scope.sliders.x_shaft_22x

                    $scope.shaftflag = 0
                    $scope.shaftflagy = 0
                    $scope.capture_count_flag = 0
                    $scope.height_canopy_flag = 0
                    $scope.door_diameter_flag = 0

                    if ($scope.original_time_of_flight_prim.capture_counts != capture_counts) {
                        if (capture_counts == 1 || capture_counts == 0) {
                            $scope.capture_count_flag = 0
                            TimeOfFlightData['Primary_Log_OutputCounts'] = capture_counts
                        } else {
                            $scope.resetmsg()
                            $scope.capture_count_flag = 1
                            $scope.capture_counts_msg = 'Please Enter either 0 or 1 for Capture Output Counts.'
                        }
                    }

                    if ($scope.original_time_of_flight_prim.height_canopy != height_canopy) {
                        if (height_canopy == 2000 || height_canopy == 2100 || height_canopy == 2200 || height_canopy == 2300 || height_canopy == 2400 || height_canopy == 2500 || height_canopy == 2600) {
                            $scope.height_canopy_flag = 0
                            TimeOfFlightData['Primary_DoorSetting_HeightUnderCanopy'] = height_canopy
                        } else {
                            $scope.resetmsg()
                            $scope.height_canopy_flag = 1
                            $scope.height_canopy_msg = 'Please Enter one among these values for Height under Canopy : 2000, 2100, 2200, 2300, 2400, 2500, 2600'
                        }
                    }

                    if ($scope.original_time_of_flight_prim.door_diameter != door_diameter) {
                        if (door_diameter == 1800 || door_diameter == 1900 || door_diameter == 1981 || door_diameter == 2000 || door_diameter == 2100 || door_diameter == 2135 || door_diameter == 2200) {
                            $scope.door_diameter_flag = 0
                            TimeOfFlightData['Primary_DoorSetting_Diameter'] = door_diameter
                        } else {
                            $scope.resetmsg()
                            $scope.door_diameter_flag = 1
                            $scope.door_diameter_msg = 'Please Enter one among these values for Door Diameter: 1800, 1900, 1981, 2000, 2100, 2135, 2200'
                        }
                    }

                    if ($scope.original_time_of_flight_prim.x_shaft_1x != x_shaft_1x) {
                        if (x_shaft_1x > 171 || x_shaft_1x == undefined) {
                            $scope.resetmsg()
                            $scope.shaftflag = 1
                            $scope.shaftmsg = 'Please Enter value for Shaft Position 1 XAxes between 0-171'
                        } else {
                            TimeOfFlightData['Primary_DoorSetting_ShaftPosition1_X'] = x_shaft_1x
                        }
                    }

                    if ($scope.original_time_of_flight_prim.x_shaft_2x != x_shaft_2x) {
                        if (x_shaft_2x > 171 || x_shaft_2x == undefined) {
                            $scope.resetmsg()
                            $scope.shaftflag = 1
                            $scope.shaftmsg = 'Please Enter value Shaft Position 2 XAxes between 0-171'
                        } else {
                            TimeOfFlightData['Primary_DoorSetting_ShaftPosition2_X'] = x_shaft_2x
                        }
                    }

                    if ($scope.original_time_of_flight_prim.x_shaft_11x != x_shaft_11x) {
                        if (x_shaft_11x > 131 || x_shaft_11x == undefined) {
                            $scope.resetmsg()
                            $scope.shaftflagy = 1
                            $scope.shaftmsgy = 'Please Enter value for Shaft Position 1 Y Axes between 0-131'
                        } else {
                            TimeOfFlightData['Primary_DoorSetting_ShaftPosition1_Y'] = x_shaft_11x
                        }
                    }

                    if ($scope.original_time_of_flight_prim.x_shaft_22x != x_shaft_22x) {
                        if (x_shaft_22x > 131 || x_shaft_22x == undefined) {
                            $scope.resetmsg()
                            $scope.shaftflagy = 1
                            $scope.shaftmsgy = 'Please Enter value Shaft Position 2 Y Axes between 0-131'
                        } else {
                            TimeOfFlightData['Primary_DoorSetting_ShaftPosition2_Y'] = x_shaft_22x
                        }
                    }

                    if ($scope.original_time_of_flight_prim.capture_image != $scope.sliders.capture_image) {
                        TimeOfFlightData['Primary_Log_Capture'] = $scope.sliders.capture_image
                    }
                    if ($scope.original_time_of_flight_prim.sensor_direction != $scope.sliders.sensor_direction) {
                        TimeOfFlightData['Primary_DoorSetting_SensorDirection'] = $scope.sliders.sensor_direction
                    }
                    if ($scope.original_time_of_flight_prim.primary_door_setting_open != $scope.sliders.primary_door_setting_open) {
                        TimeOfFlightData['Primary_DoorSetting_DoorOpen'] = $scope.sliders.primary_door_setting_open
                    }
                    if ($scope.original_time_of_flight_prim.primary_door_setting_close != $scope.sliders.primary_door_setting_close) {
                        TimeOfFlightData['Primary_DoorSetting_DoorClose'] = $scope.sliders.primary_door_setting_close
                    }
                    if ($scope.original_time_of_flight_prim.wheel_chair != $scope.sliders.wheel_chair) {
                        TimeOfFlightData['Primary_DoorSetting_WheelChair'] = $scope.sliders.wheel_chair
                    }
                    if ($scope.original_time_of_flight_prim.verification_device != $scope.sliders.verification_device) {
                        TimeOfFlightData['Primary_DoorSetting_VerificationDevice'] = $scope.sliders.verification_device
                    }
                    if ($scope.original_time_of_flight_prim.lowObjValue != $scope.sliders.lowObjValue) {
                        TimeOfFlightData['Primary_Sensitivity_LowObject'] = $scope.sliders.lowObjValue
                    }
                    if ($scope.original_time_of_flight_prim.blindingValue != $scope.sliders.blindingValue) {
                        TimeOfFlightData['Primary_Sensitivity_SensorBlinding'] = $scope.sliders.blindingValue
                    }
                    if ($scope.original_time_of_flight_prim.onePersonValue != $scope.sliders.onePersonValue) {
                        TimeOfFlightData['Primary_Sensitivity_OnePerson'] = $scope.sliders.onePersonValue
                    }
                    if ($scope.original_time_of_flight_prim.morePersonValue != $scope.sliders.morePersonValue) {
                        TimeOfFlightData['Primary_Sensitivity_MorePerson'] = $scope.sliders.morePersonValue
                    }
                    if ($scope.original_time_of_flight_prim.volumeValue != $scope.sliders.volumeValue) {
                        TimeOfFlightData['Primary_Sensitivity_Volume'] = $scope.sliders.volumeValue
                    }
                    if ($scope.original_time_of_flight_prim.momentValue != $scope.sliders.momentValue) {
                        TimeOfFlightData['Primary_Sensitivity_Moment'] = $scope.sliders.momentValue
                    }

                    if (!angular.equals({}, TimeOfFlightData)) {
                        if ($scope.shaftflag == 0 && $scope.shaftflagy == 0 && $scope.capture_count_flag == 0 && $scope.height_canopy_flag == 0 && $scope.door_diameter_flag == 0) {
                            EditDoorService.putTimeofFlight(TimeOfFlightData, doorId).then(function(data) {
                                    if (data.success == true) {
                                        $scope.tofSaved = true
                                        $scope.tof_message = data.message
                                        $scope.status = 'success'
                                        $scope.original_time_of_flight_prim = angular.copy($scope.sliders)
                                        $scope.drawShapeOnPrimary()
                                    } else {
                                        $scope.tofSaved = true
                                        $scope.tof_message = data.message
                                        $scope.status = 'failed'
                                    }
                                },
                                function(result) {
                                    console.log('error data', result)
                                })
                        }
                    }
                } else {
                    var capture_counts_sec = $scope.sliders_sec.capture_counts_sec
                    var height_canopy_sec = $scope.sliders_sec.height_canopy_sec
                    var door_diameter_sec = $scope.sliders_sec.door_diameter_sec
                    var x_shaft_1x_sec = $scope.sliders_sec.x_shaft_1x_sec
                    var x_shaft_2x_sec = $scope.sliders_sec.x_shaft_2x_sec
                    var x_shaft_11x_sec = $scope.sliders_sec.x_shaft_11x_sec
                    var x_shaft_22x_sec = $scope.sliders_sec.x_shaft_22x_sec

                    $scope.shaftflag_sec = 0
                    $scope.shaftflag_secy = 0

                    $scope.capture_count_flag_sec = 0
                    $scope.height_canopy_flag_sec = 0
                    $scope.door_diameter_flag_sec = 0

                    if ($scope.original_time_of_flight_sec.capture_counts_sec != capture_counts_sec) {
                        if (capture_counts_sec == 1 || capture_counts_sec == 0) {
                            $scope.capture_count_flag_sec = 0
                            TimeOfFlightData_sec['Secondary_Log_OutputCounts'] = capture_counts_sec
                        } else {
                            $scope.resetmsg()
                            $scope.capture_count_flag_sec = 1
                            $scope.capture_counts_msg_sec = 'Please Enter either 0 or 1 for Capture Output Counts.'
                        }
                    }

                    if ($scope.original_time_of_flight_sec.height_canopy_sec != height_canopy_sec) {
                        if (height_canopy_sec == 2000 || height_canopy_sec == 2100 || height_canopy_sec == 2200 || height_canopy_sec == 2300 || height_canopy_sec == 2400 || height_canopy_sec == 2500 || height_canopy_sec == 2600) {
                            $scope.height_canopy_flag_sec = 0
                            TimeOfFlightData_sec['Secondary_DoorSetting_HeightUnderCanopy'] = height_canopy_sec
                        } else {
                            $scope.resetmsg()
                            $scope.height_canopy_flag_sec = 1
                            $scope.height_canopy_msg_sec = 'Please Enter one among these values for Height under Canopy  : 2000, 2100, 2200, 2300, 2400, 2500, 2600'
                        }
                    }

                    if ($scope.original_time_of_flight_sec.door_diameter_sec != door_diameter_sec) {
                        if (door_diameter_sec == 1800 || door_diameter_sec == 1900 || door_diameter_sec == 1981 || door_diameter_sec == 2000 || door_diameter_sec == 2100 || door_diameter_sec == 2135 || door_diameter_sec == 2200) {
                            $scope.door_diameter_flag_sec = 0
                            TimeOfFlightData_sec['Secondary_DoorSetting_Diameter'] = door_diameter_sec
                        } else {
                            $scope.resetmsg()
                            $scope.door_diameter_flag_sec = 1
                            $scope.door_diameter_msg_sec = 'Please Enter one among these values for Door Diameter : 1800, 1900, 1981, 2000, 2100, 2135, 2200'
                        }
                    }

                    if ($scope.original_time_of_flight_sec.x_shaft_1x_sec != x_shaft_1x_sec) {
                        if (x_shaft_1x_sec > 171 || x_shaft_1x_sec == undefined) {
                            $scope.resetmsg()
                            $scope.shaftflag_sec = 1
                            $scope.shaftmsgsec = 'Please Enter value between 0-171 for 1X Shaft Position'
                        } else {
                            TimeOfFlightData_sec['Secondary_DoorSetting_ShaftPosition1_X'] = x_shaft_1x_sec
                        }
                    }

                    if ($scope.original_time_of_flight_sec.x_shaft_11x_sec != x_shaft_11x_sec) {
                        if (x_shaft_11x_sec > 171 || x_shaft_11x_sec == undefined) {
                            $scope.resetmsg()
                            $scope.shaftflag_sec = 1
                            $scope.shaftmsgsec = 'Please Enter value between 0-171 for 2X Shaft Position'
                        } else {
                            TimeOfFlightData_sec['Secondary_DoorSetting_ShaftPosition2_X'] = x_shaft_11x_sec
                        }
                    }

                    if ($scope.original_time_of_flight_sec.x_shaft_2x_sec != x_shaft_2x_sec) {
                        if (x_shaft_2x_sec > 131 || x_shaft_2x_sec == undefined) {
                            $scope.resetmsg()
                            $scope.shaftflag_secy = 1
                            $scope.shaftmsgsecy = 'Please Enter value between 0-131 for 1Y Shaft Position'
                        } else {
                            TimeOfFlightData_sec['Secondary_DoorSetting_ShaftPosition1_Y'] = x_shaft_2x_sec
                        }
                    }

                    if ($scope.original_time_of_flight_sec.x_shaft_22x_sec != x_shaft_22x_sec) {
                        if (x_shaft_22x_sec > 131 || x_shaft_22x_sec == undefined) {
                            $scope.resetmsg()
                            $scope.shaftflag_secy = 1
                            $scope.shaftmsgsecy = 'Please Enter value between 0-131 for 2Y Shaft Position'
                        } else {
                            TimeOfFlightData_sec['Secondary_DoorSetting_ShaftPosition2_Y'] = x_shaft_22x_sec
                        }
                    }

                    if ($scope.original_time_of_flight_sec.capture_image_sec != $scope.sliders_sec.capture_image_sec) {
                        TimeOfFlightData_sec['Secondary_Log_Capture'] = $scope.sliders_sec.capture_image_sec
                    }
                    if ($scope.original_time_of_flight_sec.sensor_direction_sec != $scope.sliders_sec.sensor_direction_sec) {
                        TimeOfFlightData_sec['Secondary_DoorSetting_SensorDirection'] = $scope.sliders_sec.sensor_direction_sec
                    }
                    if ($scope.original_time_of_flight_sec.secondary_door_setting_open_sec != $scope.sliders_sec.secondary_door_setting_open_sec) {
                        TimeOfFlightData_sec['Secondary_DoorSetting_DoorOpen'] = $scope.sliders_sec.secondary_door_setting_open_sec
                    }
                    if ($scope.original_time_of_flight_sec.secondary_door_setting_close_sec != $scope.sliders_sec.secondary_door_setting_close_sec) {
                        TimeOfFlightData_sec['Secondary_DoorSetting_DoorClose'] = $scope.sliders_sec.secondary_door_setting_close_sec
                    }
                    if ($scope.original_time_of_flight_sec.wheel_chair_sec != $scope.sliders_sec.wheel_chair_sec) {
                        TimeOfFlightData_sec['Secondary_DoorSetting_WheelChair'] = $scope.sliders_sec.wheel_chair_sec
                    }
                    if ($scope.original_time_of_flight_sec.verification_device_sec != $scope.sliders_sec.verification_device_sec) {
                        TimeOfFlightData_sec['Secondary_DoorSetting_VerificationDevice'] = $scope.sliders_sec.verification_device_sec
                    }
                    if ($scope.original_time_of_flight_sec.lowObjValue_sec != $scope.sliders_sec.lowObjValue_sec) {
                        TimeOfFlightData_sec['Secondary_Sensitivity_LowObject'] = $scope.sliders_sec.lowObjValue_sec
                    }
                    if ($scope.original_time_of_flight_sec.blindingValue_sec != $scope.sliders_sec.blindingValue_sec) {
                        TimeOfFlightData_sec['Secondary_Sensitivity_SensorBlinding'] = $scope.sliders_sec.blindingValue_sec
                    }
                    if ($scope.original_time_of_flight_sec.onePersonValue_sec != $scope.sliders_sec.onePersonValue_sec) {
                        TimeOfFlightData_sec['Secondary_Sensitivity_OnePerson'] = $scope.sliders_sec.onePersonValue_sec
                    }
                    if ($scope.original_time_of_flight_sec.morePersonValue_sec != $scope.sliders_sec.morePersonValue_sec) {
                        TimeOfFlightData_sec['Secondary_Sensitivity_MorePerson'] = $scope.sliders_sec.morePersonValue_sec
                    }
                    if ($scope.original_time_of_flight_sec.volumeValue_sec != $scope.sliders_sec.volumeValue_sec) {
                        TimeOfFlightData_sec['Secondary_Sensitivity_Volume'] = $scope.sliders_sec.volumeValue_sec
                    }
                    if ($scope.original_time_of_flight_sec.momentValue_sec != $scope.sliders_sec.momentValue_sec) {
                        TimeOfFlightData_sec['Secondary_Sensitivity_Moment'] = $scope.sliders_sec.momentValue_sec
                    }

                    if (!angular.equals({}, TimeOfFlightData_sec)) {
                        if ($scope.shaftflag_sec == 0 && $scope.shaftflag_secy == 0 && $scope.capture_count_flag_sec == 0 &&
                            $scope.height_canopy_flag_sec == 0 && $scope.door_diameter_flag_sec == 0) {
                            EditDoorService.putTimeofFlight(TimeOfFlightData_sec, doorId).then(function(data) {
                                    if (data.success == true) {
                                        $scope.tofSaved = true
                                        $scope.tof_message_sec = data.message
                                        $scope.status = 'success'
                                        $scope.original_time_of_flight_sec = angular.copy($scope.sliders_sec)
                                        $scope.drawShapeOnSecondary()
                                    } else {
                                        $scope.tofSaved = true
                                        $scope.tof_message = data.message
                                        $scope.status = 'failed'
                                    }
                                },
                                function(result) {
                                    console.log('error data', result)
                                })
                        }
                    }
                }
            }
        }
        var mtrDriveData = {}
        var level6 = JSON.parse($window.sessionStorage.getItem('userInfo')).level6
        var mdplcflag = userLevelService.canSetPlcMotorDrive(level6)
        $scope.validateMotorDrive = function() {
            if (mdplcflag.isserviceEmployee == 0) {
                alert('You need to be Service Engineer to modify data.')
                $scope.mtr_drive = angular.copy($scope.original_motor_drive)
            } else {
                $scope.aecmsg1 = 0
                $scope.aecmsg2 = 0
                $scope.decmsg1 = 0
                $scope.decmsg2 = 0
                $scope.brktimemsg = 0
                $scope.brkpercentmsg = 0
                $scope.base_frequency_flag = 0
                $scope.base_voltage_flag = 0
                $scope.normal_speed_flag = 0
                $scope.slow_speed_outer_flag = 0
                $scope.slow_speed_inner_flag = 0

                var nodecimal = /^\d*\.?0{0,1}$/ // no decimal allowed
                var twoDecimal = /^\d*\.?\d{0,2}$/ // to allow 2 digit after decimal
                var oneDecimal = /^\d*\.?\d{0,1}$/ // to allow 1 digit after decimal
                var break_percent_val = ''
                var base_freqncy_val = ''
                var base_voltage_val = ''

                mtrDriveData = {}
                if ($scope.original_motor_drive.base_frequency != $scope.mtr_drive.base_frequency) {
                    var base_frequency_res = twoDecimal.test($scope.mtr_drive.base_frequency)
                    if ($scope.mtr_drive.base_frequency < 30 || $scope.mtr_drive.base_frequency > 80 || $scope.mtr_drive.base_frequency == undefined || base_frequency_res == false) {
                        $scope.resetmsg()
                        $scope.base_frequency_flag = 1
                        $scope.base_frequency_msg = 'Please Enter Base Frequency value between 30.00-80.00 (two digit after decimal)'
                    } else {
                        base_freqncy_val = $scope.mtr_drive.base_frequency * 100
                        mtrDriveData['BaseFrequency'] = base_freqncy_val
                    }
                }
                if ($scope.original_motor_drive.base_voltage != $scope.mtr_drive.base_voltage) {
                    var base_voltage_res = oneDecimal.test($scope.mtr_drive.base_voltage)
                    if ($scope.mtr_drive.base_voltage < 75 || $scope.mtr_drive.base_voltage > 150 || $scope.mtr_drive.base_voltage == undefined || base_voltage_res == false) {
                        $scope.resetmsg()
                        $scope.base_voltage_flag = 1
                        $scope.base_voltage_msg = 'Please Enter Base Voltage value between 75.0-150.0 (single digit after decimal)'
                    } else {
                        base_voltage_val = $scope.mtr_drive.base_voltage * 10
                        mtrDriveData['BaseVoltage'] = base_voltage_val
                    }
                }
                if ($scope.original_motor_drive.normal_speed != $scope.mtr_drive.normal_speed) {
                    var normal_speed_res = twoDecimal.test($scope.mtr_drive.normal_speed)
                    if ($scope.mtr_drive.normal_speed < 35 || $scope.mtr_drive.normal_speed > 50 || $scope.mtr_drive.normal_speed == undefined || normal_speed_res == false) {
                        $scope.resetmsg()
                        $scope.normal_speed_flag = 1
                        $scope.normal_speed_msg = 'Please Enter Normal Speed value between 35.00-50.00 (two digit after decimal)'
                    } else {
                        var normal_speed_val = $scope.mtr_drive.normal_speed * 100
                        mtrDriveData['NormalSpeed'] = normal_speed_val
                    }
                }

                if ($scope.original_motor_drive.slow_speed_outer != $scope.mtr_drive.slow_speed_outer) {
                    var slow_speed_outer_res = twoDecimal.test($scope.mtr_drive.slow_speed_outer)
                    if ($scope.mtr_drive.slow_speed_outer < 5 || $scope.mtr_drive.slow_speed_outer > 10 || slow_speed_outer_res == false) {
                        $scope.resetmsg()
                        $scope.slow_speed_outer_flag = 1
                        $scope.slow_speed_outer_msg = 'Please Enter Slow Speed Non-Secured (Hz) value between 5.00-10.00 (two digit after decimal)'
                    } else {
                        var slow_speed_outer_val = $scope.mtr_drive.slow_speed_outer * 100
                        mtrDriveData['SlowSpeedOuter'] = slow_speed_outer_val
                    }
                }

                if ($scope.original_motor_drive.slow_speed_inner != $scope.mtr_drive.slow_speed_inner) {
                    var slow_speed_inner_res = twoDecimal.test($scope.mtr_drive.slow_speed_inner)
                    if ($scope.mtr_drive.slow_speed_inner < 5 || $scope.mtr_drive.slow_speed_inner > 10 || $scope.mtr_drive.slow_speed_inner == undefined || slow_speed_inner_res == false) {
                        $scope.resetmsg()
                        $scope.slow_speed_inner_flag = 1
                        $scope.slow_speed_inner_msg = 'Please Enter Slow Speed Secured (Hz) value between 5.00-10.00 (two digit after decimal)'
                    } else {
                        var slow_speed_inner_val = $scope.mtr_drive.slow_speed_inner * 100
                        mtrDriveData['SlowSpeedInner'] = slow_speed_inner_val
                    }
                }
                if ($scope.original_motor_drive.aec_time_one != $scope.mtr_drive.aec_time_one) {
                    var aec_time_one_res = oneDecimal.test($scope.mtr_drive.aec_time_one)
                    if ($scope.mtr_drive.aec_time_one >= 0 && $scope.mtr_drive.aec_time_one <= 1 && aec_time_one_res == true) {
                        var aec_time_one_val = $scope.mtr_drive.aec_time_one * 10
                        mtrDriveData['AccelerationTime1st'] = aec_time_one_val
                    } else {
                        $scope.resetmsg()
                        $scope.aecmsg1 = 1
                    }
                }
                if ($scope.original_motor_drive.aec_time_two != $scope.mtr_drive.aec_time_two) {
                    var aec_time_two_res = oneDecimal.test($scope.mtr_drive.aec_time_two)
                    if ($scope.mtr_drive.aec_time_two >= 0 && $scope.mtr_drive.aec_time_two <= 1 && aec_time_two_res == true) {
                        var aec_time_two_val = $scope.mtr_drive.aec_time_two * 10
                        mtrDriveData['AccelerationTime2nd'] = aec_time_two_val
                    } else {
                        $scope.resetmsg()
                        $scope.aecmsg2 = 1
                    }
                }

                if ($scope.original_motor_drive.dec_time_one != $scope.mtr_drive.dec_time_one) {
                    var dec_time_one_res = oneDecimal.test($scope.mtr_drive.dec_time_one)
                    if ($scope.mtr_drive.dec_time_one >= 0 && $scope.mtr_drive.dec_time_one <= 1 && dec_time_one_res == true) {
                        var dec_time_one_val = $scope.mtr_drive.dec_time_one * 10
                        mtrDriveData['DecelerationTime1st'] = dec_time_one_val
                    } else {
                        $scope.resetmsg()
                        $scope.decmsg1 = 1
                    }
                }

                if ($scope.original_motor_drive.dec_time_two != $scope.mtr_drive.dec_time_two) {
                    var dec_time_two_res = oneDecimal.test($scope.mtr_drive.dec_time_two)
                    if ($scope.mtr_drive.dec_time_two >= 0 && $scope.mtr_drive.dec_time_two <= 1 && dec_time_two_res == true) {
                        var dec_time_two_val = $scope.mtr_drive.dec_time_two * 10
                        mtrDriveData['DecelerationTime2nd'] = dec_time_two_val
                    } else {
                        $scope.resetmsg()
                        $scope.decmsg2 = 1
                    }
                }

                if ($scope.original_motor_drive.break_time != $scope.mtr_drive.break_time) {
                    var break_time_res = oneDecimal.test($scope.mtr_drive.break_time)
                    if ($scope.mtr_drive.break_time >= 0 && $scope.mtr_drive.break_time <= 1 && break_time_res == true) {
                        var break_time_val = $scope.mtr_drive.break_time * 10
                        mtrDriveData['BrakingTime'] = break_time_val
                    } else {
                        $scope.resetmsg()
                        $scope.brktimemsg = 1
                    }
                }

                if ($scope.original_motor_drive.break_percent != $scope.mtr_drive.break_percent) {
                    //  var threeDigitDecimal = /^\d*\.?\d{0,3}$/ //to allow 3 digit after decimal
                    var break_percent_res = oneDecimal.test($scope.mtr_drive.break_percent)
                    if ($scope.mtr_drive.break_percent >= 0 && $scope.mtr_drive.break_percent <= 30 && break_percent_res == true) {
                        break_percent_val = $scope.mtr_drive.break_percent * 10
                        mtrDriveData['Braking'] = break_percent_val
                    } else {
                        $scope.resetmsg()
                        $scope.brkpercentmsg = 1
                    }
                }

                if (!angular.equals({}, mtrDriveData)) {
                    if ($scope.aecmsg1 != 1 && $scope.aecmsg2 != 1 && $scope.decmsg1 != 1 && $scope.decmsg2 != 1 && $scope.brktimemsg != 1 && $scope.brkpercentmsg != 1 &&
                        $scope.base_frequency_flag != 1 && $scope.base_voltage_flag != 1 && $scope.normal_speed_flag != 1 &&
                        $scope.slow_speed_outer_flag != 1 && $scope.slow_speed_inner_flag != 1) {
                        EditDoorService.putMotorDrive(mtrDriveData, doorId).then(function(data) {
                                if (data.success == true) {
                                    $scope.mtrSaved = true
                                    $scope.mtrdrve_message = data.message
                                    $scope.original_motor_drive = angular.copy($scope.mtr_drive)
                                } else {
                                    $scope.mtrSaved = true
                                    $scope.mtrdrve_message = data.message
                                }
                            },
                            function(result) {
                                console.log('error data', result)
                            })
                    }
                }
            }
        }

        var plcData1 = {}
        var nodecimal = /^\d*\.?0{0,1}$/
        $scope.validatePlcData1 = function(plc_data1) {
            if (mdplcflag.isserviceEmployee == 0) {
                alert('You need to be Service Engineer to modify data.')
                $scope.plc_data1 = angular.copy($scope.original_plc_data1)
            } else {
                var plcFormKeys = [
                    'OpenTimeIn',
                    'PresenceDelay',
                    'TimeOutTime',
                    'EnableSVIn',
                    'OpenTimeOut',
                    'IRSSensorDelay',
                    'IllegalTime',
                    'EnableSVOut',
                    'ReturnSignalInTime',
                    'IllegalUse',
                    'CleaningTime',
                    'ReturnSignalOutTime',
                    'TimeExceededMax',
                    'FireAlarmModeSet'
                ]
                var regexp = /^\d*\.?\d{0,1}$/
                var oneDecimal = /^\d*\.?\d{0,1}$/ // to allow 1 digit after decimal

                plcData1 = {}
                $scope.plcFlag1 = 0
                $scope.openTimemsg = 0
                $scope.openTimeoutmsg = 0
                $scope.invalidPlcData1 = 0
                $scope.returnSignalInMsg = 0
                $scope.returnSignalOutMsg = 0
                $scope.PresenceOnDelayMsg = 0
                $scope.PresenceOffDelayMsg = 0
                $scope.alramDelayMsg = 0
                $scope.TimeExceededMaxMsg = 0
                $scope.antiLockTimeMsg = 0
                $scope.stepOutMsg = 0
                $scope.cleaningTimeMsg = 0
                $scope.fireAlarmMsg = 0
                $scope.svNonSecuredMsg = 0
                $scope.svSecuredMsg = 0

                for (var i = 0; i < plcFormKeys.length; i++) {
                    if (plc_data1[i].value != $scope.original_plc_data1[i].value) {
                        if (i == 0) { // Open Time Non Secured Side
                            var opentimeIn = oneDecimal.test(plc_data1[0].value)
                            if (!(plc_data1[0].value >= 5 && plc_data1[0].value <= 12.5 && opentimeIn == true)) {
                                $scope.resetmsg()
                                $scope.openTimemsg = 1
                            } else {
                                var val = plc_data1[i].value * 10
                                plcData1[plcFormKeys[i]] = val
                            }
                        } else if (i == 1) { // Presence On Delay
                            var PresenceDelay = oneDecimal.test(plc_data1[1].value)
                            if (!(plc_data1[1].value >= 0.5 && plc_data1[1].value <= 2.5 && PresenceDelay == true)) {
                                $scope.resetmsg()
                                $scope.PresenceOnDelayMsg = 1
                            } else {
                                var val = plc_data1[i].value * 10
                                plcData1[plcFormKeys[i]] = val
                            }
                        } else if (i == 2) { // anti lock in time
                            var antiLock = oneDecimal.test(plc_data1[2].value)
                            if (!(plc_data1[2].value >= 10 && plc_data1[2].value <= 60 && antiLock == true)) {
                                $scope.resetmsg()
                                $scope.antiLockTimeMsg = 1
                            } else {
                                var val = plc_data1[i].value * 10
                                plcData1[plcFormKeys[i]] = val
                            }
                        } else if (i == 3) { // SV Secured Side Enabled
                            var svnSecured = nodecimal.test(plc_data1[3].value)
                            if (plc_data1[3].value >= 0 && plc_data1[3].value <= 1 && svnSecured == true) {
                                var sv_non_secured_val = plc_data1[3].value
                                plcData1[plcFormKeys[i]] = sv_non_secured_val
                            } else {
                                $scope.resetmsg()
                                $scope.svNonSecuredMsg = 1
                            }
                        } else if (i == 4) { // Open Time Secured Side
                            var opentimeout = oneDecimal.test(plc_data1[4].value)
                            if (!(plc_data1[4].value >= 5 && plc_data1[4].value <= 12.5 && opentimeout == true)) {
                                $scope.resetmsg()
                                $scope.openTimeoutmsg = 1
                            } else {
                                var val = plc_data1[i].value * 10
                                plcData1[plcFormKeys[i]] = val
                            }
                        } else if (i == 5) { // PresenceOff Delay
                            var presence_off_delay = oneDecimal.test(plc_data1[5].value)
                            if (!(plc_data1[5].value >= 0.5 && plc_data1[5].value <= 2.5 && presence_off_delay == true)) {
                                $scope.resetmsg()
                                $scope.PresenceOffDelayMsg = 1
                            } else {
                                var val = plc_data1[i].value * 10
                                plcData1[plcFormKeys[i]] = val
                            }
                        } else if (i == 6) { // Step out before Alarm
                            var step_out = oneDecimal.test(plc_data1[6].value)
                            if (!(plc_data1[6].value >= 2.5 && plc_data1[6].value <= 12.5 && step_out == true)) {
                                $scope.resetmsg()
                                $scope.stepOutMsg = 1
                            } else {
                                var val = plc_data1[i].value * 10
                                plcData1[plcFormKeys[i]] = val
                            }
                        } else if (i == 7) { // SV Secured Side Enabled
                            var svn_secured = nodecimal.test(plc_data1[7].value)
                            if (plc_data1[7].value >= 0 && plc_data1[7].value <= 1 && svn_secured == true) {
                                var svn_secured_val = plc_data1[7].value
                                plcData1[plcFormKeys[i]] = svn_secured_val
                            } else {
                                $scope.resetmsg()
                                $scope.svSecuredMsg = 1
                            }
                        } else if (i == 8) { // Return Signal Time Non Secured Side
                            var return_signal_time_in = oneDecimal.test(plc_data1[8].value)
                            if (!(plc_data1[8].value >= 0.2 && plc_data1[8].value <= 5 && return_signal_time_in == true)) {
                                $scope.resetmsg()
                                $scope.returnSignalInMsg = 1
                            } else {
                                var val = plc_data1[i].value * 10
                                plcData1[plcFormKeys[i]] = val
                            }
                        } else if (i == 9) { // Alarm delay
                            var alram_delay = oneDecimal.test(plc_data1[9].value)
                            if (!(plc_data1[9].value >= 0.2 && plc_data1[9].value <= 5 && alram_delay == true)) {
                                $scope.resetmsg()
                                $scope.alramDelayMsg = 1
                            } else {
                                var val = plc_data1[i].value * 10
                                plcData1[plcFormKeys[i]] = val
                            }
                        } else if (i == 10) { // Cleaning Time
                            var cleaning_time = oneDecimal.test(plc_data1[10].value)
                            if (!(plc_data1[10].value >= 120 && plc_data1[10].value <= 600 && cleaning_time == true)) {
                                $scope.resetmsg()
                                $scope.cleaningTimeMsg = 1
                            } else {
                                var val = plc_data1[i].value * 10
                                plcData1[plcFormKeys[i]] = val
                            }
                        } else if (i == 11) { // Return Signal Time Secured Side
                            var return_signal_time_out = oneDecimal.test(plc_data1[11].value)
                            if (!(plc_data1[11].value >= 0.2 && plc_data1[11].value <= 5 && return_signal_time_out == true)) {
                                $scope.resetmsg()
                                $scope.returnSignalOutMsg = 1
                            } else {
                                var val = plc_data1[i].value * 10
                                plcData1[plcFormKeys[i]] = val
                            }
                        } else if (i == 12) { // Time Exceeded Max
                            var time_exced_max = oneDecimal.test(plc_data1[12].value)
                            if (!(plc_data1[12].value >= 15 && plc_data1[12].value <= 90 && time_exced_max == true)) {
                                $scope.resetmsg()
                                $scope.TimeExceededMaxMsg = 1
                            } else {
                                var val = plc_data1[i].value * 10
                                plcData1[plcFormKeys[i]] = val
                            }
                        } else if (i == 13) { // Fire Alarm Mode
                            var fire_alarm = nodecimal.test(plc_data1[13].value)
                            if (plc_data1[11].value >= 0 && plc_data1[13].value <= 2 && fire_alarm == true) {
                                var fire_alarm_val = plc_data1[13].value
                                plcData1[plcFormKeys[i]] = fire_alarm_val
                            } else {
                                $scope.resetmsg()
                                $scope.fireAlarmMsg = 1
                            }
                        }
                    }
                }
            }

            if (!angular.equals({}, plcData1)) {
                if ($scope.openTimemsg != 1 && $scope.openTimeoutmsg != 1 && $scope.plcFlag1 == 0 && $scope.returnSignalInMsg != 1 && $scope.returnSignalOutMsg != 1 &&
                    $scope.PresenceOnDelayMsg != 1 && $scope.PresenceOffDelayMsg != 1 && $scope.alramDelayMsg != 1 && $scope.TimeExceededMaxMsg != 1 && $scope.antiLockTimeMsg != 1 &&
                    $scope.stepOutMsg != 1 && $scope.cleaningTimeMsg != 1 && $scope.fireAlarmMsg != 1 && $scope.svNonSecuredMsg != 1 && $scope.svSecuredMsg != 1) {

                    EditDoorService.putPlcData1(plcData1, doorId).then(function(data) {
                            if (data.success == true) {
                                $scope.settingReg = true
                                $scope.plcdata1_message = data.message
                                $scope.original_plc_data1 = angular.copy(plc_data1)
                            } else {
                                $scope.settingReg = true
                                $scope.plcdata1_message = data.message
                            }
                        },
                        function(error) {
                            console.log('Error Data', error)
                        })
                }
            }
        }

        $scope.UpdateDoorData = function() {
            var doorName = ''
            var campusName = ''
            var buildingName = ''
            var entranceName = ''
            var subEntranceName = ''

            var campusId = $scope.campusId
            var buildingId = $scope.buildingId
            var entranceId = $scope.entranceId
            var subEntranceId = $scope.subEntranceId
            var flagFields = 0
            var invalidflag = 0
            $scope.invaildrealName = 0
            $scope.invalidCamp = 0
            $scope.invalidBldng = 0
            $scope.invalidEntr = 0
            $scope.invalidSubEntr = 0

            if ($scope.doordetail.real_name == undefined) {
                $scope.invaildrealName = 1
                invalidflag = 1
            }
            if ($scope.editFields.editCampus == true && $scope.doordetail.newcampusName == undefined) {
                $scope.invalidCamp = 1
                invalidflag = 1
            }
            if ($scope.editFields.buildingName == true && $scope.doordetail.newbuildingName == undefined) {
                $scope.invalidBldng = 1
                invalidflag = 1
            }
            if ($scope.editFields.editEntrance == true && $scope.doordetail.newentranceName == undefined) {
                $scope.invalidEntr = 1
                invalidflag = 1
            }
            if ($scope.editFields.editSubEntrance == true && $scope.doordetail.newsubEntranceName == undefined) {
                $scope.invalidSubEntr = 1
                invalidflag = 1
            }

            var pattern = /^[a-zA-Z0-9,-\./\s]*$/

            if ($scope.invaildrealName == 0) {
                if (pattern.test($scope.doordetail.real_name) == true) {
                    doorName = $scope.doordetail.real_name
                } else {
                    $scope.invaildrealName = 1
                    invalidflag = 1
                }
            }

            if ($scope.editFields.editCampus == true && $scope.invalidCamp == 0) {
                if (pattern.test($scope.doordetail.newcampusName) == true) {
                    campusName = $scope.doordetail.newcampusName
                    campusId = -1
                } else {
                    $scope.invalidCamp = 1
                    invalidflag = 1
                }
            } else {
                if ($scope.campusId != null) {
                    for (var i = 0; $scope.campuses.length > 0; i++) {
                        if ($scope.campuses[i].campusId == $scope.campusId) {
                            campusName = $scope.campuses[i].campusName
                            break
                        }
                    }
                } else {
                    $scope.invalidCamp = 1
                    invalidflag = 1
                }
            }

            if ($scope.editFields.editBuilding == true && $scope.invalidBldng == 0) {
                if (pattern.test($scope.doordetail.newbuildingName) == true) {
                    buildingName = $scope.doordetail.newbuildingName
                    buildingId = -1
                } else {
                    $scope.invalidBldng = 1
                    invalidflag = 1
                }
            } else {
                if ($scope.buildingId != null) {
                    for (var i = 0; $scope.buildings.length > 0; i++) {
                        if ($scope.buildings[i].buildingId == $scope.buildingId) {
                            buildingName = $scope.buildings[i].buildingName
                            break
                        }
                    }
                } else {
                    $scope.invalidBldng = 1
                    invalidflag = 1
                }
            }

            if ($scope.editFields.editEntrance == true && $scope.invalidEntr == 0) {
                if (pattern.test($scope.doordetail.newentranceName) == true) {
                    entranceName = $scope.doordetail.newentranceName
                    entranceId = -1
                } else {
                    $scope.invalidEntr = 1
                    invalidflag = 1
                }
            } else {
                if ($scope.entranceId != null) {
                    for (var i = 0; $scope.entrances.length > 0; i++) {
                        if ($scope.entrances[i].entranceId == $scope.entranceId) {
                            entranceName = $scope.entrances[i].entranceName
                            break
                        }
                    }
                } else {
                    $scope.invalidEntr = 1
                    invalidflag = 1
                }
            }

            if ($scope.editFields.editSubEntrance == true && $scope.invalidSubEntr == 0) {
                if (pattern.test($scope.doordetail.newsubEntranceName) == true) {
                    subEntranceName = $scope.doordetail.newsubEntranceName
                    subEntranceId = -1
                } else {
                    $scope.invalidSubEntr = 1
                    invalidflag = 1
                }
            } else {
                if ($scope.subEntranceId != null) {
                    for (var i = 0; $scope.subEntrances.length > 0; i++) {
                        if ($scope.subEntrances[i].subentranceId == $scope.subEntranceId) {
                            subEntranceName = $scope.subEntrances[i].subentranceName
                            break
                        }
                    }
                } else {
                    $scope.invalidSubEntr = 1
                    invalidflag = 1
                }
            }

            if ((campusId != null && buildingId != null && entranceId != null && subEntranceId != null) &&
                ((campusId == -1 && buildingId == -1 && entranceId == -1 && subEntranceId == -1) ||
                    (campusId >= 0 && buildingId == -1 && entranceId == -1 && subEntranceId == -1) ||
                    (campusId >= 0 && buildingId >= 0 && entranceId == -1 && subEntranceId == -1) ||
                    (campusId >= 0 && buildingId >= 0 && entranceId >= 0 && subEntranceId == -1) ||
                    (campusId >= 0 && buildingId >= 0 && entranceId >= 0 && subEntranceId >= 0))) {
                flagFields = 1
            } else {
                flagFields = 0
            }

            if ($scope.invaildrealName == 0 && $scope.invalidCamp == 0 && $scope.invalidBldng == 0 && $scope.invalidEntr == 0 && $scope.invalidSubEntr == 0) {
                flagFields = 1
                invalidflag = 0
            }

            var doorData = {
                'real_name': doorName,
                'campusName': campusName,
                'buildingName': buildingName,
                'entranceName': entranceName,
                'subEntranceName': subEntranceName,
                'campusId': campusId,
                'buildingId': buildingId,
                'entranceId': entranceId,
                'subEntranceId': subEntranceId,
                'assigned': 1
            }

            var level10 = JSON.parse($window.sessionStorage.getItem('userInfo')).level10
            var doorflag = userLevelService.canSetDoorData(level10)

            if (flagFields == 1 && invalidflag == 0) {
                if (doorflag.isserviceEmployee == 1 || doorflag.iscustomerHighestLevel == 1) {
                    EditDoorService.putDoorData(doorData, doorId).then(function(data) {
                            if (data.success == true) {
                                $scope.invaildrealName = 0
                                $scope.invalidCamp = 0
                                $scope.invalidBldng = 0
                                $scope.invalidEntr = 0
                                $scope.invalidSubEntr = 0
                                $scope.isDorDataSaved = true
                                $scope.editFields.editCampus = false
                                $scope.editFields.editBuilding = false
                                $scope.editFields.editEntrance = false
                                $scope.editFields.editSubEntrance = false
                                $scope.door_msg = data.message
                                alert('Update successful')
                                $state.go($state.current, {}, {
                                    reload: true
                                })
                            } else {
                                $scope.door_msg = 'Invalid data.'
                            }
                        },
                        function(error) {
                            console.log('Error Data', error)
                        })
                } else {
                    alert('Only Customer Highest level or Service Engineer can modify this data!')
                }
            } else {
                alert('Enter valid values!')
            }
        }

        $scope.init = function() {
            $scope.activeMenu = 'primary'
            $scope.active = 'true'
        }

        /*
        Method:onlyNumbers,
        Description: To restrict enter numbers only
        */
        $scope.onlyNumbers = function($event) {
            if (isNaN(String.fromCharCode($event.keyCode))) {
                $event.preventDefault()
            }
        }

        $scope.columnBreak = 4 // max number of cols
        $scope.columnBreak2 = 1 // max number of cols

        $scope.startNewRow = function(index, count) {
            return ((index) % count) === 0
        }

        $scope.editCampus = function(toggleField) {
            $scope.editFields.editCampus = toggleField
            if (toggleField) {
                $scope.resetDropDowns(0)
            } else {
                $scope.repopulateDropDowns(0)
            }
        }
        $scope.editBuilding = function(toggleField) {
            $scope.editFields.editBuilding = toggleField
            if (toggleField) {
                $scope.resetDropDowns(1)
            } else {
                $scope.repopulateDropDowns(1)
            }
        }
        $scope.editEntrance = function(toggleField) {
            $scope.editFields.editEntrance = toggleField
            if (toggleField) {
                $scope.resetDropDowns(2)
            } else {
                $scope.repopulateDropDowns(2)
            }
        }
        $scope.editSubEntrance = function(toggleField) {
            $scope.editFields.editSubEntrance = toggleField
            if (toggleField) {
                $scope.resetDropDowns(3)
            } else {
                $scope.repopulateDropDowns(3)
            }
        }

        /*
        Method: fetchDoorDetail()
        Service: EditDoorService
        Params: doorId
        Description: To fetch data for all the tabs
        */
        $scope.start = performance.now()
        EditDoorService.fetchDoorDetail(doorId).then(function(result) {
          var time = performance.now() - $scope.start;
          console.log('doorDetail duration',time)
                var editdoor = angular.copy(result.doorMain)
                $scope.doordetail = editdoor[0]
                if ($scope.doordetail == undefined || $scope.doordetail == null) {
                    alert('No data found for this door.')
                    $state.go('dashboard')
                }

                var plc_values = angular.copy(result.plc[0])
                var motorDrive = angular.copy(result.motorDrive[0])
                var timeofflight = angular.copy(result.timeOfFlight[0])

                if (plc_values != undefined) {
                    $scope.flag = 0

                    $scope.input1 = {
                        'ES Non Secured Side Closed': plc_values.EndSwitchOutsideClosed,
                        'ES Secured Side Open': plc_values.EndSwitchInsideOpen,
                        'Anti Lock-In Button': plc_values.EmergencyButton,
                        'Special Pulse Non Secured Side': plc_values.PulseInSpecial,
                        'ES Non Secured Side Slow': plc_values.EndSwitchOutsideSlow,
                        'Biometric Passage Granted': plc_values.BiometricAccessGranted,
                        'Safety Rail': plc_values.SafetyRail,
                        'Special Pulse Secured Side ': plc_values.PulseOutSpecial,
                        'ES Non Secured Side Open': plc_values.EndSwitchOutsideOpen,
                        'Fire Alarm': plc_values.FireAlarm,
                        'Pulse Non Secured Side': plc_values.PulseIn,
                        'Both Doors Open': plc_values.BothDoorsOpen,
                        'ES Secured Side Closed': plc_values.EndSwitchInsideClosed,
                        'Motor Thermal Overload': plc_values.MotorThermalOverload,
                        'Pulse Secured Side': plc_values.PulseOut,
                        'Lock Switch': plc_values.LockSwitch,
                        'ES Secured Side Slow': plc_values.EndSwitchInsideSlow,
                        'Power Failure': plc_values.PowerFailure
                    }

                    $scope.input2 = {
                        'Biometric Passage Rejected': plc_values.BiometricRejectionEntry,
                        'Reset': plc_values.ResetSwitch,
                        'AIR Sensor Non Secured Side': plc_values.AIRSensorsIn,
                        'More Person Secured Side': plc_values.TwoPersonOut,
                        'Infra Red Sensors': plc_values.InfraRedSensors,
                        'Empty Door Non Secured Side': plc_values.EmptyDoorIn,
                        'SV Enabled Non Secured Side': plc_values.SVSEnabledIn,
                        'Suspicious Secured Side': plc_values.SuspiciousOut,
                        'SV Non Secured Side Enabled ': plc_values.SVSInOn,
                        'One Person Non Secured Side': plc_values.OnePersonIn,
                        'Empty Door Secured Side': plc_values.EmptyDoorOut,
                        'AIR Sensor Secured Side': plc_values.AIRSensorsOut,
                        'SV Secured Side Enabled ': plc_values.SVSOutOn,
                        'More Person Non Secured Side': plc_values.TwoPersonIn,
                        'One Person Secured Side': plc_values.OnePersonOut,
                        'SV Enabled Secured Side': plc_values.SVSEnabledOut,
                        'Cleaning Mode': plc_values.CleaningMode,
                        'Suspicious Non Secured Side': plc_values.SuspiciousIn
                    }

                    // Output (1)
                    $scope.output1 = [{
                        key: 'Return Signal Non Secured Side',
                        value: plc_values.ReturnSignalIn
                    }, {
                        key: 'Lock Secured Side',
                        value: plc_values.LockInner
                    }, {
                        key: 'VFD Speed 2 and 4',
                        value: plc_values.VFDSpeedRef2and4
                    }, {
                        key: 'General Alarm',
                        value: plc_values.GeneralAlarm
                    }, {
                        key: 'Return Signal Secured Side',
                        value: plc_values.ReturnSignalOut
                    }, {
                        key: 'Mag Lock Non Secured Side',
                        value: plc_values.MagLockOuter
                    }, {
                        key: 'VFD Speed 3 and 4',
                        value: plc_values.VFDSpeedRef3and4
                    }, {
                        key: 'Signal Led Green Non Secured Side',
                        value: plc_values.SignalLEDGreenIn
                    }, {
                        key: 'Motor Non Secured Side',
                        value: plc_values.MotorOuter
                    }, {
                        key: 'Mag Lock Secured Side',
                        value: plc_values.MagLockInner
                    }, {
                        key: 'VFD Second Acc Dec',
                        value: plc_values.VFDSecondAccDec
                    }, {
                        key: 'Signal Led Red Non Secured Side',
                        value: plc_values.SignalLEDRedIn
                    }, {
                        key: 'Motor Secured Side ',
                        value: plc_values.MotorInner
                    }, {
                        key: 'VFD Forward',
                        value: plc_values.VFDForward
                    }, {
                        key: 'SV Reset',
                        value: plc_values.TOFReset
                    }, {
                        key: 'Signal Led Green Secured Side',
                        value: plc_values.SignalLEDGreenOut
                    }, {
                        key: 'Lock Non Secured Side',
                        value: plc_values.LockOuter
                    }, {
                        key: 'VFD Reverse',
                        value: plc_values.VFDReverse
                    }, {
                        key: 'SV Shutdown',
                        value: plc_values.TOFShutdown
                    }, {
                        key: 'Signal Led Red Secured Side',
                        value: plc_values.SignalLEDRedOut
                    }]

                    $scope.output2_1 = [{
                        key: 'Authorization Non Secured Side',
                        value: plc_values.AuthorizationIn
                    }, {
                        key: 'AIR active Non Secured Side',
                        value: plc_values.AIRActiveIn
                    }, {
                        key: 'Authorization Secured Side',
                        value: plc_values.AuthorizationOut
                    }, {
                        key: 'AIR active Secured Side',
                        value: plc_values.AIRActiveOut
                    }, {
                        key: 'Two Person Rejection',
                        value: plc_values.TwoPersonRejection
                    }, {
                        key: 'Biometric Rejection',
                        value: plc_values.BiometricRejection
                    }]

                    $scope.output2_2 = [{
                        key: 'Time Exceeded In Cabin',
                        value: plc_values.TimeExceededInCabin
                    }, {
                        key: 'Safety Rail Activation',
                        value: plc_values.SafetyRailActivation
                    }, {
                        key: 'Anti Lock-in Button Activation',
                        value: plc_values.EmergencyButtonActivation
                    }, {
                        key: 'Power Loss',
                        value: plc_values.PowerLoss
                    }, {
                        key: 'IR sensor Hung',
                        value: plc_values.IRSensorHung
                    }, {
                        key: 'Person In Cabin',
                        value: plc_values.PersonInCabin
                    }]

                    $scope.output2_3 = [{
                        key: 'Start biometric',
                        value: plc_values.BiometricStart
                    }, {
                        key: 'Non Secured Side Door Closed',
                        value: plc_values.OuterDoorClosed
                    }, {
                        key: 'Secured Side Door Closed',
                        value: plc_values.InnerDoorClosed
                    }, {
                        key: 'Anti-Lock-in Button LED',
                        value: plc_values.EmergencyButtonLED
                    }, {
                        key: 'Voice Message 1',
                        value: plc_values.Voice1
                    }, {
                        key: 'Voice Message 2',
                        value: plc_values.Voice2
                    }]

                    $scope.output2_4 = [{
                        key: 'Signal Green Interior',
                        value: plc_values.SignalGreenInterior
                    }, {
                        key: 'Signal Red Interior',
                        value: plc_values.SignalRedInterior
                    }, {
                        key: 'Enable Biometric Non Secured Side',
                        value: plc_values.EnableBiometricEntry
                    }, {
                        key: 'Enable Biometric Secured Side',
                        value: plc_values.EnableBiometricExit
                    }]

                    // Setting Registers
                    $scope.plc_data1 = [{
                        key: 'Open Time Non Secured Side (s)',
                        value: parseFloat(plc_values.OpenTimeIn / 10).toFixed(1)

                    }, {
                        key: 'Presence On Delay (s)',
                        value: parseFloat(plc_values.PresenceDelay / 10).toFixed(1)

                    }, {
                        key: 'Anti lock-in time (s)',
                        value: parseFloat(plc_values.TimeOutTime / 10).toFixed(1)

                    }, {
                        key: 'SV Non Secured Side Enabled ',
                        value: plc_values.EnableSVIn

                    }, {
                        key: 'Open Time Secured Side (s)',
                        value: parseFloat(plc_values.OpenTimeOut / 10).toFixed(1)

                    }, {
                        key: 'Presence Off Delay (s)',
                        value: parseFloat(plc_values.IRSSensorDelay / 10).toFixed(1)

                    }, {
                        key: 'Step Out Before Alarm (s)',
                        value: parseFloat(plc_values.IllegalTime / 10).toFixed(1)

                    }, {
                        key: 'SV Secured Side Enabled',
                        value: plc_values.EnableSVOut
                    }, {
                        key: 'Return Signal Time Non Secured Side (s)',
                        value: parseFloat(plc_values.ReturnSignalInTime / 10).toFixed(1)

                    }, {
                        key: 'Alarm Delay (s)',
                        value: parseFloat(plc_values.IllegalUse / 10).toFixed(1)

                    }, {
                        key: 'Cleaning Time (s)',
                        value: parseFloat(plc_values.CleaningTime / 10).toFixed(1)

                    }, {
                        key: 'Return Signal Time Secured Side (s) ',
                        value: parseFloat(plc_values.ReturnSignalOutTime / 10).toFixed(1)

                    }, {
                        key: 'Time Exceeded Max (s)',
                        value: parseFloat(plc_values.TimeExceededMax / 10).toFixed(1)

                    }, {
                        key: 'Fire Alarm Mode',
                        value: plc_values.FireAlarmModeSet

                    }]

                    // Counter in (non-secured side)
                    $scope.plc_data2_1 = [{
                        key: 'Biometric rejection Count',
                        value: plc_values.BiometricRejectionIn
                    }, {
                        key: 'Door Forced Count',
                        value: plc_values.DoorForcedCountOutside

                    }, {
                        key: 'Time Exceeded Cabin Count',
                        value: plc_values.TimeExceededinCabinIn

                    }, {
                        key: 'IR Sensor Hung',
                        value: plc_values.IRSensorHungCount

                    }]

                    $scope.plc_data2_2 = [{
                        key: 'Opening Counter',
                        value: plc_values.OpeningCounterOuterDoor
                    }, {
                        key: 'Pulses Counter',
                        value: plc_values.PulsesInCounter

                    }, {
                        key: 'Special Pulses Counter',
                        value: plc_values.PulsesInSpecialCounter

                    }, {
                        key: 'Anti Lock-in Button Activation',
                        value: plc_values.ReverseButtonActivation

                    }]

                    $scope.plc_data2_3 = [{
                        key: 'Safety Rail Closing',
                        value: plc_values.SafetyRailOuterDoorClosing

                    }, {
                        key: 'SV 0 Person',
                        value: plc_values.TOF0PersonIn

                    }, {
                        key: 'SV 1 Person ',
                        value: plc_values.TOF1PersonIn

                    }, {
                        key: 'SV 2 Persons ',
                        value: plc_values.TOF2PersonsIn

                    }]

                    $scope.plc_data2_4 = [{
                        key: 'SV Rejections',
                        value: plc_values.TOFRejectionsIn

                    }, {
                        key: 'SV Suspicious ',
                        value: plc_values.TOFSuspiciousIn

                    }]

                    // Counter out (secured side)
                    $scope.counter_out_1 = [{
                        key: 'Biometric rejection Count',
                        value: plc_values.BiometricRejectionOut
                    }, {
                        key: 'Door Forced Count',
                        value: plc_values.DoorForcedCountInside

                    }, {
                        key: 'Time Exceeded Cabin Count',
                        value: plc_values.TimeExceededinCabinOut

                    }, {
                        key: 'IR Sensor Hung',
                        value: plc_values.IRSensorHungInside

                    }]

                    $scope.counter_out_2 = [{
                        key: 'Opening Counter',
                        value: plc_values.OpeningCounterInnerDoor
                    }, {
                        key: 'Pulses Counter',
                        value: plc_values.PulsesInCounter

                    }, {
                        key: 'Special Pulses Counter',
                        value: plc_values.PulsesOutSpecialCounter

                    }, {
                        key: 'Anti Lock-in Button Activation',
                        value: plc_values.AntiLockInButtonActivationOut

                    }]

                    $scope.counter_out_3 = [{
                        key: 'Safety Rail Closing',
                        value: plc_values.SafetyRailInnerDoorClosing

                    }, {
                        key: 'SV 0 Person',
                        value: plc_values.TOF0PersonOut

                    }, {
                        key: 'SV 1 Person ',
                        value: plc_values.TOF1PersonOut

                    }, {
                        key: 'SV 2 Persons ',
                        value: plc_values.TOF2PersonsOut

                    }]

                    $scope.counter_out_4 = [{
                        key: 'SV Rejections',
                        value: plc_values.TOFRejectionsOut

                    }, {
                        key: 'SV Suspicious ',
                        value: plc_values.TOFSuspiciousOut

                    }]

                    // Counter general
                    $scope.counter_general_1 = [{
                        key: 'Both Doors Open Count',
                        value: plc_values.BothDoorsOpenCount
                    }, {
                        key: 'Cleaning Count',
                        value: plc_values.Cleaning
                    }]
                    $scope.counter_general_2 = [{
                        key: 'Fire Alarm Count',
                        value: plc_values.FireAlarmCount
                    }, {
                        key: 'Locking Count',
                        value: plc_values.Locking
                    }]

                    $scope.counter_general_3 = [{
                        key: 'Power Loss Count',
                        value: plc_values.PowerLossCount
                    }, {
                        key: 'Reset Count',
                        value: plc_values.Reset

                    }]
                    $scope.counter_general_4 = [{
                        key: 'SV Rejection Count',
                        value: plc_values.TOFRejection
                    }]

                    // Event
                    $scope.events = [{
                        key: 'Event 1st',
                        value: plc_values.Event1st

                    }, {
                        key: 'Event 2nd',
                        value: plc_values.Event2nd

                    }, {
                        key: 'Event 3rd',
                        value: plc_values.Event3rd

                    }, {
                        key: 'Event 4th',
                        value: plc_values.Event4th

                    }, {
                        key: 'Event 5th',
                        value: plc_values.Event5th

                    }]

                    $scope.original_plc_data1 = angular.copy($scope.plc_data1)
                } else {
                    $scope.plcx_msg = 'No data found for this Door'
                    $scope.flag = 1
                }

                if (motorDrive != undefined) {
                    $scope.no_data_flag = 0
                    $scope.mtrdrve_message = ''

                    var brakingPercent = parseFloat(motorDrive.Braking / 10).toFixed(1)
                    var BaseFrequency = parseFloat(motorDrive.BaseFrequency / 100).toFixed(2)
                    var Normal_Speed = parseFloat(motorDrive.NormalSpeed / 100).toFixed(2)
                    var acc_1st = parseFloat(motorDrive.AccelerationTime1st / 10).toFixed(1)
                    var acc_2nd = parseFloat(motorDrive.AccelerationTime2nd / 10).toFixed(1)
                    var dcc_1st = parseFloat(motorDrive.DecelerationTime1st / 10).toFixed(1)
                    var dcc_2nd = parseFloat(motorDrive.DecelerationTime2nd / 10).toFixed(1)
                    var BrakingTime = parseFloat(motorDrive.BrakingTime / 10).toFixed(1)
                    var OutputFrequency = motorDrive.OutputFrequency / 100
                    var OutputCurrent = motorDrive.OutputCurrent / 100
                    var OutputVoltage = motorDrive.OutputVoltage / 10
                    var BaseVoltage = parseFloat(motorDrive.BaseVoltage / 10).toFixed(1)
                    var SlowSpeedOuter = parseFloat(motorDrive.SlowSpeedOuter / 100).toFixed(2)
                    var SlowSpeedInner = parseFloat(motorDrive.SlowSpeedInner / 100).toFixed(2)

                    $scope.mtr_drive = {
                        'output_frequency': OutputFrequency,
                        'output_current': OutputCurrent,
                        'output_voltage': OutputVoltage,
                        'base_frequency': BaseFrequency,
                        'normal_speed': Normal_Speed,
                        'base_voltage': BaseVoltage,
                        'slow_speed_outer': SlowSpeedOuter,
                        'slow_speed_inner': SlowSpeedInner,
                        'aec_time_one': acc_1st,
                        'aec_time_two': acc_2nd,
                        'dec_time_one': dcc_1st,
                        'dec_time_two': dcc_2nd,
                        'break_time': BrakingTime,
                        'break_percent': brakingPercent
                    }
                    $scope.original_motor_drive = angular.copy($scope.mtr_drive)
                } else {
                    $scope.mtrd_msg = 'No data found for this door.'
                    $scope.no_data_flag = 1
                }

                $scope.drawShapeOnPrimary = function() {
                    if (!$scope.sliders) {
                        X1 = timeofflight.Primary_DoorSetting_ShaftPosition1_X
                        Y1 = timeofflight.Primary_DoorSetting_ShaftPosition1_Y
                        X2 = timeofflight.Primary_DoorSetting_ShaftPosition2_X
                        Y2 = timeofflight.Primary_DoorSetting_ShaftPosition2_Y
                    } else {
                        X1 = parseInt($scope.sliders.x_shaft_1x)
                        Y1 = parseInt($scope.sliders.x_shaft_11x)
                        X2 = parseInt($scope.sliders.x_shaft_2x)
                        Y2 = parseInt($scope.sliders.x_shaft_22x)
                    }
                    // Draw circle on images
                    var canvasElement = document.getElementById('stereovisionCanvas')
                    var context = canvasElement.getContext('2d')

                    var img = document.getElementById('stereovisionImg')
                    context.drawImage(img, 0, 0, 176, 132)

                    // draw triangle
                    context.beginPath()
                    context.moveTo(X1, Y1)
                    context.lineTo(X1 + 5, Y1 + 10)
                    context.lineTo(X1 - 5, Y1 + 10)
                    context.fillStyle = '#FF0000'
                    context.fill()

                    context.beginPath()
                    context.moveTo(X2, Y2)
                    context.lineTo(X2 + 5, Y2 + 10)
                    context.lineTo(X2 - 5, Y2 + 10)
                    context.fillStyle = '#008000'
                    context.fill()

                    // Draw circle
                    r = Math.sqrt((X1 - X2) * (X1 - X2) + (Y1 - Y2) * (Y1 - Y2))
                    context.beginPath()
                    context.arc((X1 + X2) / 2, (Y1 + Y2) / 2, r / 2, 0, Math.PI * 2, true)

                    context.lineWidth = 1.5
                    context.strokeStyle = 'yellow'
                    context.stroke()

                    // Draw cross
                    Y1 = (Y1 + Y2) / 2
                    context.moveTo(X1 - 2, Y1 - 5)
                    context.lineTo(X1 + 8, Y1 + 5)
                    context.stroke()

                    context.moveTo(X1 + 8, Y1 - 5)
                    context.lineTo(X1 - 2, Y1 + 5)
                    context.stroke()
                }

                $scope.drawShapeOnSecondary = function() {
                    if (!$scope.sliders_sec) {
                        X1 = timeofflight.Secondary_DoorSetting_ShaftPosition1_X
                        Y1 = timeofflight.Secondary_DoorSetting_ShaftPosition1_Y
                        X2 = timeofflight.Secondary_DoorSetting_ShaftPosition2_X
                        Y2 = timeofflight.Secondary_DoorSetting_ShaftPosition2_Y
                    } else {
                        X1 = parseInt($scope.sliders_sec.x_shaft_1x_sec)
                        Y1 = parseInt($scope.sliders_sec.x_shaft_2x_sec)
                        X2 = parseInt($scope.sliders_sec.x_shaft_11x_sec)
                        Y2 = parseInt($scope.sliders_sec.x_shaft_22x_sec)
                    }

                    // Draw circle on image
                    var canvasElement = document.getElementById('stereovisionCanvas')
                    var context = canvasElement.getContext('2d')
                    var img = document.getElementById('stereovisionImg')

                    context.drawImage(img, 0, 0, 176, 132)

                    // draw triangle
                    context.beginPath()
                    context.moveTo(X1, Y1)
                    context.lineTo(X1 + 5, Y1 + 10)
                    context.lineTo(X1 - 5, Y1 + 10)
                    context.fillStyle = '#FF0000'
                    context.fill()

                    context.beginPath()
                    context.moveTo(X2, Y2)
                    context.lineTo(X2 + 5, Y2 + 10)
                    context.lineTo(X2 - 5, Y2 + 10)
                    context.fillStyle = '#008000'
                    context.fill()

                    // Draw circle
                    r = Math.sqrt((X1 - X2) * (X1 - X2) + (Y1 - Y2) * (Y1 - Y2))
                    context.beginPath()
                    context.arc((X1 + X2) / 2, (Y1 + Y2) / 2, r / 2, 0, Math.PI * 2, true)
                    context.lineWidth = 1.5
                    context.strokeStyle = 'yellow'
                    context.stroke()

                    // Draw cross
                    Y2 = (Y1 + Y2) / 2
                    context.moveTo(X2 - 2, Y2 - 5)
                    context.lineTo(X2 + 8, Y2 + 5)
                    context.stroke()

                    context.moveTo(X2 + 8, Y2 - 5)
                    context.lineTo(X2 - 2, Y2 + 5)
                    context.stroke()
                }

                $scope.getPrimaryData = function() {
                    $scope.activeMenu = 'primary'
                    $scope.active = 'true'
                    $scope.checkModel.primary = true
                    $scope.checkModel.secondary = false
                    $scope.tof_message_sec = ''
                    $timeout(function() {
                        $scope.stereovisionImgPath = 'http://' + $scope.doordetail.ip_number + '/image_primary.png'
                    }, CONFIG.STEREOVISION_CAPTURE_DELAY)
                    if (timeofflight != undefined) {
                        $scope.flag = 0

                        if (!$scope.sliders) {
                            $scope.sliders = {
                                capture_counts: timeofflight.Primary_Log_OutputCounts,
                                height_canopy: timeofflight.Primary_DoorSetting_HeightUnderCanopy,
                                door_diameter: timeofflight.Primary_DoorSetting_Diameter,
                                capture_image: timeofflight.Primary_Log_Capture,
                                sensor_direction: timeofflight.Primary_DoorSetting_SensorDirection,
                                primary_door_setting_open: timeofflight.Primary_DoorSetting_DoorOpen,
                                primary_door_setting_close: timeofflight.Primary_DoorSetting_DoorClose,
                                wheel_chair: timeofflight.Primary_DoorSetting_WheelChair,
                                verification_device: timeofflight.Primary_DoorSetting_VerificationDevice,
                                lowObjValue: timeofflight.Primary_Sensitivity_LowObject,
                                blindingValue: timeofflight.Primary_Sensitivity_SensorBlinding,
                                onePersonValue: timeofflight.Primary_Sensitivity_OnePerson,
                                morePersonValue: timeofflight.Primary_Sensitivity_MorePerson,
                                volumeValue: timeofflight.Primary_Sensitivity_Volume,
                                momentValue: timeofflight.Primary_Sensitivity_Moment,
                                x_shaft_1x: timeofflight.Primary_DoorSetting_ShaftPosition1_X,
                                x_shaft_2x: timeofflight.Primary_DoorSetting_ShaftPosition2_X,
                                x_shaft_11x: timeofflight.Primary_DoorSetting_ShaftPosition1_Y,
                                x_shaft_22x: timeofflight.Primary_DoorSetting_ShaftPosition2_Y,
                                min: 1,
                                max: 9
                            }
                            $scope.original_time_of_flight_prim = angular.copy($scope.sliders)
                        }
                    } else {
                        $scope.tof_msg = 'No data found for this door.r'
                        $scope.flag = 1
                    }
                }

                $scope.getSecondaryData = function() {
                    $scope.activeMenu = 'secondary'
                    $scope.checkModel.primary = false
                    $scope.checkModel.secondary = true
                    $scope.tof_message = ''
                    // Draw circle on image
                    X1 = timeofflight.Secondary_DoorSetting_ShaftPosition1_X
                    Y1 = timeofflight.Secondary_DoorSetting_ShaftPosition1_Y

                    X2 = timeofflight.Secondary_DoorSetting_ShaftPosition2_X
                    Y2 = timeofflight.Secondary_DoorSetting_ShaftPosition2_Y

                    $timeout(function() {
                        $scope.stereovisionImgPath = 'http://' + $scope.doordetail.ip_number + '/image_secondary.png'
                    }, CONFIG.STEREOVISION_CAPTURE_DELAY)

                    if (timeofflight != undefined) {
                        $scope.flag = 0

                        if (!$scope.sliders_sec) {
                            $scope.sliders_sec = {
                                capture_counts_sec: timeofflight.Secondary_Log_OutputCounts,
                                height_canopy_sec: timeofflight.Secondary_DoorSetting_HeightUnderCanopy,
                                door_diameter_sec: timeofflight.Secondary_DoorSetting_Diameter,
                                capture_image_sec: timeofflight.Secondary_Log_Capture,
                                sensor_direction_sec: timeofflight.Secondary_DoorSetting_SensorDirection,
                                secondary_door_setting_open_sec: timeofflight.Secondary_DoorSetting_DoorOpen,
                                secondary_door_setting_close_sec: timeofflight.Secondary_DoorSetting_DoorClose,
                                wheel_chair_sec: timeofflight.Secondary_DoorSetting_WheelChair,
                                verification_device_sec: timeofflight.Secondary_DoorSetting_VerificationDevice,
                                lowObjValue_sec: timeofflight.Secondary_Sensitivity_LowObject,
                                blindingValue_sec: timeofflight.Secondary_Sensitivity_SensorBlinding,
                                onePersonValue_sec: timeofflight.Secondary_Sensitivity_OnePerson,
                                morePersonValue_sec: timeofflight.Secondary_Sensitivity_MorePerson,
                                volumeValue_sec: timeofflight.Secondary_Sensitivity_Volume,
                                momentValue_sec: timeofflight.Secondary_Sensitivity_Moment,
                                x_shaft_1x_sec: timeofflight.Secondary_DoorSetting_ShaftPosition1_X,
                                x_shaft_11x_sec: timeofflight.Secondary_DoorSetting_ShaftPosition2_X,
                                x_shaft_2x_sec: timeofflight.Secondary_DoorSetting_ShaftPosition1_Y,
                                x_shaft_22x_sec: timeofflight.Secondary_DoorSetting_ShaftPosition2_Y,
                                min: 1,
                                max: 9
                            }
                            $scope.original_time_of_flight_sec = angular.copy($scope.sliders_sec)
                        }
                    } else {
                        $scope.tof_msg = 'No data found for this door.'
                        $scope.flag = 1
                    }
                }

                // Recapture image
                $scope.recaptureImage = function() {
                    $scope.stereovisionCanvasSection = false
                    $scope.loadingImg = true
                    if ($scope.checkModel.primary == true) {
                        // for primary image
                        jsonCommand = {
                            'GET_IMAGE': 0
                        }
                    } else {
                        // for secondary image
                        jsonCommand = {
                            'GET_IMAGE': 1
                        }
                    }
                    EditDoorService.updateStereovisionImage(doorId, jsonCommand).then(function(data) {
                            if (data.success == true) {} else {
                                alert('Invalid data.')
                            }
                        },
                        function(error) {
                            console.log('Error Data', error)
                        })

                    $timeout(function() {
                        $scope.loadingImg = false
                        $scope.stereovisionCanvasSection = true
                        window.location.reload(true)
                        if ($scope.checkModel.primary == true) {
                            // for primary image
                            $scope.stereovisionImgPath = 'http://' + $scope.doordetail.ip_number + '/image_primary.png'
                        } else {
                            // for secondary image
                            $scope.stereovisionImgPath = 'http://' + $scope.doordetail.ip_number + '/image_secondary.png'
                        }
                    }, CONFIG.STEREOVISION_RECAPTURE_DELAY)
                }

                $scope.getPrimaryData()
                $scope.getChangeLog()
                LocationsService.getLocations().then(function(results) {
                    if (results.companies != null) {
                        $scope.companies = results.companies
                        $scope.repopulateDropDowns(-1)
                    }
                })
            },
            function(errorResult) {
                // TODO: Manage error page
                console.log('error', errorResult)
            })

        $scope.repopulateDropDowns = function(state) {
            if ($scope.companies != null) {
                if (state == -1) {
                    if ($scope.doordetail.companyId != null) {
                        for (var i = 0; i < $scope.companies.length; i++) {
                            var tempCountries = $scope.companies[i].children
                            for (var j = 0; j < tempCountries.length; j++) {
                                if ($scope.companies[i].companyId == $scope.doordetail.companyId) {
                                    $scope.campuses = tempCountries[j].children
                                    break
                                }
                            }
                        }
                    }

                    for (var i = 0; i < $scope.campuses.length; i++) {
                        if ($scope.campuses[i].campusName == null) {
                            $scope.campuses.splice(i, 1)
                        }
                    }

                    if ($scope.doordetail.campusId != null) {
                        for (var i = 0; i < $scope.campuses.length; i++) {
                            if ($scope.campuses[i].campusId == $scope.doordetail.campusId) {
                                $scope.campusId = $scope.campuses[i].campusId
                                $scope.buildings = $scope.campuses[i].children
                                break
                            }
                        }
                    }
                    if ($scope.doordetail.buildingId != null) {
                        for (var i = 0; i < $scope.buildings.length; i++) {
                            if ($scope.buildings[i].buildingId == $scope.doordetail.buildingId) {
                                $scope.buildingId = $scope.buildings[i].buildingId
                                $scope.entrances = $scope.buildings[i].children
                                break
                            }
                        }
                    }

                    if ($scope.doordetail.entranceId != null) {
                        for (var i = 0; i < $scope.entrances.length; i++) {
                            if ($scope.entrances[i].entranceId == $scope.doordetail.entranceId) {
                                $scope.entranceId = $scope.entrances[i].entranceId
                                $scope.subEntrances = $scope.entrances[i].children
                                break
                            }
                        }
                    }
                    if ($scope.doordetail.subentranceId != null) {
                        for (var i = 0; i < $scope.subEntrances.length; i++) {
                            if ($scope.subEntrances[i].subentranceId == $scope.doordetail.subentranceId) {
                                $scope.subEntranceId = $scope.subEntrances[i].subentranceId
                                break
                            }
                        }
                    }
                }

                if (state == 0) {
                    for (var i = 0; i < $scope.companies.length; i++) {
                        var tempCountries = $scope.companies[i].children
                        for (var j = 0; j < tempCountries.length; j++) {
                            if ($scope.companies[i].companyId == $scope.doordetail.companyId) {
                                $scope.campuses = tempCountries[j].children
                                break
                            }
                        }
                    }
                }
                if (state == 1) {
                    if ($scope.campusId != null) {
                        for (var i = 0; i < $scope.campuses.length; i++) {
                            if ($scope.campuses[i].campusId == $scope.campusId) {
                                $scope.buildings = $scope.campuses[i].children
                                break
                            }
                        }
                    }
                }
                if (state == 2) {
                    if ($scope.buildingId != null) {
                        for (var i = 0; i < $scope.buildings.length; i++) {
                            if ($scope.buildings[i].buildingId == $scope.buildingId) {
                                $scope.entrances = $scope.buildings[i].children
                                break
                            }
                        }
                    }
                }
                if (state == 3) {
                    if ($scope.entranceId != null) {
                        for (var i = 0; i < $scope.entrances.length; i++) {
                            if ($scope.entrances[i].entranceId == $scope.entranceId) {
                                $scope.subEntrances = $scope.entrances[i].children
                                break
                            }
                        }
                    }
                }
            }
        }

        $scope.resetDropDowns = function(state) {
            if (state == 3) {
                $scope.subEntrances = []
                $scope.subEntranceId = null
            } else if (state == 2) {
                $scope.entrances = []
                $scope.entranceId = null
                $scope.subEntrances = []
                $scope.subEntranceId = null
            } else if (state == 1) {
                $scope.buildings = []
                $scope.buildingId = null
                $scope.entrances = []
                $scope.entranceId = null
                $scope.subEntrances = []
                $scope.subEntranceId = null
            } else if (state == 0) {
                $scope.campuses = []
                $scope.campusId = null
                $scope.buildings = []
                $scope.buildingId = null
                $scope.entrances = []
                $scope.entranceId = null
                $scope.subEntrances = []
                $scope.subEntranceId = null
            }
        }
        $scope.campusSelected = function(campus) {
            $scope.buildings = []
            $scope.buildingId = null
            $scope.entrances = []
            $scope.entranceId = null
            $scope.subEntrances = []
            $scope.subEntranceId = null
            for (var i = 0; i < $scope.campuses.length; i++) {
                if ($scope.campuses[i].campusId == campus) {
                    $scope.campusId = campus
                    $scope.buildings = $scope.campuses[i].children

                    break
                }
            }
        }
        $scope.buildingSelected = function(building) {
            $scope.entrances = []
            $scope.entranceId = null
            $scope.subEntrances = []
            $scope.subEntranceId = null
            for (var i = 0; i < $scope.buildings.length; i++) {
                if ($scope.buildings[i].buildingId == building) {
                    $scope.buildingId = building
                    $scope.entrances = $scope.buildings[i].children
                    break
                }
            }
        }
        $scope.entranceSelected = function(entrance) {
            $scope.subEntrances = []
            $scope.subEntranceId = null
            for (var i = 0; i < $scope.entrances.length; i++) {
                if ($scope.entrances[i].entranceId == entrance) {
                    $scope.entranceId = entrance
                    $scope.subEntrances = $scope.entrances[i].children
                    break
                }
            }
        }
        $scope.subentranceSelected = function(subentrance) {
            $scope.subEntranceId = subentrance
        }
    })
})
