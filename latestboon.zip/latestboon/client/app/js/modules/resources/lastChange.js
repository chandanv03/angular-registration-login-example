define([
    'angular',
    'ngResource'
], function(angular) {
    'use strict'

    return angular.module('app.resources.lastChange', ['ngResource'])
        .service('LastChange', function($resource, CONFIG, TokenService) {
            return {
                getLastChange: function(token) {

                    return $resource(CONFIG.url + 'doors/lastchange', {}, {
                        get: {
                            method: 'GET' 
                        }
                    })

                }
            }
        })
})
